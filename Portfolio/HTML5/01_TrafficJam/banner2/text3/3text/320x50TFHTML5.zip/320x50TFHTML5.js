(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"320x50TFHTML5_atlas_", frames: [[0,0,401,56]]}
];


// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.logo = function() {
	this.initialize(ss["320x50TFHTML5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A575").s().p("AgYBvIgDgBIAAgDIALgcQAFgRADgTQAEgUAAgXQAAgWgEgUQgDgTgFgRQgFgQgGgMIAAgDIADgBIAXAAIABABIACABQALATAIAbQAHAcAAAiQAAAjgHAcQgIAbgLATIgCABIgBABg");
	this.shape.setTransform(71.8375,46.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A575").s().p("AgPBbIgCgBIgBgCIAAhpIAAgBIgBgBIgJAAIgBgBIgBgCIAAgPIABgCIABgBIAJAAIABAAIAAgBIAAgHQAAgXALgKQAKgKAXABIACAAIADABIAAACIAAASIgBACIgCABIgCAAQgHAAgEAFQgEAFAAAJIAAAGIAAABIACAAIAPAAIADABIABACIAAAPIgBACIgDABIgPAAIgCABIAAABIAABpIgBACIgCABg");
	this.shape_1.setTransform(63.6,46.4238);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A575").s().p("AgLBbIgCgBIgBgCIAAiuIABgDIACgBIAXAAIACABIABADIAACuIgBACIgCABg");
	this.shape_2.setTransform(57.3,46.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A575").s().p("AghA5QgMgLAAgUIAAgzQAAgTAMgMQAMgLAVAAQAWAAALALQAMAMABATIAAAhIgBACIgDABIg4AAIAAABIgBABIAAALQAAAIAEAGQAFAFAGAAQAGAAAEgEQAEgEABgGIACgCIACgBIAXACIADABIAAACQgCASgMAKQgLAJgUAAQgVAAgMgLgAgLgkQgEAFAAAIIAAAMIABABIAAAAIAcAAIABAAIAAgBIAAgMQAAgIgEgFQgEgFgHAAQgGAAgFAFg");
	this.shape_3.setTransform(49.25,48.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A575").s().p("AggA6QgMgKAAgRIAAgCIABgCIACgBIAWAAIADABIABABIAAADQAAAGAEAEQAFAEAGAAQAHAAAEgEQAEgDAAgHQgBgFgDgDQgEgEgFgDIgLgEIgPgIQgIgEgFgHQgFgIgBgNQABgTALgKQALgKAUAAQATABAMAKQAMALAAASIgBACIgCABIgWAAIgCgBIgBgBIAAgDQAAgGgEgEQgEgEgHAAQgGAAgEAEQgEAFAAAFQAAAGADADIAJAGIAKAFIAQAHQAJAEAGAIQAGAIAAAMQAAASgMAKQgMAKgVAAQgUAAgMgKg");
	this.shape_4.setTransform(38.675,48.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A575").s().p("AgdBDIgCgBIgBgCIAAh9IABgDIACgBIAYAAIACABIABADIAAAMIAAABIABgBQACgHAGgFQAFgFAJAAIAGABIAFACIABABIAAADIgEAXQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAIgDAAIgGgBIgGABQgHACgFAGQgDAHAAAKIAABJIgBACIgCABg");
	this.shape_5.setTransform(29.825,48.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A575").s().p("AgbA/QgIgEgFgIQgEgJgBgNIAAhcIABgCIADgBIAXAAIACABIACACIAABVQAAAKADAFQAEAEAHAAQAHAAAEgFQAEgFAAgKIAAhUIABgCIACgBIAYAAIACABIABACIAAB9IgBACIgCABIgYAAIgCgBIgBgCIAAgFIAAgBIgBAAQgFAGgGADQgFACgIAAQgJAAgIgEg");
	this.shape_6.setTransform(19.6,49.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A575").s().p("AghA5QgMgLAAgUIAAgzQAAgTAMgMQAMgLAVAAQAWAAAMALQAMAMAAATIAAAzQAAAUgMALQgMALgWAAQgVAAgMgLgAgLgkQgEAFAAAIIAAAvQAAAIAEAFQAEAFAHAAQAHAAAEgFQAFgFAAgIIAAgvQAAgIgFgFQgEgFgHAAQgHAAgEAFg");
	this.shape_7.setTransform(8.425,48.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A575").s().p("AgLBbIgCgBIgBgDIAAhGIAAgBIAAgBIgkhlQgBAAAAAAQAAgBAAAAQAAgBABAAQAAAAAAAAIACgBIAaAAIABABIACACIATBCIAAAAIABAAIAUhCIABgCIACgBIAZAAIACABQAAAAAAAAQABAAAAABQAAAAAAABQAAAAgBAAIgkBlIAAABIAAABIAABGIgBADIgCABg");
	this.shape_8.setTransform(-3.15,46.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("AghA5QgMgLAAgUIAAgzQAAgTAMgMQAMgLAVAAQAWAAAMALQAMAMAAATIAAAhIgBACIgCABIg5AAIgBABIAAABIAAALQAAAIAFAGQAEAFAGAAQAGAAAEgEQAEgEACgGIAAgCIADgBIAXACIACABIABACQgCASgLAKQgMAJgUAAQgVAAgMgLgAgKgkQgFAFAAAIIAAAMIAAABIABAAIAdAAIABAAIAAgBIAAgMQAAgIgFgFQgEgFgHAAQgGAAgEAFg");
	this.shape_9.setTransform(-19.65,48.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A575").s().p("AghA5QgMgLAAgUIAAgzQAAgTAMgMQAMgLAVAAQAOAAALAFQAKAFAFAJQAFAJABAMIAAADIgBADIgCAAIgYABIgCAAIgBgCIAAgDQAAgHgFgFQgEgEgHAAQgHAAgDAFQgFAFAAAIIAAAvQAAAIAFAFQADAFAHAAQAHAAAEgEQAFgFAAgHIAAgCIABgDIACgBIAYABIACABIABACIAAAEQAAASgMALQgMALgWAAQgVAAgMgLg");
	this.shape_10.setTransform(-30.55,48.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A575").s().p("AgZBCQgJgDgGgJQgGgIgBgRQABgQAGgKQAHgIALgEQAMgEANAAIANAAIABAAIAAgBIAAgHQAAgJgEgGQgFgFgHAAQgEAAgEADQgEAEAAAGIgBACIgDABIgZAAIgCgBIgBgCQACgSAMgLQANgKASAAQANAAALAFQAKAFAGAKQAFAKABANIAABXIgBACIgDABIgXAAIgDgBIgBgCIAAgEIAAgBIgBAAQgFAFgGADQgGACgIAAIgCAAQgHAAgHgCgAgKANQgGAFAAAJQAAAJAFAEQAEADAGAAQAHAAAFgEQAGgFAAgJIAAgPIAAgBIgBAAIgNAAQgIAAgFAEg");
	this.shape_11.setTransform(-41.875,48.9286);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A575").s().p("AgdBDIgCgBIgBgCIAAh9IABgDIACgBIAYAAIACABIABADIAAAMIAAABIABgBQACgHAGgFQAFgFAJAAIAGABIAFACIABABIAAADIgEAXQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAIgDAAIgGgBIgGABQgHACgFAGQgDAHAAAKIAABJIgBACIgCABg");
	this.shape_12.setTransform(-50.875,48.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A575").s().p("AgtBbIgCgBIgBgCIAAiuIABgDIACgBIApAAQAXAAAOANQAOAMAAAYQAAAOgFAJQgEAKgKAFIAAABIAAABQAKAFAFALQAGAKAAAQQAAAQgGALQgGALgMAGQgLAGgOAAgAgSAJIAAAAIAAA2IAAABIABABIAPAAQAJAAAGgHQAGgIAAgNQAAgOgGgHQgGgIgJAAIgPAAIgBABgAgSg/IAAABIAAAwIAAABIABAAIANAAQAKAAAGgGQAGgHAAgMQAAgMgGgHQgGgHgKAAIgNAAIgBABg");
	this.shape_13.setTransform(-61.025,46.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A575").s().p("AACBvIgCgBIgBgBQgLgTgIgbQgHgcAAgjQAAgiAHgcQAIgbALgTIABgBIACgBIAXAAIADABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQgGAMgFAQQgFARgDATQgDAUgBAWQABAXADAUQADATAFARQAFAQAGAMQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAIgDABg");
	this.shape_14.setTransform(-71.775,46.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-143.9,27.1,288,38.6), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgmBPIgCgBIAAgCIAAiXIAAgDIACAAIAbAAIABAAIABADIAAB+IAAABIABAAIAvAAIACABIABABIAAAWIgBACIgCABg");
	this.shape.setTransform(330.1,-125.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AggBDQgMgMAAgWIAAhtIABgDIACAAIAaAAIACAAIABADIAABwQAAAIADAEQAEAEAFAAQAGAAADgEQAEgEAAgIIAAhwIABgDIACAAIAaAAIACAAIABADIAABtQAAAOgGALQgFAKgKAGQgLAGgNAAQgUAAgMgNg");
	this.shape_1.setTransform(319.525,-124.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgmBPIgCgBIAAgCIAAiXIAAgDIACAAIBNAAIACAAIAAADIAAAVIAAACIgCABIguAAIgBAAIAAABIAAAkIAAABIABAAIAaAAIACABIAAACIAAAUIAAACIgCACIgaAAIgBAAIAAABIAAA9IgBACIgCABg");
	this.shape_2.setTransform(309.725,-125.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAPBPIgCgBIgBgCIAAg9IAAgBIgBAAIgVAAIgBAAIAAABIAAA9IgBACIgCABIgbAAIgCgBIAAgCIAAiXIAAgDIACAAIAbAAIACAAIABADIAAA9IAAABIABAAIAVAAIABAAIAAgBIAAg9IABgDIACAAIAbAAIACAAIAAADIAACXIAAACIgCABg");
	this.shape_3.setTransform(299.175,-125.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgNBPIgCgBIgBgCIAAh+IAAgBIgBAAIgbAAIgCgBIAAgCIAAgVIAAgDIACAAIBYAAIACAAIABADIAAAVIgBACIgCABIgbAAIgBAAIAAABIAAB+IgBACIgDABg");
	this.shape_4.setTransform(288.5,-125.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMBPIgCgBIgBgCIAAiXIABgDIACAAIAZAAIACAAIABADIAACXIgBACIgCABg");
	this.shape_5.setTransform(280.6,-125.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AAWBPIgCAAIgBgCIgDgWIgBgBIgBgBIgbAAIgBABIAAAAIgFAXIAAACIgCAAIgbAAIgCAAIAAgDIAhiXIABgDIACAAIAeAAIACAAIAAADIAhCXIAAADIgCAAgAAAgdIgJA5IAAABIABAAIASAAIABAAIAAgBIgJg5IgBgBIgBABg");
	this.shape_6.setTransform(272.3375,-125.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgmBPIgCgBIAAgCIAAiXIAAgDIACAAIBNAAIACAAIAAADIAAAVIAAACIgCABIguAAIgBAAIAAABIAAAkIAAABIABAAIAaAAIACABIAAACIAAAUIAAACIgCACIgaAAIgBAAIAAABIAAA9IgBACIgCABg");
	this.shape_7.setTransform(262.325,-125.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AARBPIgCAAIgBgCIgdhUIAAgBIgBABIAABTIAAACIgCABIgaAAIgCgBIgBgCIAAiXIABgDIACAAIAcAAIACAAIABACIAcBUQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABAAIAAhTIAAgDIACAAIAaAAIACAAIABADIAACXIgBACIgCABg");
	this.shape_8.setTransform(251.425,-125.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AggBDQgMgMAAgWIAAhtIABgDIACAAIAaAAIACAAIABADIAABwQAAAIADAEQAEAEAFAAQAGAAADgEQAEgEAAgIIAAhwIABgDIACAAIAaAAIACAAIABADIAABtQAAAOgGALQgFAKgKAGQgLAGgNAAQgUAAgMgNg");
	this.shape_9.setTransform(240.175,-124.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgWBLQgKgEgFgKQgGgJAAgNIAAgGIABgDIACgBIAaAAIACABIABADIAAAFQAAAHADAFQAEADAEAAQAGAAADgDQAEgFAAgGQAAgFgCgEIgIgHIgLgKIgRgNQgIgGgFgKQgFgJAAgNQAAgNAFgJQAGgJAJgGQAKgFANAAQATAAAMAMQAMALAAAVIAAAEIAAADIgCABIgaAAIgCgBIgBgDIAAgFQAAgIgEgDQgDgFgFAAQgFABgEADQgDAEAAAHQAAAFACAEQACADAFAFIALAKIAUAOQAIAIAEAHQAEAIAAALQAAAOgFAKQgGAKgKAEQgKAGgNAAQgMAAgKgGg");
	this.shape_10.setTransform(225.225,-125.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgMBPIgDgBIAAgCIAAiXIAAgDIADAAIAZAAIACAAIABADIAACXIgBACIgCABg");
	this.shape_11.setTransform(217.5,-125.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgmBPIgCgBIAAgCIAAiYIAAgBIACgBIBNAAIACABIABABIAAAXIgBACIgCAAIgvAAIgBABIAAAAIAAAkIAAABIABAAIAaAAIADABIAAACIAAAVIAAABIgDABIgaAAIgBABIAAAAIAAAkIAAABIABAAIAvAAIACABIABADIAAAVIgBACIgCABg");
	this.shape_12.setTransform(374.2,-148.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AARBPIgCgBIgBgBIgdhUIAAAAIgBAAIAABTIAAACIgCABIgaAAIgCgBIgBgCIAAiYIABgBIACgBIAcAAIACABIABABIAcBTQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIAAhTIAAgBIACgBIAaAAIACABIABABIAACYIgBACIgCABg");
	this.shape_13.setTransform(363.275,-148.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AggBEQgMgLgBgVIAAhHQABgVAMgMQAMgMAUAAQAOAAAKAFQAKAGAGAKQAGAKAAAOIAABHQAAAOgGAKQgGAKgKAFQgKAGgOAAQgUgBgMgMgAgJgxQgEAFAAAHIAABLQAAAGAEAFQAEAFAFAAQAHAAADgFQAEgFAAgGIAAhLQAAgHgEgFQgDgDgHAAQgFAAgEADg");
	this.shape_14.setTransform(352.075,-148.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgmBPIgCgBIAAgCIAAiYIAAgBIACgBIBNAAIABABIABABIAAAXIgBACIgBAAIguAAIgCABIAAAAIAAAkIAAABIACAAIAaAAIACABIAAACIAAAVIAAABIgCABIgaAAIgCABIAAAAIAAAkIAAABIACAAIAuAAIABABIABADIAAAVIgBACIgBABg");
	this.shape_15.setTransform(342,-148.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAXBPIgCgBIgBgCIAAhhIAAgBIgBABIgSAiIAAACIgBAAIAAAAIgBgCIgRgiIgBgBIAAABIAABhIgBACIgCABIgbAAIgBgBIgBgCIAAiYIABgBIABgBIAaAAIACAAIACACIATAqQAAAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIATgqIACgCIABAAIAbAAIACABIAAABIAACYIAAACIgCABg");
	this.shape_16.setTransform(330.725,-148.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AggBEQgMgLgBgVIAAhHQABgVAMgMQAMgMAUAAQAOAAAKAFQAKAGAGAKQAGAKAAAOIAABHQAAAOgGAKQgGAKgKAFQgKAGgOAAQgUgBgMgMgAgJgxQgEAFAAAHIAABLQAAAGAEAFQAEAFAFAAQAHAAADgFQAEgFAAgGIAAhLQAAgHgEgFQgDgDgHAAQgFAAgEADg");
	this.shape_17.setTransform(319.175,-148.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgWBLQgKgEgFgKQgGgJAAgNIAAgHIABgCIACAAIAaAAIACAAIABACIAAAGQAAAHADAEQAEAEAEABQAGgBADgEQAEgDAAgHQAAgFgCgEIgIgIIgLgJIgRgNQgIgGgFgJQgFgKAAgNQAAgMAFgKQAGgJAJgGQAKgFANAAQATAAAMAMQAMAMAAATIAAAFIAAACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgEgEQgDgDgFAAQgFgBgEAEQgDAEAAAHQAAAFACADQACAFAFADIALAKIAUAPQAIAHAEAJQAEAHAAAMQAAANgFAJQgGALgKAEQgKAGgNAAQgMAAgKgGg");
	this.shape_18.setTransform(308.825,-148.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgWBLQgKgEgFgKQgGgJAAgNIAAgHIABgCIACAAIAaAAIACAAIABACIAAAGQAAAHADAEQAEAEAEABQAGgBADgEQAEgDAAgHQAAgFgCgEIgIgIIgLgJIgRgNQgIgGgFgJQgFgKAAgNQAAgMAFgKQAGgJAJgGQAKgFANAAQATAAAMAMQAMAMAAATIAAAFIAAACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgEgEQgDgDgFAAQgFgBgEAEQgDAEAAAHQAAAFACADQACAFAFADIALAKIAUAPQAIAHAEAJQAEAHAAAMQAAANgFAJQgGALgKAEQgKAGgNAAQgMAAgKgGg");
	this.shape_19.setTransform(294.175,-148.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AARBPIgCgBIgBgBIgdhUIAAAAIgBAAIAABTIAAACIgCABIgaAAIgCgBIgBgCIAAiYIABgBIACgBIAcAAIACABIABABIAcBTQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIAAhTIAAgBIACgBIAaAAIACABIABABIAACYIgBACIgCABg");
	this.shape_20.setTransform(283.275,-148.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AggBFQgMgLAAgUIAAhMQAAgTAMgLQAMgMAUAAQANAAALAFQAKAGAFAJQAGAKAAANIAAAIIgBADIgCAAIgaAAIgCAAIgBgDIAAgJQAAgHgDgEQgEgDgGAAQgFAAgEADQgDAEAAAHIAABNQAAAGADAEQAEAEAFABQAGgBAEgEQADgEAAgGIAAgTIAAAAIgBgBIgKAAIgCAAIAAgDIAAgTIAAgCIACAAIAoAAIACAAIABACIAAApQAAANgGAKQgFAKgKAEQgLAGgNAAQgUgBgMgLg");
	this.shape_21.setTransform(272.225,-148.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNBPIgCgBIAAgCIAAiYIAAgBIACgBIAaAAIACABIABABIAACYIgBACIgCABg");
	this.shape_22.setTransform(264.35,-148.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgWBLQgKgEgFgKQgGgJAAgNIAAgHIABgCIACAAIAaAAIACAAIABACIAAAGQAAAHADAEQAEAEAEABQAGgBADgEQAEgDAAgHQAAgFgCgEIgIgIIgLgJIgRgNQgIgGgFgJQgFgKAAgNQAAgMAFgKQAGgJAJgGQAKgFANAAQATAAAMAMQAMAMAAATIAAAFIAAACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgEgEQgDgDgFAAQgFgBgEAEQgDAEAAAHQAAAFACADQACAFAFADIALAKIAUAPQAIAHAEAJQAEAHAAAMQAAANgFAJQgGALgKAEQgKAGgNAAQgMAAgKgGg");
	this.shape_23.setTransform(256.725,-148.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AARBPIgCAAIgCgCIgQg+IAAgBIgBAAIgIAAIgBAAIAAABIAAA9IgBACIgCABIgaAAIgCgBIgBgCIAAiXIABgCIACgBIAtAAQAMAAAKAGQAJAGAGALQAFAKAAAOQAAAOgFAKQgFAJgJAGIgBABIAAAAIAVBDIAAACIgCABgAgNgyIAAAAIAAAnIAAABIABAAIAKAAQAGAAAFgFQAEgFAAgKQAAgKgEgFQgFgGgGAAIgKAAIgBABg");
	this.shape_24.setTransform(242.0375,-148.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AAWBPIgCgBIgBgCIgDgVIgBgBIgBAAIgbAAIgBAAIAAABIgFAVIAAACIgCABIgbAAIgCgBIAAgCIAhiYIABgBIACgBIAeAAIACABIAAABIAhCYIAAACIgCABgAAAgeIgJA6IAAABIABAAIASAAIABAAIAAgBIgJg6IgBAAIgBAAg");
	this.shape_25.setTransform(230.7875,-148.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgmBPIgCgBIgBgCIAAiYIABgBIACgBIBMAAIACABIACABIAAAXIgCACIgCAAIguAAIAAABIAAAAIAAAkIAAABIAAAAIAbAAIABABIABACIAAAVIgBABIgBABIgbAAIAAABIAAAAIAAAkIAAABIAAAAIAuAAIACABIACADIAAAVIgCACIgCABg");
	this.shape_26.setTransform(220.45,-148.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgmBPIgCgBIgBgCIAAiYIABgBIACgBIAaAAIADABIABABIAAB+IAAABIABAAIAuAAIACABIAAADIAAAVIAAACIgCABg");
	this.shape_27.setTransform(210.8,-148.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgXBLQgKgFgFgKQgGgKAAgNIAAhJQAAgNAGgKQAFgKAKgGQAKgFANAAQAOAAAKAFQAKAGAFAKQAGAKAAANIAAADIgBABIgCABIgaABIgCAAIgBgCIAAgGQAAgHgDgEQgEgDgGAAQgFAAgEADQgDAEAAAHIAABNQAAAHADADQAEAEAFABQAGgBAEgEQADgDAAgHIAAgGIABgCIACgBIAaABIACABIABACIAAADQAAANgGAKQgFAKgKAFQgKAGgOAAQgNAAgKgGg");
	this.shape_28.setTransform(200.425,-148.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgCBPIgCgBIgBgCIAAh7IAAgBIgBgBIgQAEIgCgBIgBgCIAAgTIABgBIABgCIAQgHIACgBIACAAIAaAAIACABIABABIAACYIgBACIgCABg");
	this.shape_29.setTransform(187.275,-148.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AADBJIgCAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIAFgeIAAAAIgBgBIgSAAIgBABIgBAAIgDAeIgBADIgCAAIgbAAIgCAAIgBgDIAFgeIAAAAIgBgBIgKAAIgCAAIgBgCIAAgWIABgCIACgBIAOAAIABAAIAAAAIAEgWIAAgBIgBAAIgKAAIgCgBIgBgCIAAgWIABgCIACgBIANAAIABAAIABgBIAEgdIABgCIACgBIAbAAIABABIAAACIgDAdIAAABIABAAIASAAIAAAAIABgBIAEgdIABgCIACgBIAbAAIABABIABACIgEAdIAAABIABAAIAKAAIABABIABACIAAAWIgBACIgBABIgPAAIgBAAIAAABIgDAWIAAAAIABAAIAKAAIABABIABACIAAAWIgBACIgBAAIgOAAIgBABIgBAAIgEAeIgBADIgCAAgAgIgKIgDAWIABAAIAAAAIASAAIAAAAIABAAIAEgWIgBgBIgBAAIgSAAIgBAAIAAABg");
	this.shape_30.setTransform(177.45,-148.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(107.2,-164.1,335.1,54.5), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-63,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-63,0,401,56), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjA6IAAhzIBGAAIAAAWIgvAAIAAAZIArAAIAAAUIgrAAIAAAaIAwAAIAAAWg");
	this.shape.setTransform(109.8,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUA6IgXgoIgRAAIAAAoIgXAAIAAhzIAtAAQAQAAAMAMQALALAAAPQAAAMgGAHQgGAJgKAGIAZArgAgUgBIAWAAQAHAAAEgGQAFgEAAgIQAAgHgFgEQgEgGgHAAIgWAAg");
	this.shape_1.setTransform(100.525,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpArQgSgSAAgZQAAgYASgSQARgRAYAAQAZAAARARQASASAAAYQAAAZgSASQgRARgZAAQgYAAgRgRgAgagaQgKAKgBAQQABAQAKALQALALAPAAQAQAAAKgLQALgLAAgQQAAgQgLgKQgKgLgQAAQgPAAgLALg");
	this.shape_2.setTransform(88.45,15.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiA6IAAhKIggA0IgCAAIghg0IAABKIgXAAIAAhzIAYAAIAgA3IAhg3IAYAAIAABzg");
	this.shape_3.setTransform(75.125,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAbA6IgwhGIAABGIgXAAIAAhzIARAAIAyBGIAAhGIAWAAIAABzg");
	this.shape_4.setTransform(58.65,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUA6IgXgoIgRAAIAAAoIgXAAIAAhzIAtAAQAQAAAMAMQALALAAAPQAAAMgGAHQgGAJgKAGIAZArgAgUgBIAWAAQAHAAAEgGQAFgEAAgIQAAgHgFgEQgEgGgHAAIgWAAg");
	this.shape_5.setTransform(48.425,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAeA6IgHgVIgtAAIgHAVIgZAAIAphzIAbAAIApBzgAgPAQIAfAAIgQgug");
	this.shape_6.setTransform(37.475,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgjA6IAAhzIBGAAIAAAWIgvAAIAAAZIArAAIAAAUIgrAAIAAAaIAwAAIAAAWg");
	this.shape_7.setTransform(27.9,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghA6IAAhzIAXAAIAABdIAsAAIAAAWg");
	this.shape_8.setTransform(19.675,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("ApSCWQgyAAAAgyIAAjHQAAgyAyAAISlAAQAyAAAAAyIAADHQAAAygyAAg");
	this.shape_9.setTransform(64.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,129,30), null);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0,0,1456,180), null);


// stage content:
(lib._320x50TFHTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_781 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(781).call(this.frame_781).wait(62));

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-130.7,-52.1,-47.8,-19.8).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape.setTransform(270.6,35.075);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-121,-49.6,-38.1,-17.3).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_1.setTransform(270.6,35.075);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-111.3,-47.1,-28.4,-14.8).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_2.setTransform(270.6,35.075);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-101.6,-44.7,-18.7,-12.4).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_3.setTransform(270.6,35.075);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-91.9,-42.2,-9,-9.9).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_4.setTransform(270.6,35.075);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-82.2,-39.7,0.7,-7.4).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_5.setTransform(270.6,35.075);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-72.5,-37.3,10.4,-5).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_6.setTransform(270.6,35.075);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-62.8,-34.8,20.1,-2.5).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_7.setTransform(270.6,35.075);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-53.1,-32.3,29.8,0).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_8.setTransform(270.6,35.075);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-43.4,-29.9,39.5,2.4).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_9.setTransform(270.6,35.075);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-33.8,-27.4,49.1,4.9).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_10.setTransform(270.6,35.075);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-24.1,-25,58.8,7.3).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_11.setTransform(270.6,35.075);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-14.4,-22.5,68.5,9.8).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_12.setTransform(270.6,35.075);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-4.7,-20,78.2,12.3).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_13.setTransform(270.6,35.075);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],5,-17.6,87.9,14.7).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_14.setTransform(270.6,35.075);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],14.7,-15.1,97.6,17.2).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_15.setTransform(270.6,35.075);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],24.4,-12.7,107.3,19.6).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_16.setTransform(270.6,35.075);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],34.1,-10.2,117,22.1).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_17.setTransform(270.6,35.075);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],43.8,-7.7,126.7,24.6).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_18.setTransform(270.6,35.075);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],53.5,-5.3,136.4,27).s().p("AmXBZQgUAAAAgUIAAiIQAAgVAUAAIMvAAQAVAAAAAVIAACIQAAAUgVAAg");
	this.shape_19.setTransform(270.6,35.075);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(199).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(39));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(200).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(38));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(201).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(37));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(202).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(36));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(203).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(35));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(204).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(34));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(205).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(206).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(207).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(208).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(30));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(209).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(29));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(210).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(211).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(27));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(212).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(26));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(213).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(214).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(24));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(215).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(23));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(216).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(22));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(217).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(218).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(20));

	// Слой_3
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(270.55,48.85,0.6858,0.6858,0,0,0,64.6,15.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({y:35.1,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:19.15,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:48.85},0).to({y:35.1,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:19.15,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:48.85},0).to({y:35.1,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:19.15,alpha:0},12,cjs.Ease.get(-1)).wait(1));

	// logo
	this.instance_1 = new lib.logo_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(227.15,19.2,0.2184,0.2307,0,0,0,-63,0.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(171).to({_off:false},0).to({y:6.75,alpha:1},17,cjs.Ease.get(1)).wait(73).to({regY:-0.2,y:-4.2,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(178).to({_off:false,regY:0.2,y:19.2},0).to({y:6.75,alpha:1},17,cjs.Ease.get(1)).wait(73).to({regY:-0.2,y:-4.2,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(178).to({_off:false,regY:0.2,y:19.2},0).to({y:6.75,alpha:1},17,cjs.Ease.get(1)).wait(73).to({regY:-0.2,y:-4.2,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(7));

	// t1.2
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(110.85,22.8,0.8333,0.8333,0,0,0,274.7,-136.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(175).to({_off:false},0).to({regY:-136.5,y:26.1,alpha:1},13).wait(80).to({y:25.1},0).to({regY:-136.7,y:22.8,alpha:0},12).to({_off:true},1).wait(175).to({_off:false},0).to({regY:-136.5,y:26.1,alpha:1},13).wait(80).to({y:25.1},0).to({regY:-136.7,y:22.8,alpha:0},12).to({_off:true},1).wait(175).to({_off:false},0).to({regY:-136.5,y:26.1,alpha:1},13).wait(80).to({y:25.1},0).to({regY:-136.7,y:22.8,alpha:0},12).wait(1));

	// Слой_7
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(204,204,204,0)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_20.setTransform(281.2,25);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(204,204,204,0.035)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_21.setTransform(281.2,25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(204,204,204,0.067)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_22.setTransform(281.2,25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(204,204,204,0.094)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_23.setTransform(281.2,25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(204,204,204,0.125)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_24.setTransform(281.2,25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(204,204,204,0.149)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_25.setTransform(281.2,25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(204,204,204,0.173)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_26.setTransform(281.2,25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(204,204,204,0.196)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_27.setTransform(281.2,25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(204,204,204,0.216)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_28.setTransform(281.2,25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(204,204,204,0.231)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_29.setTransform(281.2,25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(204,204,204,0.247)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_30.setTransform(281.2,25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(204,204,204,0.263)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_31.setTransform(281.2,25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(204,204,204,0.271)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_32.setTransform(281.2,25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(204,204,204,0.282)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_33.setTransform(281.2,25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(204,204,204,0.29)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_34.setTransform(281.2,25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(204,204,204,0.294)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_35.setTransform(281.2,25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(204,204,204,0.298)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_36.setTransform(281.2,25);
	this.shape_36._off = true;

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(204,204,204,0.298)").s().p("ApjD6IAAnzITIAAIAAHzg");
	this.shape_37.setTransform(281.2,25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(204,204,204,0.255)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_38.setTransform(281.2,25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(204,204,204,0.212)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_39.setTransform(281.2,25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(204,204,204,0.169)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_40.setTransform(281.2,25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(204,204,204,0.129)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_41.setTransform(281.2,25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(204,204,204,0.086)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_42.setTransform(281.2,25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(204,204,204,0.043)").s().p("ApjD6IAAnzITHAAIAAHzg");
	this.shape_43.setTransform(281.2,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},171).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},85).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},171).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},85).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},171).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},85).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_20}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(171).to({_off:false},0).to({_off:true},1).wait(108).to({_off:false},0).to({_off:true},1).wait(171).to({_off:false},0).to({_off:true},1).wait(108).to({_off:false},0).to({_off:true},1).wait(171).to({_off:false},0).to({_off:true},1).wait(108).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_36).wait(187).to({_off:false},0).wait(1).to({_off:true},85).wait(195).to({_off:false},0).wait(1).to({_off:true},85).wait(195).to({_off:false},0).wait(1).to({_off:true},85).wait(8));

	// Слой_8
	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_44.setTransform(160.025,25);
	this.shape_44._off = true;

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.086)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_45.setTransform(160.025,25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.165)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_46.setTransform(160.025,25);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.243)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_47.setTransform(160.025,25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.318)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_48.setTransform(160.025,25);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.388)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_49.setTransform(160.025,25);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.455)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_50.setTransform(160.025,25);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.518)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_51.setTransform(160.025,25);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.576)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_52.setTransform(160.025,25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.631)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_53.setTransform(160.025,25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.682)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_54.setTransform(160.025,25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.729)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_55.setTransform(160.025,25);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.773)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_56.setTransform(160.025,25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.812)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_57.setTransform(160.025,25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.847)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_58.setTransform(160.025,25);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.878)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_59.setTransform(160.025,25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.906)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_60.setTransform(160.025,25);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.933)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_61.setTransform(160.025,25);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.953)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_62.setTransform(160.025,25);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.969)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_63.setTransform(160.025,25);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.984)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_64.setTransform(160.025,25);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.992)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_65.setTransform(160.025,25);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_66.setTransform(160.025,25);
	this.shape_66._off = true;

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.98)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_67.setTransform(160.025,25);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.918)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_68.setTransform(160.025,25);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.816)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_69.setTransform(160.025,25);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.675)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_70.setTransform(160.025,25);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.49)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_71.setTransform(160.025,25);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.267)").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_72.setTransform(160.025,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_44}]},148).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_66}]},102).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_44}]},1).to({state:[]},1).to({state:[{t:this.shape_44}]},148).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_66}]},102).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_44}]},1).to({state:[]},1).to({state:[{t:this.shape_44}]},148).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_66}]},102).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_44}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_44).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_66).wait(170).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(103).to({_off:true},1).wait(7));

	// t1.1
	this.instance_3 = new lib.bg2_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(41.15,69.45,0.2778,0.2778,0,0,0,300.1,250.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(97).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},64).wait(206).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},64).wait(206).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},64).wait(109));

	// t1.2
	this.instance_4 = new lib.t11();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-92.9,149.3,0.9206,0.9206);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({y:152.25,alpha:1},13).wait(35).to({regX:-0.1,regY:0.1,x:-93,y:137.9,alpha:0},7,cjs.Ease.get(-1)).to({_off:true},1).wait(225).to({_off:false,regX:0,regY:0,x:-92.9,y:149.3},0).to({y:152.25,alpha:1},13).wait(35).to({regX:-0.1,regY:0.1,x:-93,y:137.9,alpha:0},7,cjs.Ease.get(-1)).to({_off:true},1).wait(225).to({_off:false,regX:0,regY:0,x:-92.9,y:149.3},0).to({y:152.25,alpha:1},13).wait(35).to({regX:-0.1,regY:0.1,x:-93,y:137.9,alpha:0},7,cjs.Ease.get(-1)).to({_off:true},1).wait(225));

	// bg-2
	this.instance_5 = new lib.t12();
	this.instance_5.parent = this;
	this.instance_5.setTransform(251.7,6.3,0.6979,0.6979,0,0,0,131.4,15.4);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(54).to({_off:false},0).to({y:3.05,alpha:1},7).to({_off:true},111).wait(163).to({_off:false,y:6.3,alpha:0},0).to({y:3.05,alpha:1},7).to({_off:true},111).wait(163).to({_off:false,y:6.3,alpha:0},0).to({y:3.05,alpha:1},7).to({_off:true},111).wait(109));

	// Слой_15
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F8F8F8").s().p("A/lD6IAAnzMA/LAAAIAAHzg");
	this.shape_73.setTransform(160.025,25);

	this.timeline.addTween(cjs.Tween.get(this.shape_73).to({_off:true},172).wait(109).to({_off:false},0).to({_off:true},172).wait(109).to({_off:false},0).to({_off:true},172).wait(109));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(117.8,11.8,244.5,47.2);
// library properties:
lib.properties = {
	id: '307B5D341DDBB5459CF568EEF0A1BE55',
	width: 320,
	height: 50,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/320x50TFHTML5_atlas_.png", id:"320x50TFHTML5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['307B5D341DDBB5459CF568EEF0A1BE55'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;