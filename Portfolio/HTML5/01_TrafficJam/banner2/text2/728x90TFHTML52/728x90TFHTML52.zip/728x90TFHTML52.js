(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90TFHTML52_atlas_", frames: [[0,0,401,56]]}
];


// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.logo = function() {
	this.initialize(ss["728x90TFHTML52_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AggBDIgBgBIgBgCIAAiAIABgBIABgBIAWAAIACABIABABIAABrIAAAAIABABIAnAAIABAAIABACIAAASIgBACIgBABg");
	this.shape.setTransform(213.3,-128.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AASBDIgBgBIgBgBIgDgTIAAAAIgBgBIgXAAIgBABIAAAAIgEATIAAABIgCABIgXAAIgBgBIAAgCIAciAIAAgBIACgBIAZAAIACABIAAABIAcCAIAAACIgCABgAAAgZIgIAxIAAAAIABABIAPAAIABgBIAAAAIgIgxIAAAAIgBAAg");
	this.shape_1.setTransform(204.1625,-128.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgKBDIgCgBIgBgCIAAgxIAAgBIAAgBIgahMIAAgCIABgBIAYAAIACABIABABIALAuIAAAAIABAAIALguIABgBIACgBIAYAAIABABIAAACIgaBMIgBABIAAABIAAAxIAAACIgCABg");
	this.shape_2.setTransform(194.875,-128.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_3.setTransform(185.825,-128.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AggBDIgBgBIgBgCIAAiAIABgBIABgBIAXAAIABABIABABIAABrIAAAAIABABIAnAAIACAAIAAACIAAASIAAACIgCABg");
	this.shape_4.setTransform(177.5,-128.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_5.setTransform(168.925,-128.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgLBDIgBgBIgBgCIAAiAIABgBIABgBIAWAAIACABIABABIAACAIgBACIgCABg");
	this.shape_6.setTransform(162.45,-128.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgjBDIgBgBIAAgCIAAiAIAAgBIABgBIAjAAQARAAAKAKQAKAKAAARIAAA7QAAARgKAKQgKAKgRAAgAgJgqIAAAAIAABVIAAAAIABABIAIgBQAEAAAEgEQACgEAAgHIAAg3QAAgHgCgFQgEgEgEAAIgIAAIgBABg");
	this.shape_7.setTransform(155.75,-128.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_8.setTransform(143.075,-128.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgLBDIgBgBIgBgCIAAiAIABgBIABgBIAWAAIABABIABABIAACAIgBACIgBABg");
	this.shape_9.setTransform(136.55,-128.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAOBDIgBgBIgBgBIgYhHIAAAAIgBAAIAABGIAAACIgCABIgWAAIgCgBIAAgCIAAiAIAAgBIACgBIAYAAIABABIABABIAYBGIABABIAAgBIAAhGIABgBIABgBIAXAAIABABIABABIAACAIgBACIgBABg");
	this.shape_10.setTransform(303.2,-147.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_11.setTransform(293.825,-147.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_12.setTransform(285.025,-147.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AAOBDIgCAAIgBgCIgOg0IAAgBIAAgBIgHAAIgBABIAAABIAAAzIgBADIgBAAIgXAAIgBAAIgBgDIAAiAIABgBIABgBIAmAAQALAAAIAFQAIAGAEAJQAFAJAAALQAAAMgEAIQgFAIgHAFIgBAAIAAABIASA4IgBADIgBAAgAgLgqIAAAAIAAAhIAAAAIABABIAJAAQAFAAADgEQAEgFAAgIQAAgIgEgFQgDgFgFAAIgJAAIgBABg");
	this.shape_13.setTransform(276.475,-147.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AggBDIgBgBIgBgCIAAiAIABgBIABgBIBAAAIACABIABABIAAATIgBACIgCAAIgmAAIgBABIAAAAIAAAeIAAABIABAAIAVAAIACABIABACIAAARIgBACIgCAAIgVAAIgBABIAAAAIAAAfIAAAAIABABIAmAAIACAAIABACIAAASIgBACIgCABg");
	this.shape_14.setTransform(267.75,-147.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgjBDIgBAAIgBgDIAAiAIABgBIABgBIAlAAQALAAAIAFQAJAGAEAJQAFAJgBAMQAAASgJAJQgKALgPAAIgNAAIgBAAIAAABIAAAyIgBADIgCAAgAgKgqIAAAAIAAAiIAAAAIABABIAIAAQAFAAAEgEQADgFAAgJQAAgIgDgFQgEgFgFAAIgIAAIgBABg");
	this.shape_15.setTransform(259.15,-147.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASBDIgBgBIgBgBIgDgTIAAAAIgBgBIgXAAIgBABIAAAAIgEATIAAABIgCABIgXAAIgBgBIAAgCIAciAIAAgBIACgBIAZAAIACABIAAABIAcCAIAAACIgCABgAAAgZIgIAxIAAAAIABABIAPAAIABgBIAAAAIgIgxIAAAAIgBAAg");
	this.shape_16.setTransform(245.9125,-147.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAOBDIgCgBIAAgBIgYhHIgBAAIAAAAIAABGIgBACIgBABIgWAAIgCgBIgBgCIAAiAIABgBIACgBIAYAAIABABIABABIAYBGIAAABIABgBIAAhGIABgBIACgBIAWAAIABABIAAABIAACAIAAACIgBABg");
	this.shape_17.setTransform(232.4,-147.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgbA7QgJgKgBgRIAAg/QABgRAJgKQALgJAQAAQALAAAJAEQAJAEAEAJQAFAIAAALIAAAHIAAACIgCAAIgWAAIgCAAIgBgCIAAgIQAAgFgDgEQgDgDgFAAQgEAAgDADQgDAEAAAFIAABAQAAAGADAEQADADAEAAQAFAAADgDQADgEAAgGIAAgPIAAgBIAAAAIgJAAIgCgBIAAgBIAAgQIAAgCIACAAIAiAAIACAAIAAACIAAAiQAAALgFAIQgEAIgJAFQgJAEgLAAQgQAAgLgJg");
	this.shape_18.setTransform(223.1,-147.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLBDIgBgBIgBgCIAAiAIABgBIABgBIAWAAIACABIABABIAACAIgBACIgCABg");
	this.shape_19.setTransform(216.45,-147.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_20.setTransform(210.025,-147.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_21.setTransform(197.675,-147.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgaA5QgLgLAAgSIAAhdIABgBIABAAIAXAAIABAAIABABIAABgQAAAGADAEQADADAEAAQAFAAADgDQADgEAAgGIAAhgIABgBIABAAIAXAAIABAAIABABIAABdQAAAMgFAJQgFAJgIAEQgJAGgLAAQgQAAgKgLg");
	this.shape_22.setTransform(188.775,-147.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_23.setTransform(179.675,-147.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgKBDIgCgBIAAgCIAAiAIAAgBIACgBIAVAAIACABIABABIAACAIgBACIgCABg");
	this.shape_24.setTransform(172.95,-147.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgLBDIgCgBIgBgBIgbiAIAAgCIACgBIAYAAIACABIABABIAMBTIAAABIABgBIANhTIABgBIACgBIAYAAIABABIAAACIgbCAIgBABIgCABg");
	this.shape_25.setTransform(166.1,-147.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgjBDIgCgBIAAgCIAAiAIAAgBIACgBIAgAAQALAAAJAEQAJAEAFAIQAFAIAAANQAAAJgDAHQgDAHgGAEIgBABIAAAAQAHAEAEAIQAEAHAAALQABANgGAIQgEAIgJAFQgJAEgLAAgAgKAJIAAAiIAAAAIABAAIAIAAQAFAAAEgEQADgEAAgJQAAgJgDgEQgEgFgFAAIgIAAIgBAAIAAABgAgKgqIAAAAIAAAeIAAABIABAAIAGAAQAGAAAEgEQADgEAAgIQAAgHgDgFQgEgEgGAAIgGAAIgBABg");
	this.shape_26.setTransform(157.1271,-147.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_27.setTransform(147.975,-147.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgCBDIgBgBIgBgCIAAhoIAAgBIgBAAIgNADIgCAAIgBgCIAAgQIABgCIABgBIAOgGIABgBIABAAIAWAAIACABIABABIAACAIgBACIgCABg");
	this.shape_28.setTransform(136.775,-147.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t122, new cjs.Rectangle(133.2,-161.1,283.1,46), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A575").s().p("AgXA1QgFgIgBgMIAAgiQABgNAFgHQAGgHALAAIAHABQAFABADAEIABAAIAAAAIAAgjIABgCIABAAIAQAAIABAAIABACIAAByIgBABIgBABIgQAAIgBgBIgBgBIAAgDIAAgBIgBABQgDADgFACIgHABQgLAAgGgHgAgHgIQgCADAAAFIAAAfQAAAFACAEQADADAEAAQAFAAADgDQACgEAAgFIAAgfQAAgFgCgDQgDgDgFAAQgEAAgDADg");
	this.shape.setTransform(176.8,-108.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAVIgBACIgBABIglAAIAAAAIgBABIAAAHQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQABIABAAIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_1.setTransform(169.575,-106.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A575").s().p("AANA8IgBgBIgBgBIgMgnIAAgBIgBABIgIAMIAAABIAAAAIAAAZIgBACIgBABIgQAAIgBgBIgBgCIAAhxIABgCIABgBIAQAAIABABIABACIAAA7IAAAAIABAAIARgcIABgBIACgBIAQAAIACABIgBACIgRAaIgBAAIAAABIAVA2IAAACIgCABg");
	this.shape_2.setTransform(162.4375,-108.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAiQAAAMgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAGACADQADADAEAAQAFAAADgDQADgDAAgGIAAgfQAAgFgDgEQgDgDgFAAQgEAAgDADg");
	this.shape_3.setTransform(154.875,-106.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAiQAAAMgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAGACADQADADAEAAQAFAAADgDQADgDAAgGIAAgfQAAgFgDgEQgDgDgFAAQgEAAgDADg");
	this.shape_4.setTransform(147.525,-106.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A575").s().p("AgHA8IgBgBIgBgCIAAhxIABgCIABgBIAPAAIABABIABACIAABxIgBACIgBABg");
	this.shape_5.setTransform(142.15,-108.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A575").s().p("AgTAsIgBgBIgBgBIAAhSIABgBIABgBIAQAAIABABIABABIAAAIIAAABIABgBQABgFADgDQAEgDAGAAIAEAAIADACIABABIAAACIgDAPIgBACIgBAAIgEgBIgEAAQgFABgDAEQgCAFAAAHIAAAvIgBABIgBABg");
	this.shape_6.setTransform(138.125,-106.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAVIgBACIgBABIglAAIAAAAIgBABIAAAHQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQABIABAAIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_7.setTransform(131.575,-106.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A575").s().p("AgIAsIgBgBIgBgBIgVhSIAAgCIACgBIARAAIACABIAAABIAKA3IAAAAIABAAIAKg3IAAgBIACgBIARABIACAAIAAACIgVBSIAAABIgCABg");
	this.shape_8.setTransform(124.375,-106.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("AgXA0QgIgIgBgQIAAg3QABgQAIgIQAJgJAOAAQAPAAAJAJQAIAIABAQIAAA3QgBAQgIAIQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAHIAAA5QAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAg5QAAgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_9.setTransform(116.875,-108.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A575").s().p("AAMAsIgBAAIgBgCIAAg3QAAgGgDgEQgCgDgFAAQgEAAgCADQgDAEAAAGIAAA3IgBACIgBAAIgQAAIgBAAIgBgCIAAhSIABgBIABgBIAQAAIABABIABABIAAAEIAAAAIABAAQAEgEAEgCIAHgBQALAAAGAHQAGAIAAANIAAA5IgBACIgBAAg");
	this.shape_10.setTransform(105.825,-106.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAVIgBACIgBABIglAAIAAAAIgBABIAAAHQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQABIABAAIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_11.setTransform(98.475,-106.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A575").s().p("AAMA2QgIAAgEgBQgFgCgCgEQgEgFAAgIIAAgzIAAAAIgBgBIgFAAIgCAAIgBgCIAAgKIABgBIACgBIAFAAIABAAIAAAAIAAgTIABgCIACAAIANAAIABAAIABACIAAATIAAAAIABAAIALAAIABABIABABIAAAKIgBACIgBAAIgLAAIgBABIAAAAIAAAsQABAGACACQACACAEAAIACAAIABABIABABIAAANIgBACIgBAAg");
	this.shape_12.setTransform(92.35,-107.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A575").s().p("AgJA8IgCgBIAAgBIAAhFIAAgBIgBAAIgGAAIgBgBIgBgBIAAgKIABgCIABAAIAGAAIABAAIAAgBIAAgEQAAgQAHgGQAGgGAPAAIABAAIACABIAAABIAAAMIAAABIgBABIgCAAQgFAAgCADQgDADAAAHIAAADIABABIAAAAIALAAIABAAIABACIAAAKIgBABIgBABIgLAAIAAAAIgBABIAABFIAAABIgCABg");
	this.shape_13.setTransform(87.475,-108.4268);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A575").s().p("AgXA0QgIgIgBgQIAAg3QABgQAIgIQAJgJAOAAQAPAAAJAJQAIAIABAQIAAA3QgBAQgIAIQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAHIAAA5QAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAg5QAAgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_14.setTransform(81.075,-108.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A575").s().p("AgVAmQgHgHgBgLIAAgBIABgBIACAAIAOAAIABAAIACABIAAABQAAAEADADQADADADgBQAFABACgDQACgDABgEQAAgDgCgCIgGgEIgIgDIgJgFQgFgDgEgFQgDgEAAgJQgBgMAIgHQAHgGANAAQANAAAHAHQAIAGABANIgBABIgCAAIgOAAIgBAAIgBgBIAAgBQAAgEgDgDQgCgDgFAAQgDAAgDADQgCADAAAEQAAADACACQACACADACIAGADIALAGQAFABAFAGQADAEAAAJQABALgJAHQgHAGgOABQgMgBgJgGg");
	this.shape_15.setTransform(70.4,-106.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A575").s().p("AgHA8IgCgBIAAgCIAAhxIAAgCIACgBIAPAAIABABIABACIAABxIgBACIgBABg");
	this.shape_16.setTransform(65.05,-108.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A575").s().p("AALA2QgHAAgEgBQgFgCgDgEQgCgFAAgIIAAgzIgBAAIAAgBIgHAAIgBAAIAAgCIAAgKIAAgBIABgBIAHAAIAAAAIABAAIAAgTIAAgCIABAAIAOAAIACAAIAAACIAAATIAAAAIABAAIAKAAIACABIAAABIAAAKIAAACIgCAAIgKAAIgBABIAAAAIAAAsQABAGABACQADACAEAAIABAAIACABIAAABIAAANIAAACIgCAAg");
	this.shape_17.setTransform(57.3,-107.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A575").s().p("AgQArQgGgCgEgFQgEgGAAgLQAAgKAEgHQAFgFAHgDQAIgCAIAAIAJAAIAAAAIABgBIAAgFQAAgFgDgEQgDgEgFAAQgDAAgCACQgCADgBAEIgBABIgBABIgRAAIgBgBIAAgBQABgMAIgHQAIgGALgBQAJAAAHADQAHAEAEAGQADAHAAAIIAAA5IAAACIgCABIgPAAIgCgBIAAgCIAAgDIgBAAIAAAAQgDAEgFACQgDABgGAAQgFAAgFgCgAgGAJQgEADAAAGQAAAGADACQADACAEAAQAEAAAEgCQADgEABgFIAAgKIgBgBIAAgBIgJAAQgFAAgDAEg");
	this.shape_18.setTransform(51.175,-106.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A575").s().p("AAMA8IgBgBIgBgCIAAg4QAAgFgDgEQgCgDgFAAQgEAAgCADQgDAEAAAFIAAA4IgBACIgBABIgQAAIgBgBIgBgCIAAhxIABgCIABgBIAQAAIABABIABACIAAAjIAAABIABgBQAEgEAEgCIAHgBQALAAAGAIQAGAHAAANIAAA5IgBACIgBABg");
	this.shape_19.setTransform(43.925,-108.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A575").s().p("AgIA8IgBgBIgBgCIAAhiIAAgBIgBAAIgUAAIgBAAIgBgCIAAgMIABgCIABgBIA+AAIACABIABACIAAAMIgBACIgCAAIgVAAIgBAAIAAABIAABiIgBACIgBABg");
	this.shape_20.setTransform(36.325,-108.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(30.5,-121.1,183.4,25.299999999999997), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgmBQIgCAAIgBgCIAAibIABgCIACgBIAaAAIACABIABACIAACBIAAABIABAAIAwAAIABAAIABACIAAAXIgBACIgBAAg");
	this.shape.setTransform(320.3,-124.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AAXBQIgDAAIgBgCIgDgWIgBgBIgBAAIgbAAIgCAAIAAAAIgEAXIgBACIgCAAIgbAAIgCAAIAAgCIAhibIABgCIACgBIAfAAIABABIABACIAiCbIAAACIgCAAgAAAgeIgKA6IAAABIABAAIATAAIABAAIAAgBIgKg6IgBAAIAAAAg");
	this.shape_1.setTransform(309.3,-124.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgNBQIgCAAIgBgCIAAg9IAAAAIAAgBIgghdIAAgCIACgBIAdAAIACABIABACIAOA2IAAACIABgCIAOg2IABgCIACgBIAcAAIACABQABAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIghBdIAAABIAAAAIAAA9IgBACIgCAAg");
	this.shape_2.setTransform(298.1083,-124.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AghBGQgNgMABgVIAAhJQgBgVANgMQAMgMAVAAQAOAAALAFQAKAFAGALQAFAKAAAOIAABJQAAAOgFAKQgGAKgKAGQgLAFgOAAQgVAAgMgMgAgKgxQgDAEAAAIIAABLQAAAHADAFQAEAEAGAAQAHAAADgEQAEgFAAgHIAAhLQAAgIgEgEQgDgEgHgBQgGABgEAEg");
	this.shape_3.setTransform(287.25,-124.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgnBQIgBAAIgBgCIAAibIABgCIABgBIAbAAIACABIABACIAACBIAAABIABAAIAwAAIABAAIABACIAAAXIgBACIgBAAg");
	this.shape_4.setTransform(277.2,-124.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgWBNQgKgFgGgKQgFgJAAgMIAAgIIAAgCIACgBIAbAAIACABIABACIAAAFQAAAIADAFQADADAFAAQAGAAADgDQAEgFAAgHQAAgEgCgEQgDgEgFgEIgLgKIgRgNQgIgGgGgKQgFgJAAgNQAAgNAFgLQAGgJAKgFQAKgFANAAQAUAAAMALQAMAMAAAVIAAAFIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgDgFQgEgEgFAAQgFAAgEAEQgDAEAAAIQAAAFACADQACAEAEAFIAMAKQAMAIAIAGQAJAIAEAHQAEAJAAALQAAAOgGAKQgFAKgKAFQgLAGgNgBQgMABgKgGg");
	this.shape_5.setTransform(266.875,-124.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMBQIgCAAIgBgCIAAibIABgCIACgBIAaAAIACABIAAACIAACbIAAACIgCAAg");
	this.shape_6.setTransform(258.975,-124.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgqBQIgBAAIgBgCIAAibIABgCIABgBIAqAAQAVABALALQANAMABAVIAABHQgBAUgNANQgLAMgVgBgAgMgzIAABnIAAABIABAAIALAAQAFgBAEgFQAEgEAAgJIAAhDQAAgJgEgEQgEgGgFAAIgLAAIgBAAIAAABg");
	this.shape_7.setTransform(250.95,-124.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgWBNQgKgFgGgKQgFgJAAgMIAAgIIAAgCIACgBIAbAAIACABIABACIAAAFQAAAIADAFQADADAFAAQAGAAADgDQAEgFAAgHQAAgEgCgEQgDgEgFgEIgLgKIgRgNQgIgGgGgKQgFgJAAgNQAAgNAFgLQAGgJAKgFQAKgFANAAQAUAAAMALQAMAMAAAVIAAAFIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgDgFQgEgEgFAAQgFAAgEAEQgDAEAAAIQAAAFACADQACAEAEAFIAMAKQAMAIAIAGQAJAIAEAHQAEAJAAALQAAAOgGAKQgFAKgKAFQgLAGgNgBQgMABgKgGg");
	this.shape_8.setTransform(235.725,-124.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgMBQIgCAAIgBgCIAAibIABgCIACgBIAaAAIACABIAAACIAACbIAAACIgCAAg");
	this.shape_9.setTransform(227.825,-124.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AARBRIgCgBIgBgCIgdhVIgBgBIAAABIAABUIgBACIgCACIgaAAIgCgCIgBgCIAAiaIABgCIACAAIAdAAIACAAIABACIAdBVIAAABIABgCIAAhUIABgCIACAAIAaAAIACAAIABACIAACaIgBACIgCACg");
	this.shape_10.setTransform(373.875,-147.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AghBGQgNgMAAgVIAAhJQAAgVANgMQAMgNAVAAQAOAAAKAGQALAGAGAKQAFAKAAAOIAABJQAAANgFALQgGAKgLAFQgKAHgOAAQgVgBgMgMgAgKgxQgDAEAAAIIAABLQAAAHADAFQAEAFAGAAQAHAAADgFQAEgFAAgHIAAhLQAAgIgEgEQgDgFgHABQgGgBgEAFg");
	this.shape_11.setTransform(362.5,-147.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgWBNQgKgGgGgIQgFgKAAgNIAAgHIAAgCIACgBIAbAAIACABIABACIAAAGQAAAHADAEQADAFAFAAQAGAAADgFQAEgDAAgIQAAgEgCgEQgDgEgFgEIgLgKIgRgNQgIgGgGgJQgFgKAAgOQAAgNAFgJQAGgKAKgFQAKgGANAAQAUABAMAMQAMAMAAATIAAAGIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgDgFQgEgDgFAAQgFAAgEADQgDAEAAAHQAAAFACAEQACAEAEAEIAMAKQAMAJAIAGQAJAIAEAIQAEAIAAALQAAAOgGAJQgFAKgKAGQgLAFgNABQgMgBgKgFg");
	this.shape_12.setTransform(351.975,-147.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AARBRIgCgBIgBgCIgRg/IAAgBIgBAAIgIAAIgBAAIAAABIAAA/IgBACIgCABIgbAAIgCgBIgBgCIAAibIABgCIACgBIAuAAQANABAJAGQAKAGAFALQAGALAAAOQAAAOgFAKQgFAJgKAGIAAABIAAABIAVBDIAAADIgCABgAgNgyIAAAnIAAABIABAAIAKAAQAHAAAEgFQAEgGAAgJQAAgLgEgFQgEgFgHAAIgKAAIgBAAIAAABg");
	this.shape_13.setTransform(341.5875,-147.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgmBRIgCgCIgBgCIAAiaIABgCIACAAIBOAAIACAAIAAACIAAAWIAAADIgCABIgwAAIAAAAIgBABIAAAkIABAAIAAABIAbAAIACAAIABACIAAAWIgBACIgCABIgbAAIAAAAIgBABIAAAkIABABIAAAAIAwAAIACACIAAACIAAAVIAAACIgCACg");
	this.shape_14.setTransform(331.075,-147.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgrBRIgCgBIAAgCIAAibIAAgCIACgBIAuAAQANABAKAGQAJAGAGALQAFALAAAOQAAAWgLAMQgMAMgTABIgQAAIgBAAIAAABIAAA9IgBACIgCABgAgNgyIAAAoIAAABIABAAIAKAAQAHAAAEgFQAFgGAAgKQAAgKgFgGQgEgFgHAAIgKAAIgBAAIAAABg");
	this.shape_15.setTransform(320.775,-147.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAXBRIgDgBIgBgCIgDgWIgBgBIgBAAIgbAAIgCAAIAAABIgEAWIgBACIgCABIgbAAIgCgBIAAgDIAhiaIABgCIACAAIAfAAIABAAIABACIAiCaIAAADIgCABgAAAgeIgKA7IAAABIABAAIATAAIABAAIAAgBIgKg7IgBgBIAAABg");
	this.shape_16.setTransform(304.8,-147.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AARBRIgCgBIgBgCIgdhVIgBgBIAAABIAABUIgBACIgCACIgaAAIgCgCIgBgCIAAiaIABgCIACAAIAdAAIACAAIABACIAdBVIAAABIABgCIAAhUIABgCIACAAIAaAAIACAAIABACIAACaIgBACIgCACg");
	this.shape_17.setTransform(288.525,-147.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AggBGQgNgLAAgUIAAhNQAAgUANgLQAMgNAUAAQAOAAAKAGQAKAGAGAJQAGAKAAANIAAAJIgBACIgCABIgbAAIgCgBIgBgCIAAgJQAAgHgDgFQgEgDgGAAQgFAAgEADQgDAFAAAHIAABNQAAAHADAEQAEAFAFAAQAGAAAEgFQADgEAAgHIAAgSIAAgBIgBAAIgKAAIgCgBIAAgDIAAgTIAAgCIACAAIApAAIACAAIABACIAAAqQAAANgGAKQgGAJgKAGQgKAFgOABQgUgBgMgMg");
	this.shape_18.setTransform(277.325,-147.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgMBRIgCgCIgBgCIAAiaIABgCIACAAIAaAAIACAAIAAACIAACaIAAACIgCACg");
	this.shape_19.setTransform(269.275,-147.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgWBNQgKgGgGgIQgFgKAAgNIAAgHIAAgCIACgBIAbAAIACABIABACIAAAGQAAAHADAEQADAFAFAAQAGAAADgFQAEgDAAgIQAAgEgCgEQgDgEgFgEIgLgKIgRgNQgIgGgGgJQgFgKAAgOQAAgNAFgJQAGgKAKgFQAKgGANAAQAUABAMAMQAMAMAAATIAAAGIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgDgFQgEgDgFAAQgFAAgEADQgDAEAAAHQAAAFACAEQACAEAEAEIAMAKQAMAJAIAGQAJAIAEAIQAEAIAAALQAAAOgGAJQgFAKgKAGQgLAFgNABQgMgBgKgFg");
	this.shape_20.setTransform(261.575,-147.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgWBNQgKgGgGgIQgFgKAAgNIAAgHIAAgCIACgBIAbAAIACABIABACIAAAGQAAAHADAEQADAFAFAAQAGAAADgFQAEgDAAgIQAAgEgCgEQgDgEgFgEIgLgKIgRgNQgIgGgGgJQgFgKAAgOQAAgNAFgJQAGgKAKgFQAKgGANAAQAUABAMAMQAMAMAAATIAAAGIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgHgDgFQgEgDgFAAQgFAAgEADQgDAEAAAHQAAAFACAEQACAEAEAEIAMAKQAMAJAIAGQAJAIAEAIQAEAIAAALQAAAOgGAJQgFAKgKAGQgLAFgNABQgMgBgKgFg");
	this.shape_21.setTransform(246.625,-147.95);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AggBEQgMgMgBgWIAAhwIABgCIACAAIAbAAIACAAIABACIAABzQAAAHADAFQAEAFAFAAQAGAAADgFQAEgFAAgHIAAhzIABgCIACAAIAbAAIACAAIABACIAABwQgBAOgFALQgGALgKAFQgKAHgOAAQgUgBgMgNg");
	this.shape_22.setTransform(235.875,-147.85);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AghBGQgMgMAAgVIAAhJQAAgVAMgMQANgNAUAAQAOAAALAGQAKAGAFAKQAHAKgBAOIAABJQABANgHALQgFAKgKAFQgLAHgOAAQgUgBgNgMgAgJgxQgEAEAAAIIAABLQAAAHAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgHIAAhLQAAgIgEgEQgEgFgGABQgFgBgEAFg");
	this.shape_23.setTransform(224.95,-147.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgMBRIgCgCIgBgCIAAiaIABgCIACAAIAaAAIACAAIAAACIAACaIAAACIgCACg");
	this.shape_24.setTransform(216.825,-147.95);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgOBRIgCgBIgBgCIghibIAAgCIACAAIAeAAIACAAIABACIAPBkIABABIAAgBIAQhkIABgCIACAAIAcAAIACAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIghCbIgBACIgCABg");
	this.shape_25.setTransform(208.6208,-147.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgqBRIgCgCIgBgCIAAiaIABgCIACAAIAmAAQAOgBALAFQALAFAGAKQAGAJAAAQQAAALgEAIQgEAJgIAEIAAABIAAABQAIAEAFAKQAFAJAAANQABAQgHAJQgFALgLAEQgKAFgOABgAgMAKIgBABIAAAoIABABIAAAAIALAAQAGABAFgGQAEgFAAgLQAAgKgEgGQgFgGgGAAIgLAAIAAABgAgNgyIAAAkIABAAIAAAAIAJAAQAHAAAEgEQAEgFAAgJQAAgJgEgGQgEgEgHAAIgJAAIAAAAIgBABg");
	this.shape_26.setTransform(197.7768,-147.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AghBGQgMgMAAgVIAAhJQAAgVAMgMQANgNAUAAQAOAAALAGQAKAGAFAKQAHAKgBAOIAABJQABANgHALQgFAKgKAFQgLAHgOAAQgUgBgNgMgAgJgxQgEAEAAAIIAABLQAAAHAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgHIAAhLQAAgIgEgEQgEgFgGABQgFgBgEAFg");
	this.shape_27.setTransform(186.7,-147.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgCBRIgDgCIgBgCIAAh9IAAgBIgBAAIgPADIgDAAIAAgCIAAgUIAAgCIACgBIAQgIIABAAIADAAIAaAAIACAAIABACIAACaIgBACIgCACg");
	this.shape_28.setTransform(173.3,-147.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(104.5,-163.9,341.2,55.400000000000006), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-63,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-63,0,401,56), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjA6IAAhzIBGAAIAAAWIgvAAIAAAZIArAAIAAAUIgrAAIAAAaIAwAAIAAAWg");
	this.shape.setTransform(109.8,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUA6IgXgoIgRAAIAAAoIgXAAIAAhzIAtAAQAQAAAMAMQALALAAAPQAAAMgGAHQgGAJgKAGIAZArgAgUgBIAWAAQAHAAAEgGQAFgEAAgIQAAgHgFgEQgEgGgHAAIgWAAg");
	this.shape_1.setTransform(100.525,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpArQgSgSAAgZQAAgYASgSQARgRAYAAQAZAAARARQASASAAAYQAAAZgSASQgRARgZAAQgYAAgRgRgAgagaQgKAKgBAQQABAQAKALQALALAPAAQAQAAAKgLQALgLAAgQQAAgQgLgKQgKgLgQAAQgPAAgLALg");
	this.shape_2.setTransform(88.45,15.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiA6IAAhKIggA0IgCAAIghg0IAABKIgXAAIAAhzIAYAAIAgA3IAhg3IAYAAIAABzg");
	this.shape_3.setTransform(75.125,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAbA6IgwhGIAABGIgXAAIAAhzIARAAIAyBGIAAhGIAWAAIAABzg");
	this.shape_4.setTransform(58.65,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUA6IgXgoIgRAAIAAAoIgXAAIAAhzIAtAAQAQAAAMAMQALALAAAPQAAAMgGAHQgGAJgKAGIAZArgAgUgBIAWAAQAHAAAEgGQAFgEAAgIQAAgHgFgEQgEgGgHAAIgWAAg");
	this.shape_5.setTransform(48.425,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAeA6IgHgVIgtAAIgHAVIgZAAIAphzIAbAAIApBzgAgPAQIAfAAIgQgug");
	this.shape_6.setTransform(37.475,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgjA6IAAhzIBGAAIAAAWIgvAAIAAAZIArAAIAAAUIgrAAIAAAaIAwAAIAAAWg");
	this.shape_7.setTransform(27.9,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghA6IAAhzIAXAAIAABdIAsAAIAAAWg");
	this.shape_8.setTransform(19.675,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("ApSCWQgyAAAAgyIAAjHQAAgyAyAAISlAAQAyAAAAAyIAADHQAAAygyAAg");
	this.shape_9.setTransform(64.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,129,30), null);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0,0,1456,180), null);


// stage content:
(lib._728x90TFHTML52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_781 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(781).call(this.frame_781).wait(1));

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-235.2,-93.9,-85.9,-35.8).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape.setTransform(616.7,63.15);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-217.8,-89.4,-68.5,-31.3).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_1.setTransform(616.7,63.15);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-200.3,-85,-51,-26.9).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_2.setTransform(616.7,63.15);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-182.9,-80.5,-33.6,-22.4).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_3.setTransform(616.7,63.15);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-165.4,-76.1,-16.1,-18).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_4.setTransform(616.7,63.15);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-148,-71.7,1.3,-13.6).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_5.setTransform(616.7,63.15);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-130.5,-67.2,18.8,-9.1).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_6.setTransform(616.7,63.15);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-113.1,-62.8,36.2,-4.7).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_7.setTransform(616.7,63.15);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-95.6,-58.3,53.7,-0.2).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_8.setTransform(616.7,63.15);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-78.2,-53.9,71.1,4.2).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_9.setTransform(616.7,63.15);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-60.7,-49.4,88.6,8.7).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_10.setTransform(616.7,63.15);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-43.3,-45,106,13.1).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_11.setTransform(616.7,63.15);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-25.9,-40.5,123.4,17.6).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_12.setTransform(616.7,63.15);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-8.4,-36.1,140.9,22).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_13.setTransform(616.7,63.15);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],9,-31.6,158.3,26.5).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_14.setTransform(616.7,63.15);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],26.5,-27.2,175.8,30.9).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_15.setTransform(616.7,63.15);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],43.9,-22.8,193.2,35.3).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_16.setTransform(616.7,63.15);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],61.4,-18.3,210.7,39.8).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_17.setTransform(616.7,63.15);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],78.8,-13.9,228.1,44.2).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_18.setTransform(616.7,63.15);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],96.3,-9.4,245.6,48.7).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_19.setTransform(616.7,63.15);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(199).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(200).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(19));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(201).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(18));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(202).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(203).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(204).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(15));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(205).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(206).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(13));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(207).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(208).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(209).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(210).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(211).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(212).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(213).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(214).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(215).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(216).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(217).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(218).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(1));

	// Слой_3
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(616.65,87.9,1.2345,1.2345,0,0,0,64.6,15.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({y:63.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:34.45,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:87.9},0).to({y:63.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:34.45,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:87.9},0).to({y:63.2,alpha:1},17,cjs.Ease.get(1)).wait(21));

	// logo
	this.instance_1 = new lib.logo_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(538.5,34.55,0.3931,0.4153,0,0,0,-63,0);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(171).to({_off:false},0).to({y:12.15,alpha:1},17,cjs.Ease.get(1)).wait(73).to({y:-7.55,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(178).to({_off:false,y:34.55},0).to({y:12.15,alpha:1},17,cjs.Ease.get(1)).wait(73).to({y:-7.55,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(178).to({_off:false,y:34.55},0).to({y:12.15,alpha:1},17,cjs.Ease.get(1)).wait(32));

	// Слой_5
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(253.55,41.05,1.5,1.5,0,0,0,274.7,-136.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(175).to({_off:false},0).to({regY:-136.6,y:45.05,alpha:1},13).wait(80).to({regY:-136.7,y:41.05,alpha:0},12).to({_off:true},1).wait(175).to({_off:false},0).to({regY:-136.6,y:45.05,alpha:1},13).wait(80).to({regY:-136.7,y:41.05,alpha:0},12).to({_off:true},1).wait(175).to({_off:false},0).to({regY:-136.6,y:45.05,alpha:1},13).wait(32));

	// Слой_6
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(204,204,204,0)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_20.setTransform(617.8,45);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(204,204,204,0.047)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_21.setTransform(617.8,45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(204,204,204,0.09)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_22.setTransform(617.8,45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(204,204,204,0.129)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_23.setTransform(617.8,45);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(204,204,204,0.165)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_24.setTransform(617.8,45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(204,204,204,0.196)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_25.setTransform(617.8,45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(204,204,204,0.224)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_26.setTransform(617.8,45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(204,204,204,0.247)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_27.setTransform(617.8,45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(204,204,204,0.267)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_28.setTransform(617.8,45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(204,204,204,0.278)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_29.setTransform(617.8,45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(204,204,204,0.29)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_30.setTransform(617.8,45);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(204,204,204,0.294)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_31.setTransform(617.8,45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(204,204,204,0.298)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_32.setTransform(617.8,45);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(204,204,204,0.255)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_33.setTransform(617.8,45);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(204,204,204,0.212)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_34.setTransform(617.8,45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(204,204,204,0.169)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_35.setTransform(617.8,45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(204,204,204,0.086)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_36.setTransform(617.8,45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(204,204,204,0.043)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_37.setTransform(617.8,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},159).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},102).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},159).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},102).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},159).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(159).to({_off:false},0).to({_off:true},1).wait(120).to({_off:false},0).to({_off:true},1).wait(159).to({_off:false},0).to({_off:true},1).wait(120).to({_off:false},0).to({_off:true},1).wait(159).to({_off:false},0).to({_off:true},1).wait(60));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(162).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(165).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(165).to({_off:false},0).to({_off:true},1).wait(57));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(171).to({_off:false},0).wait(102).to({_off:true},1).wait(178).to({_off:false},0).wait(102).to({_off:true},1).wait(178).to({_off:false},0).wait(49));

	// Слой_7
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_38.setTransform(364,45);
	this.shape_38._off = true;

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.086)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_39.setTransform(364,45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.165)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_40.setTransform(364,45);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.243)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_41.setTransform(364,45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.318)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_42.setTransform(364,45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.388)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_43.setTransform(364,45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.455)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_44.setTransform(364,45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.518)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_45.setTransform(364,45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.576)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_46.setTransform(364,45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.631)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_47.setTransform(364,45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.682)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_48.setTransform(364,45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.729)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_49.setTransform(364,45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.773)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_50.setTransform(364,45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.812)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_51.setTransform(364,45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.847)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_52.setTransform(364,45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.878)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_53.setTransform(364,45);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.906)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_54.setTransform(364,45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.933)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_55.setTransform(364,45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.953)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_56.setTransform(364,45);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.969)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_57.setTransform(364,45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.984)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_58.setTransform(364,45);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.992)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_59.setTransform(364,45);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_60.setTransform(364,45);
	this.shape_60._off = true;

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.98)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_61.setTransform(364,45);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.918)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_62.setTransform(364,45);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.816)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_63.setTransform(364,45);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.675)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_64.setTransform(364,45);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.49)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_65.setTransform(364,45);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.267)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_66.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_38}]},148).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},102).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_38}]},1).to({state:[]},1).to({state:[{t:this.shape_38}]},148).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},102).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_38}]},1).to({state:[]},1).to({state:[{t:this.shape_38}]},148).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.shape_38).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(71));
	this.timeline.addTween(cjs.Tween.get(this.shape_60).wait(170).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(50));

	// t1.1
	this.instance_3 = new lib.t122();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-124.65,206.05,1.2391,1.2391);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:-0.1,regY:0.1,x:-154.95,y:206.15,alpha:1},23,cjs.Ease.get(1)).to({_off:true},148).wait(110).to({_off:false,regX:0,regY:0,x:-124.65,y:206.05,alpha:0},0).to({regX:-0.1,regY:0.1,x:-154.95,y:206.15,alpha:1},23,cjs.Ease.get(1)).to({_off:true},148).wait(110).to({_off:false,regX:0,regY:0,x:-124.65,y:206.05,alpha:0},0).to({regX:-0.1,regY:0.1,x:-154.95,y:206.15,alpha:1},23,cjs.Ease.get(1)).to({_off:true},148).wait(49));

	// t1.2
	this.instance_4 = new lib.t12();
	this.instance_4.parent = this;
	this.instance_4.setTransform(137.55,250.75,1.2842,1.2842,0,0,0,131.4,15.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(37).to({_off:false},0).to({y:230.1,alpha:1},23,cjs.Ease.get(1)).to({_off:true},111).wait(147).to({_off:false,y:250.75,alpha:0},0).to({y:230.1,alpha:1},23,cjs.Ease.get(1)).to({_off:true},111).wait(147).to({_off:false,y:250.75,alpha:0},0).to({y:230.1,alpha:1},23,cjs.Ease.get(1)).to({_off:true},111).wait(49));

	// bg-2
	this.instance_5 = new lib.bg2_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150,125,0.5,0.5,0,0,0,300,250);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(10).to({_off:false},0).to({alpha:1},13,cjs.Ease.get(1)).to({_off:true},148).wait(120).to({_off:false,alpha:0},0).to({alpha:1},13,cjs.Ease.get(1)).to({_off:true},148).wait(120).to({_off:false,alpha:0},0).to({alpha:1},13,cjs.Ease.get(1)).to({_off:true},148).wait(49));

	// Слой_15
	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#E1E4E3").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_67.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_67).wait(782));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(362.2,37.5,365.90000000000003,70.4);
// library properties:
lib.properties = {
	id: '307B5D341DDBB5459CF568EEF0A1BE55',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/728x90TFHTML52_atlas_.png", id:"728x90TFHTML52_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['307B5D341DDBB5459CF568EEF0A1BE55'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;