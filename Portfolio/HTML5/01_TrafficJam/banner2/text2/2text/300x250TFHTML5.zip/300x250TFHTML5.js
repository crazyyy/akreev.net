(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250TFHTML5_atlas_", frames: [[0,0,401,56]]}
];


// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.logo = function() {
	this.initialize(ss["300x250TFHTML5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A575").s().p("AgXA1QgFgIgBgMIAAgiQABgNAFgHQAHgHAKAAIAIABQAEABADAEIABAAIAAAAIAAgjIABgCIABAAIAQAAIABAAIABACIAAByIgBABIgBABIgQAAIgBgBIgBgBIAAgDIAAgBIgBABQgDADgEACIgIABQgKAAgHgHgAgGgIQgDADAAAFIAAAfQAAAFADAEQACADAEAAQAFAAADgDQACgEAAgFIAAgfQAAgFgCgDQgDgDgFAAQgEAAgCADg");
	this.shape.setTransform(97.4,61.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A575").s().p("AgVAmQgIgIAAgNIAAghQAAgNAIgHQAIgIANAAQAOAAAIAIQAIAHAAANIAAAWIgBABIgBAAIglAAIAAAAIgBABIAAAIQABAFACADQADAEAEAAQAEAAADgDQACgCABgEIABgCIABAAIAQABIABABIABACQgCALgHAHQgIAGgNAAQgNgBgIgGgAgHgXQgCADgBAGIAAAHIABABIAAAAIASAAIABAAIAAgBIAAgHQAAgGgDgDQgCgEgFAAQgEAAgDAEg");
	this.shape_1.setTransform(90.175,62.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A575").s().p("AANA7IgBAAIgBgBIgMgmIAAgBIgBAAIgIAMIAAAAIAAABIAAAZIgBACIgBAAIgQAAIgBAAIgBgCIAAhyIABgBIABgBIAQAAIABABIABABIAAA8IAAAAIABAAIARgcIABgBIACAAIAQAAIACABIgBABIgRAaIgBABIAAAAIAVA2IAAACIgCAAg");
	this.shape_2.setTransform(83.0375,61.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A575").s().p("AgVAmQgIgIAAgNIAAgiQAAgLAIgIQAIgIANAAQAOAAAIAIQAIAIAAALIAAAiQAAANgIAIQgIAGgOABQgNgBgIgGgAgHgXQgCADgBAGIAAAeQABAFACADQADAEAEAAQAFAAADgEQADgDAAgFIAAgeQAAgGgDgDQgDgEgFAAQgEAAgDAEg");
	this.shape_3.setTransform(75.475,62.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A575").s().p("AgVAmQgIgIAAgNIAAgiQAAgLAIgIQAIgIANAAQAOAAAIAIQAIAIAAALIAAAiQAAANgIAIQgIAGgOABQgNgBgIgGgAgHgXQgCADgBAGIAAAeQABAFACADQADAEAEAAQAFAAADgEQADgDAAgFIAAgeQAAgGgDgDQgDgEgFAAQgEAAgDAEg");
	this.shape_4.setTransform(68.125,62.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A575").s().p("AgHA7IgBAAIgBgCIAAhyIABgBIABgBIAPAAIACABIAAABIAAByIAAACIgCAAg");
	this.shape_5.setTransform(62.75,61.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A575").s().p("AgTAsIgBAAIgBgCIAAhSIABgCIABAAIAQAAIABAAIABACIAAAIIAAAAIABAAQABgFADgDQAEgDAGAAIAEAAIADACIABABIAAABIgDAQIgBABIgBAAIgEAAIgEAAQgFABgDAFQgCAEAAAGIAAAwIgBACIgBAAg");
	this.shape_6.setTransform(58.725,62.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A575").s().p("AgVAmQgIgIAAgNIAAghQAAgNAIgHQAIgIANAAQAOAAAIAIQAIAHAAANIAAAWIgBABIgBAAIglAAIAAAAIgBABIAAAIQABAFACADQADAEAEAAQAEAAADgDQACgCABgEIABgCIABAAIAQABIABABIABACQgCALgHAHQgIAGgNAAQgNgBgIgGgAgHgXQgCADgBAGIAAAHIABABIAAAAIASAAIABAAIAAgBIAAgHQAAgGgDgDQgCgEgFAAQgEAAgDAEg");
	this.shape_7.setTransform(52.175,62.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A575").s().p("AgIArIgBAAIgBgBIgVhSIAAgCIACAAIARAAIACAAIAAACIAKA2IAAAAIABAAIAKg2IAAgCIACAAIARAAIACABIAAABIgVBSIAAABIgCAAg");
	this.shape_8.setTransform(44.975,62.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("AgXA0QgIgJgBgOIAAg5QABgPAIgIQAJgJAOAAQAPAAAJAJQAIAIABAPIAAA5QgBAOgIAJQgJAJgPAAQgOAAgJgJgAgIgnQgEAEAAAGIAAA7QAAAGAEAEQADAEAFAAQAGAAADgEQAEgEAAgGIAAg7QAAgGgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_9.setTransform(37.475,61.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A575").s().p("AAMAsIgBAAIgBgCIAAg3QAAgGgDgEQgCgDgFAAQgEAAgCADQgDAEAAAGIAAA3IgBACIgBAAIgQAAIgBAAIgBgCIAAhSIABgBIABgBIAQAAIABABIABABIAAAEIAAAAIABAAQAEgEAEgCIAHgBQALAAAGAHQAGAIAAANIAAA5IgBACIgBAAg");
	this.shape_10.setTransform(106.875,44.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAghQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAWIgBABIgBABIglAAIAAAAIgBABIAAAHQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgCIABAAIAQABIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_11.setTransform(99.525,44.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A575").s().p("AAMA2QgHAAgFgBQgFgCgDgEQgDgFAAgIIAAgzIAAAAIAAgBIgHAAIgBAAIgBgCIAAgKIABgBIABgBIAHAAIAAAAIAAAAIAAgTIABgCIABAAIAOAAIABAAIABACIAAATIAAAAIABAAIAKAAIACABIABABIAAAKIgBACIgCAAIgKAAIgBABIAAAAIAAAsQAAAGACACQADACAEAAIABAAIACABIAAABIAAANIAAACIgCAAg");
	this.shape_12.setTransform(93.4,43.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A575").s().p("AgJA8IgCgBIAAgBIAAhFIAAgBIgBAAIgGAAIgBgBIgBgBIAAgKIABgCIABAAIAGAAIABAAIAAgBIAAgEQAAgQAHgGQAGgGAPAAIABAAIACABIAAABIAAAMIAAABIgBABIgCAAQgFAAgCADQgDADAAAHIAAADIABABIAAAAIALAAIABAAIABACIAAAKIgBABIgBABIgLAAIAAAAIgBABIAABFIAAABIgCABg");
	this.shape_13.setTransform(88.525,42.9732);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A575").s().p("AgXA0QgIgIgBgQIAAg4QABgOAIgJQAJgJAOAAQAPAAAJAJQAIAJABAOIAAA4QgBAQgIAIQgJAJgPAAQgOAAgJgJgAgIgnQgEAEAAAGIAAA7QAAAGAEAEQADAEAFAAQAGAAADgEQAEgEAAgGIAAg7QAAgGgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_14.setTransform(82.125,43);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A575").s().p("AgVAmQgHgHgBgLIAAgBIABgBIABgBIAPAAIABAAIABABIAAACQAAAEAEADQADACADAAQAEAAADgCQACgDAAgEQAAgDgCgCIgFgEIgHgDIgKgFQgGgDgDgFQgDgEgBgJQAAgMAIgHQAHgGANgBQANABAIAHQAHAGABANIgCABIgBAAIgOAAIgBAAIgBgBIAAgBQAAgEgDgDQgDgDgEAAQgDAAgDADQgDADAAAEQAAADADACQABACAEACIAGADIALAGQAFABAEAGQAFAEAAAJQgBALgHAHQgJAGgNAAQgMAAgJgGg");
	this.shape_15.setTransform(71.45,44.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A575").s().p("AgHA8IgBgBIgBgBIAAhyIABgCIABAAIAPAAIABAAIABACIAAByIgBABIgBABg");
	this.shape_16.setTransform(66.1,43);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A575").s().p("AALA2QgGAAgFgBQgFgCgCgEQgDgFAAgIIAAgzIgBAAIgBgBIgFAAIgCAAIAAgCIAAgKIAAgBIACgBIAFAAIABAAIABAAIAAgTIAAgCIACAAIANAAIACAAIABACIAAATIAAAAIAAAAIALAAIABABIAAABIAAAKIAAACIgBAAIgLAAIAAABIAAAAIAAAsQAAAGACACQACACAEAAIACAAIABABIAAABIAAANIAAACIgBAAg");
	this.shape_17.setTransform(58.35,43.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A575").s().p("AgQArQgGgCgEgGQgEgFAAgLQAAgLAEgGQAFgFAHgDQAIgCAIAAIAJAAIAAgBIABAAIAAgFQAAgGgDgDQgDgDgFgBQgDAAgCACQgCADgBAEIgBABIgBAAIgRAAIgBAAIAAgBQABgMAIgHQAIgGALgBQAJABAHACQAHAEAEAHQADAGAAAIIAAA6IAAABIgCABIgPAAIgCgBIAAgBIAAgEIgBAAIAAAAQgDAEgFACQgDABgGAAQgFAAgFgCgAgGAJQgEADAAAGQAAAFADADQADADAEgBQAEAAAEgCQADgEABgFIAAgKIgBgBIAAAAIgJAAQgFgBgDAEg");
	this.shape_18.setTransform(52.225,44.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A575").s().p("AAMA8IgBgBIgBgBIAAg5QAAgFgDgEQgCgDgFAAQgEAAgCADQgDAEAAAFIAAA5IgBABIgBABIgQAAIgBgBIgBgBIAAhyIABgCIABAAIAQAAIABAAIABACIAAAjIAAABIABgBQAEgEAEgCIAHgBQALAAAGAIQAGAHAAANIAAA6IgBABIgBABg");
	this.shape_19.setTransform(44.975,43);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A575").s().p("AgIA8IgBgBIgBgBIAAhiIAAgBIgBAAIgUAAIgBgBIgBgCIAAgMIABgCIABAAIA+AAIACAAIABACIAAAMIgBACIgCABIgVAAIgBAAIAAABIAABiIgBABIgBABg");
	this.shape_20.setTransform(37.375,43);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(31.5,30.3,132.7,43.60000000000001), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgkBLIgCAAIgBgCIAAiRIABgCIACAAIAZAAIACAAIABACIAAB4IAAABIABAAIAsAAIACABIABACIAAAVIgBACIgCAAg");
	this.shape.setTransform(125.45,20.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AAVBLIgCAAIgBgCIgDgVIgBAAIgBgBIgaAAIAAAAIgBABIgEAVIgBACIgBAAIgaAAIgCAAIAAgDIAgiQIABgCIACAAIAcAAIACAAIAAACIAgCQIAAADIgCAAgAAAgcIgJA3IAAABIABAAIARAAIABgBIAAAAIgJg3IAAAAIgBAAg");
	this.shape_1.setTransform(115.175,20.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgMBLIgCgBIgBgCIAAg3IAAgBIAAgBIgdhWIAAgDIABAAIAbAAIACAAIABACIANAzIAAABIABgBIANgzIABgCIACAAIAbAAIACAAIAAADIgeBWIgBABIAAABIAAA3IgBACIgCABg");
	this.shape_2.setTransform(104.7,20.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgfBBQgMgLAAgUIAAhEQAAgTAMgMQAMgLATAAQANAAAKAFQAJAFAGAKQAFAJABANIAABEQgBANgFAKQgGAKgJAFQgKAFgNAAQgTAAgMgMgAgJguQgDAEAAAHIAABHQAAAHADAEQAEAEAFAAQAGAAADgEQAEgEAAgHIAAhHQAAgHgEgEQgDgEgGAAQgFAAgEAEg");
	this.shape_3.setTransform(94.55,20.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgkBLIgCAAIgBgCIAAiRIABgCIACAAIAZAAIACAAIABACIAAB4IAAABIABAAIAsAAIACABIAAACIAAAVIAAACIgCAAg");
	this.shape_4.setTransform(85.15,20.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgVBIQgJgFgFgJQgFgJgBgLIAAgHIABgCIACgBIAZAAIACABIAAACIAAAFQABAHADAEQADAEAEAAQAGAAADgEQADgEAAgGQAAgFgCgDIgHgIIgLgJIgPgMQgIgGgFgJQgFgJAAgMQAAgMAFgJQAFgJAKgFQAJgFAMAAQASAAAMALQALALAAATIAAAFIAAACIgCABIgZAAIgCgBIgBgCIAAgGQAAgGgDgEQgDgEgFAAQgFAAgDAEQgDADAAAHQAAAEACAEQABAEAFAEIALAJQALAIAIAGQAHAHAEAHQAEAIAAALQAAAMgFAKQgFAJgKAFQgJAFgNAAQgLAAgKgFg");
	this.shape_5.setTransform(75.475,20.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMBLIgCAAIAAgCIAAiRIAAgCIACAAIAYAAIACAAIABACIAACRIgBACIgCAAg");
	this.shape_6.setTransform(68.125,20.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgnBLIgCAAIAAgCIAAiRIAAgCIACAAIAnAAQATAAAMALQALALAAATIAABDQAAATgLALQgMALgTAAgAgLgvIAABfIAAABIABAAIAKAAQAFAAADgFQAEgEAAgIIAAg/QAAgIgDgFQgEgEgFAAIgKAAIgBAAIAAABg");
	this.shape_7.setTransform(60.575,20.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgVBIQgJgFgFgJQgFgJgBgLIAAgHIABgCIACgBIAZAAIACABIAAACIAAAFQABAHADAEQADAEAEAAQAGAAADgEQADgEAAgGQAAgFgCgDIgHgIIgLgJIgPgMQgIgGgFgJQgFgJAAgMQAAgMAFgJQAFgJAKgFQAJgFAMAAQASAAAMALQALALAAATIAAAFIAAACIgCABIgZAAIgCgBIgBgCIAAgGQAAgGgDgEQgDgEgFAAQgFAAgDAEQgDADAAAHQAAAEACAEQABAEAFAEIALAJQALAIAIAGQAHAHAEAHQAEAIAAALQAAAMgFAKQgFAJgKAFQgJAFgNAAQgLAAgKgFg");
	this.shape_8.setTransform(46.325,20.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgMBLIgCAAIAAgCIAAiRIAAgCIACAAIAYAAIACAAIABACIAACRIgBACIgCAAg");
	this.shape_9.setTransform(38.975,20.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAQBLIgCAAIgBgCIgbhQIAAAAIgBAAIAABQIAAACIgCAAIgZAAIgCAAIgBgCIAAiRIABgCIACAAIAbAAIACAAIABACIAbBPIAAABIABgBIAAhPIABgCIABAAIAZAAIACAAIABACIAACRIgBACIgCAAg");
	this.shape_10.setTransform(106.475,-1.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgfBBQgLgLAAgUIAAhEQAAgTALgMQAMgLATAAQANAAAJAFQALAFAFAKQAGAJgBANIAABEQABANgGAKQgFAKgLAFQgJAFgNAAQgTAAgMgMgAgJguQgDAEAAAHIAABHQAAAHADAEQAEAEAFAAQAGAAAEgEQADgEAAgHIAAhHQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_11.setTransform(95.85,-1.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgVBIQgJgFgFgJQgFgJgBgLIAAgHIABgCIACgBIAZAAIACABIAAACIAAAFQABAHADAEQADAEAEAAQAGAAADgEQADgEAAgGQAAgFgCgDIgHgIIgLgJIgPgMQgIgGgFgJQgFgJAAgMQAAgMAFgJQAFgJAKgFQAJgFAMAAQASAAAMALQALALAAATIAAAFIAAACIgCABIgZAAIgCgBIgBgCIAAgGQAAgGgDgEQgDgEgFAAQgFAAgDAEQgDADAAAHQAAAEACAEQABAEAFAEIALAJQALAIAIAGQAHAHAEAHQAEAIAAALQAAAMgFAKQgFAJgKAFQgJAFgNAAQgLAAgKgFg");
	this.shape_12.setTransform(85.975,-1.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AAQBLIgCAAIgBgCIgQg7IAAgBIgBAAIgHAAIgBAAIAAABIAAA7IgBACIgCAAIgZAAIgCAAIgBgCIAAiQIABgCIACgCIAqAAQAMABAKAFQAJAGAFALQAFAKAAANQAAANgFAJQgFAJgJAGIAAABIAAAAIAUBAIgBABIgBABgAgMgvIAAAlIAAABIABAAIAJAAQAGgBAEgFQAEgFAAgIQAAgKgEgFQgEgFgGAAIgJAAIgBAAIAAABg");
	this.shape_13.setTransform(76.325,-1.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgkBLIgCAAIgBgCIAAiRIABgCIACAAIBJAAIACAAIABACIAAAVIgBACIgCABIgsAAIgBAAIAAABIAAAiIAAAAIABABIAYAAIADABIAAABIAAAUIAAACIgDABIgYAAIgBAAIAAABIAAAiIAAABIABAAIAsAAIACABIABACIAAAVIgBACIgCAAg");
	this.shape_14.setTransform(66.5,-1.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgnBLIgCAAIgBgCIAAiQIABgCIACgCIAqAAQAMABAJAFQAJAHAFAKQAFAKAAAOQAAATgKALQgLAMgSAAIgPAAIAAABIgBABIAAA5IAAACIgCAAgAgMgvIAAAmIABABIAAAAIAKAAQAGAAAEgFQAEgGAAgJQAAgKgEgFQgEgFgGAAIgKAAIAAAAIgBABg");
	this.shape_15.setTransform(56.775,-1.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAVBLIgCAAIgBgCIgDgVIgBAAIgBgBIgaAAIAAAAIgBABIgEAVIgBACIgBAAIgaAAIgCAAIAAgDIAgiQIABgCIACAAIAcAAIACAAIAAACIAgCQIAAADIgCAAgAAAgcIgJA3IAAABIABAAIARAAIABgBIAAAAIgJg3IAAAAIgBAAg");
	this.shape_16.setTransform(41.875,-1.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAQBLIgCAAIgBgCIgbhQIAAAAIgBAAIAABQIAAACIgCAAIgZAAIgCAAIgBgCIAAiRIABgCIACAAIAbAAIACAAIABACIAbBPIAAABIABgBIAAhPIABgCIABAAIAZAAIACAAIABACIAACRIgBACIgCAAg");
	this.shape_17.setTransform(147.025,-23.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgeBCQgMgLAAgTIAAhHQAAgTAMgLQALgLATAAQANAAAJAFQAKAFAFAJQAGAJAAANIAAAIIgBACIgCABIgZAAIgCgBIAAgCIAAgJQgBgGgDgEQgDgEgGAAQgFAAgDAEQgDAEgBAGIAABIQABAHADAEQADAEAFAAQAGAAADgEQADgEABgHIAAgRIgBAAIAAgBIgKAAIgCgBIAAgBIAAgSIAAgCIACgBIAmAAIACABIABACIAAAmQAAANgGAJQgFAJgKAFQgJAFgNAAQgTAAgLgLg");
	this.shape_18.setTransform(136.525,-23.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgMBLIgCAAIAAgCIAAiRIAAgCIACAAIAYAAIACAAIABACIAACRIgBACIgCAAg");
	this.shape_19.setTransform(129.025,-23.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgVBIQgJgFgFgJQgFgJgBgLIAAgHIABgCIACgBIAZAAIACABIAAACIAAAFQABAHADAEQADAEAEAAQAGAAADgEQADgEAAgGQAAgFgCgDIgHgIIgLgJIgPgMQgIgGgFgJQgFgJAAgMQAAgMAFgJQAFgJAKgFQAJgFAMAAQASAAAMALQALALAAATIAAAFIAAACIgCABIgZAAIgCgBIgBgCIAAgGQAAgGgDgEQgDgEgFAAQgFAAgDAEQgDADAAAHQAAAEACAEQABAEAFAEIALAJQALAIAIAGQAHAHAEAHQAEAIAAALQAAAMgFAKQgFAJgKAFQgJAFgNAAQgLAAgKgFg");
	this.shape_20.setTransform(121.775,-23.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgVBIQgJgFgFgJQgFgJgBgLIAAgHIABgCIACgBIAZAAIACABIAAACIAAAFQABAHADAEQADAEAEAAQAGAAADgEQADgEAAgGQAAgFgCgDIgHgIIgLgJIgPgMQgIgGgFgJQgFgJAAgMQAAgMAFgJQAFgJAKgFQAJgFAMAAQASAAAMALQALALAAATIAAAFIAAACIgCABIgZAAIgCgBIgBgCIAAgGQAAgGgDgEQgDgEgFAAQgFAAgDAEQgDADAAAHQAAAEACAEQABAEAFAEIALAJQALAIAIAGQAHAHAEAHQAEAIAAALQAAAMgFAKQgFAJgKAFQgJAFgNAAQgLAAgKgFg");
	this.shape_21.setTransform(107.825,-23.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgeBAQgMgMAAgVIAAhoIABgCIACAAIAZAAIACAAIABACIAABsQAAAHADAEQADAEAFAAQAFAAAEgEQAEgEAAgHIAAhsIAAgCIACAAIAZAAIACAAIABACIAABoQAAAOgGAKQgFAKgJAFQgKAGgNAAQgTAAgLgMg");
	this.shape_22.setTransform(97.8,-23.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgfBBQgMgLAAgUIAAhEQAAgTAMgMQAMgLATAAQANAAAKAFQAKAFAFAKQAFAJAAANIAABEQAAANgFAKQgFAKgKAFQgKAFgNAAQgTAAgMgMgAgJguQgDAEAAAHIAABHQAAAHADAEQAEAEAFAAQAGAAADgEQAEgEAAgHIAAhHQAAgHgEgEQgDgEgGAAQgFAAgEAEg");
	this.shape_23.setTransform(87.55,-23.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgMBLIgCAAIAAgCIAAiRIAAgCIACAAIAYAAIACAAIABACIAACRIgBACIgCAAg");
	this.shape_24.setTransform(79.975,-23.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNBLIgCAAIgBgCIgeiRIAAgCIACAAIAcAAIABAAIABACIAOBeIABABIAAgBIAPheIABgCIACAAIAbAAIABAAIAAACIgeCRIgBACIgCAAg");
	this.shape_25.setTransform(72.3,-23.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgoBLIgCAAIAAgCIAAiRIAAgCIACAAIAkAAQANAAAKAEQALAFAFAJQAGAJAAAOQAAALgEAHQgDAIgIAFIAAAAIAAABQAIAEAEAJQAFAJAAAMQAAAOgFAJQgGAKgKAFQgKAEgMAAgAgMAKIAAAmIAAABIABAAIAKAAQAGAAAEgFQAEgFAAgKQAAgJgEgGQgEgFgGAAIgKAAIgBAAIAAABgAgMgvIAAAiIAAAAIABABIAIAAQAGAAAEgFQAEgFAAgIQAAgJgEgFQgEgEgGAAIgIAAIgBAAIAAABg");
	this.shape_26.setTransform(62.175,-23.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgfBBQgLgLAAgUIAAhEQAAgTALgMQAMgLATAAQANAAAJAFQALAFAFAKQAGAJgBANIAABEQABANgGAKQgFAKgLAFQgJAFgNAAQgTAAgMgMgAgIguQgEAEgBAHIAABHQABAHAEAEQADAEAFAAQAGAAAEgEQADgEAAgHIAAhHQAAgHgDgEQgEgEgGAAQgFAAgDAEg");
	this.shape_27.setTransform(51.85,-23.675);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgDBLIgBAAIgBgCIAAh2IAAgBIgBAAIgPADIgCAAIAAgCIAAgTIAAgBIABgCIAQgHIABAAIACAAIAZAAIABAAIABACIAACRIgBACIgBAAg");
	this.shape_28.setTransform(39.25,-23.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(35.2,-38.6,124.2,74), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(0,0,401,56), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAyAAIAAAQIgiAAIAAARIAfAAIAAAPIgfAAIAAATIAjAAIAAAQg");
	this.shape.setTransform(97.35,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOAqIgQgdIgNAAIAAAdIgQAAIAAhTIAgAAQAMAAAIAIQAJAJgBALQABAIgFAFQgEAHgIADIATAggAgPgBIAQAAQAFABADgEQAEgEAAgFQAAgFgEgEQgDgDgFgBIgQAAg");
	this.shape_1.setTransform(90.6,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAfQgNgNAAgSQAAgSANgMQANgNARAAQASAAANANQANAMAAASQAAASgNANQgNANgSAAQgRAAgNgNgAgSgTQgIAIAAALQAAAMAIAHQAIAJAKgBQAMABAHgJQAIgHAAgMQAAgLgIgIQgHgHgMgBQgKABgIAHg");
	this.shape_2.setTransform(81.85,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAYAqIAAg1IgXAlIgBAAIgXglIAAA1IgRAAIAAhTIARAAIAXAoIAYgoIARAAIAABTg");
	this.shape_3.setTransform(72.2,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUAqIgjgzIAAAzIgRAAIAAhTIANAAIAjAyIAAgyIARAAIAABTg");
	this.shape_4.setTransform(60.25,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAqIgQgdIgNAAIAAAdIgQAAIAAhTIAhAAQALAAAIAIQAIAJAAALQAAAIgEAFQgEAHgIADIATAggAgPgBIARAAQAEABAEgEQADgEAAgFQAAgFgDgEQgEgDgEgBIgRAAg");
	this.shape_5.setTransform(52.85,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAWAqIgFgPIghAAIgFAPIgSAAIAehTIATAAIAeBTgAgLALIAWAAIgLghg");
	this.shape_6.setTransform(44.875,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAyAAIAAAQIgiAAIAAARIAfAAIAAAPIgfAAIAAATIAjAAIAAAQg");
	this.shape_7.setTransform(37.95,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAqIAAhTIAQAAIAABDIAfAAIAAAQg");
	this.shape_8.setTransform(31.975,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("ApSCWQgyAAAAgyIAAjHQAAgyAyAAISlAAQAyAAAAAyIAADHQAAAygyAAg");
	this.shape_9.setTransform(64.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,129,30), null);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0,0,600,500), null);


// stage content:
(lib._300x250TFHTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_787 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(787).call(this.frame_787).wait(1));

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-338.9,-135.3,-123.7,-51.5).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape.setTransform(150.8,179.875);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-313.7,-128.9,-98.6,-45.1).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_1.setTransform(150.8,179.875);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-288.6,-122.4,-73.4,-38.6).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_2.setTransform(150.8,179.875);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-263.4,-116,-48.3,-32.2).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_3.setTransform(150.8,179.875);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-238.3,-109.6,-23.1,-25.8).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_4.setTransform(150.8,179.875);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-213.2,-103.2,2,-19.4).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_5.setTransform(150.8,179.875);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-188,-96.8,27.1,-13).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_6.setTransform(150.8,179.875);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-162.9,-90.4,52.3,-6.6).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_7.setTransform(150.8,179.875);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-137.7,-84,77.4,-0.2).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_8.setTransform(150.8,179.875);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-112.6,-77.6,102.6,6.2).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_9.setTransform(150.8,179.875);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-87.4,-71.1,127.7,12.7).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_10.setTransform(150.8,179.875);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-62.3,-64.7,152.9,19.1).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_11.setTransform(150.8,179.875);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-37.1,-58.3,178,25.5).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_12.setTransform(150.8,179.875);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-12,-51.9,203.2,31.9).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_13.setTransform(150.8,179.875);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],13.2,-45.5,228.3,38.3).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_14.setTransform(150.8,179.875);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],38.3,-39.1,253.4,44.7).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_15.setTransform(150.8,179.875);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],63.4,-32.7,278.6,51.1).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_16.setTransform(150.8,179.875);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],88.6,-26.3,303.7,57.5).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_17.setTransform(150.8,179.875);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],113.7,-19.9,328.9,63.9).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_18.setTransform(150.8,179.875);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],138.9,-13.5,354,70.3).s().p("AwiDnQg0AAAAg1IAAljQAAg1A0AAMAhEAAAQA2AAAAA1IAAFjQAAA1g2AAg");
	this.shape_19.setTransform(150.8,179.875);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(187).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(188).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(19));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(189).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(18));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(190).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(191).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(192).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(15));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(193).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(194).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(13));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(195).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(196).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(197).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(198).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(199).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(200).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(201).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(202).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(203).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(204).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(205).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(206).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(226).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(1));

	// Слой_3
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(150.7,215.6,1.7785,1.7785,0,0,0,64.5,15.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(170).to({_off:false},0).to({y:180,alpha:1},17,cjs.Ease.get(1)).wait(70).to({y:144.45,alpha:0},11,cjs.Ease.get(-1)).to({_off:true},1).wait(170).to({_off:false,y:215.6},0).to({y:180,alpha:1},17,cjs.Ease.get(1)).wait(70).to({y:144.45,alpha:0},11,cjs.Ease.get(-1)).to({_off:true},1).wait(170).to({_off:false,y:215.6},0).to({y:180,alpha:1},17,cjs.Ease.get(1)).wait(63));

	// logo
	this.instance_1 = new lib.logo_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150.8,113.05,0.6222,0.6222,0,0,0,199.6,27.7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(159).to({_off:false},0).to({regY:27.5,y:88.05,alpha:1},17,cjs.Ease.get(1)).wait(74).to({regY:27.7,y:63.25,alpha:0},11,cjs.Ease.get(-1)).to({_off:true},1).wait(166).to({_off:false,y:113.05},0).to({regY:27.5,y:88.05,alpha:1},17,cjs.Ease.get(1)).wait(74).to({regY:27.7,y:63.25,alpha:0},11,cjs.Ease.get(-1)).to({_off:true},1).wait(166).to({_off:false,y:113.05},0).to({regY:27.5,y:88.05,alpha:1},17,cjs.Ease.get(1)).wait(74));

	// Слой_5
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_20.setTransform(150,125);
	this.shape_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(159).to({_off:false},0).to({_off:true},110).wait(159).to({_off:false},0).to({_off:true},110).wait(159).to({_off:false},0).wait(91));

	// Слой_6
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3F3F3F").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_21.setTransform(150,125);
	this.shape_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(159).to({_off:false},0).to({_off:true},110).wait(159).to({_off:false},0).to({_off:true},110).wait(159).to({_off:false},0).wait(91));

	// Слой_7
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_22.setTransform(150,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.043)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_23.setTransform(150,125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.086)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_24.setTransform(150,125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.129)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_25.setTransform(150,125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.173)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_26.setTransform(150,125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.216)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_27.setTransform(150,125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.263)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_28.setTransform(150,125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.306)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_29.setTransform(150,125);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.349)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_30.setTransform(150,125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.392)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_31.setTransform(150,125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.435)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_32.setTransform(150,125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.478)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_33.setTransform(150,125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.522)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_34.setTransform(150,125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.565)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_35.setTransform(150,125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.608)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_36.setTransform(150,125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.651)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_37.setTransform(150,125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.694)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_38.setTransform(150,125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.737)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_39.setTransform(150,125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.784)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_40.setTransform(150,125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.827)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_41.setTransform(150,125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.871)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_42.setTransform(150,125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.914)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_43.setTransform(150,125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.957)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_44.setTransform(150,125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_45.setTransform(150,125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3F3F3F").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_46.setTransform(150,125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(63,63,63,0.859)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_47.setTransform(150,125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(63,63,63,0.714)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_48.setTransform(150,125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(63,63,63,0.573)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_49.setTransform(150,125);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(63,63,63,0.427)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_50.setTransform(150,125);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(63,63,63,0.286)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_51.setTransform(150,125);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(63,63,63,0.141)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_52.setTransform(150,125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(63,63,63,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_53.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_22}]},136).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},102).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[]},1).to({state:[{t:this.shape_22}]},136).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},102).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[]},1).to({state:[{t:this.shape_22}]},136).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).wait(91));

	// t1.1
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-8.45,131.5,1.9155,1.9155);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-33.95,alpha:1},15,cjs.Ease.get(1)).wait(50).to({scaleX:1.4991,scaleY:1.4991,x:-41.6,y:92.4},16,cjs.Ease.get(1)).to({_off:true},78).wait(110).to({_off:false,scaleX:1.9155,scaleY:1.9155,x:-8.45,y:131.5,alpha:0},0).to({x:-33.95,alpha:1},15,cjs.Ease.get(1)).wait(50).to({scaleX:1.4991,scaleY:1.4991,x:-41.6,y:92.4},16,cjs.Ease.get(1)).to({_off:true},78).wait(110).to({_off:false,scaleX:1.9155,scaleY:1.9155,x:-8.45,y:131.5,alpha:0},0).to({x:-33.95,alpha:1},15,cjs.Ease.get(1)).wait(50).to({scaleX:1.4991,scaleY:1.4991,x:-41.6,y:92.4},16,cjs.Ease.get(1)).to({_off:true},78).wait(91));

	// t1.2
	this.instance_3 = new lib.t12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(164.7,155.45,1.5537,1.5537,0,0,0,131.4,15.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({y:121.45,alpha:1},16,cjs.Ease.get(1)).to({_off:true},78).wait(175).to({_off:false,y:155.45,alpha:0},0).to({y:121.45,alpha:1},16,cjs.Ease.get(1)).to({_off:true},78).wait(175).to({_off:false,y:155.45,alpha:0},0).to({y:121.45,alpha:1},16,cjs.Ease.get(1)).to({_off:true},78).wait(91));

	// bg-2
	this.instance_4 = new lib.bg2_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(175.5,125,0.5,0.5,0,0,0,300,250);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(81).to({_off:false},0).to({x:150,alpha:1},20,cjs.Ease.get(1)).to({_off:true},58).wait(191).to({_off:false,x:175.5,alpha:0},0).to({x:150,alpha:1},20,cjs.Ease.get(1)).to({_off:true},58).wait(191).to({_off:false,x:175.5,alpha:0},0).to({x:150,alpha:1},20,cjs.Ease.get(1)).to({_off:true},58).wait(91));

	// Слой_15
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#F8F8F8").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_54.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape_54).wait(788));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,125,175.5,125);
// library properties:
lib.properties = {
	id: '307B5D341DDBB5459CF568EEF0A1BE55',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/300x250TFHTML5_atlas_.png", id:"300x250TFHTML5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['307B5D341DDBB5459CF568EEF0A1BE55'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;