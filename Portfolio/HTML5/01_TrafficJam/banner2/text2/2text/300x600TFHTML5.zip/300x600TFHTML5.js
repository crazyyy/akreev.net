(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x600TFHTML5_atlas_", frames: [[0,0,300,206]]}
];


// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,1200);


(lib.logo = function() {
	this.initialize(ss["300x600TFHTML5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A575").s().p("AgWA1QgHgIAAgMIAAgiQAAgNAHgHQAFgHAMAAIAGABQAFABADAEIABAAIAAAAIAAgjIABgCIACAAIAPAAIACAAIAAACIAAByIAAABIgCABIgPAAIgCgBIgBgBIAAgDIAAgBIgBABQgDADgFACIgGABQgMAAgFgHgAgHgIQgDADAAAFIAAAfQAAAFADAEQADADAEAAQAEAAADgDQADgEAAgFIAAgfQAAgFgDgDQgDgDgEAAQgEAAgDADg");
	this.shape.setTransform(152.35,81.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAghQAAgNAIgHQAIgHANgBQAOABAIAHQAIAHAAANIAAAWIgBABIgBABIglAAIAAAAIgBAAIAAAIQABAGACADQADADAEAAQAEAAADgDQACgCABgEIABgCIABAAIAQABIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgCgFgBQgEABgDACg");
	this.shape_1.setTransform(145.125,83.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A575").s().p("AANA8IgBgBIgBgBIgMgmIAAgCIgBABIgIAMIAAABIAAAAIAAAaIgBABIgBABIgQAAIgBgBIgBgBIAAhzIABgBIABAAIAQAAIABAAIABABIAAA8IAAABIABgBIARgcIABgBIACgBIAQAAIACABIgBACIgRAaIgBABIAAAAIAVA2IAAACIgCABg");
	this.shape_2.setTransform(137.9875,81.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAgiQAAgMAIgHQAIgHANgBQAOABAIAHQAIAHAAAMIAAAiQAAANgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAGACADQADADAEAAQAFAAADgDQADgDAAgGIAAgfQAAgFgDgEQgDgCgFgBQgEABgDACg");
	this.shape_3.setTransform(130.425,83.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAgiQAAgMAIgHQAIgHANgBQAOABAIAHQAIAHAAAMIAAAiQAAANgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAGACADQADADAEAAQAFAAADgDQADgDAAgGIAAgfQAAgFgDgEQgDgCgFgBQgEABgDACg");
	this.shape_4.setTransform(123.075,83.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A575").s().p("AgHA8IgCgBIAAgBIAAhzIAAgBIACAAIAPAAIABAAIABABIAABzIgBABIgBABg");
	this.shape_5.setTransform(117.7,81.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A575").s().p("AgTAsIgBgBIgBgBIAAhSIABgBIABgBIAQAAIABABIABABIAAAIIAAAAIABAAQABgFADgDQAEgDAGAAIAEABIADABIABABIAAABIgDAQIgBABIgBAAIgEAAIgEAAQgFABgDAFQgCAEAAAHIAAAvIgBABIgBABg");
	this.shape_6.setTransform(113.675,83.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAghQAAgNAIgHQAIgHANgBQAOABAIAHQAIAHAAANIAAAWIgBABIgBABIglAAIAAAAIgBAAIAAAIQABAGACADQADADAEAAQAEAAADgDQACgCABgEIABgCIABAAIAQABIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgCgFgBQgEABgDACg");
	this.shape_7.setTransform(107.125,83.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A575").s().p("AgIArIgBAAIgBgBIgVhSIAAgCIACgBIARAAIACABIAAACIAKA2IAAABIABgBIAKg2IAAgCIACgBIARABIACAAIAAACIgVBSIAAABIgCAAg");
	this.shape_8.setTransform(99.925,83.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("AgXA0QgIgIgBgPIAAg5QABgOAIgJQAJgJAOAAQAPAAAJAJQAIAJABAOIAAA5QgBAPgIAIQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAGIAAA7QAAAGAEAEQADAEAFAAQAGAAADgEQAEgEAAgGIAAg7QAAgGgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_9.setTransform(92.425,81.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A575").s().p("AAMAsIgBAAIgBgCIAAg3QAAgGgDgEQgCgDgFAAQgEAAgCADQgDAEAAAGIAAA3IgBACIgBAAIgQAAIgBAAIgBgCIAAhSIABgBIABgBIAQAAIABABIABABIAAAEIAAAAIABAAQAEgEAEgCIAHgBQALAAAGAHQAGAIAAANIAAA5IgBACIgBAAg");
	this.shape_10.setTransform(157.125,65.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAVIgBACIgBABIglAAIAAAAIgBABIAAAHQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQABIABAAIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_11.setTransform(149.775,65.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A575").s().p("AAMA2QgIAAgEgBQgFgCgCgEQgEgFAAgIIAAgzIAAAAIgBgBIgFAAIgCAAIgBgCIAAgKIABgBIACgBIAFAAIABAAIAAAAIAAgTIABgCIACAAIANAAIABAAIABACIAAATIAAAAIABAAIALAAIABABIABABIAAAKIgBACIgBAAIgLAAIgBABIAAAAIAAAsQABAGACACQACACAEAAIACAAIABABIABABIAAANIgBACIgBAAg");
	this.shape_12.setTransform(143.65,64.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A575").s().p("AgJA8IgCgBIAAgBIAAhFIAAgBIgBAAIgGAAIgBgBIgBgBIAAgKIABgCIABAAIAGAAIABAAIAAgBIAAgEQAAgQAHgGQAGgGAPAAIABAAIACABIAAABIAAAMIAAABIgBABIgCAAQgFAAgCADQgDADAAAHIAAADIABABIAAAAIALAAIABAAIABACIAAAKIgBABIgBABIgLAAIAAAAIgBABIAABFIAAABIgCABg");
	this.shape_13.setTransform(138.775,63.4732);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A575").s().p("AgXA0QgIgIgBgQIAAg3QABgQAIgIQAJgJAOAAQAPAAAJAJQAIAIABAQIAAA3QgBAQgIAIQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAHIAAA5QAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAg5QAAgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_14.setTransform(132.375,63.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A575").s().p("AgVAmQgHgHgBgLIAAgBIABgBIACAAIAOAAIABAAIACABIAAABQAAAEADADQADADADgBQAFABACgDQACgDABgEQAAgDgCgCIgGgEIgIgDIgJgFQgFgDgEgFQgDgEAAgJQgBgMAIgHQAHgGANAAQANAAAHAHQAIAGABANIgBABIgCABIgOAAIgBgBIgBgBIAAgBQAAgEgDgDQgCgDgFAAQgDAAgDADQgCADAAAEQAAADACACQACACADACIAGADIALAGQAFABAFAGQAEAEAAAJQAAALgJAHQgHAGgOABQgMgBgJgGg");
	this.shape_15.setTransform(121.7,65.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A575").s().p("AgHA8IgCgBIAAgCIAAhxIAAgCIACgBIAPAAIABABIABACIAABxIgBACIgBABg");
	this.shape_16.setTransform(116.35,63.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A575").s().p("AALA2QgHAAgEgBQgFgCgDgEQgCgFAAgIIAAgzIgBAAIAAgBIgHAAIgBAAIAAgCIAAgKIAAgBIABgBIAHAAIAAAAIABAAIAAgTIAAgCIABAAIAOAAIACAAIAAACIAAATIAAAAIABAAIAKAAIACABIAAABIAAAKIAAACIgCAAIgKAAIgBABIAAAAIAAAsQAAAGACACQADACAEAAIABAAIACABIAAABIAAANIAAACIgCAAg");
	this.shape_17.setTransform(108.6,64.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A575").s().p("AgQArQgGgCgEgFQgEgGAAgLQAAgKAEgHQAFgFAHgDQAIgCAIAAIAJAAIAAAAIABgBIAAgFQAAgFgDgEQgDgEgFAAQgDAAgCACQgCADgBAEIgBABIgBABIgRAAIgBgBIAAgBQABgMAIgHQAIgGALgBQAJAAAHADQAHAEAEAGQADAHAAAJIAAA4IAAACIgCABIgPAAIgCgBIAAgCIAAgDIgBAAIAAAAQgDAEgFACQgDABgGAAQgFAAgFgCgAgGAJQgEADAAAGQAAAGADACQADACAEAAQAEAAAEgCQADgEABgFIAAgKIgBgBIAAgBIgJAAQgFAAgDAEg");
	this.shape_18.setTransform(102.475,65.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A575").s().p("AAMA8IgBgBIgBgCIAAg4QAAgFgDgEQgCgDgFAAQgEAAgCADQgDAEAAAFIAAA4IgBACIgBABIgQAAIgBgBIgBgCIAAhxIABgCIABgBIAQAAIABABIABACIAAAjIAAABIABgBQAEgEAEgCIAHgBQALAAAGAIQAGAHAAANIAAA5IgBACIgBABg");
	this.shape_19.setTransform(95.225,63.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A575").s().p("AgIA8IgBgBIgBgCIAAhiIAAgBIgBAAIgUAAIgBAAIgBgCIAAgMIABgCIABgBIA+AAIACABIABACIAAAMIgBACIgCAAIgVAAIgBAAIAAABIAABiIgBACIgBABg");
	this.shape_20.setTransform(87.625,63.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(51.1,50.8,142.4,43.60000000000001), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmBQIgCgCIgBgCIAAiYIABgCIACAAIAbAAIACAAIAAACIAAB/IABAAIAAABIAvAAIACABIABACIAAAVIgBACIgCACg");
	this.shape.setTransform(172.375,24.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWBQIgCgBIgBgCIgEgWIAAAAIgBgBIgbAAIgBABIgBAAIgEAWIgBACIgCABIgaAAIgCgBIgBgDIAiiYIABgCIACAAIAdAAIACAAIABACIAiCYIgBADIgCABgAAAgeIgKA6IABABIABAAIASAAIABAAIAAgBIgKg6IAAAAIgBAAg");
	this.shape_1.setTransform(161.525,24.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgMBQIgCgCIgBgCIAAg6IAAgBIAAgBIgghcQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIACAAIAcAAIACAAIABACIAOA2IAAAAIABAAIAOg2IABgCIACAAIAcAAIACAAIAAACIggBcIAAABIAAABIAAA6IgBACIgCACg");
	this.shape_2.setTransform(150.4792,24.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AggBFQgNgMAAgUIAAhIQAAgVANgMQAMgMAUAAQAOgBAKAGQAKAFAGAKQAGALAAAOIAABIQAAANgGAKQgGALgKAEQgKAHgOAAQgUgBgMgMgAgJgxQgEAFAAAHIAABLQAAAHAEAEQAEAFAFAAQAGAAAEgFQAEgEAAgHIAAhLQAAgHgEgFQgEgEgGAAQgFAAgEAEg");
	this.shape_3.setTransform(139.725,24.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgmBQIgCgCIgBgCIAAiYIABgCIACAAIAbAAIACAAIAAACIAAB/IABAAIAAABIAvAAIACABIABACIAAAVIgBACIgCACg");
	this.shape_4.setTransform(129.825,24.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWBMQgKgFgGgJQgEgKgBgMIAAgIIABgCIACAAIAaAAIACAAIABACIAAAGQAAAIADADQADAFAFAAQAGAAADgEQAEgEAAgHQAAgFgCgEQgDgDgEgFIgMgJIgRgNQgIgGgFgJQgGgKAAgNQAAgNAGgJQAFgKALgFQAJgGANABQATAAANAMQAMAMgBATIAAAFIAAACIgCABIgaAAIgCgBIgBgCIAAgGQAAgGgEgFQgDgEgFAAQgFAAgEAEQgDAEAAAHQAAAEACAEQACAFAFADIALAKQAMAJAIAGQAIAIAFAIQADAHAAAMQABANgGAKQgFAJgLAGQgKAFgNABQgMgBgKgFg");
	this.shape_5.setTransform(119.6,24.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgMBQIgCgCIgBgCIAAiYIABgCIACAAIAaAAIACAAIAAACIAACYIAAACIgCACg");
	this.shape_6.setTransform(111.85,24.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpBQIgCgCIgBgCIAAiYIABgCIACAAIApAAQAUgBAMAMQANAMAAAVIAABGQAAATgNAMQgMANgUAAgAgLgzIgBABIAABlIABAAIAAABIALAAQAFgBAEgEQADgFABgJIAAhCQAAgIgEgFQgEgFgGAAIgKAAIAAAAg");
	this.shape_7.setTransform(103.875,24.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWBMQgKgFgGgJQgFgKAAgMIAAgIIABgCIACAAIAaAAIACAAIABACIAAAGQAAAIAEADQADAFAEAAQAGAAAEgEQADgEAAgHQAAgFgCgEQgDgDgFgFIgLgJIgRgNQgIgGgFgJQgGgKABgNQgBgNAGgJQAFgKAKgFQAKgGANABQAUAAALAMQANAMAAATIAAAFIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgGgDgFQgEgEgFAAQgFAAgDAEQgEAEAAAHQAAAEACAEQACAFAEADIAMAKQAMAJAIAGQAIAIAEAIQAFAHAAAMQAAANgGAKQgGAJgKAGQgJAFgNABQgNgBgKgFg");
	this.shape_8.setTransform(88.85,24.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMBQIgCgCIgBgCIAAiYIABgCIACAAIAaAAIACAAIAAACIAACYIAAACIgCACg");
	this.shape_9.setTransform(81.05,24.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQBQIgBgBIgBgBIgdhVIgBgBIAAABIAABUIgBACIgBABIgbAAIgBgBIgBgCIAAiZIABgCIABgBIAdAAIACABIABACIAdBUIAAAAIAAAAIAAhUIABgCIACgBIAaAAIACABIACACIAACZIgCACIgCABg");
	this.shape_10.setTransform(161.7,0.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggBFQgNgMAAgVIAAhIQAAgUANgMQAMgMAUgBQAOABAKAFQAKAGAGAJQAGALAAANIAABIQAAAOgGAKQgGAKgKAGQgKAFgOAAQgUAAgMgMgAgJgwQgEAEAAAHIAABKQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIIAAhKQAAgHgEgEQgEgFgGAAQgFAAgEAFg");
	this.shape_11.setTransform(150.475,0.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgWBMQgKgFgGgJQgFgKAAgMIAAgHIABgCIACgBIAaAAIACABIABACIAAAFQAAAHAEAFQADAEAEAAQAGAAAEgEQADgEAAgHQAAgEgCgEQgDgFgFgDIgLgKIgRgNQgIgGgFgKQgGgJABgNQgBgNAGgKQAFgJAKgFQAKgFANgBQAUABALALQAMAMAAAUIAAAGIAAACIgCABIgaAAIgCgBIgBgCIAAgGQAAgIgDgDQgEgFgFAAQgFAAgDAEQgEAEAAAHQAAAEACAFQACADAEAFIAMAKQAMAIAIAHQAIAHAEAHQAEAJABAKQAAAOgGAKQgFAKgLAFQgKAGgMgBQgNABgKgGg");
	this.shape_12.setTransform(140.05,0.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AARBQIgCgBIgCgCIgQg+IgBgBIAAAAIgIAAIgBAAIAAABIAAA+IgBACIgCABIgaAAIgCgBIgBgCIAAiZIABgCIACgBIAsAAQANABAKAGQAJAGAGAKQAFALAAAOQAAAOgFAKQgFAJgJAGIgBABIAAABIAVBDIAAACIgCABgAgNgyIAAAAIAAAnIAAABIABAAIAKAAQAGAAAFgFQAEgGAAgJQAAgKgEgFQgFgGgGAAIgKAAIgBABg");
	this.shape_13.setTransform(129.825,0.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgmBQIgCgBIgBgCIAAiZIABgCIACgBIBNAAIACABIABACIAAAWIgBACIgCABIgvAAIAAAAIgBABIAAAkIABABIAAAAIAbAAIACABIAAACIAAAVIAAACIgCABIgbAAIAAAAIgBABIAAAkIABABIAAAAIAvAAIACABIABACIAAAWIgBACIgCABg");
	this.shape_14.setTransform(119.475,0.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgqBQIgCgBIgBgCIAAiZIABgCIACgBIAtAAQAMABAKAGQAKAGAFALQAGAKgBAPQAAAVgLAMQgLAMgSAAIgRAAIAAABIAAABIAAA8IgBACIgCABgAgMgyIAAAAIAAAoIAAABIAAAAIAKAAQAHAAAEgFQAEgFABgKQgBgLgEgFQgEgGgHAAIgKAAIAAABg");
	this.shape_15.setTransform(109.25,0.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAWBQIgCgBIgBgCIgEgWIAAgBIgBAAIgbAAIgBAAIgBABIgEAWIgBACIgCABIgaAAIgCgBIgBgCIAiiZIABgCIACgBIAdAAIACABIABACIAiCZIgBACIgCABgAAAgdIgKA5IABABIABAAIASAAIABAAIAAgBIgKg5IAAgBIgBABg");
	this.shape_16.setTransform(93.475,0.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AARBPIgCAAIgCgBIgchVIgBgBIAAABIAABUIgBACIgBAAIgaAAIgCAAIgBgCIAAiZIABgCIACgBIAcAAIACABIABACIAdBTIAAABIABgBIAAhTIABgCIABgBIAaAAIACABIABACIAACZIgBACIgCAAg");
	this.shape_17.setTransform(183.1,-22.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggBGQgMgMAAgUIAAhLQAAgVAMgLQAMgLAUgBQANABALAFQAKAFAFAKQAGAKAAANIAAAJIgBABIgCABIgaAAIgCgBIgBgBIAAgKQAAgGgEgEQgDgFgGAAQgFAAgEAFQgDAEAAAGIAABMQAAAHADAFQAEAEAFAAQAGAAADgEQAEgFAAgHIAAgSIAAgBIgBAAIgKAAIgCgBIAAgCIAAgSIAAgCIACgCIAoAAIACACIABACIAAAoQAAAOgGAJQgFAKgKAFQgLAGgNgBQgUAAgMgLg");
	this.shape_18.setTransform(172.025,-22.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgMBPIgCAAIgBgCIAAiZIABgCIACgBIAZAAIADABIAAACIAACZIAAACIgDAAg");
	this.shape_19.setTransform(164.1,-22.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWBMQgKgFgFgKQgGgJAAgMIAAgHIABgCIACgBIAaAAIACABIABACIAAAFQAAAHAEAFQADAEAEAAQAGAAAEgEQADgEAAgHQAAgEgCgEQgCgFgGgDIgLgKIgRgNQgIgGgFgKQgFgJAAgNQAAgNAFgKQAFgJAKgFQAKgFANgBQATABAMALQANAMAAAUIAAAGIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgIgDgDQgEgFgFAAQgFAAgDAEQgEAEAAAHQAAAEACAFQACADAEAFIAMAKQAMAIAIAHQAIAHAEAHQAFAJAAAKQgBAOgFAKQgGAKgKAFQgJAGgNgBQgNABgKgGg");
	this.shape_20.setTransform(156.45,-22.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgWBMQgKgFgFgKQgGgJAAgMIAAgHIABgCIACgBIAaAAIACABIABACIAAAFQAAAHADAFQADAEAFAAQAGAAADgEQAEgEAAgHQAAgEgDgEQgBgFgGgDIgLgKIgRgNQgIgGgFgKQgFgJAAgNQAAgNAFgKQAGgJAJgFQAKgFANgBQAUABALALQAMAMABAUIAAAGIgBACIgCABIgaAAIgCgBIgBgCIAAgGQAAgIgDgDQgEgFgFAAQgFAAgDAEQgEAEAAAHQAAAEACAFQACADAEAFIAMAKQAMAIAIAHQAIAHAEAHQAFAJAAAKQgBAOgFAKQgGAKgJAFQgKAGgNgBQgNABgKgGg");
	this.shape_21.setTransform(141.7,-22.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AggBEQgMgNAAgWIAAhuIAAgCIACgBIAbAAIACABIABACIAABxQAAAIADAFQAEAEAFAAQAGAAADgEQAEgFAAgIIAAhxIABgCIACgBIAaAAIACABIABACIAABuQAAAOgFALQgGAKgKAHQgKAFgOAAQgUAAgMgMg");
	this.shape_22.setTransform(131.1,-22.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AggBFQgNgMAAgVIAAhIQAAgUANgMQAMgMAUgBQAOABAKAFQAKAGAGAJQAGALAAANIAABIQAAAOgGAKQgGAKgKAGQgKAFgOAAQgUAAgMgMgAgJgwQgEAEAAAHIAABKQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIIAAhKQAAgHgEgEQgEgFgGAAQgFAAgEAFg");
	this.shape_23.setTransform(120.275,-22.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgMBPIgCAAIgBgCIAAiZIABgCIACgBIAaAAIABABIABACIAACZIgBACIgBAAg");
	this.shape_24.setTransform(112.3,-22.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgOBPIgCAAIgBgCIggiYIAAgDIACgBIAeAAIABABIABACIAPBjIABABIABgBIAPhjIABgCIACgBIAcAAIACABIAAADIggCYIgBACIgCAAg");
	this.shape_25.setTransform(104.1375,-22.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgqBPIgCAAIgBgCIAAiZIABgCIACgBIAmAAQAOAAAKAFQALAFAGAJQAGAKAAAPQAAALgEAIQgDAIgIAGIgBAAIABABQAIAFAFAJQAEAIABANQAAAPgGALQgGAKgLAEQgKAGgNgBgAgMAJIgBABIAAApIABABIAAAAIAKAAQAHAAAEgGQAEgFABgKQgBgKgEgGQgEgGgGAAIgLAAIAAAAgAgMgzIgBABIAAAkIABABIAAAAIAJAAQAGAAAFgFQAEgFAAgJQAAgJgEgFQgFgFgGAAIgJAAIAAAAg");
	this.shape_26.setTransform(93.525,-22.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AggBFQgNgMAAgVIAAhIQAAgUANgMQAMgMAUgBQAOABAKAFQAKAGAGAJQAGALAAANIAABIQAAAOgGAKQgGAKgKAGQgKAFgOAAQgUAAgMgMgAgJgwQgEAEAAAHIAABKQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIIAAhKQAAgHgEgEQgEgFgGAAQgFAAgEAFg");
	this.shape_27.setTransform(82.575,-22.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgDBPIgBAAIgBgCIAAh8IAAgBIgBAAIgQACIgCAAIgBgBIAAgUIABgCIABgCIAQgHIACgBIABAAIAbAAIACABIABACIAACZIgBACIgCAAg");
	this.shape_28.setTransform(69.3,-22.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(23.2,-38.5,209,78.2), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-63,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-63,0,300,206), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAyAAIAAAQIgiAAIAAARIAfAAIAAAPIgfAAIAAATIAjAAIAAAQg");
	this.shape.setTransform(97.35,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOAqIgQgdIgNAAIAAAdIgQAAIAAhTIAgAAQAMAAAIAIQAJAJgBALQABAIgFAFQgEAHgIADIATAggAgPgBIAQAAQAFABADgEQAEgEAAgFQAAgFgEgEQgDgDgFgBIgQAAg");
	this.shape_1.setTransform(90.6,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAfQgNgNAAgSQAAgSANgMQANgNARAAQASAAANANQANAMAAASQAAASgNANQgNANgSAAQgRAAgNgNgAgSgTQgIAIAAALQAAAMAIAHQAIAJAKgBQAMABAHgJQAIgHAAgMQAAgLgIgIQgHgHgMgBQgKABgIAHg");
	this.shape_2.setTransform(81.85,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAYAqIAAg1IgXAlIgBAAIgXglIAAA1IgRAAIAAhTIARAAIAXAoIAYgoIARAAIAABTg");
	this.shape_3.setTransform(72.2,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUAqIgjgzIAAAzIgRAAIAAhTIANAAIAjAyIAAgyIARAAIAABTg");
	this.shape_4.setTransform(60.25,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAqIgQgdIgNAAIAAAdIgQAAIAAhTIAhAAQALAAAIAIQAIAJAAALQAAAIgEAFQgEAHgIADIATAggAgPgBIARAAQAEABAEgEQADgEAAgFQAAgFgDgEQgEgDgEgBIgRAAg");
	this.shape_5.setTransform(52.85,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAWAqIgFgPIghAAIgFAPIgSAAIAehTIATAAIAeBTgAgLALIAWAAIgLghg");
	this.shape_6.setTransform(44.875,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAyAAIAAAQIgiAAIAAARIAfAAIAAAPIgfAAIAAATIAjAAIAAAQg");
	this.shape_7.setTransform(37.95,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAqIAAhTIAQAAIAABDIAfAAIAAAQg");
	this.shape_8.setTransform(31.975,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("ApSCWQgyAAAAgyIAAjHQAAgyAyAAISlAAQAyAAAAAyIAADHQAAAygyAAg");
	this.shape_9.setTransform(64.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,129,30), null);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0,0,600,1200), null);


// stage content:
(lib._300x600TFHTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_781 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(781).call(this.frame_781).wait(62));

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-294.9,-117.8,-107.7,-44.9).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape.setTransform(150,378.05);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-273,-112.2,-85.8,-39.3).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_1.setTransform(150,378.05);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-251.1,-106.6,-63.9,-33.7).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_2.setTransform(150,378.05);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-229.2,-101,-42,-28.1).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_3.setTransform(150,378.05);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-207.4,-95.5,-20.2,-22.6).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_4.setTransform(150,378.05);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-185.5,-89.9,1.7,-17).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_5.setTransform(150,378.05);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-163.6,-84.3,23.6,-11.4).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_6.setTransform(150,378.05);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-141.7,-78.7,45.5,-5.8).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_7.setTransform(150,378.05);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-119.8,-73.1,67.4,-0.2).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_8.setTransform(150,378.05);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-98,-67.6,89.2,5.3).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_9.setTransform(150,378.05);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-76.1,-62,111.1,10.9).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_10.setTransform(150,378.05);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-54.2,-56.4,133,16.5).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_11.setTransform(150,378.05);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-32.3,-50.8,154.9,22.1).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_12.setTransform(150,378.05);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-10.5,-45.2,176.7,27.7).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_13.setTransform(150,378.05);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],11.4,-39.7,198.6,33.2).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_14.setTransform(150,378.05);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],33.3,-34.1,220.5,38.8).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_15.setTransform(150,378.05);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],55.2,-28.5,242.4,44.4).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_16.setTransform(150,378.05);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],77.1,-22.9,264.3,50).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_17.setTransform(150,378.05);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],98.9,-17.4,286.1,55.5).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_18.setTransform(150,378.05);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],120.8,-11.8,308,61.1).s().p("AuYDJQgvABABgwIAAkzQgBgwAvABIcwAAQAwgBAAAwIAAEzQAAAwgwgBg");
	this.shape_19.setTransform(150,378.05);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(199).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(39));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(200).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(38));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(201).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(37));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(202).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(36));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(203).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(35));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(204).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(34));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(205).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(206).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(207).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(208).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(30));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(209).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(29));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(210).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(211).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(27));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(212).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(26));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(213).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(214).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(24));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(215).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(23));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(216).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(22));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(217).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(218).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(20));

	// Слой_3
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(150,409.1,1.548,1.548,0,0,0,64.5,15.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({y:378.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:342.15,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:409.15},0).to({y:378.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:342.15,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:409.15},0).to({y:378.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:342.15,alpha:0},12,cjs.Ease.get(-1)).wait(1));

	// logo
	this.instance_1 = new lib.logo_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(93.65,181.1,0.6485,0.6485,0,0,0,0.1,0.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(171).to({_off:false},0).to({y:145.05,alpha:1},17,cjs.Ease.get(0.99)).wait(73).to({y:109,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},8).wait(171).to({_off:false,y:181.1},0).to({y:145.05,alpha:1},17,cjs.Ease.get(0.99)).wait(73).to({y:109,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},8).wait(171).to({_off:false,y:181.1},0).to({y:145.05,alpha:1},17,cjs.Ease.get(0.99)).wait(73).to({y:109,alpha:0},12,cjs.Ease.get(-1)).wait(8));

	// Слой_7
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_20.setTransform(150,300);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.063)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_21.setTransform(149.975,300);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.125)").s().p("EgXbAu4MAAAhdvMAu2AAAMAAABdvg");
	this.shape_22.setTransform(149.95,300);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.188)").s().p("EgXaAu4MAAAhdvMAu1AAAMAAABdvg");
	this.shape_23.setTransform(149.9,300);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.251)").s().p("EgXaAu4MAAAhdvMAu1AAAMAAABdvg");
	this.shape_24.setTransform(149.875,300);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.314)").s().p("EgXaAu4MAAAhdvMAu0AAAMAAABdvg");
	this.shape_25.setTransform(149.85,300);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.376)").s().p("EgXZAu4MAAAhdvMAuzAAAMAAABdvg");
	this.shape_26.setTransform(149.825,300);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.439)").s().p("EgXZAu4MAAAhdvMAuzAAAMAAABdvg");
	this.shape_27.setTransform(149.775,300);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.502)").s().p("EgXZAu4MAAAhdvMAuzAAAMAAABdvg");
	this.shape_28.setTransform(149.75,300);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.561)").s().p("EgXYAu4MAAAhdvMAuxAAAMAAABdvg");
	this.shape_29.setTransform(149.725,300);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.624)").s().p("EgXYAu4MAAAhdvMAuxAAAMAAABdvg");
	this.shape_30.setTransform(149.7,300);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.686)").s().p("EgXYAu4MAAAhdvMAuxAAAMAAABdvg");
	this.shape_31.setTransform(149.65,300);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.749)").s().p("EgXXAu4MAAAhdvMAuvAAAMAAABdvg");
	this.shape_32.setTransform(149.625,300);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.812)").s().p("EgXXAu4MAAAhdvMAuvAAAMAAABdvg");
	this.shape_33.setTransform(149.6,300);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("EgXXAu4MAAAhdvMAuvAAAMAAABdvg");
	this.shape_34.setTransform(149.575,300);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.937)").s().p("EgXWAu4MAAAhdvMAutAAAMAAABdvg");
	this.shape_35.setTransform(149.525,300);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("EgXWAu4MAAAhdvMAutAAAMAAABdvg");
	this.shape_36.setTransform(149.5,300);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_37.setTransform(151,300);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FBFBFB").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_38.setTransform(151,300);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#EEEEEE").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_39.setTransform(151,300);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#DADADA").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_40.setTransform(151,300);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#BCBCBC").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_41.setTransform(151,300);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#979797").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_42.setTransform(151,300);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#696969").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_43.setTransform(151,300);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_44.setTransform(151,300);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.98)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_45.setTransform(151,300);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.918)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_46.setTransform(151,300);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.816)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_47.setTransform(151,300);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.675)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_48.setTransform(151,300);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.49)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_49.setTransform(151,300);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.267)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_50.setTransform(151,300);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("EgXlAu4MAAAhdvMAvLAAAMAAABdvg");
	this.shape_51.setTransform(151,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},155).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},102).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},155).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},102).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},155).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},102).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).wait(1));

	// t1.1
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-41.4,265.4,1.4991,1.4991);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-41.6,y:245.4,alpha:1},13,cjs.Ease.get(1)).wait(71).to({y:462.4},11,cjs.Ease.get(1)).to({_off:true},76).wait(110).to({_off:false,x:-41.4,y:265.4,alpha:0},0).to({x:-41.6,y:245.4,alpha:1},13,cjs.Ease.get(1)).wait(71).to({y:462.4},11,cjs.Ease.get(1)).to({_off:true},76).wait(110).to({_off:false,x:-41.4,y:265.4,alpha:0},0).to({x:-41.6,y:245.4,alpha:1},13,cjs.Ease.get(1)).wait(71).to({y:462.4},11,cjs.Ease.get(1)).to({_off:true},76).wait(110));

	// t1.2
	this.instance_3 = new lib.t12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(164.15,284.45,1.5537,1.5537,0,0,0,131.4,15.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:164.7,y:274.45,alpha:1},13,cjs.Ease.get(1)).wait(23).to({y:467.45},11,cjs.Ease.get(1)).to({_off:true},76).wait(158).to({_off:false,x:164.15,y:284.45,alpha:0},0).to({x:164.7,y:274.45,alpha:1},13,cjs.Ease.get(1)).wait(23).to({y:467.45},11,cjs.Ease.get(1)).to({_off:true},76).wait(158).to({_off:false,x:164.15,y:284.45,alpha:0},0).to({x:164.7,y:274.45,alpha:1},13,cjs.Ease.get(1)).wait(23).to({y:467.45},11,cjs.Ease.get(1)).to({_off:true},76).wait(110));

	// Слой_5
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1125.9,122.4,1125.9,334.4).s().p("A3WUPMAAAgodMAutAAAMAAAAodg");
	this.shape_52.setTransform(149.6,479.475);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1122.1,82.2,1122.1,273.9).s().p("A3SUFMAAAgoJMAulAAAMAAAAoJg");
	this.shape_53.setTransform(149.7,478.475);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1118.6,45.9,1118.6,219.2).s().p("A3OT8MAAAgn3MAudAAAMAAAAn3g");
	this.shape_54.setTransform(149.8,477.575);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1115.5,13.3,1115.5,170.3).s().p("A3LT0MAAAgnnMAuXAAAMAAAAnng");
	this.shape_55.setTransform(149.85,476.775);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1112.7,-15.5,1112.7,127).s().p("A3JTtMAAAgnZMAuTAAAMAAAAnZg");
	this.shape_56.setTransform(149.925,476.075);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1110.3,-40.3,1110.3,89.6).s().p("A3GTnMAAAgnMMAuOAAAMAAAAnMg");
	this.shape_57.setTransform(150,475.45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1108.3,-61.4,1108.3,57.9).s().p("A3EThMAAAgnBMAuKAAAMAAAAnBg");
	this.shape_58.setTransform(150.05,474.925);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1106.6,-78.6,1106.6,32).s().p("A3DTdMAAAgm5MAuGAAAMAAAAm5g");
	this.shape_59.setTransform(150.1,474.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1105.3,-92,1105.3,11.9).s().p("A3BTaMAAAgmzMAuDAAAMAAAAmzg");
	this.shape_60.setTransform(150.125,474.175);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1104.4,-101.6,1104.4,-2.6).s().p("A3BTXMAAAgmtMAuDAAAMAAAAmtg");
	this.shape_61.setTransform(150.15,473.95);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1103.8,-107.3,1103.8,-11.2).s().p("A3ATWMAAAgmrMAuBAAAMAAAAmrg");
	this.shape_62.setTransform(150.175,473.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],1103.6,-109.3,1103.6,-14.1).s().p("A3ATWMAAAgmqMAuBAAAMAAAAmqg");
	this.shape_63.setTransform(150.175,473.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_52}]},84).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[]},76).to({state:[{t:this.shape_52}]},194).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[]},76).to({state:[{t:this.shape_52}]},194).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[]},76).wait(110));

	// bg-2
	this.instance_4 = new lib.bg2_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,125,0.5,0.5,0,0,0,300,250);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(84).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},76).wait(194).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},76).wait(194).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},76).wait(110));

	// Слой_15
	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#333333").s().p("EgXgAu4MAAAhdvMAvBAAAMAAABdvg");
	this.shape_64.setTransform(150.475,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_64).to({_off:true},171).wait(110).to({_off:false},0).to({_off:true},171).wait(110).to({_off:false},0).to({_off:true},171).wait(110));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(143.2,300,163.40000000000003,309);
// library properties:
lib.properties = {
	id: '307B5D341DDBB5459CF568EEF0A1BE55',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/300x600TFHTML5_atlas_.png", id:"300x600TFHTML5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['307B5D341DDBB5459CF568EEF0A1BE55'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;