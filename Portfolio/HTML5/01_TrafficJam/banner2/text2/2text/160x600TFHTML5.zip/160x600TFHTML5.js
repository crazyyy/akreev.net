(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"160x600TFHTML5_atlas_", frames: [[0,0,300,206]]}
];


// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,1200);


(lib.logo = function() {
	this.initialize(ss["160x600TFHTML5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A575").s().p("AgXA1QgGgIAAgMIAAgiQAAgNAGgHQAHgHAKAAIAHABQAFABADAEIABAAIAAAAIAAgjIABgCIABAAIAQAAIABAAIABACIAAByIgBABIgBABIgQAAIgBgBIgBgBIAAgDIAAgBIgBABQgDADgFACIgHABQgKAAgHgHgAgHgIQgCADAAAFIAAAfQAAAFACAEQADADAEAAQAFAAADgDQACgEAAgFIAAgfQAAgFgCgDQgDgDgFAAQgEAAgDADg");
	this.shape.setTransform(96.35,77.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAghQAAgNAIgHQAIgHANgBQAOABAIAHQAIAHAAANIAAAWIgBABIgBAAIglAAIAAAAIgBABIAAAIQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgCIABAAIAQABIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgCgFgBQgEABgDACg");
	this.shape_1.setTransform(89.125,79.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A575").s().p("AANA7IgBAAIgBgBIgMgmIAAgCIgBABIgIAMIAAABIAAAAIAAAaIgBABIgBAAIgQAAIgBAAIgBgBIAAhzIABgBIABAAIAQAAIABAAIABABIAAA8IAAABIABgBIARgcIABgBIACgBIAQAAIACABIgBACIgRAaIgBABIAAAAIAVA2IAAACIgCAAg");
	this.shape_2.setTransform(81.9875,77.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAgiQAAgMAIgHQAIgHANgBQAOABAIAHQAIAHAAAMIAAAiQAAANgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAGACADQADADAEAAQAFAAADgDQADgDAAgGIAAgfQAAgFgDgEQgDgCgFgBQgEABgDACg");
	this.shape_3.setTransform(74.425,79.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAgiQAAgMAIgHQAIgHANgBQAOABAIAHQAIAHAAAMIAAAiQAAANgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAGACADQADADAEAAQAFAAADgDQADgDAAgGIAAgfQAAgFgDgEQgDgCgFgBQgEABgDACg");
	this.shape_4.setTransform(67.075,79.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A575").s().p("AgHA7IgCAAIAAgBIAAhzIAAgBIACAAIAPAAIABAAIABABIAABzIgBABIgBAAg");
	this.shape_5.setTransform(61.7,77.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A575").s().p("AgTAsIgBgBIgBgBIAAhSIABgBIABgBIAQAAIABABIABABIAAAIIAAAAIABAAQABgFADgDQAEgDAGAAIAEABIADABIABABIAAABIgDAQIgBABIgBAAIgEAAIgEAAQgFABgDAFQgCAEAAAHIAAAvIgBABIgBABg");
	this.shape_6.setTransform(57.675,79.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A575").s().p("AgVAlQgIgHAAgNIAAghQAAgNAIgHQAIgHANgBQAOABAIAHQAIAHAAANIAAAWIgBABIgBAAIglAAIAAAAIgBABIAAAIQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgCIABAAIAQABIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgCgFgBQgEABgDACg");
	this.shape_7.setTransform(51.125,79.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A575").s().p("AgIArIgBAAIgBgBIgVhSIAAgCIACgBIARAAIACABIAAACIAKA2IAAABIABgBIAKg2IAAgCIACgBIARABIACAAIAAACIgVBSIAAABIgCAAg");
	this.shape_8.setTransform(43.925,79.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("AgXA0QgIgIgBgPIAAg5QABgOAIgJQAJgJAOAAQAPAAAJAJQAIAJABAOIAAA5QgBAPgIAIQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAGIAAA7QAAAGAEAEQADAEAFAAQAGAAADgEQAEgEAAgGIAAg7QAAgGgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_9.setTransform(36.425,77.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A575").s().p("AAMAsIgBAAIgBgCIAAg3QAAgGgDgEQgCgDgFAAQgEAAgCADQgDAEAAAGIAAA3IgBACIgBAAIgQAAIgBAAIgBgCIAAhSIABgBIABgBIAQAAIABABIABABIAAAEIAAAAIABAAQAEgEAEgCIAHgBQALAAAGAHQAGAIAAANIAAA5IgBACIgBAAg");
	this.shape_10.setTransform(105.825,60.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgHANgBQAOABAIAHQAIAIAAAMIAAAVIgBACIgBABIglAAIAAAAIgBABIAAAHQABAGACADQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQABIABAAIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_11.setTransform(98.475,61.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A575").s().p("AAMA2QgIAAgEgBQgFgCgCgEQgEgFAAgIIAAgzIAAAAIgBgBIgFAAIgCAAIgBgCIAAgKIABgBIACgBIAFAAIABAAIAAAAIAAgTIABgCIACAAIANAAIABAAIABACIAAATIAAAAIABAAIALAAIABABIABABIAAAKIgBACIgBAAIgLAAIgBABIAAAAIAAAsQABAGACACQACACAEAAIACAAIABABIABABIAAANIgBACIgBAAg");
	this.shape_12.setTransform(92.35,59.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A575").s().p("AgJA8IgCgBIAAgBIAAhFIAAgBIgBAAIgGAAIgBgBIgBgBIAAgKIABgCIABAAIAGAAIABAAIAAgBIAAgEQAAgQAHgGQAGgGAPAAIABAAIACABIAAABIAAAMIAAABIgBABIgCAAQgFAAgCADQgDADAAAHIAAADIABABIAAAAIALAAIABAAIABACIAAAKIgBABIgBABIgLAAIAAAAIgBABIAABFIAAABIgCABg");
	this.shape_13.setTransform(87.475,59.4232);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A575").s().p("AgXA0QgIgIgBgQIAAg3QABgQAIgIQAJgJAOAAQAPAAAJAJQAIAIABAQIAAA3QgBAQgIAIQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAHIAAA5QAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAg5QAAgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_14.setTransform(81.075,59.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A575").s().p("AgVAmQgHgHgBgLIAAAAIABgCIACAAIAOAAIABAAIACABIAAABQAAAEADADQADADADgBQAFABACgDQACgDABgEQAAgDgCgCIgGgEIgIgDIgJgFQgFgDgEgFQgDgEAAgJQgBgMAIgHQAHgGANAAQANAAAHAHQAIAGABANIgBABIgCAAIgOAAIgBAAIgBgBIAAgBQAAgEgDgDQgCgDgFAAQgDAAgDADQgCADAAAEQAAADACACQACACADACIAGADIALAGQAFABAFAGQADAEAAAJQABALgJAHQgHAGgOABQgMgBgJgGg");
	this.shape_15.setTransform(70.4,61.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A575").s().p("AgHA8IgCgBIAAgCIAAhxIAAgCIACgBIAPAAIABABIABACIAABxIgBACIgBABg");
	this.shape_16.setTransform(65.05,59.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A575").s().p("AALA2QgHAAgEgBQgFgCgDgEQgCgFAAgIIAAgzIgBAAIAAgBIgHAAIgBAAIAAgCIAAgKIAAgBIABgBIAHAAIAAAAIABAAIAAgTIAAgCIABAAIAOAAIACAAIAAACIAAATIAAAAIABAAIAKAAIACABIAAABIAAAKIAAACIgCAAIgKAAIgBABIAAAAIAAAsQABAGABACQADACAEAAIABAAIACABIAAABIAAANIAAACIgCAAg");
	this.shape_17.setTransform(57.3,59.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A575").s().p("AgQArQgGgCgEgFQgEgGAAgLQAAgKAEgHQAFgFAHgDQAIgCAIAAIAJAAIAAAAIABgBIAAgFQAAgFgDgEQgDgEgFAAQgDAAgCADQgCACgBAEIgBABIgBABIgRAAIgBgBIAAgBQABgMAIgHQAIgGALgBQAJAAAHADQAHAEAEAGQADAHAAAIIAAA5IAAACIgCABIgPAAIgCgBIAAgCIAAgDIgBAAIAAAAQgDAEgFACQgDABgGAAQgFAAgFgCgAgGAJQgEADAAAGQAAAGADACQADACAEABQAEgBAEgCQADgEABgFIAAgKIgBgBIAAgBIgJAAQgFAAgDAEg");
	this.shape_18.setTransform(51.175,61.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A575").s().p("AAMA8IgBgBIgBgCIAAg4QAAgFgDgEQgCgDgFAAQgEAAgCADQgDAEAAAFIAAA4IgBACIgBABIgQAAIgBgBIgBgCIAAhxIABgCIABgBIAQAAIABABIABACIAAAjIAAABIABgBQAEgEAEgBIAHgCQALAAAGAIQAGAHAAANIAAA5IgBACIgBABg");
	this.shape_19.setTransform(43.925,59.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A575").s().p("AgIA8IgBgBIgBgCIAAhiIAAgBIgBAAIgUAAIgBAAIgBgCIAAgMIABgCIABgBIA+AAIACABIABACIAAAMIgBACIgCAAIgVAAIgBAAIAAABIAABiIgBACIgBABg");
	this.shape_20.setTransform(36.325,59.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(30.5,46.7,94.2,43.599999999999994), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AggBDIgCgBIAAgCIAAiAIAAgBIACgBIAWAAIACABIABABIAABrIAAAAIABABIAnAAIABAAIABACIAAASIgBACIgBABg");
	this.shape.setTransform(114.1,20.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AASBDIgBgBIgBgBIgDgTIAAAAIgBgBIgXAAIgBABIAAAAIgEATIAAABIgCABIgXAAIgBgBIAAgCIAciAIAAgBIACgBIAZAAIACABIAAABIAcCAIAAACIgCABgAAAgZIgIAxIAAAAIABABIAPAAIABgBIAAAAIgIgxIAAAAIgBAAg");
	this.shape_1.setTransform(104.9625,20.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKBDIgCgBIgBgCIAAgxIAAgBIAAgBIgahMIAAgCIABgBIAYAAIACABIABABIALAuIAAAAIABAAIALguIABgBIACgBIAYAAIABABIAAACIgaBMIgBABIAAABIAAAxIAAACIgCABg");
	this.shape_2.setTransform(95.675,20.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_3.setTransform(86.625,20.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggBDIgBgBIgBgCIAAiAIABgBIABgBIAWAAIACABIABABIAABrIAAAAIABABIAnAAIABAAIABACIAAASIgBACIgBABg");
	this.shape_4.setTransform(78.3,20.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_5.setTransform(69.725,20.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLBDIgBgBIAAgCIAAiAIAAgBIABgBIAWAAIACABIABABIAACAIgBACIgCABg");
	this.shape_6.setTransform(63.25,20.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgiBDIgCgBIAAgCIAAiAIAAgBIACgBIAiAAQARAAAKAKQAKAKAAARIAAA7QAAARgKAKQgKAKgRAAgAgJgqIAAAAIAABVIAAAAIABABIAIgBQAEAAAEgEQACgEAAgHIAAg3QAAgHgCgFQgEgEgEAAIgIAAIgBABg");
	this.shape_7.setTransform(56.55,20.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_8.setTransform(43.875,20.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgLBDIgBgBIgBgCIAAiAIABgBIABgBIAWAAIACABIABABIAACAIgBACIgCABg");
	this.shape_9.setTransform(37.35,20.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOBDIgCgBIgBgBIgXhHIAAAAIgBAAIAABGIgBACIgBABIgWAAIgCgBIAAgCIAAiAIAAgBIACgBIAYAAIACABIABABIAXBGIABABIAAgBIAAhGIABgBIACgBIAVAAIACABIABABIAACAIgBACIgCABg");
	this.shape_10.setTransform(97.25,0.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_11.setTransform(87.825,0.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_12.setTransform(79.075,0.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAOBDIgCAAIgBgCIgOg0IAAgBIAAAAIgHAAIgBAAIAAABIAAA0IgBACIgBAAIgXAAIgBAAIgBgCIAAiBIABgBIABgBIAmAAQALAAAIAGQAIAFAEAIQAFAKAAAMQAAALgEAJQgFAHgHAFIgBAAIAAABIASA5IgBACIgBAAgAgLgqIAAABIAAAgIAAAAIABABIAJAAQAFAAADgFQAEgEAAgIQAAgJgEgEQgDgFgFABIgJAAIgBAAg");
	this.shape_13.setTransform(70.475,0.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AggBDIgBgBIgBgCIAAiAIABgBIABgBIBAAAIACABIABABIAAATIgBACIgCAAIgmAAIgBABIAAAAIAAAeIAAABIABAAIAVAAIADABIAAACIAAARIAAACIgDAAIgVAAIgBABIAAAAIAAAfIAAAAIABABIAmAAIACAAIABACIAAASIgBACIgCABg");
	this.shape_14.setTransform(61.75,0.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgjBDIgCAAIgBgCIAAiBIABgBIACgBIAmAAQAKAAAIAGQAJAFAEAIQAEAKABAMQgBASgJAJQgJALgQAAIgOAAIAAAAIgBABIAAAzIAAACIgCAAgAgKgqIgBABIAAAhIABABIAAAAIAJAAQAFAAADgFQAFgEAAgIQAAgJgFgFQgDgFgFABIgJAAIAAAAg");
	this.shape_15.setTransform(53.2,0.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AASBDIgBgBIgBgBIgDgTIAAAAIgBgBIgXAAIgBABIAAAAIgEATIAAABIgCABIgXAAIgBgBIAAgCIAciAIAAgBIACgBIAZAAIACABIAAABIAcCAIAAACIgCABgAAAgZIgIAxIAAAAIABABIAPAAIABgBIAAAAIgIgxIAAAAIgBAAg");
	this.shape_16.setTransform(39.9125,0.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAOBDIgCgBIgBgBIgXhHIgBAAIAAAAIAABGIgBACIgBABIgWAAIgCgBIgBgCIAAiAIABgBIACgBIAYAAIABABIABABIAYBGIAAABIABgBIAAhGIABgBIACgBIAVAAIACABIAAABIAACAIAAACIgCABg");
	this.shape_17.setTransform(61.85,-18.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgbA7QgJgKgBgRIAAg/QABgRAJgKQALgJAQAAQALAAAJAEQAJAEAEAJQAFAIAAALIAAAHIAAACIgCAAIgWAAIgCAAIgBgCIAAgIQAAgFgDgEQgDgDgFAAQgEAAgDADQgDAEAAAFIAABAQAAAGADAEQADADAEAAQAFAAADgDQADgEAAgGIAAgPIAAgBIAAAAIgJAAIgCgBIAAgBIAAgQIAAgCIACAAIAiAAIACAAIAAACIAAAiQAAALgFAIQgEAIgJAFQgJAEgLAAQgQAAgLgJg");
	this.shape_18.setTransform(52.55,-18.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKBDIgCgBIAAgCIAAiAIAAgBIACgBIAVAAIABABIACABIAACAIgCACIgBABg");
	this.shape_19.setTransform(45.95,-18.725);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_20.setTransform(39.475,-18.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgSBAQgJgFgEgHQgFgIAAgLIAAgGIABgBIACgBIAVAAIACABIABABIAAAFQAAAGADAEQADADADAAQAFAAADgDQADgDAAgGQAAgEgCgDQgCgEgEgDIgKgIIgOgLQgGgFgFgIQgEgIAAgLQAAgLAEgIQAFgIAIgEQAIgEALAAQAQAAAKAKQAKAJABARIAAAFIgBABIgCABIgWAAIgBgBIgBgBIAAgFQAAgGgDgEQgDgDgEAAQgEAAgDADQgDADAAAGQAAAEACADQABAEAEADIAKAJIARAMQAGAGAEAGQADAHAAAKQAAALgEAIQgFAIgIAFQgJAEgLAAQgKAAgIgEg");
	this.shape_21.setTransform(98.475,-38.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgaA5QgLgLAAgSIAAhdIABgBIABAAIAXAAIABAAIABABIAABgQAAAGADAEQADADAEAAQAFAAADgDQADgEAAgGIAAhgIABgBIABAAIAXAAIABAAIABABIAABdQAAAMgFAJQgFAJgIAEQgJAGgLAAQgQAAgKgLg");
	this.shape_22.setTransform(89.575,-38.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_23.setTransform(80.475,-38.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgKBDIgCgBIgBgCIAAiAIABgBIACgBIAVAAIABABIABABIAACAIgBACIgBABg");
	this.shape_24.setTransform(73.75,-38.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgMBDIgBgBIgBgBIgbiAIAAgCIABgBIAZAAIACABIABABIAMBTIABABIAAgBIANhTIABgBIACgBIAXAAIACABIAAACIgcCAIAAABIgCABg");
	this.shape_25.setTransform(66.9,-38.425);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgjBDIgCgBIAAgCIAAiAIAAgBIACgBIAgAAQALAAAJAEQAJAEAFAIQAFAIAAANQAAAJgDAHQgDAHgGAEIgBABIAAAAQAHAEAEAIQAEAHAAALQABANgGAIQgEAIgJAFQgJAEgLAAgAgKAJIAAAiIAAAAIABAAIAIAAQAFAAAEgEQADgEAAgJQAAgJgDgEQgEgFgFAAIgIAAIgBAAIAAABgAgKgqIAAAAIAAAeIAAABIABAAIAGAAQAGAAAEgEQADgEAAgIQAAgHgDgFQgEgEgGAAIgGAAIgBABg");
	this.shape_26.setTransform(57.9271,-38.425);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgbA6QgKgKgBgSIAAg8QABgRAKgKQAKgKARAAQAMAAAIAEQAJAFAFAIQAEAJABALIAAA8QgBAMgEAJQgFAIgJAFQgIAEgMAAQgRAAgKgKgAgIgpQgDAEAAAGIAAA/QAAAGADADQADAEAFAAQAFAAADgEQAEgDAAgGIAAg/QAAgGgEgEQgDgDgFAAQgFAAgDADg");
	this.shape_27.setTransform(48.775,-38.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgCBDIgBgBIgBgCIAAhoIAAgBIgBAAIgNADIgCAAIgBgCIAAgQIABgCIABgBIAOgGIABgBIABAAIAWAAIACABIABABIAACAIgBACIgCABg");
	this.shape_28.setTransform(37.575,-38.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(34,-51.7,110.19999999999999,85.4), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-63,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-63,0,300,206), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAyAAIAAAQIgiAAIAAARIAfAAIAAAPIgfAAIAAATIAjAAIAAAQg");
	this.shape.setTransform(97.35,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOAqIgQgdIgNAAIAAAdIgQAAIAAhTIAgAAQAMAAAIAIQAJAJgBALQABAIgFAFQgEAHgIADIATAggAgPgBIAQAAQAFABADgEQAEgEAAgFQAAgFgEgEQgDgDgFgBIgQAAg");
	this.shape_1.setTransform(90.6,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAfQgNgNAAgSQAAgSANgMQANgNARAAQASAAANANQANAMAAASQAAASgNANQgNANgSAAQgRAAgNgNgAgSgTQgIAIAAALQAAAMAIAHQAIAJAKgBQAMABAHgJQAIgHAAgMQAAgLgIgIQgHgHgMgBQgKABgIAHg");
	this.shape_2.setTransform(81.85,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAYAqIAAg1IgXAlIgBAAIgXglIAAA1IgRAAIAAhTIARAAIAXAoIAYgoIARAAIAABTg");
	this.shape_3.setTransform(72.2,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUAqIgjgzIAAAzIgRAAIAAhTIANAAIAjAyIAAgyIARAAIAABTg");
	this.shape_4.setTransform(60.25,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAqIgQgdIgNAAIAAAdIgQAAIAAhTIAhAAQALAAAIAIQAIAJAAALQAAAIgEAFQgEAHgIADIATAggAgPgBIARAAQAEABAEgEQADgEAAgFQAAgFgDgEQgEgDgEgBIgRAAg");
	this.shape_5.setTransform(52.85,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAWAqIgFgPIghAAIgFAPIgSAAIAehTIATAAIAeBTgAgLALIAWAAIgLghg");
	this.shape_6.setTransform(44.875,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAyAAIAAAQIgiAAIAAARIAfAAIAAAPIgfAAIAAATIAjAAIAAAQg");
	this.shape_7.setTransform(37.95,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAqIAAhTIAQAAIAABDIAfAAIAAAQg");
	this.shape_8.setTransform(31.975,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("ApSCWQgyAAAAgyIAAjHQAAgyAyAAISlAAQAyAAAAAyIAADHQAAAygyAAg");
	this.shape_9.setTransform(64.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,129,30), null);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0,0,320,1200), null);


// stage content:
(lib._160x600TFHTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_781 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(781).call(this.frame_781).wait(1));

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-204.6,-81.7,-74.7,-31.1).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape.setTransform(80.825,338.625);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-189.4,-77.8,-59.5,-27.2).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_1.setTransform(80.825,338.625);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-174.2,-73.9,-44.3,-23.3).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_2.setTransform(80.825,338.625);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-159,-70.1,-29.1,-19.5).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_3.setTransform(80.825,338.625);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-143.8,-66.2,-13.9,-15.6).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_4.setTransform(80.825,338.625);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-128.7,-62.3,1.2,-11.7).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_5.setTransform(80.825,338.625);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-113.5,-58.4,16.4,-7.8).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_6.setTransform(80.825,338.625);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-98.3,-54.6,31.6,-4).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_7.setTransform(80.825,338.625);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-83.1,-50.7,46.8,-0.1).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_8.setTransform(80.825,338.625);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-67.9,-46.8,62,3.8).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_9.setTransform(80.825,338.625);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-52.8,-43,77.1,7.6).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_10.setTransform(80.825,338.625);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-37.6,-39.1,92.3,11.5).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_11.setTransform(80.825,338.625);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-22.4,-35.2,107.5,15.4).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_12.setTransform(80.825,338.625);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-7.3,-31.4,122.6,19.2).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_13.setTransform(80.825,338.625);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],7.9,-27.5,137.8,23.1).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_14.setTransform(80.825,338.625);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],23.1,-23.7,153,26.9).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_15.setTransform(80.825,338.625);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],38.3,-19.8,168.2,30.8).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_16.setTransform(80.825,338.625);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],53.5,-15.9,183.4,34.7).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_17.setTransform(80.825,338.625);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],68.6,-12,198.5,38.6).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_18.setTransform(80.825,338.625);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],83.8,-8.2,213.7,42.4).s().p("Ap+CMQggAAAAghIAAjVQAAghAgAAIT9AAQAgAAAAAhIAADVQAAAhggAAg");
	this.shape_19.setTransform(80.825,338.625);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(199).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(200).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(19));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(201).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(18));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(202).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(203).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(204).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(15));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(205).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(206).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(13));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(207).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(208).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(209).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(210).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(211).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(212).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(213).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(214).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(215).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(216).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(217).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(218).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(1));

	// Слой_3
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(80.75,360.2,1.0741,1.0741,0,0,0,64.5,15.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({y:338.7,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:313.7,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:360.2},0).to({y:338.7,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:313.7,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:360.2},0).to({y:338.7,alpha:1},17,cjs.Ease.get(1)).wait(21));

	// logo
	this.instance_1 = new lib.logo_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(40.85,202,0.45,0.45,0,0,0,0,0.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(171).to({_off:false},0).to({y:177,alpha:1},17,cjs.Ease.get(0.99)).wait(73).to({y:152,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},8).wait(171).to({_off:false,y:202},0).to({y:177,alpha:1},17,cjs.Ease.get(0.99)).wait(73).to({y:152,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},8).wait(171).to({_off:false,y:202},0).to({y:177,alpha:1},17,cjs.Ease.get(0.99)).wait(32));

	// Слой_7
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_20.setTransform(80,300);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.063)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_21.setTransform(80,300);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.125)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_22.setTransform(80,300);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.188)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_23.setTransform(80,300);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.251)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_24.setTransform(80,300);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.314)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_25.setTransform(80,300);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.376)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_26.setTransform(80,300);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.439)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_27.setTransform(80,300);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.502)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_28.setTransform(80,300);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.561)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_29.setTransform(80,300);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.624)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_30.setTransform(80,300);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.686)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_31.setTransform(80,300);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.749)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_32.setTransform(80,300);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.812)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_33.setTransform(80,300);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_34.setTransform(80,300);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.937)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_35.setTransform(80,300);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_36.setTransform(80,300);
	this.shape_36._off = true;

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.98)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_37.setTransform(80,300);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.918)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_38.setTransform(80,300);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.816)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_39.setTransform(80,300);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.675)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_40.setTransform(80,300);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.49)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_41.setTransform(80,300);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.267)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_42.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},155).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},102).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},155).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},102).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},155).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(155).to({_off:false},0).to({_off:true},1).wait(124).to({_off:false},0).to({_off:true},1).wait(155).to({_off:false},0).to({_off:true},1).wait(124).to({_off:false},0).to({_off:true},1).wait(155).to({_off:false},0).to({_off:true},1).wait(64));
	this.timeline.addTween(cjs.Tween.get(this.shape_36).wait(171).to({_off:false},0).wait(102).to({_off:true},1).wait(178).to({_off:false},0).wait(102).to({_off:true},1).wait(178).to({_off:false},0).wait(49));

	// t1.1
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-29.1,245.4,1.4991,1.4991);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-41.6,alpha:1},13,cjs.Ease.get(1)).wait(35).to({y:265.4},13,cjs.Ease.get(1)).wait(23).to({y:462.4},11,cjs.Ease.get(1)).to({_off:true},76).wait(110).to({_off:false,x:-29.1,y:245.4,alpha:0},0).to({x:-41.6,alpha:1},13,cjs.Ease.get(1)).wait(35).to({y:265.4},13,cjs.Ease.get(1)).wait(23).to({y:245.4},0).to({y:462.4},11,cjs.Ease.get(1)).to({_off:true},76).wait(110).to({_off:false,x:-29.1,y:245.4,alpha:0},0).to({x:-41.6,alpha:1},13,cjs.Ease.get(1)).wait(35).to({y:265.4},13,cjs.Ease.get(1)).wait(23).to({y:245.4},0).to({y:462.4},11,cjs.Ease.get(1)).to({_off:true},76).wait(49));

	// t1.2
	this.instance_3 = new lib.t12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(194.7,274.45,1.5537,1.5537,0,0,0,131.4,15.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:164.7,alpha:1},13,cjs.Ease.get(1)).wait(23).to({y:467.45},11,cjs.Ease.get(1)).to({_off:true},76).wait(158).to({_off:false,x:194.7,y:274.45,alpha:0},0).to({x:164.7,alpha:1},13,cjs.Ease.get(1)).wait(23).to({y:467.45},11,cjs.Ease.get(1)).to({_off:true},76).wait(158).to({_off:false,x:194.7,y:274.45,alpha:0},0).to({x:164.7,alpha:1},13,cjs.Ease.get(1)).wait(23).to({y:467.45},11,cjs.Ease.get(1)).to({_off:true},76).wait(49));

	// Слой_5
	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],602.3,122.4,602.3,334.4).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_43.setTransform(80.025,479.475);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],601.8,81.3,601.8,273.8).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_44.setTransform(80.025,479.475);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],601.3,44.2,601.3,219).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_45.setTransform(80.025,479.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],600.9,10.9,600.9,170).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_46.setTransform(80.025,479.475);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],600.5,-18.4,600.5,126.7).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_47.setTransform(80.025,479.475);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],600.2,-43.9,600.2,89.2).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_48.setTransform(80.025,479.475);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],599.9,-65.4,599.9,57.4).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_49.setTransform(80.025,479.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],599.7,-83,599.7,31.5).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_50.setTransform(80.025,479.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],599.5,-96.6,599.5,11.3).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_51.setTransform(80.025,479.475);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],599.4,-106.4,599.4,-3.1).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_52.setTransform(80.025,479.475);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],599.3,-112.3,599.3,-11.8).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_53.setTransform(80.025,479.475);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(22,21,27,0)","rgba(22,21,27,0.82)","#16151B"],[0,0.82,1],599.3,-114.3,599.3,-14.7).s().p("AsfUPMAAAgodIY/AAMAAAAodg");
	this.shape_54.setTransform(80.025,479.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_43}]},84).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[]},76).to({state:[{t:this.shape_43}]},194).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[]},76).to({state:[{t:this.shape_43}]},194).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[]},76).wait(49));

	// bg-2
	this.instance_4 = new lib.bg2_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,125,0.5,0.5,0,0,0,300,250);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(84).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},76).wait(194).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},76).wait(194).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},76).wait(49));

	// Слой_15
	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_55.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_55).to({_off:true},171).wait(110).to({_off:false},0).to({_off:true},171).wait(110).to({_off:false},0).to({_off:true},171).wait(49));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(80,300,107.1,309);
// library properties:
lib.properties = {
	id: '307B5D341DDBB5459CF568EEF0A1BE55',
	width: 160,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg2.jpg?1590409766606", id:"bg2"},
		{src:"images/160x600TFHTML5_atlas_.png?1590409766539", id:"160x600TFHTML5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['307B5D341DDBB5459CF568EEF0A1BE55'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;