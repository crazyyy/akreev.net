(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90TFHTML51_atlas_", frames: [[0,0,401,56]]}
];


// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.logo = function() {
	this.initialize(ss["728x90TFHTML51_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A575").s().p("AgXA1QgFgIgBgMIAAgiQABgNAFgHQAGgHAMAAIAHABQAEABADAEIABAAIAAAAIAAgjIABgCIABAAIAQAAIACAAIAAACIAAByIAAABIgCABIgQAAIgBgBIgBgBIAAgDIAAgBIgBABQgDADgEACIgHABQgMAAgGgHgAgGgIQgDADgBAFIAAAfQABAFADAEQACADAEAAQAEAAADgDQADgEAAgFIAAgfQAAgFgDgDQgDgDgEAAQgEAAgCADg");
	this.shape.setTransform(70.3,68.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgIANAAQAOAAAIAIQAIAIAAAMIAAAWIgBABIgBABIglAAIAAAAIgBABIAAAHQABAFACAEQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQAAIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_1.setTransform(63.075,70.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A575").s().p("AANA8IgBgBIgBgBIgMgnIAAgBIgBABIgIAMIAAABIAAAAIAAAaIgBABIgBABIgQAAIgBgBIgBgBIAAhyIABgCIABAAIAQAAIABAAIABACIAAA7IAAABIABgBIARgcIABgBIACgBIAQAAIACABIgBACIgRAaIgBAAIAAABIAVA2IAAACIgCABg");
	this.shape_2.setTransform(55.9375,68.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgIANAAQAOAAAIAIQAIAIAAAMIAAAiQAAAMgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAFACAEQADADAEAAQAFAAADgDQADgEAAgFIAAgfQAAgFgDgEQgDgDgFAAQgEAAgDADg");
	this.shape_3.setTransform(48.375,70.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgIANAAQAOAAAIAIQAIAIAAAMIAAAiQAAAMgIAHQgIAIgOAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAfQABAFACAEQADADAEAAQAFAAADgDQADgEAAgFIAAgfQAAgFgDgEQgDgDgFAAQgEAAgDADg");
	this.shape_4.setTransform(41.025,70.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A575").s().p("AgHA8IgBgBIgBgBIAAhyIABgCIABAAIAPAAIACAAIAAACIAAByIAAABIgCABg");
	this.shape_5.setTransform(35.65,68.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A575").s().p("AgTAsIgBgBIgBgBIAAhSIABgBIABgBIAQAAIABABIABABIAAAIIAAABIABgBQABgFADgDQAEgDAGAAIAEABIADABIABABIAAACIgDAPIgBACIgBAAIgEgBIgEAAQgFABgDAEQgCAFAAAHIAAAvIgBABIgBABg");
	this.shape_6.setTransform(31.625,70.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgIANAAQAOAAAIAIQAIAIAAAMIAAAWIgBABIgBABIglAAIAAAAIgBABIAAAHQABAFACAEQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQAAIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_7.setTransform(25.075,70.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A575").s().p("AgIAsIgBgBIgBgBIgVhSIAAgCIACgBIARAAIACABIAAABIAKA3IAAABIABgBIAKg3IAAgBIACgBIARABIACAAIAAACIgVBSIAAABIgCABg");
	this.shape_8.setTransform(17.875,70.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("AgXA0QgIgJgBgPIAAg4QABgOAIgJQAJgJAOAAQAPAAAJAJQAIAJABAOIAAA4QgBAPgIAJQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAHIAAA5QAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAg5QAAgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_9.setTransform(10.375,68.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A575").s().p("AAMAsIgBAAIgBgCIAAg3QAAgGgDgEQgCgDgFAAQgEAAgCADQgDAEAAAGIAAA3IgBACIgBAAIgQAAIgBAAIgBgCIAAhSIABgBIABgBIAQAAIABABIABABIAAAEIAAAAIABAAQAEgEAEgCIAHgBQALAAAGAHQAGAIAAANIAAA5IgBACIgBAAg");
	this.shape_10.setTransform(-0.675,70.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A575").s().p("AgVAlQgIgHAAgMIAAgiQAAgMAIgIQAIgIANAAQAOAAAIAIQAIAIAAAMIAAAWIgBABIgBABIglAAIAAAAIgBABIAAAHQABAFACAEQADADAEAAQAEAAADgCQACgDABgEIABgBIABAAIAQAAIABABIABABQgCAMgHAGQgIAHgNAAQgNAAgIgIgAgHgYQgCAEgBAFIAAAIIABAAIAAAAIASAAIABAAIAAAAIAAgIQAAgFgDgEQgCgDgFAAQgEAAgDADg");
	this.shape_11.setTransform(-8.025,70.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A575").s().p("AAMA2QgHAAgFgBQgFgCgDgEQgDgFAAgIIAAgzIAAAAIAAgBIgHAAIgBAAIgBgCIAAgKIABgBIABgBIAHAAIAAAAIAAAAIAAgTIABgCIABAAIAOAAIABAAIABACIAAATIAAAAIABAAIAKAAIACABIABABIAAAKIgBACIgCAAIgKAAIgBABIAAAAIAAAsQAAAGACACQADACAEAAIABAAIACABIAAABIAAANIAAACIgCAAg");
	this.shape_12.setTransform(-14.15,69.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A575").s().p("AgJA8IgCgBIAAgBIAAhFIAAgBIgBAAIgGAAIgBgBIgBgBIAAgKIABgCIABAAIAGAAIABAAIAAgBIAAgEQAAgQAHgGQAGgGAPAAIABAAIACABIAAABIAAAMIAAABIgBABIgCAAQgFAAgCADQgDADAAAHIAAADIABABIAAAAIALAAIABAAIABACIAAAKIgBABIgBABIgLAAIAAAAIgBABIAABFIAAABIgCABg");
	this.shape_13.setTransform(-19.025,68.5232);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A575").s().p("AgXA0QgIgJgBgPIAAg4QABgOAIgJQAJgJAOAAQAPAAAJAJQAIAJABAOIAAA4QgBAPgIAJQgJAIgPABQgOgBgJgIgAgIgnQgEAEAAAHIAAA5QAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAg5QAAgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_14.setTransform(-25.425,68.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A575").s().p("AgVAmQgHgHgBgLIAAgBIABgBIABAAIAPAAIABAAIABAAIAAACQAAAEAEADQADADADgBQAEABADgDQACgCAAgFQAAgDgCgCIgFgEIgHgDIgKgFQgGgDgDgFQgDgEgBgJQAAgMAIgHQAHgGANgBQANABAIAHQAHAGABANIgCABIgBAAIgOAAIgBAAIgBgBIAAgBQAAgFgDgCQgDgDgEAAQgDAAgDADQgDADAAAEQAAADADACQABACAEACIAGADIALAGQAFABAEAGQAFAEAAAJQgBAMgHAGQgJAGgNABQgMgBgJgGg");
	this.shape_15.setTransform(-36.1,70.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A575").s().p("AgHA8IgBgBIgBgBIAAhyIABgCIABAAIAPAAIABAAIABACIAAByIgBABIgBABg");
	this.shape_16.setTransform(-41.45,68.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A575").s().p("AALA2QgGAAgFgBQgFgCgCgEQgDgFAAgIIAAgzIgBAAIgBgBIgFAAIgCAAIAAgCIAAgKIAAgBIACgBIAFAAIABAAIABAAIAAgTIAAgCIACAAIANAAIACAAIABACIAAATIAAAAIAAAAIALAAIABABIAAABIAAAKIAAACIgBAAIgLAAIAAABIAAAAIAAAsQAAAGACACQACACAEAAIACAAIABABIAAABIAAANIAAACIgBAAg");
	this.shape_17.setTransform(-49.2,69.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A575").s().p("AgQArQgGgCgEgFQgEgGAAgLQAAgLAEgGQAFgFAHgDQAIgCAIAAIAJAAIAAAAIABgBIAAgFQAAgFgDgEQgDgDgFgBQgDAAgCACQgCADgBAEIgBABIgBABIgRAAIgBgBIAAgBQABgMAIgHQAIgGALgBQAJAAAHADQAHAEAEAGQADAHAAAIIAAA6IAAABIgCABIgPAAIgCgBIAAgBIAAgEIgBAAIAAAAQgDAEgFACQgDABgGAAQgFAAgFgCgAgGAJQgEADAAAGQAAAGADACQADADAEgBQAEAAAEgCQADgDABgGIAAgKIgBgBIAAAAIgJAAQgFAAgDADg");
	this.shape_18.setTransform(-55.325,70.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A575").s().p("AAMA8IgBgBIgBgBIAAg5QAAgFgDgEQgCgDgFAAQgEAAgCADQgDAEAAAFIAAA5IgBABIgBABIgQAAIgBgBIgBgBIAAhyIABgCIABAAIAQAAIABAAIABACIAAAjIAAABIABgBQAEgEAEgCIAHgBQALAAAGAIQAGAHAAANIAAA6IgBABIgBABg");
	this.shape_19.setTransform(-62.575,68.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A575").s().p("AgIA8IgBgBIgBgBIAAhiIAAgCIgBAAIgUAAIgBAAIgBgCIAAgMIABgCIABAAIA+AAIACAAIABACIAAAMIgBACIgCAAIgVAAIgBAAIAAACIAABiIgBABIgBABg");
	this.shape_20.setTransform(-70.175,68.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-94.5,55.8,189.1,25.299999999999997), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgkBNIgCgBIgBgCIAAiTIABgCIACgBIAZAAIACABIABACIAAB6IAAABIABAAIAtAAIACABIAAACIAAAVIAAACIgCABg");
	this.shape.setTransform(317.775,-125.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AAVBNIgCgBIgBgCIgDgVIgBAAIgBgBIgaAAIgBAAIAAABIgEAVIgBACIgCABIgaAAIgCgBIAAgCIAgiTIABgCIACgBIAdAAIACABIABACIAgCTIgBACIgCABgAAAgcIgJA3IAAABIABAAIASAAIAAAAIAAgBIgJg3IAAgBIgBABg");
	this.shape_1.setTransform(307.3125,-125.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgMBNIgCgBIAAgCIAAg5IAAgBIgBAAIgehYIAAgDIACgBIAbAAIACABIABACIANA0IAAABIABgBIANg0IABgCIACgBIAbAAIACABQAAABAAAAQABAAAAAAQAAABAAAAQAAAAAAABIgfBYIgBAAIAAABIAAA5IAAACIgCABg");
	this.shape_2.setTransform(296.6958,-125.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgfBCQgMgLAAgUIAAhFQAAgUAMgMQAMgLATgBQANABAKAFQAKAFAGAKQAFAKAAANIAABFQAAANgFAKQgGAJgKAGQgKAFgNABQgTgBgMgMgAgJgvQgDAEAAAIIAABHQAAAIADADQAEAEAFABQAGgBAEgEQADgDAAgIIAAhHQAAgIgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_3.setTransform(286.325,-125.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgkBNIgCgBIgBgCIAAiTIABgCIACgBIAZAAIACABIABACIAAB6IAAABIABAAIAtAAIACABIAAACIAAAVIAAACIgCABg");
	this.shape_4.setTransform(276.775,-125.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgVBJQgKgFgFgJQgFgJAAgMIAAgHIAAgCIADgBIAYAAIADABIABACIAAAGQgBAGAEAEQADAEAEABQAGgBADgDQADgEAAgHQAAgEgCgEQgCgDgFgFIgLgJIgQgMQgHgGgFgJQgFgJgBgMQAAgNAGgKQAFgIAKgFQAJgGAMAAQATAAALAMQAMALAAAUIAAAEIAAADIgDABIgYAAIgDgBIgBgDIAAgFQAAgHgCgEQgEgEgFAAQgFAAgDADQgDAFAAAHQAAAEACAEQACADAEAEIALAKQALAIAIAGQAIAHAEAIQAEAIAAAKQAAANgGAJQgFAKgJAFQgKAFgNABQgLgBgKgFg");
	this.shape_5.setTransform(266.9,-125.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgLBNIgCgBIgBgCIAAiTIABgCIACgBIAYAAIACABIABACIAACTIgBACIgCABg");
	this.shape_6.setTransform(259.45,-125.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgnBNIgCgBIgBgCIAAiTIABgCIACgBIAnAAQATABAMALQAMALAAAUIAABDQAAAUgMALQgMAMgTAAgAgLgxIAAABIAABhIAAABIABAAIAKAAQAFAAADgFQAEgFAAgIIAAg/QAAgIgDgFQgEgFgGAAIgJAAIgBAAg");
	this.shape_7.setTransform(251.775,-125.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgVBJQgKgFgFgJQgFgJAAgMIAAgHIAAgCIACgBIAaAAIABABIABACIAAAGQAAAGAEAEQADAEAFABQAFgBADgDQADgEABgHQgBgEgBgEQgDgDgFgFIgKgJIgQgMQgJgGgFgJQgFgJAAgMQAAgNAFgKQAGgIAJgFQAKgGAMAAQATAAAMAMQALALAAAUIAAAEIgBADIgCABIgZAAIgBgBIgBgDIAAgFQAAgHgDgEQgEgEgFAAQgFAAgDADQgDAFgBAHQAAAEACAEQADADAEAEIALAKQAMAIAHAGQAIAHAEAIQAEAIAAAKQAAANgFAJQgGAKgKAFQgJAFgMABQgNgBgJgFg");
	this.shape_8.setTransform(237.25,-125.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgMBNIgCgBIgBgCIAAiTIABgCIACgBIAZAAIACABIABACIAACTIgBACIgCABg");
	this.shape_9.setTransform(229.8,-125.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAQBNIgCgBIgBgBIgbhRIgBgBIAAABIAABQIgBACIgCABIgZAAIgCgBIAAgCIAAiTIAAgCIACgBIAcAAIABABIABACIAbBRIABAAIABgBIAAhQIABgCIACgBIAZAAIACABIABACIAACTIgBACIgCABg");
	this.shape_10.setTransform(368.75,-146.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgfBDQgMgMAAgUIAAhFQAAgUAMgLQAMgMATAAQANgBAKAGQAKAFAGAKQAFAKAAANIAABFQAAANgFAKQgGAJgKAGQgKAFgNAAQgTAAgMgLgAgJgvQgDAFAAAGIAABIQAAAHADAFQAEAEAFAAQAGAAAEgEQADgFAAgHIAAhIQAAgGgDgFQgEgEgGAAQgFAAgEAEg");
	this.shape_11.setTransform(357.925,-146.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgVBJQgKgFgFgJQgFgJAAgMIAAgGIAAgCIADgCIAYAAIADACIABACIAAAEQgBAHAEAFQADAEAEAAQAGgBADgDQADgEAAgHQAAgEgCgDQgCgFgFgDIgLgJIgQgNQgHgGgFgJQgFgJgBgNQAAgMAGgJQAFgKAKgFQAJgEAMAAQATgBALAMQAMAMAAASIAAAGIAAABIgDABIgYAAIgDgBIgBgBIAAgGQAAgHgCgEQgEgEgFAAQgFAAgDAEQgDAEAAAGQAAAFACADQACAFAEAEIALAJQALAIAIAGQAIAHAEAHQAEAJAAAKQAAANgGAKQgFAJgJAFQgKAFgNAAQgLAAgKgFg");
	this.shape_12.setTransform(347.9,-146.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AAQBNIgCgBIgBgBIgQg9IAAgBIgBAAIgIAAIAAABIgBAAIAAA8IAAACIgCABIgaAAIgCgBIgBgCIAAiTIABgCIACgBIArAAQANAAAJAGQAJAGAFAKQAFALAAANQAAAOgEAJQgFAJgJAGIgBAAIAAABIAUBBIAAACIgCABgAgMgxIgBABIAAAlIABABIAAAAIAKAAQAGAAAEgFQAEgFABgJQgBgKgEgFQgEgFgGAAIgKAAIAAAAg");
	this.shape_13.setTransform(338.0625,-146.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgkBNIgCgBIgBgCIAAiTIABgCIACgBIBKAAIACABIAAACIAAAVIAAACIgCABIgtAAIgBAAIAAABIAAAjIAAAAIABABIAZAAIACAAIABACIAAAVIgBACIgCAAIgZAAIgBABIAAAAIAAAjIAAABIABAAIAtAAIACABIAAACIAAAVIAAACIgCABg");
	this.shape_14.setTransform(328.025,-146.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgpBNIgCgBIAAgCIAAiTIAAgCIACgBIArAAQANAAAKAGQAIAGAFALQAGAKAAAOQgBAUgKALQgLANgSAAIgPAAIgBAAIAAABIAAA6IgBACIgCABgAgMgxIAAABIAAAnIAAAAIABABIAKAAQAFAAAEgGQAFgFAAgJQAAgKgFgGQgEgFgFAAIgKAAIgBAAg");
	this.shape_15.setTransform(318.2,-146.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAVBNIgCgBIgBgCIgDgVIgBAAIgBgBIgaAAIgBAAIAAABIgEAVIgBACIgCABIgaAAIgCgBIAAgCIAgiTIABgCIACgBIAdAAIACABIABACIAgCTIgBACIgCABgAAAgcIgJA3IAAABIABAAIASAAIAAAAIAAgBIgJg3IAAgBIgBABg");
	this.shape_16.setTransform(303.0125,-146.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAQBNIgCgBIgBgBIgbhRIgBgBIAAABIAABQIgBACIgCABIgZAAIgCgBIgBgCIAAiTIABgCIACgBIAcAAIACABIAAACIAbBRIABAAIABgBIAAhQIAAgCIADgBIAZAAIACABIABACIAACTIgBACIgCABg");
	this.shape_17.setTransform(287.55,-146.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgfBDQgLgLgBgTIAAhJQABgUALgKQAMgLATAAQANAAAKAEQAKAGAFAJQAFAKABAMIAAAIIgBACIgCABIgaAAIgCgBIAAgCIAAgJQAAgGgEgEQgDgEgGAAQgFAAgDAEQgEAEAAAGIAABKQAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHIAAgSIgBAAIAAgBIgKAAIgCgBIAAgBIAAgSIAAgCIACgBIAnAAIACABIABACIAAAnQgBANgFAJQgFAJgKAFQgKAFgNAAQgTAAgMgLg");
	this.shape_18.setTransform(276.875,-146.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLBNIgCgBIgCgCIAAiTIACgCIACgBIAYAAIACABIABACIAACTIgBACIgCABg");
	this.shape_19.setTransform(269.25,-146.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgVBJQgJgFgGgJQgFgJAAgMIAAgGIAAgCIADgCIAYAAIADACIABACIAAAEQgBAHAEAFQADAEAEAAQAGgBADgDQAEgEgBgHQAAgEgCgDQgCgFgFgDIgLgJIgQgNQgHgGgFgJQgGgJAAgNQAAgMAGgJQAFgKAJgFQAJgEANAAQATgBALAMQAMAMAAASIAAAGIAAABIgDABIgYAAIgDgBIgBgBIAAgGQAAgHgCgEQgEgEgFAAQgFAAgDAEQgDAEAAAGQAAAFACADQACAFAEAEIALAJQAMAIAHAGQAIAHAEAHQAEAJAAAKQAAANgGAKQgFAJgKAFQgJAFgNAAQgLAAgKgFg");
	this.shape_20.setTransform(261.85,-146.45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgVBJQgJgFgGgJQgFgJAAgMIAAgGIABgCIACgCIAZAAIACACIABACIAAAEQAAAHADAFQADAEAEAAQAGgBADgDQAEgEAAgHQgBgEgCgDQgCgFgEgDIgMgJIgQgNQgIgGgFgJQgEgJgBgNQABgMAEgJQAGgKAKgFQAIgEANAAQATgBAMAMQALAMAAASIAAAGIAAABIgCABIgZAAIgCgBIgCgBIAAgGQAAgHgDgEQgDgEgFAAQgFAAgDAEQgDAEAAAGQAAAFABADQADAFAEAEIALAJQALAIAIAGQAIAHAEAHQAEAJAAAKQAAANgGAKQgFAJgJAFQgKAFgNAAQgMAAgJgFg");
	this.shape_21.setTransform(247.65,-146.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgfBBQgLgMgBgVIAAhqIABgCIACgBIAZAAIACABIABACIAABtQAAAIAEAEQADAEAFAAQAGAAADgEQAEgEgBgIIAAhtIABgCIACgBIAZAAIADABIABACIAABqQAAAOgGAKQgFAKgKAGQgKAFgNABQgTgBgMgMg");
	this.shape_22.setTransform(237.45,-146.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgfBDQgMgMAAgUIAAhFQAAgUAMgLQAMgMATAAQANgBAKAGQAKAFAGAKQAFAKAAANIAABFQAAANgFAKQgGAJgKAGQgKAFgNAAQgTAAgMgLgAgJgvQgDAFAAAGIAABIQAAAHADAFQAEAEAFAAQAGAAAEgEQADgFAAgHIAAhIQAAgGgDgFQgEgEgGAAQgFAAgEAEg");
	this.shape_23.setTransform(227.025,-146.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgLBNIgCgBIgCgCIAAiTIACgCIACgBIAYAAIACABIABACIAACTIgBACIgCABg");
	this.shape_24.setTransform(219.3,-146.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNBNIgCgBIgBgCIgfiTIAAgCIACgBIAcAAIACABIABACIAOBfIABABIAAgBIAPhfIABgCIACgBIAbAAIACABIABACIggCTIgBACIgCABg");
	this.shape_25.setTransform(211.4875,-146.475);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgoBNIgCgBIgBgCIAAiTIABgCIACgBIAkAAQANAAALAFQAKAFAGAJQAGAJAAAOQAAALgEAIQgEAIgHAFIgBAAIABABQAHAFAFAIQAFAJAAANQAAAOgGAKQgFAJgKAFQgKAFgNAAgAgMAJIAAABIAAAnIAAABIABAAIAJAAQAHAAAEgFQAEgFAAgKQAAgKgEgFQgEgGgGAAIgKAAIgBAAgAgMgxIAAABIAAAiIAAABIABABIAIAAQAGAAAEgFQAEgFAAgIQAAgKgEgEQgEgFgGAAIgIAAIgBAAg");
	this.shape_26.setTransform(201.2019,-146.475);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgfBDQgMgMAAgUIAAhFQAAgUAMgLQAMgMATAAQANgBAKAGQAKAFAGAKQAFAKAAANIAABFQAAANgFAKQgGAJgKAGQgKAFgNAAQgTAAgMgLgAgJgvQgDAFAAAGIAABIQAAAHADAFQAEAEAFAAQAGAAAEgEQADgFAAgHIAAhIQAAgGgDgFQgEgEgGAAQgFAAgEAEg");
	this.shape_27.setTransform(190.675,-146.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgCBNIgCgBIgBgCIAAh3IgBgBIAAgBIgPADIgCAAIgBgCIAAgTIAAgBIACgCIAPgHIACAAIACgBIAZAAIACABIABACIAACTIgBACIgCABg");
	this.shape_28.setTransform(177.9,-146.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(112.4,-161.6,324.70000000000005,51.3), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-63,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-63,0,401,56), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjA6IAAhzIBGAAIAAAWIgvAAIAAAZIArAAIAAAUIgrAAIAAAaIAwAAIAAAWg");
	this.shape.setTransform(109.8,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUA6IgXgoIgRAAIAAAoIgXAAIAAhzIAtAAQAQAAAMAMQALALAAAPQAAAMgGAHQgGAJgKAGIAZArgAgUgBIAWAAQAHAAAEgGQAFgEAAgIQAAgHgFgEQgEgGgHAAIgWAAg");
	this.shape_1.setTransform(100.525,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpArQgSgSAAgZQAAgYASgSQARgRAYAAQAZAAARARQASASAAAYQAAAZgSASQgRARgZAAQgYAAgRgRgAgagaQgKAKgBAQQABAQAKALQALALAPAAQAQAAAKgLQALgLAAgQQAAgQgLgKQgKgLgQAAQgPAAgLALg");
	this.shape_2.setTransform(88.45,15.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiA6IAAhKIggA0IgCAAIghg0IAABKIgXAAIAAhzIAYAAIAgA3IAhg3IAYAAIAABzg");
	this.shape_3.setTransform(75.125,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAbA6IgwhGIAABGIgXAAIAAhzIARAAIAyBGIAAhGIAWAAIAABzg");
	this.shape_4.setTransform(58.65,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUA6IgXgoIgRAAIAAAoIgXAAIAAhzIAtAAQAQAAAMAMQALALAAAPQAAAMgGAHQgGAJgKAGIAZArgAgUgBIAWAAQAHAAAEgGQAFgEAAgIQAAgHgFgEQgEgGgHAAIgWAAg");
	this.shape_5.setTransform(48.425,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAeA6IgHgVIgtAAIgHAVIgZAAIAphzIAbAAIApBzgAgPAQIAfAAIgQgug");
	this.shape_6.setTransform(37.475,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgjA6IAAhzIBGAAIAAAWIgvAAIAAAZIArAAIAAAUIgrAAIAAAaIAwAAIAAAWg");
	this.shape_7.setTransform(27.9,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghA6IAAhzIAXAAIAABdIAsAAIAAAWg");
	this.shape_8.setTransform(19.675,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A575").s().p("ApSCWQgyAAAAgyIAAjHQAAgyAyAAISlAAQAyAAAAAyIAADHQAAAygyAAg");
	this.shape_9.setTransform(64.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,129,30), null);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0,0,1456,180), null);


// stage content:
(lib._728x90TFHTML51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_781 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(781).call(this.frame_781).wait(1));

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-235.2,-93.9,-85.9,-35.8).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape.setTransform(616.7,63.15);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.388)","rgba(255,255,255,0)"],[0,0.51,1],-217.8,-89.4,-68.5,-31.3).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_1.setTransform(616.7,63.15);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-200.3,-85,-51,-26.9).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_2.setTransform(616.7,63.15);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-182.9,-80.5,-33.6,-22.4).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_3.setTransform(616.7,63.15);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-165.4,-76.1,-16.1,-18).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_4.setTransform(616.7,63.15);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.392)","rgba(255,255,255,0)"],[0,0.51,1],-148,-71.7,1.3,-13.6).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_5.setTransform(616.7,63.15);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-130.5,-67.2,18.8,-9.1).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_6.setTransform(616.7,63.15);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-113.1,-62.8,36.2,-4.7).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_7.setTransform(616.7,63.15);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-95.6,-58.3,53.7,-0.2).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_8.setTransform(616.7,63.15);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.396)","rgba(255,255,255,0)"],[0,0.51,1],-78.2,-53.9,71.1,4.2).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_9.setTransform(616.7,63.15);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-60.7,-49.4,88.6,8.7).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_10.setTransform(616.7,63.15);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-43.3,-45,106,13.1).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_11.setTransform(616.7,63.15);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-25.9,-40.5,123.4,17.6).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_12.setTransform(616.7,63.15);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0,0.51,1],-8.4,-36.1,140.9,22).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_13.setTransform(616.7,63.15);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],9,-31.6,158.3,26.5).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_14.setTransform(616.7,63.15);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],26.5,-27.2,175.8,30.9).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_15.setTransform(616.7,63.15);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],43.9,-22.8,193.2,35.3).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_16.setTransform(616.7,63.15);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.404)","rgba(255,255,255,0)"],[0,0.51,1],61.4,-18.3,210.7,39.8).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_17.setTransform(616.7,63.15);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],78.8,-13.9,228.1,44.2).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_18.setTransform(616.7,63.15);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.408)","rgba(255,255,255,0)"],[0,0.51,1],96.3,-9.4,245.6,48.7).s().p("AreCgQglABAAglIAAj2QAAgmAlAAIW8AAQAmAAgBAmIAAD2QABAlgmgBg");
	this.shape_19.setTransform(616.7,63.15);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(199).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(200).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(19));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(201).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(18));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(202).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(203).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(204).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(15));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(205).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(206).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(13));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(207).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(208).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(209).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(210).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(211).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(212).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(213).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(214).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(215).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(216).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(217).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(218).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(1));

	// Слой_3
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(616.65,87.9,1.2345,1.2345,0,0,0,64.6,15.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({y:63.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:34.45,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:87.9},0).to({y:63.2,alpha:1},17,cjs.Ease.get(1)).wait(69).to({y:34.45,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(182).to({_off:false,y:87.9},0).to({y:63.2,alpha:1},17,cjs.Ease.get(1)).wait(21));

	// logo
	this.instance_1 = new lib.logo_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(538.5,34.55,0.3931,0.4153,0,0,0,-63,0);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(171).to({_off:false},0).to({y:12.15,alpha:1},17,cjs.Ease.get(1)).wait(73).to({y:-7.55,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(178).to({_off:false,y:34.55},0).to({y:12.15,alpha:1},17,cjs.Ease.get(1)).wait(73).to({y:-7.55,alpha:0},12,cjs.Ease.get(-1)).to({_off:true},1).wait(178).to({_off:false,y:34.55},0).to({y:12.15,alpha:1},17,cjs.Ease.get(1)).wait(32));

	// t1.2
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(253.55,41.05,1.5,1.5,0,0,0,274.7,-136.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(175).to({_off:false},0).to({regY:-136.6,y:45.05,alpha:1},13).wait(80).to({regY:-136.7,y:41.05,alpha:0},12).to({_off:true},1).wait(175).to({_off:false},0).to({regY:-136.6,y:45.05,alpha:1},13).wait(80).to({regY:-136.7,y:41.05,alpha:0},12).to({_off:true},1).wait(175).to({_off:false},0).to({regY:-136.6,y:45.05,alpha:1},13).wait(32));

	// Слой_7
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(204,204,204,0)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_20.setTransform(617.8,45);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(204,204,204,0.024)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_21.setTransform(617.8,45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(204,204,204,0.051)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_22.setTransform(617.8,45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(204,204,204,0.075)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_23.setTransform(617.8,45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(204,204,204,0.094)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_24.setTransform(617.8,45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(204,204,204,0.114)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_25.setTransform(617.8,45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(204,204,204,0.133)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_26.setTransform(617.8,45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(204,204,204,0.153)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_27.setTransform(617.8,45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(204,204,204,0.173)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_28.setTransform(617.8,45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(204,204,204,0.188)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_29.setTransform(617.8,45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(204,204,204,0.204)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_30.setTransform(617.8,45);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(204,204,204,0.216)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_31.setTransform(617.8,45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(204,204,204,0.231)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_32.setTransform(617.8,45);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(204,204,204,0.243)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_33.setTransform(617.8,45);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(204,204,204,0.251)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_34.setTransform(617.8,45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(204,204,204,0.263)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_35.setTransform(617.8,45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(204,204,204,0.271)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_36.setTransform(617.8,45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(204,204,204,0.278)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_37.setTransform(617.8,45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(204,204,204,0.282)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_38.setTransform(617.8,45);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(204,204,204,0.29)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_39.setTransform(617.8,45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(204,204,204,0.294)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_40.setTransform(617.8,45);
	this.shape_40._off = true;

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(204,204,204,0.298)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_41.setTransform(617.8,45);
	this.shape_41._off = true;

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(204,204,204,0.255)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_42.setTransform(617.8,45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(204,204,204,0.212)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_43.setTransform(617.8,45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(204,204,204,0.169)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_44.setTransform(617.8,45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(204,204,204,0.129)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_45.setTransform(617.8,45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(204,204,204,0.086)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_46.setTransform(617.8,45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(204,204,204,0.043)").s().p("AxOHCIAAuDMAicAAAIAAODg");
	this.shape_47.setTransform(617.8,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},148).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},102).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},148).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},102).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_20}]},148).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(71));
	this.timeline.addTween(cjs.Tween.get(this.shape_40).wait(168).to({_off:false},0).wait(1).to({_off:true},1).wait(279).to({_off:false},0).wait(1).to({_off:true},1).wait(279).to({_off:false},0).wait(1).to({_off:true},1).wait(50));
	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(170).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(50));

	// Слой_8
	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_48.setTransform(364,45);
	this.shape_48._off = true;

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.086)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_49.setTransform(364,45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.165)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_50.setTransform(364,45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.243)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_51.setTransform(364,45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.318)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_52.setTransform(364,45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.388)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_53.setTransform(364,45);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.455)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_54.setTransform(364,45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.518)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_55.setTransform(364,45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.576)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_56.setTransform(364,45);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.631)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_57.setTransform(364,45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.682)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_58.setTransform(364,45);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.729)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_59.setTransform(364,45);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.773)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_60.setTransform(364,45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.812)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_61.setTransform(364,45);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.847)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_62.setTransform(364,45);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.878)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_63.setTransform(364,45);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.906)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_64.setTransform(364,45);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.933)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_65.setTransform(364,45);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.953)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_66.setTransform(364,45);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.969)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_67.setTransform(364,45);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.984)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_68.setTransform(364,45);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.992)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_69.setTransform(364,45);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_70.setTransform(364,45);
	this.shape_70._off = true;

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.98)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_71.setTransform(364,45);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.918)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_72.setTransform(364,45);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0.816)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_73.setTransform(364,45);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(255,255,255,0.675)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_74.setTransform(364,45);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.49)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_75.setTransform(364,45);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.267)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_76.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_48}]},148).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_70}]},102).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_48}]},1).to({state:[]},1).to({state:[{t:this.shape_48}]},148).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_70}]},102).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_48}]},1).to({state:[]},1).to({state:[{t:this.shape_48}]},148).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_70}]},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.shape_48).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(148).to({_off:false},0).to({_off:true},1).wait(71));
	this.timeline.addTween(cjs.Tween.get(this.shape_70).wait(170).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(103).to({_off:true},1).wait(177).to({_off:false},0).wait(50));

	// t1.1
	this.instance_3 = new lib.bg2_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,125,0.5,0.5,0,0,0,300,250);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(97).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},64).wait(206).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},64).wait(206).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},64).wait(48));

	// t1.2
	this.instance_4 = new lib.t11();
	this.instance_4.parent = this;
	this.instance_4.setTransform(30.95,206.75,1.2121,1.2121,0,0,0,-0.1,0);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({y:210.65,alpha:1},13).wait(35).to({y:200.7},13,cjs.Ease.get(1)).to({_off:true},111).wait(109).to({_off:false,y:206.75,alpha:0},0).to({y:210.65,alpha:1},13).wait(35).to({y:200.7},13,cjs.Ease.get(1)).to({_off:true},111).wait(109).to({_off:false,y:206.75,alpha:0},0).to({y:210.65,alpha:1},13).wait(35).to({y:200.7},13,cjs.Ease.get(1)).to({_off:true},111).wait(48));

	// bg-2
	this.instance_5 = new lib.t12();
	this.instance_5.parent = this;
	this.instance_5.setTransform(529.05,8.65,1.2562,1.2562,0,0,0,131.4,15.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(48).to({_off:false},0).to({regY:15.4,y:5.45,alpha:1},13).to({_off:true},111).wait(157).to({_off:false,regY:15.5,y:8.65,alpha:0},0).to({regY:15.4,y:5.45,alpha:1},13).to({_off:true},111).wait(157).to({_off:false,regY:15.5,y:8.65,alpha:0},0).to({regY:15.4,y:5.45,alpha:1},13).to({_off:true},111).wait(48));

	// Слой_15
	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#F8F8F8").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_77.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_77).to({_off:true},172).wait(109).to({_off:false},0).to({_off:true},172).wait(109).to({_off:false},0).to({_off:true},172).wait(48));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,37.5,364.1,68.8);
// library properties:
lib.properties = {
	id: '307B5D341DDBB5459CF568EEF0A1BE55',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/728x90TFHTML51_atlas_.png", id:"728x90TFHTML51_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['307B5D341DDBB5459CF568EEF0A1BE55'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;