(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_LaundryRoom_atlas_", frames: [[912,0,98,28],[0,0,454,280],[338,282,336,280],[0,282,336,280],[676,282,336,280],[456,0,454,280]]}
];


// symbols:



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_LaundryRoom_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["336x280_LaundryRoom_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["336x280_LaundryRoom_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.screen22 = function() {
	this.initialize(ss["336x280_LaundryRoom_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.screen23 = function() {
	this.initialize(ss["336x280_LaundryRoom_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen31 = function() {
	this.initialize(ss["336x280_LaundryRoom_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAMIg8AAIAAAlIA7AAIAAAMIg7AAIAAAoIA8AAIAAAMg");
	this.shape.setTransform(213.25,88.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAYA5IgcgtIgWAAIAAAtIgPAAIAAhxIAtAAQAJAAAGACQAGADAFAEQAFAFADAGQACAGAAAIQABAIgDAGQgCAGgFADQgEAEgFADIgLADIAeAugAgaAAIAdAAQAKAAAHgGQAFgGABgKQgBgKgFgFQgHgHgKAAIgdAAg");
	this.shape_1.setTransform(203.15,88.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAmA5IgKgZIg3AAIgKAZIgRAAIAuhxIARAAIAuBxgAgYATIAwAAIgYg9g");
	this.shape_2.setTransform(192,88.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAZA5IgZhbIgYBbIgQAAIgghxIAPAAIAaBeIAaheIALAAIAaBeIAZheIAQAAIggBxg");
	this.shape_3.setTransform(178.725,88.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgwA5IAAhxIAnAAQANAAAKAEQALAEAIAIQAIAIAEAKQAEALAAALQAAAMgEALQgEAKgIAIQgIAIgLAEQgKAEgNAAgAgiAtIAZAAQAKAAAIgEQAIgEAGgGQAFgGADgIQADgIAAgJQAAgIgDgIQgDgIgFgGQgGgGgIgEQgIgEgKAAIgZAAg");
	this.shape_4.setTransform(165.375,88.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAZA5IgdgtIgWAAIAAAtIgPAAIAAhxIAtAAQAJAAAGACQAGADAFAEQAFAFACAGQADAGAAAIQAAAIgCAGQgDAGgEADQgEAEgFADIgLADIAeAugAgaAAIAdAAQAKAAAGgGQAGgGABgKQgBgKgGgFQgGgHgKAAIgdAAg");
	this.shape_5.setTransform(154.2,88.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAmA5IgKgZIg3AAIgKAZIgRAAIAuhxIARAAIAuBxgAgYATIAwAAIgYg9g");
	this.shape_6.setTransform(143.05,88.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAhA5IAAg0IhCAAIAAA0IgOAAIAAhxIAOAAIAAAxIBCAAIAAgxIAPAAIAABxg");
	this.shape_7.setTransform(131.275,88.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgbA5QgGgCgFgEQgEgEgDgGQgDgGAAgIQAAgGACgFQACgGADgEIAIgGIAKgGIgGgNQgDgGAAgGQAAgGADgFQACgFADgDQAFgEAEgCQAGgCAGAAQAFAAAFABQAEACAEADQADADACAEQACAEAAAFQAAAHgDAFQgCAEgEAEIgKAHIgKAGIAHAIIAGAHIAGAIIAHAHQAGgHACgHIAFgMIALAFIgHAPIgJAPIALAKIAMALIgSAAIgGgFIgHgHQgGAHgIADQgHAEgKAAQgIAAgHgCgAgdAMQgGAGAAAJQAAAFACAEQACAEAEADQADADAEABQAEACAFAAQAHAAAFgDIAKgJIgJgJIgFgIIgHgJIgHgJQgIAEgEAGgAgJgvIgFAEQgCACgBADQgCADABAEQAAAEABAFIAGALIAIgFIAGgFIAFgGQACgEAAgEQAAgGgEgEQgEgDgEAAIgHABg");
	this.shape_8.setTransform(115.25,88.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgYA2QgLgFgHgIIAIgLIAHAGIAIAGIAKADQAFACAFAAQAJAAAFgCQAFgCADgDQADgDABgDIABgHQAAgGgDgDQgDgEgEgCIgLgEIgLgEIgNgEIgLgFQgFgDgDgFQgCgGAAgHQAAgHACgGQADgGAGgEQAFgEAIgDQAGgCAIAAQANAAALAEQAKAEAHAIIgJAKQgHgHgIgDQgJgDgIAAQgLAAgGAFQgHAFABAIQAAAFADADIAHAFIALAEIALADIANAFQAGACAFADQAFAEADAFQACAGAAAIQAAAGgCAGQgCAGgGAFQgEAEgIADQgIADgMAAQgOAAgLgFg");
	this.shape_9.setTransform(100.15,88.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AglA5IAAhxIBLAAIAAAMIg9AAIAAAlIA8AAIAAAMIg8AAIAAAoIA9AAIAAAMg");
	this.shape_10.setTransform(90.55,88.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_11.setTransform(83.4,88.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAYA5IgbgtIgYAAIAAAtIgNAAIAAhxIAtAAQAHAAAHACQAGADAFAEQAFAFADAGQADAGAAAIQgBAIgCAGQgDAGgDADQgFAEgFADIgLADIAeAugAgbAAIAeAAQAKAAAHgGQAFgGAAgKQAAgKgFgFQgHgHgKAAIgeAAg");
	this.shape_12.setTransform(76.4,88.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgWA3QgLgFgHgIQgIgIgEgKQgEgLAAgNQAAgMAEgKQAEgLAIgIQAHgIALgFQALgEALAAQANAAALAEQAJAFAIAIQAIAIAEALQAEAKAAAMQAAANgEALQgEAKgIAIQgIAIgJAFQgLAEgNAAQgLAAgLgEgAgRgqQgHAEgFAGQgGAGgDAJQgDAIAAAJQAAAKADAJQADAIAGAGQAFAHAHADQAJAEAIAAQAJAAAJgEQAHgDAFgHQAGgGADgIQADgJAAgKQAAgJgDgIQgDgJgGgGQgFgGgHgEQgJgDgJAAQgIAAgJADg");
	this.shape_13.setTransform(64.3,88.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgYA2QgLgFgHgIIAIgLIAHAGIAJAGIAJADQAGACAEAAQAIAAAGgCQAEgCADgDQAEgDABgDIABgHQAAgGgCgDQgDgEgFgCIgLgEIgMgEIgMgEIgLgFQgEgDgDgFQgDgGAAgHQAAgHADgGQADgGAFgEQAFgEAHgDQAIgCAHAAQANAAALAEQAJAEAHAIIgIAKQgGgHgJgDQgIgDgJAAQgKAAgHAFQgGAFgBAIQAAAFAEADIAHAFIALAEIALADIANAFQAGACAFADQAEAEADAFQADAGAAAIQAAAGgCAGQgCAGgFAFQgGAEgIADQgIADgLAAQgOAAgLgFg");
	this.shape_14.setTransform(52.6,88.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgYA2QgLgFgHgIIAIgLIAHAGIAIAGIAKADQAFACAFAAQAJAAAFgCQAFgCADgDQADgDABgDIABgHQAAgGgDgDQgDgEgEgCIgLgEIgLgEIgNgEIgLgFQgFgDgDgFQgCgGAAgHQAAgHACgGQADgGAGgEQAFgEAIgDQAGgCAIAAQANAAALAEQAJAEAIAIIgJAKQgHgHgIgDQgJgDgIAAQgLAAgGAFQgHAFABAIQAAAFADADIAHAFIALAEIALADIANAFQAGACAFADQAFAEADAFQACAGAAAIQAAAGgCAGQgCAGgGAFQgEAEgIADQgIADgMAAQgOAAgLgFg");
	this.shape_15.setTransform(42.55,88.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AglA5IAAhxIBLAAIAAAMIg8AAIAAAlIA7AAIAAAMIg7AAIAAAoIA8AAIAAAMg");
	this.shape_16.setTransform(32.95,88.325);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgPA3QgKgEgIgIQgIgIgFgLQgEgLAAgNQAAgMAEgLQAFgLAIgIQAIgIAKgEQALgEALAAQAIAAAGACQAHABAFADQAGADAEAFIAIAJIgMAGQgFgHgIgFQgJgEgKAAQgIAAgIADQgIADgGAHQgGAGgDAIQgEAJAAAJQAAAKAEAJQADAIAGAHQAGAGAIADQAIAEAIAAQAKAAAJgFQAIgFAFgHIAMAHQgHAJgLAHQgKAGgQAAQgLAAgLgEg");
	this.shape_17.setTransform(22.275,88.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgPA3QgKgEgIgIQgIgIgFgLQgEgLAAgNQAAgMAEgLQAFgLAIgIQAIgIAKgEQALgEALAAQAIAAAGACQAHABAFADQAGADAEAFIAIAJIgMAGQgFgHgIgFQgJgEgKAAQgIAAgIADQgIADgGAHQgGAGgDAIQgEAJAAAJQAAAKAEAJQADAIAGAHQAGAGAIADQAIAEAIAAQAKAAAJgFQAIgFAFgHIAMAHQgHAJgLAHQgKAGgQAAQgLAAgLgEg");
	this.shape_18.setTransform(10.675,88.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAnA5IgKgZIg5AAIgKAZIgQAAIAuhxIAQAAIAvBxgAgXATIAvAAIgYg9g");
	this.shape_19.setTransform(-1,88.325);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgGA5IAAhlIgkAAIAAgMIBVAAIAAAMIgkAAIAABlg");
	this.shape_20.setTransform(189.35,71.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AglA5IAAhxIBLAAIAAAMIg8AAIAAAlIA6AAIAAAMIg6AAIAAAoIA8AAIAAAMg");
	this.shape_21.setTransform(179,71.125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAiA5IhChaIAABaIgOAAIAAhxIAOAAIBBBYIAAhYIAOAAIAABxg");
	this.shape_22.setTransform(167.025,71.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_23.setTransform(158.1,71.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgqA5IAAhxIAyAAQAIAAAGACIAKAGQAEAEACAFQACAGAAAGQAAAFgBAFIgFAIIgGAFIgIADQAFABAEACIAHAGIAFAIQACAFAAAFQAAAHgDAGQgCAGgEAEQgFAEgGACQgGACgIAAgAgcAtIAiAAQALAAAFgGQAGgFAAgJQAAgEgCgEIgEgGQgCgDgEgBQgEgCgGAAIgiAAgAgcgHIAiAAQAKAAAFgFQAEgFAAgIQAAgIgEgFQgFgGgKAAIgiAAg");
	this.shape_24.setTransform(150.125,71.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAnA5IgKgZIg5AAIgKAZIgQAAIAuhxIAQAAIAvBxgAgXATIAvAAIgYg9g");
	this.shape_25.setTransform(138.05,71.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgPA3QgKgEgIgIQgIgIgFgLQgEgLAAgNQAAgMAEgLQAFgLAIgIQAIgIAKgEQALgEALAAQAIAAAGACQAHABAFADQAGADAEAFIAIAJIgMAGQgFgHgIgFQgJgEgKAAQgIAAgIADQgIADgGAHQgGAGgDAIQgEAJAAAJQAAAKAEAJQADAIAGAHQAGAGAIADQAIAEAIAAQAKAAAJgFQAIgFAFgHIAMAHQgHAJgLAHQgKAGgQAAQgLAAgLgEg");
	this.shape_26.setTransform(126.025,71.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAhA5IAAg0IhCAAIAAA0IgOAAIAAhxIAOAAIAAAxIBCAAIAAgxIAPAAIAABxg");
	this.shape_27.setTransform(107.925,71.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgHA5IAAhlIgkAAIAAgMIBWAAIAAAMIgkAAIAABlg");
	this.shape_28.setTransform(96.1,71.125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_29.setTransform(88.4,71.125);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAZA5IgZhbIgYBbIgQAAIgghxIAPAAIAaBeIAaheIALAAIAaBeIAZheIAQAAIggBxg");
	this.shape_30.setTransform(77.975,71.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAZA5IgqgzIgMANIAAAmIgNAAIAAhxIANAAIAAA6IAzg6IARAAIgvA2IAzA7g");
	this.shape_31.setTransform(59.75,71.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgWA3QgKgFgIgIQgHgIgEgKQgFgLAAgNQAAgMAFgKQAEgLAHgIQAIgIAKgFQAKgEAMAAQANAAAKAEQALAFAHAIQAHAIAFALQAEAKAAAMQAAANgEALQgFAKgHAIQgHAIgLAFQgKAEgNAAQgMAAgKgEgAgRgqQgHAEgGAGQgFAGgDAJQgDAIAAAJQAAAKADAJQADAIAFAGQAGAHAHADQAIAEAJAAQAKAAAHgEQAIgDAGgHQAFgGADgIQADgJAAgKQAAgJgDgIQgDgJgFgGQgGgGgIgEQgHgDgKAAQgJAAgIADg");
	this.shape_32.setTransform(46.7,71.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgWA3QgKgFgIgIQgHgIgEgKQgFgLAAgNQAAgMAFgKQAEgLAHgIQAIgIAKgFQALgEALAAQANAAAKAEQALAFAHAIQAHAIAFALQAEAKAAAMQAAANgEALQgFAKgHAIQgHAIgLAFQgKAEgNAAQgLAAgLgEgAgRgqQgHAEgGAGQgFAGgDAJQgDAIAAAJQAAAKADAJQADAIAFAGQAGAHAHADQAIAEAJAAQAKAAAHgEQAIgDAGgHQAFgGADgIQADgJAAgKQAAgJgDgIQgDgJgFgGQgGgGgIgEQgHgDgKAAQgJAAgIADg");
	this.shape_33.setTransform(32.75,71.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AghA5IAAhxIAOAAIAABlIA1AAIAAAMg");
	this.shape_34.setTransform(21.675,71.125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AAsBEIAAhhIgmBhIgLAAIgnhhIAABhIgcAAIAAiHIAoAAIAgBUIAhhUIAoAAIAACHg");
	this.shape_35.setTransform(208.475,52.275);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgkA9QgPgJgKgQQgJgPAAgVQAAgTAJgQQAKgQAPgJQAQgJAUAAQAVAAAPAJQAQAJAJAQQAJAQABATQgBAVgJAPQgJAQgQAJQgPAJgVAAQgUAAgQgJgAgVgmQgJAGgFAKQgFAKAAAMQAAAMAFAKQAFAKAJAHQAJAFAMABQANgBAJgFQAJgHAFgKQAFgKAAgMQAAgMgFgKQgFgKgJgGQgJgFgNAAQgMAAgJAFg");
	this.shape_36.setTransform(192.075,52.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgkA9QgPgJgKgQQgJgPAAgVQAAgTAJgQQAKgQAPgJQAQgJAUAAQAVAAAPAJQAQAJAJAQQAJAQABATQgBAVgJAPQgJAQgQAJQgPAJgVAAQgUAAgQgJgAgVgmQgJAGgFAKQgFAKAAAMQAAAMAFAKQAFAKAJAHQAJAFAMABQANgBAJgFQAJgHAFgKQAFgKAAgMQAAgMgFgKQgFgKgJgGQgJgFgNAAQgMAAgJAFg");
	this.shape_37.setTransform(176.525,52.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAWBEIgagwIgVAAIAAAwIgdAAIAAiHIA+AAQAPABAKAFQAKAGAGAKQAFAJAAANQAAAMgEAIQgFAIgGAFQgHAFgIABIAfA0gAgZgFIAdAAQAJAAAGgFQAFgEAAgJQAAgJgFgEQgGgFgJAAIgdAAg");
	this.shape_38.setTransform(162.525,52.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgNBEIAAg4Ig0hPIAhAAIAgA3IAig3IAgAAIgzBPIAAA4g");
	this.shape_39.setTransform(143.925,52.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAWBEIgagwIgVAAIAAAwIgdAAIAAiHIA+AAQAPABAKAFQAKAGAGAKQAFAJAAANQAAAMgEAIQgFAIgGAFQgHAFgIABIAfA0gAgZgFIAdAAQAJAAAGgFQAFgEAAgJQAAgJgFgEQgGgFgJAAIgdAAg");
	this.shape_40.setTransform(131.225,52.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("Ag9BEIAAiHIA1AAQAUABAQAIQARAIAIAPQAJAQAAATQAAAVgJAPQgIAPgQAIQgRAJgUAAgAghAqIAZAAQAMAAAJgFQAKgGAFgKQAFgJAAgMQAAgLgEgKQgGgJgJgGQgKgFgMAAIgZAAg");
	this.shape_41.setTransform(117.45,52.275);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAgBEIg/hYIAABYIgdAAIAAiHIAeAAIA9BUIAAhUIAeAAIAACHg");
	this.shape_42.setTransform(102.45,52.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AghA+QgOgIgGgMQgHgNAAgRIAAhQIAdAAIAABPQAAAPAIAJQAIAIAPABQAPgBAIgIQAIgJAAgPIAAhPIAeAAIAABQQAAARgGANQgIAMgNAIQgNAHgVAAQgTAAgOgHg");
	this.shape_43.setTransform(87.6,52.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AAmBEIgJgXIg5AAIgIAXIghAAIA0iHIAjAAIA0CHgAAVAUIgVg6IgUA6IApAAg");
	this.shape_44.setTransform(73.175,52.275);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgqBEIAAiHIAdAAIAABtIA4AAIAAAag");
	this.shape_45.setTransform(61.325,52.275);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAWBEIgagwIgVAAIAAAwIgdAAIAAiHIA+AAQAPABAKAFQAKAGAGAKQAFAJAAANQAAAMgEAIQgFAIgGAFQgHAFgIABIAfA0gAgZgFIAdAAQAJAAAGgFQAFgEAAgJQAAgJgFgEQgGgFgJAAIgdAAg");
	this.shape_46.setTransform(44.375,52.275);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AghA+QgNgIgIgMQgGgNAAgRIAAhQIAdAAIAABPQAAAPAIAJQAJAIAOABQAPgBAIgIQAJgJAAgPIAAhPIAdAAIAABQQAAARgHANQgGAMgOAIQgOAHgUAAQgUAAgNgHg");
	this.shape_47.setTransform(30.05,52.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgkA9QgPgJgKgQQgJgPAAgVQAAgTAJgQQAKgQAPgJQAQgJAUAAQAVAAAPAJQAQAJAJAQQAJAQABATQgBAVgJAPQgJAQgQAJQgPAJgVAAQgUAAgQgJgAgVgmQgJAGgFAKQgFAKAAAMQAAAMAFAKQAFAKAJAHQAJAFAMABQANgBAJgFQAJgHAFgKQAFgKAAgMQAAgMgFgKQgFgKgJgGQgJgFgNAAQgMAAgJAFg");
	this.shape_48.setTransform(14.875,52.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgNBEIAAg4Ig0hPIAhAAIAgA3IAig3IAgAAIgzBPIAAA4g");
	this.shape_49.setTransform(0.525,52.275);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgvBEIAAiHIBfAAIAAAaIhCAAIAAAcIBAAAIAAAZIhAAAIAAAeIBCAAIAAAag");
	this.shape_50.setTransform(157.475,31.975);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgyBEIAAgYIA/hVIg/AAIAAgaIBkAAIAAAXIg+BWIA/AAIAAAag");
	this.shape_51.setTransform(145.35,31.975);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgNBEIAAiHIAbAAIAACHg");
	this.shape_52.setTransform(136.575,31.975);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AAsBEIAAhhIgmBhIgLAAIgnhhIAABhIgcAAIAAiHIAoAAIAgBUIAhhUIAoAAIAACHg");
	this.shape_53.setTransform(125.125,31.975);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgkA9QgPgJgKgQQgJgQAAgUQAAgUAJgPQAKgQAPgJQAQgJAUAAQAVAAAPAJQAQAJAJAQQAJAPABAUQgBAUgJAQQgJAQgQAJQgPAIgVABQgUgBgQgIgAgVglQgJAFgFAKQgFAKAAAMQAAAMAFALQAFAJAJAGQAJAGAMABQANgBAJgGQAJgGAFgJQAFgLAAgMQAAgMgFgKQgFgKgJgFQgJgHgNAAQgMAAgJAHg");
	this.shape_54.setTransform(108.675,32);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgOBEIAAhtIgnAAIAAgaIBrAAIAAAaIgnAAIAABtg");
	this.shape_55.setTransform(95,31.975);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgfBAQgPgGgJgKIAQgWQAHAHALAGQALAFANABQAMgBAGgEQAFgEABgHQgBgFgFgEQgGgDgJgCIgSgFQgKgCgJgEQgIgEgFgIQgHgHABgMQAAgMAGgJQAGgJAMgGQALgFAPgBQAQAAAOAFQANAFAJAJIgPAWQgJgIgKgDQgKgFgKAAQgJABgFAEQgFADAAAGQABAGAFACQAGADAIACIASAFQAKADAJAEQAIAFAGAGQAFAIABAMQAAANgGAJQgGAKgMAGQgMAGgSAAQgTgBgOgFg");
	this.shape_56.setTransform(82.9,32);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AghA9QgNgHgIgMQgGgNAAgQIAAhRIAdAAIAABPQAAAPAIAIQAJAJAOABQAPgBAJgJQAHgIABgPIAAhPIAdAAIAABRQAAAQgHANQgGAMgOAHQgOAIgUAAQgUAAgNgIg");
	this.shape_57.setTransform(69.45,32.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgcA9QgQgJgKgQQgJgPAAgVQAAgUAJgPQAKgRAQgIQAQgJAUAAQAPAAALAFQAKAEAIAIQAIAHAEAJIgYAMQgFgJgIgEQgJgHgKAAQgMAAgJAHQgKAFgFAKQgGAKAAAMQAAANAGAKQAFAKAKAFQAJAGAMABQAKgBAJgGQAIgFAFgIIAYALQgEAJgIAIQgIAHgKAFQgLAEgPABQgUAAgQgJg");
	this.shape_58.setTransform(55.175,32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t31, new cjs.Rectangle(-8.3,21.2,227.8,78.1), null);


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgEg");
	this.shape.setTransform(126.725,26.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_1.setTransform(120.275,27.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgDgCQgEgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_2.setTransform(112.45,27.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgKAAIAAgwQAAgHgCgEQgEgEgHAAQgFAAgGADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAJgBQAIAAAEAEQAEAEACAFIAEgEIAFgFIAIgDIAHgBQAKAAAFAFQAFAGAAALIAAAzg");
	this.shape_3.setTransform(99.1,27.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_4.setTransform(88.725,27.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_5.setTransform(80.125,27.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgFAFgEQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_6.setTransform(73.775,27.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgYAzIgFgBIACgKIADABIADAAQAEAAADgBQACgCACgFIAFgLIgehIIAMAAIAXA6IAYg6IAMAAIgkBWQgCAIgGAEQgFADgHAAIgEAAg");
	this.shape_7.setTransform(63.325,28.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgFAFgEQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_8.setTransform(57.575,27.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgOAwQgFgDgFgFQgEgEgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgDQAGgDAIAAQAFABAHADQAGADAEAGIAAgmIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDAEgCAEQgBAFAAAGQAAAGABAFQACAFADAEQADADAEACQAFADAEAAQAHAAAFgEQAHgDACgFIAAggQgCgFgHgDQgFgDgHAAQgEAAgFACg");
	this.shape_9.setTransform(50.15,25.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(41.9,27.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQABACADAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgIADQgGAEgHAAQgMAAgFgGg");
	this.shape_11.setTransform(33.65,27.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAGgDADgEIAAgOQgDgEgGgCQgFgCgFAAQgIAAgFAEg");
	this.shape_12.setTransform(25.35,27.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_13.setTransform(19.875,25.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAwQgGgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAHADADAHIAAgnIAMAAIAABjIgMAAIAAgLQgEAGgGADQgGAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAEADAFAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgFAAgEACg");
	this.shape_14.setTransform(158.95,10.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_15.setTransform(150.625,12.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_16.setTransform(144.325,12.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgHADQgGAEgHAAQgMAAgFgGg");
	this.shape_17.setTransform(137.35,12.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgFAxIAAhHIAKAAIAABHgAgFgjQgBgCAAgDQAAgDABgDQADgCACAAQADAAACACQACADAAADQAAADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_18.setTransform(131.5,10.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_19.setTransform(128.2,10.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_20.setTransform(121.4,12.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_21.setTransform(112.925,12.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_22.setTransform(105.025,12.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgRAFIAAgJIAjAAIAAAJg");
	this.shape_23.setTransform(98.95,12.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_24.setTransform(92.475,12.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_25.setTransform(86.175,12.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgFQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGADQgGACgHAAQgHABgGgEQgGgEgFgFIAAAmgAgNglQgGAEgDAFIAAAgQADAEAGAEQAGAEAHgBQAEABAFgDQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgDQgDgEgEgDQgFgCgEAAQgHABgGACg");
	this.shape_26.setTransform(79.225,13.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_27.setTransform(68.625,11.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgCgDQAAgDgCgCQgDgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAFgFIAGgDIAHgDIAHgCQAMABAFAGQAGAFAAAMIAAAyg");
	this.shape_28.setTransform(62.25,10.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgPAxQgIgCgGgGIAGgJQAFAGAFACQAGACAHAAIAIgBQAEgBADgCQADgDADgEQABgEAAgGIAAgKQgEAFgFAEQgHADgHAAQgHABgFgDQgGgDgFgFQgEgFgDgGQgCgHAAgIQAAgJACgHQADgHAEgFQAEgEAGgDQAGgDAHAAQAHAAAGADQAHAEADAGIAAgLIAMAAIAABGQAAAJgDAGQgDAGgFADQgFADgGACQgGACgGAAQgJAAgGgDgAgIgnQgEACgDAEQgDAEgCAFQgBAFAAAGQAAAGABAFQACAEADADQADAFAEACQAFABAEAAIAGgBIAGgCIAGgEIADgEIAAgfIgDgEIgGgEIgGgDIgGgBQgEAAgFACg");
	this.shape_29.setTransform(53.55,13.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_30.setTransform(47.75,10.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_31.setTransform(43.975,12.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_32.setTransform(32.975,12.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgBgDgDgCQgCgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAEgFIAHgDIAHgDIAHgCQAMABAFAGQAGAFAAAMIAAAyg");
	this.shape_33.setTransform(24.6,10.85);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_34.setTransform(18.275,11.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQADgHAEgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADAEAEABQAFADAEAAQAGAAAGgEQAHgDACgFIAAgfQgCgFgHgEQgGgDgGAAQgEAAgFACg");
	this.shape_35.setTransform(7.6,10.95);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_36.setTransform(-0.65,12.125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgCgCgBgDQABgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_37.setTransform(-6.5,10.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AggAyIAAhjIBBAAIAAALIg0AAIAAAgIAzAAIAAALIgzAAIAAAtg");
	this.shape_38.setTransform(-12,10.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(-18.5,2,184.1,34), null);


(lib.t21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape.setTransform(208.7,63.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag9BXIAAitIB7AAIAAAhIhWAAIAAAkIBUAAIAAAgIhUAAIAAAnIBWAAIAAAhg");
	this.shape_1.setTransform(190.3,63.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_2.setTransform(174.85,63.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAGARABQAPgBAIgFQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgGQgNgDgLgGQgLgFgHgKQgIgJAAgRQAAgOAIgMQAIgMAPgHQAOgIAUABQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgEgMgBQgMABgHAEQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIAMQgIANgPAHQgPAIgYgBQgYABgSgIg");
	this.shape_3.setTransform(159.375,63.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_4.setTransform(143.325,63.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAGARABQAPgBAIgFQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgGQgNgDgLgGQgLgFgHgKQgIgJAAgRQAAgOAIgMQAIgMAPgHQAOgIAUABQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgEgMgBQgMABgHAEQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIAMQgIANgPAHQgPAIgYgBQgYABgSgIg");
	this.shape_5.setTransform(127.025,63.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_6.setTransform(104.275,63.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAcBXIgig+IgbAAIAAA+IgkAAIAAitIBQAAQASAAANAIQANAHAHAMQAHANAAAQQAAAPgFALQgGAKgJAGQgIAHgKACIAoBCgAghgGIAmAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIgmAAg");
	this.shape_7.setTransform(87.95,63.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_8.setTransform(70.275,63.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_9.setTransform(51.075,63.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_10.setTransform(32.025,64.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_11.setTransform(13.6,63.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_12.setTransform(-1.625,63.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAcBXIghg+IgbAAIAAA+IglAAIAAitIBQAAQASAAANAIQANAHAHAMQAHANAAAQQAAAPgFALQgGAKgJAGQgJAHgJACIAnBCgAgggGIAlAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIglAAg");
	this.shape_13.setTransform(189.55,38.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_14.setTransform(171.9,38.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_15.setTransform(156.675,38.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_16.setTransform(140.025,39.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_17.setTransform(121.575,38.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AguBOQgUgMgMgTQgLgVAAgaQAAgaALgTQAMgVAUgLQAVgLAZAAQAbAAAUALQAUALALAVQAMATABAaQgBAagMAVQgLATgUAMQgUAMgbAAQgZAAgVgMgAgbgxQgLAIgHAMQgGANAAAQQAAAQAGANQAHANALAHQAMAIAPAAQAQAAAMgIQAMgHAGgNQAHgNAAgQQAAgQgHgNQgGgMgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_18.setTransform(101.9,38.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape_19.setTransform(80.8,38.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ag8BXIAAitIB5AAIAAAhIhUAAIAAAkIBSAAIAAAgIhSAAIAAAnIBUAAIAAAhg");
	this.shape_20.setTransform(55.7,38.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AApBXIAAhJIhRAAIAABJIglAAIAAitIAlAAIAABFIBRAAIAAhFIAlAAIAACtg");
	this.shape_21.setTransform(38.35,38.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_22.setTransform(21.25,38.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgkBPQgVgLgMgVQgNgTAAgcQAAgbANgTQAMgVAVgLQAUgLAaAAQARAAAOAGQANAFALAJQAKAIAGALIgfAQQgGgJgLgGQgKgHgNAAQgPAAgNAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQANAIAPAAQALAAAKgEQAJgFAGgEIAAgVIgtAAIAAgfIBSAAIAABBQgOAPgSAJQgSAJgXAAQgagBgUgKg");
	this.shape_23.setTransform(185.15,13.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_24.setTransform(166.475,13.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgSBXIAAitIAlAAIAACtg");
	this.shape_25.setTransform(153.45,13.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgkBOQgVgLgMgUQgMgVAAgaQAAgaAMgUQAMgUAVgMQAVgLAZAAQATAAAOAHQAOAFAKAKQAJAKAGALIgfAPQgGgKgLgIQgKgGgOgBQgPAAgMAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQAMAIAPAAQAOAAAKgIQALgGAGgMIAfAQQgGALgJAJQgKAKgOAGQgOAHgTAAQgZAAgVgMg");
	this.shape_26.setTransform(141.175,13.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_27.setTransform(122.475,14.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_28.setTransform(104.025,13.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AguBOQgUgLgMgVQgLgUAAgaQAAgaALgTQAMgVAUgLQAVgMAZAAQAbAAAUAMQAUALALAVQAMATABAaQgBAagMAUQgLAVgUALQgUAMgbAAQgZAAgVgMgAgbgxQgLAIgHANQgGANAAAPQAAAQAGANQAHANALAHQAMAHAPABQAQgBAMgHQAMgHAGgNQAHgNAAgQQAAgPgHgNQgGgNgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_29.setTransform(84.35,13.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAcBXIgig+IgbAAIAAA+IglAAIAAitIBRAAQASAAANAIQANAHAHAMQAHANABAQQgBAPgFALQgGAKgJAGQgJAHgJACIAoBCgAghgGIAmAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIgmAAg");
	this.shape_30.setTransform(66.45,13.875);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_31.setTransform(50.1,13.875);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_32.setTransform(33.075,13.875);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgSBXIAAitIAkAAIAACtg");
	this.shape_33.setTransform(20.05,13.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t21, new cjs.Rectangle(-10.7,0,232.7,80), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgEg");
	this.shape.setTransform(126.725,26.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_1.setTransform(120.275,27.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgDgCQgEgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_2.setTransform(112.45,27.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgKAAIAAgwQAAgHgCgEQgEgEgHAAQgFAAgGADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAJgBQAIAAAEAEQAEAEACAFIAEgEIAFgFIAIgDIAHgBQAKAAAFAFQAFAGAAALIAAAzg");
	this.shape_3.setTransform(99.1,27.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_4.setTransform(88.725,27.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_5.setTransform(80.125,27.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgFAFgEQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_6.setTransform(73.775,27.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgYAzIgFgBIACgKIADABIADAAQAEAAADgBQACgCACgFIAFgLIgehIIAMAAIAXA6IAYg6IAMAAIgkBWQgCAIgGAEQgFADgHAAIgEAAg");
	this.shape_7.setTransform(63.325,28.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgFAFgEQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_8.setTransform(57.575,27.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgOAwQgFgDgFgFQgEgEgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgDQAGgDAIAAQAFABAHADQAGADAEAGIAAgmIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDAEgCAEQgBAFAAAGQAAAGABAFQACAFADAEQADADAEACQAFADAEAAQAHAAAFgEQAHgDACgFIAAggQgCgFgHgDQgFgDgHAAQgEAAgFACg");
	this.shape_9.setTransform(50.15,25.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(41.9,27.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQABACADAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgIADQgGAEgHAAQgMAAgFgGg");
	this.shape_11.setTransform(33.65,27.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAGgDADgEIAAgOQgDgEgGgCQgFgCgFAAQgIAAgFAEg");
	this.shape_12.setTransform(25.35,27.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_13.setTransform(19.875,25.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAwQgGgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAHADADAHIAAgnIAMAAIAABjIgMAAIAAgLQgEAGgGADQgGAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAEADAFAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgFAAgEACg");
	this.shape_14.setTransform(158.95,10.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_15.setTransform(150.625,12.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_16.setTransform(144.325,12.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgHADQgGAEgHAAQgMAAgFgGg");
	this.shape_17.setTransform(137.35,12.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgFAxIAAhHIAKAAIAABHgAgFgjQgBgCAAgDQAAgDABgDQADgCACAAQADAAACACQACADAAADQAAADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_18.setTransform(131.5,10.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_19.setTransform(128.2,10.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_20.setTransform(121.4,12.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_21.setTransform(112.925,12.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_22.setTransform(105.025,12.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgRAFIAAgJIAjAAIAAAJg");
	this.shape_23.setTransform(98.95,12.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_24.setTransform(92.475,12.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_25.setTransform(86.175,12.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgFQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGADQgGACgHAAQgHABgGgEQgGgEgFgFIAAAmgAgNglQgGAEgDAFIAAAgQADAEAGAEQAGAEAHgBQAEABAFgDQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgDQgDgEgEgDQgFgCgEAAQgHABgGACg");
	this.shape_26.setTransform(79.225,13.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_27.setTransform(68.625,11.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgCgDQAAgDgCgCQgDgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAFgFIAGgDIAHgDIAHgCQAMABAFAGQAGAFAAAMIAAAyg");
	this.shape_28.setTransform(62.25,10.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgPAxQgIgCgGgGIAGgJQAFAGAFACQAGACAHAAIAIgBQAEgBADgCQADgDADgEQABgEAAgGIAAgKQgEAFgFAEQgHADgHAAQgHABgFgDQgGgDgFgFQgEgFgDgGQgCgHAAgIQAAgJACgHQADgHAEgFQAEgEAGgDQAGgDAHAAQAHAAAGADQAHAEADAGIAAgLIAMAAIAABGQAAAJgDAGQgDAGgFADQgFADgGACQgGACgGAAQgJAAgGgDgAgIgnQgEACgDAEQgDAEgCAFQgBAFAAAGQAAAGABAFQACAEADADQADAFAEACQAFABAEAAIAGgBIAGgCIAGgEIADgEIAAgfIgDgEIgGgEIgGgDIgGgBQgEAAgFACg");
	this.shape_29.setTransform(53.55,13.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_30.setTransform(47.75,10.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_31.setTransform(43.975,12.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_32.setTransform(32.975,12.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgBgDgDgCQgCgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAEgFIAHgDIAHgDIAHgCQAMABAFAGQAGAFAAAMIAAAyg");
	this.shape_33.setTransform(24.6,10.85);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_34.setTransform(18.275,11.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQADgHAEgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADAEAEABQAFADAEAAQAGAAAGgEQAHgDACgFIAAgfQgCgFgHgEQgGgDgGAAQgEAAgFACg");
	this.shape_35.setTransform(7.6,10.95);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_36.setTransform(-0.65,12.125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgCgCgBgDQABgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_37.setTransform(-6.5,10.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AggAyIAAhjIBBAAIAAALIg0AAIAAAgIAzAAIAAALIgzAAIAAAtg");
	this.shape_38.setTransform(-12,10.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-18.5,2,184.1,34), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape.setTransform(208.7,63.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag9BXIAAitIB7AAIAAAhIhWAAIAAAkIBUAAIAAAgIhUAAIAAAnIBWAAIAAAhg");
	this.shape_1.setTransform(190.3,63.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_2.setTransform(174.85,63.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAGARABQAPgBAIgFQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgGQgNgDgLgGQgLgFgHgKQgIgJAAgRQAAgOAIgMQAIgMAPgHQAOgIAUABQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgEgMgBQgMABgHAEQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIAMQgIANgPAHQgPAIgYgBQgYABgSgIg");
	this.shape_3.setTransform(159.375,63.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_4.setTransform(143.325,63.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAGARABQAPgBAIgFQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgGQgNgDgLgGQgLgFgHgKQgIgJAAgRQAAgOAIgMQAIgMAPgHQAOgIAUABQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgEgMgBQgMABgHAEQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIAMQgIANgPAHQgPAIgYgBQgYABgSgIg");
	this.shape_5.setTransform(127.025,63.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_6.setTransform(104.275,63.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAcBXIgig+IgbAAIAAA+IgkAAIAAitIBQAAQASAAANAIQANAHAHAMQAHANAAAQQAAAPgFALQgGAKgJAGQgIAHgKACIAoBCgAghgGIAmAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIgmAAg");
	this.shape_7.setTransform(87.95,63.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_8.setTransform(70.275,63.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_9.setTransform(51.075,63.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_10.setTransform(32.025,64.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_11.setTransform(13.6,63.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_12.setTransform(-1.625,63.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAcBXIghg+IgbAAIAAA+IglAAIAAitIBQAAQASAAANAIQANAHAHAMQAHANAAAQQAAAPgFALQgGAKgJAGQgJAHgJACIAnBCgAgggGIAlAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIglAAg");
	this.shape_13.setTransform(189.55,38.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_14.setTransform(171.9,38.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_15.setTransform(156.675,38.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_16.setTransform(140.025,39.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_17.setTransform(121.575,38.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AguBOQgUgMgMgTQgLgVAAgaQAAgaALgTQAMgVAUgLQAVgLAZAAQAbAAAUALQAUALALAVQAMATABAaQgBAagMAVQgLATgUAMQgUAMgbAAQgZAAgVgMgAgbgxQgLAIgHAMQgGANAAAQQAAAQAGANQAHANALAHQAMAIAPAAQAQAAAMgIQAMgHAGgNQAHgNAAgQQAAgQgHgNQgGgMgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_18.setTransform(101.9,38.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape_19.setTransform(80.8,38.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ag8BXIAAitIB5AAIAAAhIhUAAIAAAkIBSAAIAAAgIhSAAIAAAnIBUAAIAAAhg");
	this.shape_20.setTransform(55.7,38.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AApBXIAAhJIhRAAIAABJIglAAIAAitIAlAAIAABFIBRAAIAAhFIAlAAIAACtg");
	this.shape_21.setTransform(38.35,38.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_22.setTransform(21.25,38.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgkBPQgVgLgMgVQgNgTAAgcQAAgbANgTQAMgVAVgLQAUgLAaAAQARAAAOAGQANAFALAJQAKAIAGALIgfAQQgGgJgLgGQgKgHgNAAQgPAAgNAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQANAIAPAAQALAAAKgEQAJgFAGgEIAAgVIgtAAIAAgfIBSAAIAABBQgOAPgSAJQgSAJgXAAQgagBgUgKg");
	this.shape_23.setTransform(185.15,13.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_24.setTransform(166.475,13.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgSBXIAAitIAlAAIAACtg");
	this.shape_25.setTransform(153.45,13.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgkBOQgVgLgMgUQgMgVAAgaQAAgaAMgUQAMgUAVgMQAVgLAZAAQATAAAOAHQAOAFAKAKQAJAKAGALIgfAPQgGgKgLgIQgKgGgOgBQgPAAgMAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQAMAIAPAAQAOAAAKgIQALgGAGgMIAfAQQgGALgJAJQgKAKgOAGQgOAHgTAAQgZAAgVgMg");
	this.shape_26.setTransform(141.175,13.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_27.setTransform(122.475,14.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_28.setTransform(104.025,13.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AguBOQgUgLgMgVQgLgUAAgaQAAgaALgTQAMgVAUgLQAVgMAZAAQAbAAAUAMQAUALALAVQAMATABAaQgBAagMAUQgLAVgUALQgUAMgbAAQgZAAgVgMgAgbgxQgLAIgHANQgGANAAAPQAAAQAGANQAHANALAHQAMAHAPABQAQgBAMgHQAMgHAGgNQAHgNAAgQQAAgPgHgNQgGgNgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_29.setTransform(84.35,13.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAcBXIgig+IgbAAIAAA+IglAAIAAitIBRAAQASAAANAIQANAHAHAMQAHANABAQQgBAPgFALQgGAKgJAGQgJAHgJACIAoBCgAghgGIAmAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIgmAAg");
	this.shape_30.setTransform(66.45,13.875);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_31.setTransform(50.1,13.875);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_32.setTransform(33.075,13.875);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgSBXIAAitIAkAAIAACtg");
	this.shape_33.setTransform(20.05,13.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-10.7,0,232.7,80), null);


(lib.pc23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen23();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc23, new cjs.Rectangle(0,0,336,280), null);


(lib.pc22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen22();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc22, new cjs.Rectangle(0,0,336,280), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc21, new cjs.Rectangle(0,0,336,280), null);


(lib.pc3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen31();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc3, new cjs.Rectangle(0,0,454,280), null);


(lib.pc1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc1, new cjs.Rectangle(0,0,454,280), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,98,28), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape.setTransform(83.525,17.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_1.setTransform(73.675,17.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAdAyIg5hPIAABPIgNAAIAAhjIAOAAIA4BNIAAhNIAMAAIAABjg");
	this.shape_2.setTransform(64.1,15.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgEQAGgEAHAAQAHAAAGADQAGACAEAFQAEAFADAIQACAGAAAJQAAAJgCAGQgDAHgEAFQgEAFgGACQgGAEgHAAQgHAAgGgEQgGgDgFgHIAAAngAgNgkQgGADgDAFIAAAfQADAFAGAEQAGAEAHAAQAEAAAFgDQAEgCADgDIAFgIQABgGAAgGQAAgGgBgFQgCgFgDgEQgDgDgEgCQgFgDgEAAQgHAAgGAEg");
	this.shape_3.setTransform(50.825,18.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_4.setTransform(41.975,17.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_5.setTransform(33.55,15.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVAvQgJgEgHgHIAIgKIAGAGIAHAEIAIADIAJABQAHAAAFgBQAEgCADgCIAEgGIABgGQAAgFgDgDIgGgFIgKgEIgKgDIgLgDQgFgBgEgDQgEgDgDgFQgCgEAAgHQAAgGACgFQADgFAEgEQAFgEAGgCQAHgCAGAAQAMAAAIAEQAJADAGAHIgHAJQgGgGgHgDQgIgDgHAAQgJAAgGAFQgFAEAAAHQAAAEACADIAHAFIAJADIAKADIALAEQAFACAFACQAEAEACAEQADAFAAAHQAAAGgCAFQgCAFgFAEQgEAEgHADQgHADgKAAQgMAAgKgFg");
	this.shape_6.setTransform(24.925,15.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_7.setTransform(54.8207,16.3109,0.8366,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,109.6,32.7), null);


// stage content:
(lib._336x280_LaundryRoom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_830 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(830).call(this.frame_830).wait(475));

	// btn
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(168,214.3,1,1,0,0,0,54.8,16.3);
	this.instance.alpha = 0.0117;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(62).to({_off:false},0).to({y:217.3,alpha:1},8,cjs.Ease.get(1)).wait(50).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(94).to({_off:false,y:213.45},0).to({y:216.45,alpha:1},8).wait(49).to({alpha:0.0117},13).to({_off:true},1).wait(70).to({_off:false,y:207.15},0).to({y:210.15,alpha:1},8).wait(48).to({alpha:0.0117},11).to({_off:true},1).wait(62).to({_off:false,y:214.3},0).to({y:217.3,alpha:1},8,cjs.Ease.get(1)).wait(50).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(94).to({_off:false,y:213.45},0).to({y:216.45,alpha:1},8).wait(49).to({alpha:0.0117},13).to({_off:true},1).wait(70).to({_off:false,y:208},0).to({y:211,alpha:1},8).wait(48).to({alpha:0.0117},11).to({_off:true},1).wait(62).to({_off:false,y:216},0).to({y:219,alpha:1},8,cjs.Ease.get(1)).wait(50).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(94).to({_off:false,y:216},0).to({y:219,alpha:1},8).wait(49).to({alpha:0.0117},13).to({_off:true},1).wait(70).to({_off:false,y:208},0).to({y:211,alpha:1},8).wait(48).to({alpha:0.0117},11).wait(1));

	// Слой_23
	this.instance_1 = new lib.logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(168.1,67.05,0.8,0.8,0,0,0,49.1,14.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(62).to({_off:false},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(50).to({alpha:0},11).to({_off:true},1).wait(94).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(49).to({alpha:0},13).to({_off:true},1).wait(70).to({_off:false,y:79.05},0).to({y:70.05,alpha:1},8,cjs.Ease.get(1)).wait(48).to({alpha:0},11).to({_off:true},1).wait(62).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(50).to({alpha:0},11).to({_off:true},1).wait(94).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(49).to({alpha:0},13).to({_off:true},1).wait(70).to({_off:false,y:79.05},0).to({y:70.05,alpha:1},8,cjs.Ease.get(1)).wait(48).to({alpha:0},11).to({_off:true},1).wait(62).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(50).to({alpha:0},11).to({_off:true},1).wait(94).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(49).to({alpha:0},13).to({_off:true},1).wait(70).to({_off:false,y:79.05},0).to({y:70.05,alpha:1},8,cjs.Ease.get(1)).wait(48).to({alpha:0},11).wait(1));

	// t12
	this.instance_2 = new lib.t12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,182,1,1,0,0,0,73.5,17);
	this.instance_2.alpha = 0.0117;
	this.instance_2._off = true;

	this.instance_3 = new lib.t22();
	this.instance_3.parent = this;
	this.instance_3.setTransform(167.95,182,1,1,0,0,0,73.5,17);
	this.instance_3.alpha = 0.0117;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(58).to({_off:false},0).to({y:173.35,alpha:1},8,cjs.Ease.get(1)).wait(54).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(361).to({_off:false,y:182},0).to({y:173.35,alpha:1},8,cjs.Ease.get(1)).wait(54).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(361).to({_off:false,y:182},0).to({y:173.35,alpha:1},8,cjs.Ease.get(1)).wait(54).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(303));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(223).to({_off:false},0).to({y:173.35,alpha:1},8).wait(52).to({alpha:0.0117},13).to({_off:true},1).wait(361).to({_off:false,y:182},0).to({y:173.35,alpha:1},8).wait(52).to({alpha:0.0117},13).to({_off:true},1).wait(361).to({_off:false,y:182},0).to({y:173.35,alpha:1},8).wait(52).to({alpha:0.0117},13).to({_off:true},1).wait(138));

	// t11
	this.instance_4 = new lib.t11();
	this.instance_4.parent = this;
	this.instance_4.setTransform(168,149,1,1,0,0,0,105.6,41);
	this.instance_4.alpha = 0.0117;
	this.instance_4._off = true;

	this.instance_5 = new lib.t21();
	this.instance_5.parent = this;
	this.instance_5.setTransform(168,149,1,1,0,0,0,105.6,41);
	this.instance_5.alpha = 0.0117;
	this.instance_5._off = true;

	this.instance_6 = new lib.t31();
	this.instance_6.parent = this;
	this.instance_6.setTransform(168,130.8,1,1,0,0,0,105.6,41);
	this.instance_6.alpha = 0.0117;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55).to({_off:false},0).to({y:118.35,alpha:1},8,cjs.Ease.get(1)).wait(57).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(358).to({_off:false,y:149},0).to({y:118.35,alpha:1},8,cjs.Ease.get(1)).wait(57).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(358).to({_off:false,y:149},0).to({y:118.35,alpha:1},8,cjs.Ease.get(1)).wait(57).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(303));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(220).to({_off:false},0).to({y:118.35,alpha:1},8).wait(55).to({alpha:0.0117},13).to({_off:true},1).wait(358).to({_off:false,y:149},0).to({y:118.35,alpha:1},8).wait(55).to({alpha:0.0117},13).to({_off:true},1).wait(358).to({_off:false,y:149},0).to({y:118.35,alpha:1},8).wait(55).to({alpha:0.0117},13).to({_off:true},1).wait(138));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(361).to({_off:false},0).to({y:118.35,alpha:1},8).wait(54).to({alpha:0.0117},11).to({_off:true},1).wait(361).to({_off:false,y:130.8},0).to({y:118.35,alpha:1},8).wait(54).to({alpha:0.0117},11).to({_off:true},1).wait(361).to({_off:false,y:130.8},0).to({y:118.35,alpha:1},8).wait(54).to({alpha:0.0117},11).wait(1));

	// Слой_14
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A0iAKIAAgTMApFAAAIAAATg");
	this.shape.setTransform(168,140);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A0iDGIAAmLMApFAAAIAAGLg");
	this.shape_1.setTransform(168,140);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A0iFxIAArhMApFAAAIAALhg");
	this.shape_2.setTransform(168,140);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A0iIKIAAwTMApFAAAIAAQTg");
	this.shape_3.setTransform(168,140.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A0iKQIAA0fMApFAAAIAAUfg");
	this.shape_4.setTransform(168,140.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A0iMFIAA4JMApFAAAIAAYJg");
	this.shape_5.setTransform(168,140);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A0iNoIAA7PMApFAAAIAAbPg");
	this.shape_6.setTransform(168,140.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("A0iO5IAA9xMApFAAAIAAdxg");
	this.shape_7.setTransform(168,140.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("A0iP3IAA/tMApFAAAIAAftg");
	this.shape_8.setTransform(168,140.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A0iQkMAAAghHMApFAAAMAAAAhHg");
	this.shape_9.setTransform(168,140.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("A0iQ/MAAAgh9MApFAAAMAAAAh9g");
	this.shape_10.setTransform(168,140.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_11.setTransform(168,140.025);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.992)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_12.setTransform(168,140.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.969)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_13.setTransform(168,140.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.925)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_14.setTransform(168,140.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.867)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_15.setTransform(168,140.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.792)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_16.setTransform(168,140.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.702)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_17.setTransform(168,140.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.596)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_18.setTransform(168,140.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.471)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_19.setTransform(168,140.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.329)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_20.setTransform(168,140.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.173)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_21.setTransform(168,140.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_22.setTransform(168,140.025);
	this.shape_22._off = true;

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("A0iC/IAAl9MApFAAAIAAF9g");
	this.shape_23.setTransform(168,140);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("A0iF0IAArnMApFAAAIAALng");
	this.shape_24.setTransform(168,140);
	this.shape_24._off = true;

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("A0iIpIAAxRMApFAAAIAARRg");
	this.shape_25.setTransform(168,140.025);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("A0iLeIAA27MApFAAAIAAW7g");
	this.shape_26.setTransform(168,140.025);
	this.shape_26._off = true;

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("A0iOTIAA8lMApFAAAIAAclg");
	this.shape_27.setTransform(168,140.025);
	this.shape_27._off = true;

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.922)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_28.setTransform(168,140.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.847)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_29.setTransform(168,140.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.769)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_30.setTransform(168,140.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.694)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_31.setTransform(168,140.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.616)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_32.setTransform(168,140.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.537)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_33.setTransform(168,140.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.463)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_34.setTransform(168,140.025);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.384)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_35.setTransform(168,140.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.306)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_36.setTransform(168,140.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.231)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_37.setTransform(168,140.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.153)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_38.setTransform(168,140.025);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.078)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_39.setTransform(168,140.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.91)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_40.setTransform(168,140.025);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.82)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_41.setTransform(168,140.025);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.725)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_42.setTransform(168,140.025);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.635)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_43.setTransform(168,140.025);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.545)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_44.setTransform(168,140.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.455)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_45.setTransform(168,140.025);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.365)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_46.setTransform(168,140.025);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.275)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_47.setTransform(168,140.025);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.18)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_48.setTransform(168,140.025);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.09)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_49.setTransform(168,140.025);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("A0iFWIAAqrMApFAAAIAAKrg");
	this.shape_50.setTransform(168,140);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("A0iJlIAAzJMApFAAAIAATJg");
	this.shape_51.setTransform(168,140);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("A0iM5IAA5xMApFAAAIAAZxg");
	this.shape_52.setTransform(168,140.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("A0iPQIAA+fMApFAAAIAAefg");
	this.shape_53.setTransform(168,140.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("A0iQqMAAAghTMApFAAAMAAAAhTg");
	this.shape_54.setTransform(168,140.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},47).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},62).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},85).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},60).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},61).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},59).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},47).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},62).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},85).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},60).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},61).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},59).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},52).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},62).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},85).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},60).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).to({state:[{t:this.shape}]},61).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},59).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_22}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(47).to({_off:false},0).to({_off:true},1).wait(169).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(123).to({_off:false},0).to({_off:true},1).wait(169).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(164).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(76));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(58).to({_off:false},0).wait(62).to({_off:true},1).wait(102).to({_off:false},0).wait(60).to({_off:true},1).wait(80).to({_off:false},0).wait(59).to({_off:true},1).wait(69).to({_off:false},0).wait(62).to({_off:true},1).wait(102).to({_off:false},0).wait(60).to({_off:true},1).wait(80).to({_off:false},0).wait(59).to({_off:true},1).wait(69).to({_off:false},0).wait(62).to({_off:true},1).wait(102).to({_off:false},0).wait(60).to({_off:true},1).wait(80).to({_off:false},0).wait(59).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(131).to({_off:false},0).to({_off:true},1).wait(164).to({_off:false},0).to({_off:true},1).wait(137).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(164).to({_off:false},0).to({_off:true},1).wait(137).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(164).to({_off:false},0).to({_off:true},1).wait(137).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(218).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(75));
	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(219).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(74));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(220).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(73));
	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(221).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(72));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(222).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(293).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(71));

	// screen31.jpg
	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(0,0,0,0.004)").s().p("A7QWvMAAAgtdMA2hAAAMAAAAtdg");
	this.shape_55.setTransform(168,140.025);
	this.shape_55._off = true;

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(0,0,0,0.063)").s().p("A7HWnMAAAgtNMA2PAAAMAAAAtNg");
	this.shape_56.setTransform(168,140.025);
	this.shape_56._off = true;

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(0,0,0,0.114)").s().p("A7AWhMAAAgtBMA2AAAAMAAAAtBg");
	this.shape_57.setTransform(168,140);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(0,0,0,0.153)").s().p("A66WcMAAAgs3MA11AAAMAAAAs3g");
	this.shape_58.setTransform(168.025,140.025);
	this.shape_58._off = true;

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(0,0,0,0.176)").s().p("A62WZMAAAgsxMA1tAAAMAAAAsxg");
	this.shape_59.setTransform(168.025,140.025);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(0,0,0,0.196)").s().p("A6zWWMAAAgssMA1nAAAMAAAAssg");
	this.shape_60.setTransform(168.025,140);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(0,0,0,0.2)").s().p("A6yWWMAAAgsrMA1lAAAMAAAAsrg");
	this.shape_61.setTransform(168.025,140);
	this.shape_61._off = true;

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(0,0,0,0.18)").s().p("A61WYMAAAgsvMA1rAAAMAAAAsvg");
	this.shape_62.setTransform(168.025,140.025);
	this.shape_62._off = true;

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(0,0,0,0.165)").s().p("A64WaMAAAgszMA1xAAAMAAAAszg");
	this.shape_63.setTransform(168.025,140);
	this.shape_63._off = true;

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(0,0,0,0.145)").s().p("A66WdMAAAgs5MA11AAAMAAAAs5g");
	this.shape_64.setTransform(168.025,140.025);
	this.shape_64._off = true;

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(0,0,0,0.129)").s().p("A69WfMAAAgs9MA17AAAMAAAAs9g");
	this.shape_65.setTransform(168,140);
	this.shape_65._off = true;

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(0,0,0,0.11)").s().p("A7AWhMAAAgtBMA2BAAAMAAAAtBg");
	this.shape_66.setTransform(168.025,140.025);
	this.shape_66._off = true;

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(0,0,0,0.094)").s().p("A7CWjMAAAgtFMA2GAAAMAAAAtFg");
	this.shape_67.setTransform(168,140);
	this.shape_67._off = true;

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(0,0,0,0.075)").s().p("A7FWmMAAAgtLMA2LAAAMAAAAtLg");
	this.shape_68.setTransform(168.025,140.025);
	this.shape_68._off = true;

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(0,0,0,0.059)").s().p("A7IWoMAAAgtPMA2RAAAMAAAAtPg");
	this.shape_69.setTransform(168,140);
	this.shape_69._off = true;

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(0,0,0,0.039)").s().p("A7KWqMAAAgtTMA2VAAAMAAAAtTg");
	this.shape_70.setTransform(168,140.025);
	this.shape_70._off = true;

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(0,0,0,0.024)").s().p("A7NWsMAAAgtXMA2cAAAMAAAAtXg");
	this.shape_71.setTransform(168,140);
	this.shape_71._off = true;

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(0,0,0,0.02)").s().p("A7NWtMAAAgtZMA2cAAAMAAAAtZg");
	this.shape_72.setTransform(168,140.025);
	this.shape_72._off = true;

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(0,0,0,0.035)").s().p("A7LWrMAAAgtVMA2XAAAMAAAAtVg");
	this.shape_73.setTransform(168,140.025);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(0,0,0,0.055)").s().p("A7JWpMAAAgtRMA2SAAAMAAAAtRg");
	this.shape_74.setTransform(168,140.025);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(0,0,0,0.071)").s().p("A7GWnMAAAgtNMA2NAAAMAAAAtNg");
	this.shape_75.setTransform(168,140);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(0,0,0,0.086)").s().p("A7DWlMAAAgtIMA2IAAAMAAAAtIg");
	this.shape_76.setTransform(168,140);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(0,0,0,0.102)").s().p("A7BWiMAAAgtDMA2DAAAMAAAAtDg");
	this.shape_77.setTransform(168.025,140.025);
	this.shape_77._off = true;

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(0,0,0,0.118)").s().p("A6/WgMAAAgs/MA1/AAAMAAAAs/g");
	this.shape_78.setTransform(168.025,140.025);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(0,0,0,0.133)").s().p("A68WeMAAAgs7MA15AAAMAAAAs7g");
	this.shape_79.setTransform(168.025,140.025);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(0,0,0,0.169)").s().p("A63WaMAAAgszMA1vAAAMAAAAszg");
	this.shape_80.setTransform(168.025,140);
	this.shape_80._off = true;

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(0,0,0,0.184)").s().p("A61WYMAAAgsvMA1rAAAMAAAAsvg");
	this.shape_81.setTransform(168.025,140);
	this.shape_81._off = true;

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(0,0,0,0.153)").s().p("A65WcMAAAgs3MA1zAAAMAAAAs3g");
	this.shape_82.setTransform(168.025,140.025);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(0,0,0,0.141)").s().p("A67WeMAAAgs7MA13AAAMAAAAs7g");
	this.shape_83.setTransform(168.025,140);
	this.shape_83._off = true;

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(0,0,0,0.125)").s().p("A6+WfMAAAgs+MA19AAAMAAAAs+g");
	this.shape_84.setTransform(168.025,140);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(0,0,0,0.094)").s().p("A7CWjMAAAgtFMA2FAAAMAAAAtFg");
	this.shape_85.setTransform(168.025,140.025);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(0,0,0,0.078)").s().p("A7EWlMAAAgtJMA2KAAAMAAAAtJg");
	this.shape_86.setTransform(168,140.025);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(0,0,0,0.051)").s().p("A7JWpMAAAgtRMA2TAAAMAAAAtRg");
	this.shape_87.setTransform(168,140);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(0,0,0,0.035)").s().p("A7LWrMAAAgtVMA2YAAAMAAAAtVg");
	this.shape_88.setTransform(168,140.025);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(0,0,0,0.024)").s().p("A7NWsMAAAgtXMA2bAAAMAAAAtXg");
	this.shape_89.setTransform(168,140.025);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(0,0,0,0.043)").s().p("A7KWqMAAAgtTMA2VAAAMAAAAtTg");
	this.shape_90.setTransform(168,140.025);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(0,0,0,0.082)").s().p("A7EWlMAAAgtJMA2JAAAMAAAAtJg");
	this.shape_91.setTransform(168,140.025);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(0,0,0,0.122)").s().p("A6+WgMAAAgs/MA19AAAMAAAAs/g");
	this.shape_92.setTransform(168.025,140);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(0,0,0,0.161)").s().p("A64WbMAAAgs1MA1xAAAMAAAAs1g");
	this.shape_93.setTransform(168.025,140);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_55}]},52).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},62).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},79).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},60).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},57).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},59).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},52).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},62).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},79).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},60).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},57).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},59).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},52).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},62).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},85).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},60).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},1).to({state:[{t:this.shape_55}]},61).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},59).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_55}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_55).wait(52).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(84).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(52).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(84).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(52).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_56).wait(53).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(64).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(64).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(238).to({_off:false},0).to({_off:true},1).wait(142));
	this.timeline.addTween(cjs.Tween.get(this.shape_58).wait(55).to({_off:false},0).to({_off:true},1).wait(164).to({_off:false},0).to({_off:true},1).wait(269).to({_off:false},0).to({_off:true},1).wait(164).to({_off:false},0).to({_off:true},1).wait(269).to({_off:false},0).to({_off:true},1).wait(379));
	this.timeline.addTween(cjs.Tween.get(this.shape_61).wait(58).to({_off:false},0).wait(62).to({_off:true},1).wait(102).to({_off:false},0).wait(60).to({_off:true},1).wait(80).to({_off:false},0).wait(59).to({_off:true},1).wait(69).to({_off:false},0).wait(62).to({_off:true},1).wait(102).to({_off:false},0).wait(60).to({_off:true},1).wait(80).to({_off:false},0).wait(59).to({_off:true},1).wait(69).to({_off:false},0).wait(62).to({_off:true},1).wait(102).to({_off:false},0).wait(60).to({_off:true},1).wait(80).to({_off:false},0).wait(59).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_62).wait(121).to({_off:false},0).to({_off:true},1).wait(241).to({_off:false,y:140},0).to({_off:true},1).wait(60).to({_off:false,y:140.025},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(241).to({_off:false,y:140},0).to({_off:true},1).wait(60).to({_off:false,y:140.025},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.shape_63).wait(122).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.shape_64).wait(123).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape_65).wait(124).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_66).wait(125).to({_off:false},0).to({_off:true},1).wait(163).to({_off:false,x:168,y:140},0).to({_off:true},1).wait(138).to({_off:false,x:168.025,y:140.025},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(163).to({_off:false,x:168,y:140},0).to({_off:true},1).wait(138).to({_off:false,x:168.025,y:140.025},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(163).to({_off:false,x:168,y:140},0).to({_off:true},1).wait(138).to({_off:false,x:168.025,y:140.025},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_67).wait(126).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_68).wait(127).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_69).wait(128).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_70).wait(129).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_71).wait(130).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(302).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_72).wait(212).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(351).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(434).to({_off:false},0).to({_off:true},1).wait(139));
	this.timeline.addTween(cjs.Tween.get(this.shape_77).wait(217).to({_off:false},0).to({_off:true},1).wait(141).to({_off:false},0).to({_off:true},1).wait(292).to({_off:false},0).to({_off:true},1).wait(141).to({_off:false},0).to({_off:true},1).wait(295).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(73));
	this.timeline.addTween(cjs.Tween.get(this.shape_80).wait(221).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(370).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(371).to({_off:false},0).to({_off:true},1).wait(62).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(71));
	this.timeline.addTween(cjs.Tween.get(this.shape_81).wait(222).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(372).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(434).to({_off:false},0).to({_off:true},1).wait(150));
	this.timeline.addTween(cjs.Tween.get(this.shape_83).wait(287).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(360).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(360).to({_off:false},0).to({_off:true},1).wait(147));

	// screen23.jpg
	this.instance_7 = new lib.pc23();
	this.instance_7.parent = this;
	this.instance_7.setTransform(168,140,1,1,0,0,0,168,140);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.instance_8 = new lib.pc21();
	this.instance_8.parent = this;
	this.instance_8.setTransform(168,140,1,1,0,0,0,168,140);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(182).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).wait(90).to({alpha:0},13).to({_off:true},1).wait(320).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).wait(90).to({alpha:0},13).to({_off:true},1).wait(573));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1052).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).wait(90).to({alpha:0},13).to({_off:true},1).wait(138));

	// screen22.jpg
	this.instance_9 = new lib.pc22();
	this.instance_9.parent = this;
	this.instance_9.setTransform(168,140,1,1,0,0,0,168,140);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(151).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},31).wait(393).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},31).wait(393).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},31).wait(242));

	// screen21.jpg
	this.instance_10 = new lib.pc21();
	this.instance_10.parent = this;
	this.instance_10.setTransform(168,140,1,1,0,0,0,168,140);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.instance_11 = new lib.pc23();
	this.instance_11.parent = this;
	this.instance_11.setTransform(168,140,1,1,0,0,0,168,140);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(120).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},31).wait(393).to({_off:false,alpha:0},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},31).wait(708));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(990).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).to({_off:true},31).wait(273));

	// Слой_21
	this.instance_12 = new lib.pc3();
	this.instance_12.parent = this;
	this.instance_12.setTransform(373.8,140,1,1,0,0,0,342.5,140);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(283).to({_off:false},0).to({x:238},140).to({x:227.35,alpha:0.0117},11).to({_off:true},1).wait(283).to({_off:false,x:373.8,alpha:1},0).to({x:238},140).to({x:227.35,alpha:0.0117},11).to({_off:true},1).wait(283).to({_off:false,x:373.8,alpha:1},0).to({x:227.35},151).wait(1));

	// pc11
	this.instance_13 = new lib.pc1();
	this.instance_13.parent = this;
	this.instance_13.setTransform(227,141,1,1,0,0,0,227,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:109},131).to({_off:true},1).wait(291).to({_off:false,x:227},0).to({x:109},143).to({_off:true},1).wait(291).to({_off:false,x:227},0).to({x:109},143).to({_off:true},1).wait(303));

	// Слой_1
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("A6zWSMAAAgsjMA1nAAAMAAAAsjg");
	this.shape_94.setTransform(168.025,140);

	this.timeline.addTween(cjs.Tween.get(this.shape_94).wait(1305));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,134.6,435.3,150.9);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_LaundryRoom_atlas_.jpg", id:"336x280_LaundryRoom_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;