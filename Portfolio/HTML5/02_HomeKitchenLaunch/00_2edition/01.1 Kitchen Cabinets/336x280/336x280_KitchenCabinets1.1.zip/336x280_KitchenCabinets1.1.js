(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_KitchenCabinets1.1_atlas_P_", frames: [[0,0,98,28]]},
		{name:"336x280_KitchenCabinets1.1_atlas_NP_", frames: [[0,564,336,280],[338,564,336,280],[0,282,592,280],[0,0,685,280]]}
];


// symbols:



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_KitchenCabinets1.1_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["336x280_KitchenCabinets1.1_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen12 = function() {
	this.initialize(ss["336x280_KitchenCabinets1.1_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["336x280_KitchenCabinets1.1_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.screen31 = function() {
	this.initialize(ss["336x280_KitchenCabinets1.1_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape.setTransform(145.875,25.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_1.setTransform(139.925,23.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgYAzIgFgBIACgKIADABIADAAQAEAAADgBQACgDACgEIAFgLIgehIIAMAAIAXA6IAYg6IAMAAIgkBWQgCAIgGADQgFAEgHAAIgEAAg");
	this.shape_2.setTransform(134.575,26.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(128.725,24.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_4.setTransform(122.9,25.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgXAyQgGgCgEgDQgEgEgDgFQgCgFAAgHQAAgGACgFQABgEADgEIAHgFIAJgFQgEgGgCgGQgCgFAAgGQAAgFACgEQACgEADgDIAIgFQAFgCAFAAIAIABIAHAEQADADACAEQACADAAAFQAAAGgCAEQgCAEgEADIgIAGIgJAFIAGAHIAFAGIAGAHIAGAHIAHgNIAEgKIAJAEIgGANQgDAHgEAGIAJAJIAKAKIgPAAIgGgFIgFgGQgGAGgHADQgGAEgJAAQgHAAgFgCgAgaAKQgEAFAAAIQAAAFACADIAEAGIAGAEIAIABQAGAAAEgDQAGgCAEgFIgIgIIgFgHIgGgHIgGgJQgHAEgEAFgAgIgpIgEADIgDAFIgBAGQAAADACAFIAEAJIAHgEIAGgFIAEgFQACgDAAgEQAAgFgEgDQgDgDgEAAIgGABg");
	this.shape_5.setTransform(110.825,23.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_6.setTransform(97.825,25.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(89.975,25.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAGACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_8.setTransform(82,25.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgEQAGgEAHAAQAHAAAGADQAGACAEAFQAEAFADAIQACAGAAAJQAAAJgCAGQgDAHgEAFQgEAFgGACQgGAEgHAAQgHgBgGgDQgGgDgFgHIAAAngAgNgkQgGADgDAFIAAAfQADAGAGADQAGAEAHAAQAEAAAFgDQAEgCADgDIAFgIQABgGAAgGQAAgGgBgFQgCgFgDgEQgDgDgEgCQgFgCgEgBQgHABgGADg");
	this.shape_9.setTransform(74.175,26.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIACgIQABgEAEgDQAEgDAEgBQAFgCAGAAQAJAAAHADQAHADAEAEIgFAIQgEgEgFgCQgGgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape_10.setTransform(66.05,25.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_11.setTransform(54.525,25.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgaAkIAAgIIAmg1IgmAAIAAgKIA1AAIAAAIIgoA2IApAAIAAAJg");
	this.shape_12.setTransform(46.75,25.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_13.setTransform(41.5,23.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgJAAIAAgwQAAgHgDgEQgEgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAJgBQAIAAAEAEQAEAEACAFIAEgEIAFgFIAIgDIAHgBQAKAAAFAFQAFAGABALIAAAzg");
	this.shape_14.setTransform(33.75,25.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_15.setTransform(26,23.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAVAkIgVgdIgVAdIgNAAIAcgkIgagjIANAAIATAbIAUgbIANAAIgaAjIAcAkg");
	this.shape_16.setTransform(20.675,25.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAGgDADgEIAAgOQgDgEgGgCQgFgCgFAAQgIAAgFAEg");
	this.shape_17.setTransform(12.85,25.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgJAAIAAgwQAAgHgEgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAFgEIAHgDIAIgBQAIAAAEAEQAEAEACAFIAEgEIAGgFIAHgDIAHgBQAKAAAFAFQAFAGABALIAAAzg");
	this.shape_18.setTransform(3.05,25.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_19.setTransform(117.875,10.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgFg");
	this.shape_20.setTransform(111.425,9.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAFgFIAGgDIAHgDIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_21.setTransform(101.15,8.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_22.setTransform(93.375,10.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgFg");
	this.shape_23.setTransform(87.375,9.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_24.setTransform(81,10.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgJAAIAAgwQgBgHgCgEQgEgEgHAAQgFAAgGADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAIgBQAJAAAEAEQAEAEACAFIAEgEIAFgFIAHgDIAIgBQAKAAAFAFQAFAGAAALIAAAzg");
	this.shape_25.setTransform(71.2,10.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgXAyQgGgCgEgDQgEgEgDgFQgCgFAAgHQAAgGACgFQABgEADgEIAHgFIAJgFQgEgGgCgGQgCgFAAgGQAAgFACgEQACgEADgDIAIgFQAFgCAFAAIAIABIAHAEQADADACAEQACADAAAFQAAAGgCAEQgCAEgEADIgIAGIgJAFIAGAHIAFAGIAGAHIAGAHIAHgNIAEgKIAJAEIgGANQgDAHgEAGIAJAJIAKAKIgPAAIgGgFIgFgGQgGAGgHADQgGAEgJAAQgHAAgFgCgAgaAKQgEAFAAAIQAAAFACADIAEAGIAGAEIAIABQAGAAAEgDQAGgCAEgFIgIgIIgFgHIgGgHIgGgJQgHAEgEAFgAgIgpIgEADIgDAFIgBAGQAAADACAFIAEAJIAHgEIAGgFIAEgFQACgDAAgEQAAgFgEgDQgDgDgEAAIgGABg");
	this.shape_26.setTransform(56.475,8.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AAVAkIgVgdIgVAdIgNAAIAcgkIgagjIANAAIATAbIAUgbIANAAIgaAjIAcAkg");
	this.shape_27.setTransform(44.075,10.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_28.setTransform(38.7,8.95);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AAlAyIAAhSIgjBSIgDAAIgihSIAABSIgNAAIAAhjIASAAIAeBKIAfhKIASAAIAABjg");
	this.shape_29.setTransform(30.9,8.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t32, new cjs.Rectangle(-5.1,0,157.29999999999998,34), null);


(lib.t31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag8BXIAAitIB5AAIAAAhIhUAAIAAAkIBSAAIAAAgIhSAAIAAAnIBUAAIAAAhg");
	this.shape.setTransform(193.15,65.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_1.setTransform(178.975,65.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_2.setTransform(163.525,65.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_3.setTransform(147.55,65.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAHARAAQAPAAAIgGQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgHQgNgDgLgFQgLgFgHgJQgIgLAAgQQAAgOAIgMQAIgMAPgHQAOgHAUAAQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgFgMAAQgMAAgHAFQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAIgYAAQgYAAgSgIg");
	this.shape_4.setTransform(132.075,65.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgzBUQgNgGgHgLQgIgLAAgRQABgMAFgKQAEgKAJgGQAJgGAJgEIgHgUQgEgJAAgJQAAgMAHgJQAGgKALgFQALgGAPABQALgBAKAFQAKAEAGAJQAHAHAAAMQAAANgGAJQgGAJgKAGQgKAGgJAEIAHAJIAHAJIAOASQAGgIAEgJIAGgQIAaAMIgKAVQgGAKgIAKIAQARIASASIgrAAIgFgFIgHgHQgKAHgMAEQgKAFgOAAQgRAAgNgGgAgnAVQgFAHAAAIQABAIADAHQAEAGAGADQAGADAHABQAHgBAGgCQAGgCAFgEIgKgNIgIgKIgJgLIgIgLQgIAEgDAHgAgPg8QgFAFAAAJQAAAFACAGIAGAMQAKgFAHgGQAIgHAAgJQAAgHgFgEQgEgEgGAAQgHABgGAEg");
	this.shape_5.setTransform(109.5,65.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAHARAAQAPAAAIgGQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgHQgNgDgLgFQgLgFgHgJQgIgLAAgQQAAgOAIgMQAIgMAPgHQAOgHAUAAQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgFgMAAQgMAAgHAFQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAIgYAAQgYAAgSgIg");
	this.shape_6.setTransform(86.275,65.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_7.setTransform(69.675,65.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag8BXIAAitIB5AAIAAAhIhUAAIAAAkIBSAAIAAAgIhSAAIAAAnIBUAAIAAAhg");
	this.shape_8.setTransform(52.65,65.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag9BXIAAitIB6AAIAAAhIhVAAIAAAkIBUAAIAAAgIhUAAIAAAnIBVAAIAAAhg");
	this.shape_9.setTransform(37.5,65.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_10.setTransform(20.175,65.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAbBXIggg+IgbAAIAAA+IgmAAIAAitIBRAAQASAAANAIQANAHAHAMQAHANAAAQQAAAPgGALQgFAKgIAGQgKAHgJACIAnBCgAgggGIAmAAQALAAAHgHQAHgGABgLQgBgLgHgGQgHgGgLAAIgmAAg");
	this.shape_11.setTransform(186.55,39.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_12.setTransform(168.225,40.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AguBOQgUgMgMgUQgMgUAAgaQAAgaAMgTQAMgUAUgMQAUgLAaAAQAaAAAVALQAUAMALAUQAMATAAAaQAAAagMAUQgLAUgUAMQgVAMgaAAQgaAAgUgMgAgbgxQgMAIgGANQgHANAAAPQAAAQAHANQAGANAMAHQAMAHAPABQAQgBAMgHQALgHAHgNQAGgNAAgQQAAgPgGgNQgHgNgLgIQgMgHgQAAQgPAAgMAHg");
	this.shape_13.setTransform(148.75,39.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_14.setTransform(130.425,39.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_15.setTransform(107.75,39.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgSBXIAAitIAkAAIAACtg");
	this.shape_16.setTransform(96.65,39.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_17.setTransform(83.525,40.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAGARABQAPgBAIgFQAHgFAAgJQAAgGgHgFQgIgEgLgDIgXgGQgNgDgLgFQgLgFgHgJQgIgLAAgQQAAgOAIgMQAIgMAPgHQAOgHAUAAQAVgBARAHQARAGAMAMIgUAbQgLgKgNgEQgNgFgMABQgMgBgHAFQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAIgYAAQgYAAgSgIg");
	this.shape_18.setTransform(66.075,39.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AguBOQgUgMgMgUQgMgUAAgaQAAgaAMgTQAMgUAUgMQAUgLAaAAQAbAAAUALQAUAMALAUQAMATAAAaQAAAagMAUQgLAUgUAMQgUAMgbAAQgaAAgUgMgAgbgxQgMAIgGANQgHANABAPQgBAQAHANQAGANAMAHQAMAHAPABQAQgBAMgHQAMgHAGgNQAGgNAAgQQAAgPgGgNQgGgNgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_19.setTransform(41.75,39.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_20.setTransform(24.2,39.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_21.setTransform(207.3,13.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_22.setTransform(190.175,14.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AguBOQgUgLgMgVQgMgUAAgaQAAgaAMgTQAMgVAUgLQAVgMAZAAQAaAAAVAMQAUALAMAVQAMATgBAaQABAagMAUQgMAVgUALQgVAMgaAAQgZAAgVgMgAgbgxQgMAIgGANQgHANAAAPQAAAQAHANQAGANAMAHQAMAHAPABQAQgBAMgHQALgHAHgNQAGgNAAgQQAAgPgGgNQgHgNgLgIQgMgHgQAAQgPAAgMAHg");
	this.shape_23.setTransform(170.7,13.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_24.setTransform(152.375,13.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_25.setTransform(135.1,13.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_26.setTransform(119.875,13.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape_27.setTransform(94.95,13.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AguBOQgUgLgMgVQgMgUABgaQgBgaAMgTQAMgVAUgLQAUgMAaAAQAbAAAUAMQAUALALAVQANATAAAaQAAAagNAUQgLAVgUALQgUAMgbAAQgaAAgUgMgAgbgxQgMAIgGANQgGANAAAPQAAAQAGANQAGANAMAHQAMAHAPABQAQgBAMgHQAMgHAGgNQAHgNgBgQQABgPgHgNQgGgNgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_28.setTransform(73.9,13.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_29.setTransform(56.35,13.875);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgoBSQgSgIgNgMIAVgdQAJAKAOAHQAOAGARABQAPAAAIgGQAHgFAAgJQAAgGgHgFQgIgEgLgDIgXgGQgNgDgLgFQgLgFgHgJQgIgKAAgRQAAgOAIgMQAIgMAPgHQAOgHAUgBQAVAAARAHQARAGAMAMIgUAbQgLgJgNgFQgNgFgMABQgMgBgHAFQgGAEAAAJQAAAGAHAEQAIADALADIAXAGQANADALAGQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAHgYABQgYgBgSgHg");
	this.shape_30.setTransform(40.875,13.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_31.setTransform(23.625,14.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgkBOQgVgLgMgUQgMgVAAgaQAAgaAMgUQAMgUAVgMQAVgLAZAAQATAAAOAHQAOAFAKAKQAJAKAGALIgfAPQgGgKgLgIQgKgGgOgBQgPAAgMAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQAMAIAPAAQAOAAAKgIQALgGAGgMIAfAQQgGALgJAJQgKAKgOAGQgOAHgTAAQgZAAgVgMg");
	this.shape_32.setTransform(5.375,13.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t31, new cjs.Rectangle(-5.8,0,222.8,82), null);


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AATAyIAAgwQAAgDgBgDQgBgEgCgCQgDgCgDgBIgHAAIgFAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAEgEIAHgFIAHgCIAHgBQAMAAAFAFQAGAGAAAMIAAAyg");
	this.shape.setTransform(150.8,23.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAEgEQAFgDAAgGQAAgEgDgCQgEgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgIAAgHgDg");
	this.shape_1.setTransform(143.05,25.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgCgCgBgDQABgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_2.setTransform(137.95,23.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_3.setTransform(132.1,25.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgCgCgBgDQABgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(126.25,23.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAGgGQAFgGAJAAIAIABIAHAFIgEAHIgFgDIgEgBQgGAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_5.setTransform(122.95,23.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgKAAIAAgwQAAgHgCgEQgEgEgHAAQgFAAgGADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAJgBQAIAAAEAEQAEAEACAFIAEgEIAFgFIAIgDIAHgBQAKAAAFAFQAFAGAAALIAAAzg");
	this.shape_6.setTransform(110.35,25.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_7.setTransform(99.975,25.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_8.setTransform(93.525,24.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgDgCQgEgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_9.setTransform(87.7,25.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgHADQgGAEgHAAQgMAAgFgGg");
	this.shape_10.setTransform(80.2,25.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_11.setTransform(72.425,25.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAGgDADgEIAAgOQgDgEgGgCQgFgCgFAAQgIAAgFAEg");
	this.shape_12.setTransform(60.55,25.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgGAFgDQAGgEAIAAIAAALIgFAAIgFABIgGACIgEAFIgDADIAAAzg");
	this.shape_13.setTransform(50.825,25.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_14.setTransform(43.625,25.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_15.setTransform(37.75,23.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_16.setTransform(29.025,24.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgEQAGgEAHAAQAHAAAGADQAGACAEAFQAEAFADAIQACAGAAAJQAAAJgCAGQgDAHgEAFQgEAFgGACQgGAEgHAAQgHgBgGgDQgGgDgFgHIAAAngAgNgkQgGADgDAFIAAAfQADAGAGADQAGAEAHAAQAEAAAFgDQAEgCADgDIAFgIQABgGAAgGQAAgGgBgFQgCgFgDgEQgDgDgEgCQgFgCgEgBQgHABgGADg");
	this.shape_17.setTransform(22.725,26.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJQABgGAAgFQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_18.setTransform(13.875,25.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgGAFgDQAGgEAIAAIAAALIgFAAIgFABIgGACIgEAFIgDADIAAAzg");
	this.shape_19.setTransform(3.625,25.15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_20.setTransform(-3.575,25.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape_21.setTransform(164.95,10.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgFg");
	this.shape_22.setTransform(159.375,9.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_23.setTransform(153,10.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_24.setTransform(147.15,8.95);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_25.setTransform(141.3,10.225);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgGAHgEQAGgDAHAAQAHAAAGADQAGADAEAFQAEAEADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGADQgGACgHAAQgHAAgGgDQgGgEgFgFIAAAmgAgNglQgGAEgDAFIAAAgQADAFAGADQAGADAHABQAEgBAFgCQAEgCADgEIAFgIQABgEAAgHQAAgGgBgFQgCgFgDgDQgDgFgEgBQgFgCgEAAQgHAAgGACg");
	this.shape_26.setTransform(133.475,11.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgNAwQgHgCgEgGQgEgEgCgHQgDgHAAgJQAAgJADgGQACgHAEgFQAEgFAGgDQAGgDAHAAQAHABAGADQAHADAEAHIAAgnIALAAIAABjIgLAAIAAgLQgEAGgGADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDAEgCADQgBAGAAAGQAAAGABAFQACAFADAEQADADAEACQAFADAEAAQAGAAAHgEQAFgDAEgFIAAgfQgEgGgFgDQgHgDgGAAQgEAAgFACg");
	this.shape_27.setTransform(120.5,8.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgGAFgDQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_28.setTransform(114.325,10.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFgBAGIAAAxIgLAAIAAgIQgJAKgOAAQgFAAgEgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_29.setTransform(107.3,10.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAwQgGgCgFgGQgEgEgDgHQgCgHAAgJQAAgJACgGQADgHAEgFQAEgFAGgDQAGgDAHAAQAHABAGADQAHADAEAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDAEgCADQgBAGAAAGQAAAGABAFQACAFADAEQADADAEACQAEADAFAAQAHAAAFgEQAGgDAEgFIAAgfQgEgGgGgDQgFgDgHAAQgFAAgEACg");
	this.shape_30.setTransform(99,8.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AATAlIAAguQgBgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_31.setTransform(90.75,10.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAGACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAQgFAAgEgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_32.setTransform(82.45,10.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgFg");
	this.shape_33.setTransform(76.525,9.35);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_34.setTransform(70.7,10.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgEAEIAAA0IgKAAIAAgwQAAgHgCgEQgEgEgHAAQgFAAgGADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAIgBQAJAAAFAEQADAEACAFIAEgEIAFgFIAHgDIAIgBQAKAAAFAFQAGAGgBALIAAAzg");
	this.shape_35.setTransform(57.35,10.125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_36.setTransform(46.975,10.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgGAFgDQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_37.setTransform(40.625,10.15);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_38.setTransform(36.15,8.775);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_39.setTransform(25.375,10.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgJgDIgLgDQgFgCgEgEQgDgDAAgHIACgIQACgEADgDQAEgDAEgBQAGgCAFAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgFACgIAAQgIAAgHgDg");
	this.shape_40.setTransform(17.55,10.225);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJQABgGAAgFQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_41.setTransform(9.825,10.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_42.setTransform(1.225,10.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAFgFIAGgDIAHgDIAHgCQALAAAGAHQAGAFAAAMIAAAyg");
	this.shape_43.setTransform(-7.2,8.85);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_44.setTransform(-16.25,8.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(-23.5,0,194.2,34), null);


(lib.t21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAHARAAQAPAAAIgGQAHgGAAgHQAAgIgHgEQgIgEgLgCIgXgHQgNgDgLgFQgLgFgHgJQgIgLAAgQQAAgOAIgMQAIgMAPgHQAOgHAUAAQAVAAARAFQARAHAMALIgUAcQgLgJgNgFQgNgFgMAAQgMAAgHAFQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAIgYAAQgYAAgSgIg");
	this.shape.setTransform(143.025,65.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAbBXIghg+IgbAAIAAA+IglAAIAAitIBRAAQASAAANAIQANAHAHAMQAHANABAQQgBAPgGALQgFAKgIAGQgJAHgKACIAoBCgAghgGIAnAAQAKAAAIgHQAHgGABgLQgBgLgHgGQgIgGgKAAIgnAAg");
	this.shape_1.setTransform(127.4,65.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AguBOQgUgMgMgTQgMgVAAgaQAAgaAMgTQAMgVAUgLQAUgLAaAAQAaAAAVALQAUALALAVQAMATAAAaQAAAagMAVQgLATgUAMQgVAMgaAAQgaAAgUgMgAgbgxQgMAIgGAMQgHANAAAQQAAAQAHANQAGANAMAHQAMAHAPABQAQgBAMgHQALgHAHgNQAGgNAAgQQAAgQgGgNQgHgMgLgIQgMgHgQAAQgPAAgMAHg");
	this.shape_2.setTransform(108.7,65.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AguBOQgUgMgMgTQgMgVAAgaQAAgaAMgTQAMgVAUgLQAVgLAZAAQAaAAAVALQAUALAMAVQAMATgBAaQABAagMAVQgMATgUAMQgVAMgaAAQgZAAgVgMgAgbgxQgMAIgGAMQgHANAAAQQAAAQAHANQAGANAMAHQAMAHAPABQAQgBAMgHQALgHAHgNQAGgNAAgQQAAgQgGgNQgHgMgLgIQgMgHgQAAQgPAAgMAHg");
	this.shape_3.setTransform(88.8,65.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_4.setTransform(69.925,65.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_5.setTransform(197.25,39.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag9BXIAAitIB7AAIAAAhIhWAAIAAAkIBUAAIAAAgIhUAAIAAAnIBWAAIAAAhg");
	this.shape_6.setTransform(182.4,39.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_7.setTransform(165.075,39.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgRBXIAAitIAjAAIAACtg");
	this.shape_8.setTransform(152.05,39.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhHBXIAAitIBaAAQARAAALAHQALAGAFAKQAGAKAAAMQAAAKgEAJQgEAIgHAFQgHAGgIABQAKACAHAFQAIAGAEAJQAEAJAAALQAAANgFALQgGAKgLAGQgLAHgRAAgAgiA2IAvAAQAKAAAGgFQAGgFAAgKQAAgIgGgGQgGgFgKAAIgvAAgAgigRIAtAAQAKAAAFgFQAFgFAAgIQAAgIgFgFQgFgFgKAAIgtAAg");
	this.shape_9.setTransform(140.175,39.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_10.setTransform(122.35,39.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgkBOQgVgLgMgUQgMgVAAgaQAAgaAMgUQAMgUAVgMQAVgLAZABQATgBAOAHQAOAFAKAKQAJAJAGAMIgfAPQgGgKgLgIQgKgGgOgBQgPAAgMAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQAMAIAPAAQAOAAAKgIQALgGAGgMIAfAQQgGALgJAJQgKAKgOAGQgOAHgTAAQgZAAgVgMg");
	this.shape_11.setTransform(104.725,39.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AApBXIAAhJIhRAAIAABJIglAAIAAitIAlAAIAABFIBRAAIAAhFIAlAAIAACtg");
	this.shape_12.setTransform(79.4,39.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgoBSQgSgHgNgNIAVgdQAJAKAOAHQAOAGARABQAPgBAIgFQAHgFAAgJQAAgGgHgFQgIgEgLgDIgXgGQgNgDgLgFQgLgFgHgJQgIgLAAgQQAAgOAIgMQAIgMAPgHQAOgHAUAAQAVgBARAHQARAGAMAMIgUAbQgLgKgNgEQgNgFgMABQgMgBgHAFQgGAFAAAHQAAAHAHAEQAIADALADIAXAGQANAEALAFQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAIgYAAQgYAAgSgIg");
	this.shape_13.setTransform(61.975,39.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgSBXIAAitIAkAAIAACtg");
	this.shape_14.setTransform(50.75,39.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_15.setTransform(37.725,39.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgRBXIAAitIAjAAIAACtg");
	this.shape_16.setTransform(24.7,39.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Ag8BXIAAitIB6AAIAAAhIhWAAIAAAkIBTAAIAAAgIhTAAIAABIg");
	this.shape_17.setTransform(14.15,39.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_18.setTransform(186.125,13.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgRBXIAAitIAkAAIAACtg");
	this.shape_19.setTransform(173.1,13.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_20.setTransform(160.65,13.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_21.setTransform(144.15,13.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgoBSQgSgIgNgMIAVgdQAJAKAOAHQAOAGARABQAPAAAIgGQAHgFAAgJQAAgGgHgFQgIgEgLgDIgXgGQgNgDgLgFQgLgFgHgJQgIgKAAgRQAAgOAIgMQAIgMAPgHQAOgHAUgBQAVAAARAHQARAGAMAMIgUAbQgLgJgNgFQgNgFgMABQgMgBgHAFQgGAEAAAJQAAAGAHAEQAIADALADIAXAGQANADALAGQALAGAHAJQAHAKABAQQAAAQgIANQgIAMgPAHQgPAHgYABQgYgBgSgHg");
	this.shape_22.setTransform(128.675,13.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgyBUQgOgGgHgLQgIgLAAgRQABgNAEgJQAFgJAJgHQAJgGAKgEIgIgTQgDgKgBgJQABgMAFgJQAHgJALgGQALgFAPgBQALABAKAEQALAEAFAJQAHAHAAAMQAAANgGAJQgGAJgKAGQgJAGgKAEIAGAJIAIAJIAPASQAFgIAEgJIAGgPIAaALIgKAVQgGALgHAKIAPARIASASIgqAAIgGgGIgIgIQgJAIgMAEQgLAEgNABQgQgBgNgFgAgnAVQgEAHgBAIQAAAJAEAGQAEAGAGADQAGADAHABQAHgBAGgCQAFgCAGgEIgKgMIgIgKIgJgMIgJgMQgGAFgEAHgAgOg8QgGAGAAAIQAAAFACAGIAGAMQALgFAGgGQAIgHAAgJQgBgHgEgEQgEgEgGABQgIAAgEAEg");
	this.shape_23.setTransform(106.1,13.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgRBXIAAiMIgzAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_24.setTransform(83.2,13.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_25.setTransform(66.175,13.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgSBXIAAitIAkAAIAACtg");
	this.shape_26.setTransform(53.15,13.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_27.setTransform(40.7,13.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AhFBXIAAitIBRAAQASABANAHQANAIAHAMQAHANAAAPQAAAQgHAMQgHAMgNAHQgNAIgSAAIgsAAIAAA+gAgggHIAmAAQALAAAIgGQAHgGAAgLQAAgLgHgGQgIgGgLAAIgmAAg");
	this.shape_28.setTransform(24.225,13.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t21, new cjs.Rectangle(4.3,0,202.7,82), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape.setTransform(140.85,25.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_1.setTransform(132.475,25.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDgBIgGAAIgGAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQAMAAAFAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(124.1,23.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_3.setTransform(116.325,25.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_4.setTransform(110.325,24.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgFAxIAAhHIAKAAIAABHgAgFgjQgBgCAAgDQAAgDABgDQADgCACAAQADAAACACQADADAAADQAAADgDACQgCACgDAAQgCAAgDgCg");
	this.shape_5.setTransform(106.4,23.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AARAyIgZghIgLANIAAAUIgMAAIAAhjIAMAAIAABBIAkglIAPAAIggAgIAgAng");
	this.shape_6.setTransform(101.3,23.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_7.setTransform(90.925,24.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQABACADAAIAHABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgHADQgGAEgHAAQgMAAgFgGg");
	this.shape_8.setTransform(84.6,25.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_9.setTransform(76.125,25.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgNAwQgHgDgEgFQgEgEgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgDQAGgCAHAAQAHgBAGAEQAGAEAFAFIAAgmIALAAIAABjIgLAAIAAgLQgFAGgFAEQgHADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDAEgBAEQgCAFAAAGQAAAGACAFQABAFADAEQADAEAEACQAEACAFAAQAGAAAHgDQAGgEADgEIAAghQgDgEgGgEQgHgDgGAAQgFAAgEACg");
	this.shape_10.setTransform(67.3,23.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_11.setTransform(59.05,25.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEAAgGQAAgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgKAKIgFgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_12.setTransform(50.75,25.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_13.setTransform(44.825,24.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIACgIQACgEADgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_14.setTransform(39,25.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAGACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_15.setTransform(27.55,25.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgGAFgDQAGgEAIAAIAAALIgFAAIgFABIgGACIgEAFIgDADIAAAzg");
	this.shape_16.setTransform(17.825,25.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_17.setTransform(10.625,25.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAGgGQAFgGAJAAIAIABIAHAFIgFAHIgEgDIgFgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_18.setTransform(4.75,23.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgYAyIgFAAIACgKIADABIADAAQAEAAADgBQACgCACgFIAFgLIgehIIAMAAIAXA6IAYg6IAMAAIgkBWQgCAIgGAEQgFADgHAAIgEgBg");
	this.shape_19.setTransform(128.825,11.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgGAFgDQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_20.setTransform(123.075,10.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgFg");
	this.shape_21.setTransform(118.025,9.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_22.setTransform(111.575,10.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_23.setTransform(103.2,10.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAxIAAhIIAKAAIAABIgAgEgjQgDgCAAgDQAAgDADgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_24.setTransform(97.35,8.95);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgDAHgBQAHAAAGADQAGADAEAFQAEAFADAHQACAGAAAJQAAAJgCAHQgDAHgEAEQgEAGgGACQgGADgHAAQgHAAgGgEgAgNgLQgGADgDAGIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgCADgDQADgEACgFQABgFAAgGQAAgGgBgGQgCgDgDgEQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_25.setTransform(91.525,8.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgCgEAAgGQAAgGACgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAQgFAAgEgBgAgNADQgEAEAAAHQAAAHAEAFQAFAEAIAAQAFAAAFgCQAFgDAEgEIAAgOQgEgEgFgCQgFgCgFAAQgIAAgFAEg");
	this.shape_26.setTransform(82.85,10.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_27.setTransform(74.2,8.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAgwQAAgHgDgEQgDgEgHAAQgGAAgEADQgGAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIADgEIAGgEIAHgDIAHgBQAJAAAFAEQADAEACAFIAEgEIAGgFIAGgDIAIgBQAKAAAFAFQAGAGAAALIAAAzg");
	this.shape_28.setTransform(59,10.125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_29.setTransform(48.625,10.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgFg");
	this.shape_30.setTransform(42.175,9.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgEgCQgDgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIACgIQABgEAEgDQAEgDAEgBQAFgCAGAAQAJAAAHADQAHADAEAEIgFAIQgEgEgFgCQgGgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape_31.setTransform(36.35,10.225);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACACAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_32.setTransform(28.85,10.325);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAJAAQAHAAAGACIAKAEQAFACAEAEIAGAIIgKAGQgEgHgIgEQgHgEgJAAQgGAAgHADQgIADgFAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAFAFAIADQAHADAGAAQAJAAAHgEQAIgEAEgGIALAGQgGAIgKAGQgJAGgOAAQgJAAgKgEg");
	this.shape_33.setTransform(19.8,8.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(0,0,147.1,34), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape.setTransform(160.475,65.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_1.setTransform(144.5,65.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgRBXIAAitIAkAAIAACtg");
	this.shape_2.setTransform(133.4,65.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag2BXIAAitIAlAAIAACMIBIAAIAAAhg");
	this.shape_3.setTransform(123.525,65.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_4.setTransform(107.55,65.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag8BXIAAitIB5AAIAAAhIhUAAIAAAkIBSAAIAAAgIhSAAIAAAnIBUAAIAAAhg");
	this.shape_5.setTransform(91.35,65.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAbBXIghg+IgbAAIAAA+IglAAIAAitIBRAAQASAAANAIQANAHAHAMQAHANABAQQgBAPgFALQgGAKgJAGQgIAHgKACIAoBCgAghgGIAnAAQAKAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgKAAIgnAAg");
	this.shape_6.setTransform(75.55,65.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_7.setTransform(51.2,65.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAqBXIhShwIAABwIglAAIAAitIAmAAIBQBsIAAhsIAlAAIAACtg");
	this.shape_8.setTransform(199.625,39.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag9BXIAAitIB7AAIAAAhIhWAAIAAAkIBUAAIAAAgIhUAAIAAAnIBWAAIAAAhg");
	this.shape_9.setTransform(182.85,39.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AApBXIAAhJIhRAAIAABJIglAAIAAitIAlAAIAABFIBRAAIAAhFIAlAAIAACtg");
	this.shape_10.setTransform(165.5,39.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgkBOQgVgLgMgUQgMgVAAgaQAAgaAMgUQAMgUAVgMQAVgLAZABQATgBAOAHQAOAFAKAKQAJAJAGAMIgfAPQgGgKgLgIQgKgGgOgBQgPAAgMAHQgMAIgHANQgHANAAAPQAAARAHAMQAHANAMAHQAMAIAPAAQAOAAAKgIQALgGAGgMIAfAQQgGALgJAJQgKAKgOAGQgOAHgTAAQgZAAgVgMg");
	this.shape_11.setTransform(147.275,39.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgSBXIAAiMIgyAAIAAghICJAAIAAAhIgyAAIAACMg");
	this.shape_12.setTransform(130.55,39.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgRBXIAAitIAkAAIAACtg");
	this.shape_13.setTransform(119.45,39.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAdBXIg0hGIgNAQIAAA2IglAAIAAitIAlAAIAABOIA8hOIAuAAIhFBSIBJBbg");
	this.shape_14.setTransform(108.475,39.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape_15.setTransform(81.5,39.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_16.setTransform(61.5,39.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Ag9BXIAAitIB7AAIAAAhIhWAAIAAAkIBTAAIAAAgIhTAAIAAAnIBWAAIAAAhg");
	this.shape_17.setTransform(45.3,39.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAbBXIggg+IgbAAIAAA+IgmAAIAAitIBRAAQASAAANAIQANAHAHAMQAHANABAQQgBAPgGALQgFAKgIAGQgKAHgJACIAnBCgAgggGIAmAAQALAAAHgHQAHgGABgLQgBgLgHgGQgHgGgLAAIgmAAg");
	this.shape_18.setTransform(29.5,39.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AhPBXIAAitIBEAAQAbAAAUALQAVALAMATQALAUAAAZQAAAagLAUQgMATgVALQgUALgaAAgAgqA2IAfAAQAQAAANgHQAMgIAGgMQAHgMAAgPQAAgOgHgNQgGgMgMgHQgMgHgQAAIggAAg");
	this.shape_19.setTransform(11.825,39.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAcBXIgig+IgbAAIAAA+IgkAAIAAitIBQAAQASAAANAIQANAHAHAMQAHANABAQQgBAPgFALQgGAKgJAGQgJAHgJACIAoBCgAghgGIAmAAQALAAAIgHQAHgGAAgLQAAgLgHgGQgIgGgLAAIgmAAg");
	this.shape_20.setTransform(173.1,13.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgrBPQgRgJgJgQQgIgRAAgVIAAhnIAlAAIAABmQAAASALALQAKALATABQAUgBAKgLQALgLAAgSIAAhmIAlAAIAABnQAAAVgIARQgJAQgRAJQgSAJgaAAQgZAAgSgJg");
	this.shape_21.setTransform(154.775,14.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AguBOQgUgLgMgVQgLgUAAgaQAAgaALgTQAMgVAUgLQAVgMAZAAQAaAAAVAMQAUALAMAVQALATABAaQgBAagLAUQgMAVgUALQgVAMgaAAQgZAAgVgMgAgbgxQgLAIgHANQgGANAAAPQAAAQAGANQAHANALAHQAMAHAPABQAQgBAMgHQAMgHAGgNQAHgNAAgQQAAgPgHgNQgGgNgMgIQgMgHgQAAQgPAAgMAHg");
	this.shape_22.setTransform(135.3,13.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgRBXIAAhHIhDhmIAqAAIAqBGIArhGIAqAAIhCBmIAABHg");
	this.shape_23.setTransform(116.975,13.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("Ag8BXIAAitIB5AAIAAAhIhUAAIAAAkIBSAAIAAAgIhSAAIAAAnIBUAAIAAAhg");
	this.shape_24.setTransform(94.6,13.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAdBXIg0hGIgNAQIAAA2IglAAIAAitIAlAAIAABOIA8hOIAuAAIhFBSIBJBbg");
	this.shape_25.setTransform(79.325,13.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAwBXIgLgeIhJAAIgLAeIgqAAIBDitIAtAAIBDCtgAAbAZIgbhKIgaBKIA1AAg");
	this.shape_26.setTransform(61.3,13.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AA5BXIAAh8IgxB8IgPAAIgxh8IAAB8IglAAIAAitIA0AAIApBsIAqhsIA0AAIAACtg");
	this.shape_27.setTransform(41.25,13.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(0,0,211.2,82), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape.setTransform(533.85,71.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(533.85,71.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_2.setTransform(533.85,71.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_3.setTransform(533.85,71.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_4.setTransform(533.85,71.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_5.setTransform(533.85,71.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_6.setTransform(533.85,71.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_7.setTransform(533.85,71.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_8.setTransform(533.85,71.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_9.setTransform(533.85,71.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},44).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(98));

	// Слой_2 - копия: 2 - копия
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_10.setTransform(533.85,211.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.875)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_11.setTransform(533.85,211.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.749)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(533.85,211.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.624)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_13.setTransform(533.85,211.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.502)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_14.setTransform(533.85,211.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.376)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_15.setTransform(533.85,211.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.251)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_16.setTransform(533.85,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.125)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_17.setTransform(533.85,211.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_18.setTransform(533.85,211.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10}]}).to({state:[{t:this.shape_10}]},39).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).wait(104));

	// Слой_3 - копия: 2
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_19.setTransform(413.1,71.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.89)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_20.setTransform(413.1,71.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.776)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_21.setTransform(413.1,71.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.667)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(413.1,71.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.557)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_23.setTransform(413.1,71.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.443)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_24.setTransform(413.1,71.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.333)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_25.setTransform(413.1,71.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.224)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_26.setTransform(413.1,71.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.11)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_27.setTransform(413.1,71.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_28.setTransform(413.1,71.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19}]}).to({state:[{t:this.shape_19}]},35).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).wait(107));

	// Слой_2 - копия: 2
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_29.setTransform(413.1,211.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.875)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_30.setTransform(413.1,211.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.749)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_31.setTransform(413.1,211.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.624)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_32.setTransform(413.1,211.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.502)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(413.1,211.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.376)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_34.setTransform(413.1,211.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.251)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_35.setTransform(413.1,211.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.125)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_36.setTransform(413.1,211.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_37.setTransform(413.1,211.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29}]}).to({state:[{t:this.shape_29}]},30).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_38.setTransform(295.9,210.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.89)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_39.setTransform(295.9,210.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.776)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_40.setTransform(295.9,210.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.667)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_41.setTransform(295.9,210.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.557)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_42.setTransform(295.9,210.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.443)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_43.setTransform(295.9,210.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.333)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_44.setTransform(295.9,210.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.224)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_45.setTransform(295.9,210.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.11)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_46.setTransform(295.9,210.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA15ISvAAIAAV5g");
	this.shape_47.setTransform(295.9,210.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38}]}).to({state:[{t:this.shape_38}]},25).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).wait(117));

	// Слой_2 - копия: 2
	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_48.setTransform(295.9,69.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.875)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_49.setTransform(295.9,69.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.749)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_50.setTransform(295.9,69.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.624)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_51.setTransform(295.9,69.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.502)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_52.setTransform(295.9,69.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.376)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(295.9,69.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.251)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_54.setTransform(295.9,69.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.125)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_55.setTransform(295.9,69.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_56.setTransform(295.9,69.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48}]}).to({state:[{t:this.shape_48}]},20).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).wait(123));

	// Слой_3 - копия
	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_57.setTransform(177.2,71.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.89)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_58.setTransform(177.2,71.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.776)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_59.setTransform(177.2,71.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.667)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_60.setTransform(177.2,71.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.557)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_61.setTransform(177.2,71.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.443)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_62.setTransform(177.2,71.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.333)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(177.2,71.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.224)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_64.setTransform(177.2,71.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.11)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_65.setTransform(177.2,71.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_66.setTransform(177.2,71.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_57}]}).to({state:[{t:this.shape_57}]},15).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).wait(127));

	// Слой_2 - копия
	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_67.setTransform(177.2,211.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.875)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_68.setTransform(177.2,211.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.749)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_69.setTransform(177.2,211.3);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.624)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_70.setTransform(177.2,211.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.502)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_71.setTransform(177.2,211.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.376)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_72.setTransform(177.2,211.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0.251)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_73.setTransform(177.2,211.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(255,255,255,0.125)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(177.2,211.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_75.setTransform(177.2,211.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_67}]}).to({state:[{t:this.shape_67}]},10).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).wait(133));

	// Слой_3
	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_76.setTransform(60,210.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.89)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_77.setTransform(60,210.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.776)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_78.setTransform(60,210.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.667)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_79.setTransform(60,210.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.557)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_80.setTransform(60,210.6);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.443)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_81.setTransform(60,210.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0.333)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_82.setTransform(60,210.6);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,255,255,0.224)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_83.setTransform(60,210.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(255,255,255,0.11)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(60,210.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_85.setTransform(60,210.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_76}]}).to({state:[{t:this.shape_76}]},5).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).wait(137));

	// Слой_2
	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_86.setTransform(60,69.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.875)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_87.setTransform(60,69.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.749)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_88.setTransform(60,69.9);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.624)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_89.setTransform(60,69.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.502)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_90.setTransform(60,69.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.376)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_91.setTransform(60,69.9);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.251)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_92.setTransform(60,69.9);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0.125)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_93.setTransform(60,69.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_94.setTransform(60,69.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_86}]}).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).wait(143));

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.2,593.9,281.7);


(lib.pc12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen12();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc12, new cjs.Rectangle(0,0,336,280), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,280), null);


(lib.pc3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen31();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc3, new cjs.Rectangle(0,0,685,280), null);


(lib.marker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAagtIBrAtIhrAugAiEAAIBogsIAABZg");
	this.shape.setTransform(20.0132,255.4238,0.8834,0.8834);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0F0F0F").s().p("Ah1B2QgxgwAAhGQAAhEAxgyQAwgwBFAAQBGAAAxAwQAwAyAABEQAABGgwAwQgxAxhGAAQhFAAgwgxg");
	this.shape_1.setTransform(20.075,255.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.498)").s().p("AiNCOQg6g6AAhUQAAhSA6g7QA7g7BSABQBUgBA6A7QA6A7AABSQAABUg6A6Qg6A6hUAAQhSAAg7g6g");
	this.shape_2.setTransform(20.05,255.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgOWqMAAAgtTIAdAAMAAAAtTg");
	this.shape_3.setTransform(20.05,144.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.marker, new cjs.Rectangle(0,0,40.1,290), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,98,28), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape.setTransform(83.525,17.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_1.setTransform(73.675,17.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAdAyIg5hPIAABPIgNAAIAAhjIAOAAIA4BNIAAhNIAMAAIAABjg");
	this.shape_2.setTransform(64.1,15.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgEQAGgEAHAAQAHAAAGADQAGACAEAFQAEAFADAIQACAGAAAJQAAAJgCAGQgDAHgEAFQgEAFgGACQgGAEgHAAQgHAAgGgEQgGgDgFgHIAAAngAgNgkQgGADgDAFIAAAfQADAFAGAEQAGAEAHAAQAEAAAFgDQAEgCADgDIAFgIQABgGAAgGQAAgGgBgFQgCgFgDgEQgDgDgEgCQgFgDgEAAQgHAAgGAEg");
	this.shape_3.setTransform(50.825,18.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_4.setTransform(41.975,17.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_5.setTransform(33.55,15.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVAvQgJgEgHgHIAIgKIAGAGIAHAEIAIADIAJABQAHAAAFgBQAEgCADgCIAEgGIABgGQAAgFgDgDIgGgFIgKgEIgKgDIgLgDQgFgBgEgDQgEgDgDgFQgCgEAAgHQAAgGACgFQADgFAEgEQAFgEAGgCQAHgCAGAAQAMAAAIAEQAJADAGAHIgHAJQgGgGgHgDQgIgDgHAAQgJAAgGAFQgFAEAAAHQAAAEACADIAHAFIAJADIAKADIALAEQAFACAFACQAEAEACAEQADAFAAAHQAAAGgCAFQgCAFgFAEQgEAEgHADQgHADgKAAQgMAAgKgFg");
	this.shape_6.setTransform(24.925,15.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_7.setTransform(54.8207,16.3109,0.8366,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,109.6,32.7), null);


// stage content:
(lib._336x280_KitchenCabinets11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_791 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(791).call(this.frame_791).wait(34));

	// btn
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(168,216,1,1,0,0,0,54.8,16.3);
	this.instance.alpha = 0.0117;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({y:219,alpha:1},8,cjs.Ease.get(1)).wait(71).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(50).to({_off:false,y:216},0).to({y:219,alpha:1},8).wait(69).to({alpha:0.0117},13).to({_off:true},1).wait(56).to({_off:false,y:216},0).to({y:219,alpha:1},8).wait(66).to({alpha:0.0117},11).to({_off:true},1).wait(50).to({_off:false,y:216},0).to({y:219,alpha:1},8,cjs.Ease.get(1)).wait(62).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(47).to({_off:false,y:216},0).to({y:219,alpha:1},8).wait(63).to({alpha:0.0117},13).to({_off:true},1).wait(59).to({_off:false,y:216},0).to({y:219,alpha:1},8).wait(59).to({alpha:0.0117},11).wait(1));

	// Слой_23
	this.instance_1 = new lib.logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(168.1,67.05,0.8,0.8,0,0,0,49.1,14.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49).to({_off:false},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(71).to({alpha:0},11).to({_off:true},1).wait(50).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(69).to({alpha:0},13).to({_off:true},1).wait(56).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(66).to({alpha:0},11).to({_off:true},1).wait(50).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(62).to({alpha:0},11).to({_off:true},1).wait(47).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(63).to({alpha:0},13).to({_off:true},1).wait(59).to({_off:false,y:67.05},0).to({y:58.05,alpha:1},8,cjs.Ease.get(1)).wait(59).to({alpha:0},11).wait(1));

	// t12
	this.instance_2 = new lib.t12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,182,1,1,0,0,0,73.5,17);
	this.instance_2.alpha = 0.0117;
	this.instance_2._off = true;

	this.instance_3 = new lib.t22();
	this.instance_3.parent = this;
	this.instance_3.setTransform(167.95,182,1,1,0,0,0,73.5,17);
	this.instance_3.alpha = 0.0117;
	this.instance_3._off = true;

	this.instance_4 = new lib.t32();
	this.instance_4.parent = this;
	this.instance_4.setTransform(167.95,182,1,1,0,0,0,73.5,17);
	this.instance_4.alpha = 0.0117;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(45).to({_off:false},0).to({y:173.35,alpha:1},8,cjs.Ease.get(1)).wait(75).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(329).to({_off:false,y:182},0).to({y:173.35,alpha:1},8,cjs.Ease.get(1)).wait(66).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(270));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(187).to({_off:false},0).to({y:173.35,alpha:1},8).wait(72).to({alpha:0.0117},13).to({_off:true},1).wait(318).to({_off:false,y:182},0).to({y:173.35,alpha:1},8).wait(66).to({alpha:0.0117},13).to({_off:true},1).wait(138));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(334).to({_off:false},0).to({y:173.35,alpha:1},8).wait(69).to({alpha:0.0117},11).to({_off:true},1).wait(320).to({_off:false,y:182},0).to({y:173.35,alpha:1},8).wait(62).to({alpha:0.0117},11).wait(1));

	// t11
	this.instance_5 = new lib.t11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(168,149,1,1,0,0,0,105.6,41);
	this.instance_5.alpha = 0.0117;
	this.instance_5._off = true;

	this.instance_6 = new lib.t21();
	this.instance_6.parent = this;
	this.instance_6.setTransform(168,149,1,1,0,0,0,105.6,41);
	this.instance_6.alpha = 0.0117;
	this.instance_6._off = true;

	this.instance_7 = new lib.t31();
	this.instance_7.parent = this;
	this.instance_7.setTransform(168,149,1,1,0,0,0,105.6,41);
	this.instance_7.alpha = 0.0117;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(42).to({_off:false},0).to({y:118.35,alpha:1},8,cjs.Ease.get(1)).wait(78).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(326).to({_off:false,y:149},0).to({y:118.35,alpha:1},8,cjs.Ease.get(1)).wait(69).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(270));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(184).to({_off:false},0).to({y:118.35,alpha:1},8).wait(75).to({alpha:0.0117},13).to({_off:true},1).wait(315).to({_off:false,y:149},0).to({y:118.35,alpha:1},8).wait(69).to({alpha:0.0117},13).to({_off:true},1).wait(138));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(331).to({_off:false},0).to({y:118.35,alpha:1},8).wait(72).to({alpha:0.0117},11).to({_off:true},1).wait(317).to({_off:false,y:149},0).to({y:118.35,alpha:1},8).wait(65).to({alpha:0.0117},11).wait(1));

	// Слой_14
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A0iAKIAAgTMApFAAAIAAATg");
	this.shape.setTransform(168,140);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A0iFWIAAqrMApFAAAIAAKrg");
	this.shape_1.setTransform(168,140);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A0iJlIAAzJMApFAAAIAATJg");
	this.shape_2.setTransform(168,140);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A0iM5IAA5xMApFAAAIAAZxg");
	this.shape_3.setTransform(168,140.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A0iPQIAA+fMApFAAAIAAefg");
	this.shape_4.setTransform(168,140.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A0iQqMAAAghTMApFAAAMAAAAhTg");
	this.shape_5.setTransform(168,140.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_6.setTransform(168,140.025);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.992)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_7.setTransform(168,140.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.969)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_8.setTransform(168,140.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.925)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_9.setTransform(168,140.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.867)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_10.setTransform(168,140.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.792)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_11.setTransform(168,140.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.702)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_12.setTransform(168,140.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.596)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_13.setTransform(168,140.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.471)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_14.setTransform(168,140.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.329)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_15.setTransform(168,140.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.173)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_16.setTransform(168,140.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_17.setTransform(168,140.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("A0iC/IAAl9MApFAAAIAAF9g");
	this.shape_18.setTransform(168,140);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("A0iF0IAArnMApFAAAIAALng");
	this.shape_19.setTransform(168,140);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("A0iIpIAAxRMApFAAAIAARRg");
	this.shape_20.setTransform(168,140.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("A0iLeIAA27MApFAAAIAAW7g");
	this.shape_21.setTransform(168,140.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("A0iOTIAA8lMApFAAAIAAclg");
	this.shape_22.setTransform(168,140.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.922)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_23.setTransform(168,140.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.847)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_24.setTransform(168,140.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.769)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_25.setTransform(168,140.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.694)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_26.setTransform(168,140.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.616)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_27.setTransform(168,140.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.537)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_28.setTransform(168,140.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.463)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_29.setTransform(168,140.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.384)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_30.setTransform(168,140.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.306)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_31.setTransform(168,140.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.231)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_32.setTransform(168,140.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.153)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_33.setTransform(168,140.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.078)").s().p("A0iRIMAAAgiPMApFAAAMAAAAiPg");
	this.shape_34.setTransform(168,140.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},39).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},83).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},41).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},80).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},47).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},77).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[]},1).to({state:[{t:this.shape}]},40).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},74).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},38).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},74).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},50).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},70).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(39).to({_off:false},0).to({_off:true},1).wait(141).to({_off:false},0).to({_off:true},1).wait(146).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(129).to({_off:false},0).to({_off:true},1).wait(143).to({_off:false},0).to({_off:true},1).wait(87));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(45).to({_off:false},0).wait(83).to({_off:true},1).wait(58).to({_off:false},0).wait(80).to({_off:true},1).wait(66).to({_off:false},0).wait(88).to({_off:true},1).wait(46).to({_off:false},0).wait(74).to({_off:true},1).wait(55).to({_off:false},0).wait(74).to({_off:true},1).wait(69).to({_off:false},0).wait(82));

	// screen31.jpg
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(0,0,0,0.004)").s().p("A7QWvMAAAgtdMA2hAAAMAAAAtdg");
	this.shape_35.setTransform(168,140.025);
	this.shape_35._off = true;

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(0,0,0,0.063)").s().p("A7HWnMAAAgtNMA2PAAAMAAAAtNg");
	this.shape_36.setTransform(168,140.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(0,0,0,0.114)").s().p("A7AWhMAAAgtBMA2AAAAMAAAAtBg");
	this.shape_37.setTransform(168,140);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(0,0,0,0.153)").s().p("A66WcMAAAgs3MA11AAAMAAAAs3g");
	this.shape_38.setTransform(168.025,140.025);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(0,0,0,0.176)").s().p("A62WZMAAAgsxMA1tAAAMAAAAsxg");
	this.shape_39.setTransform(168.025,140.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(0,0,0,0.196)").s().p("A6zWWMAAAgssMA1nAAAMAAAAssg");
	this.shape_40.setTransform(168.025,140);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(0,0,0,0.2)").s().p("A6yWWMAAAgsrMA1lAAAMAAAAsrg");
	this.shape_41.setTransform(168.025,140);
	this.shape_41._off = true;

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(0,0,0,0.192)").s().p("A6zWXMAAAgstMA1nAAAMAAAAstg");
	this.shape_42.setTransform(168.025,140);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(0,0,0,0.184)").s().p("A60WYMAAAgsvMA1pAAAMAAAAsvg");
	this.shape_43.setTransform(168.025,140);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(0,0,0,0.173)").s().p("A62WZMAAAgsxMA1tAAAMAAAAsxg");
	this.shape_44.setTransform(168.025,140.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(0,0,0,0.161)").s().p("A64WbMAAAgs1MA1xAAAMAAAAs1g");
	this.shape_45.setTransform(168.025,140);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(0,0,0,0.141)").s().p("A67WeMAAAgs7MA13AAAMAAAAs7g");
	this.shape_46.setTransform(168.025,140);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(0,0,0,0.122)").s().p("A6+WgMAAAgs/MA19AAAMAAAAs/g");
	this.shape_47.setTransform(168.025,140);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(0,0,0,0.098)").s().p("A7CWjMAAAgtFMA2FAAAMAAAAtFg");
	this.shape_48.setTransform(168,140);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(0,0,0,0.071)").s().p("A7GWnMAAAgtNMA2NAAAMAAAAtNg");
	this.shape_49.setTransform(168,140);
	this.shape_49._off = true;

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(0,0,0,0.039)").s().p("A7LWqMAAAgtTMA2XAAAMAAAAtTg");
	this.shape_50.setTransform(168,140.025);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(0,0,0,0.035)").s().p("A7LWrMAAAgtVMA2XAAAMAAAAtVg");
	this.shape_51.setTransform(168,140.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(0,0,0,0.102)").s().p("A7BWiMAAAgtDMA2DAAAMAAAAtDg");
	this.shape_52.setTransform(168.025,140.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(0,0,0,0.133)").s().p("A68WeMAAAgs7MA15AAAMAAAAs7g");
	this.shape_53.setTransform(168.025,140.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(0,0,0,0.169)").s().p("A63WaMAAAgszMA1vAAAMAAAAszg");
	this.shape_54.setTransform(168.025,140);
	this.shape_54._off = true;

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(0,0,0,0.184)").s().p("A61WYMAAAgsvMA1rAAAMAAAAsvg");
	this.shape_55.setTransform(168.025,140);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(0,0,0,0.153)").s().p("A65WcMAAAgs3MA1zAAAMAAAAs3g");
	this.shape_56.setTransform(168.025,140.025);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(0,0,0,0.125)").s().p("A6+WfMAAAgs+MA19AAAMAAAAs+g");
	this.shape_57.setTransform(168.025,140);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(0,0,0,0.11)").s().p("A7AWhMAAAgtBMA2BAAAMAAAAtBg");
	this.shape_58.setTransform(168,140);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(0,0,0,0.094)").s().p("A7CWjMAAAgtFMA2FAAAMAAAAtFg");
	this.shape_59.setTransform(168.025,140.025);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(0,0,0,0.078)").s().p("A7EWlMAAAgtJMA2KAAAMAAAAtJg");
	this.shape_60.setTransform(168,140.025);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(0,0,0,0.051)").s().p("A7JWpMAAAgtRMA2TAAAMAAAAtRg");
	this.shape_61.setTransform(168,140);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(0,0,0,0.035)").s().p("A7LWrMAAAgtVMA2YAAAMAAAAtVg");
	this.shape_62.setTransform(168,140.025);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(0,0,0,0.02)").s().p("A7NWtMAAAgtZMA2cAAAMAAAAtZg");
	this.shape_63.setTransform(168,140.025);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(0,0,0,0.18)").s().p("A61WYMAAAgsvMA1rAAAMAAAAsvg");
	this.shape_64.setTransform(168.025,140.025);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(0,0,0,0.165)").s().p("A64WaMAAAgszMA1xAAAMAAAAszg");
	this.shape_65.setTransform(168.025,140);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(0,0,0,0.145)").s().p("A66WdMAAAgs5MA11AAAMAAAAs5g");
	this.shape_66.setTransform(168.025,140.025);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(0,0,0,0.129)").s().p("A69WfMAAAgs9MA17AAAMAAAAs9g");
	this.shape_67.setTransform(168,140);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(0,0,0,0.094)").s().p("A7CWjMAAAgtFMA2GAAAMAAAAtFg");
	this.shape_68.setTransform(168,140);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(0,0,0,0.075)").s().p("A7FWmMAAAgtLMA2LAAAMAAAAtLg");
	this.shape_69.setTransform(168.025,140.025);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(0,0,0,0.059)").s().p("A7IWoMAAAgtPMA2RAAAMAAAAtPg");
	this.shape_70.setTransform(168,140);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(0,0,0,0.039)").s().p("A7KWqMAAAgtTMA2VAAAMAAAAtTg");
	this.shape_71.setTransform(168,140.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(0,0,0,0.024)").s().p("A7NWsMAAAgtXMA2cAAAMAAAAtXg");
	this.shape_72.setTransform(168,140);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_35}]},39).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},83).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},41).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},80).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58,p:{x:168,y:140}}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},47).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},77).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_58,p:{x:168.025,y:140.025}}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},40).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},74).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},38).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},74).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58,p:{x:168,y:140}}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},50).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},70).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_58,p:{x:168.025,y:140.025}}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_35}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(39).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(98).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(40).to({_off:false},0).to({_off:true},1).wait(90).to({_off:false},0).to({_off:true},1).wait(38).to({_off:false},0).to({_off:true},1).wait(92).to({_off:false},0).to({_off:true},1).wait(50).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(45).to({_off:false},0).wait(84).to({_off:true},1).wait(57).to({_off:false},0).wait(80).to({_off:true},1).wait(66).to({_off:false},0).wait(77).to({_off:true},1).wait(57).to({_off:false},0).wait(75).to({_off:true},1).wait(54).to({_off:false},0).wait(74).to({_off:true},1).wait(69).to({_off:false},0).wait(70).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_49).wait(137).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(146).to({_off:false},0).to({_off:true},1).wait(221).to({_off:false},0).to({_off:true},1).wait(42).to({_off:false},0).to({_off:true},1).wait(143).to({_off:false},0).to({_off:true},1).wait(85));
	this.timeline.addTween(cjs.Tween.get(this.shape_54).wait(186).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(264).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(66).to({_off:false},0).to({_off:true},1).wait(82));

	// Слой_21
	this.instance_8 = new lib.pc3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(342.5,140,1,1,0,0,0,342.5,140);
	this.instance_8.alpha = 0.0117;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(267).to({_off:false},0).to({x:303.25,alpha:1},13).to({x:7.35},131).to({x:-6.5,alpha:0},11).to({_off:true},1).wait(250).to({_off:false,x:342.5,alpha:0.0117},0).to({x:303.25,alpha:1},13).to({x:7.35},127).to({x:-6.5,alpha:0},11).wait(1));

	// screen21.jpg
	this.instance_9 = new lib.pc21("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(296,140,1,1,0,0,0,296,140);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(136).to({_off:false},0).to({x:40,alpha:0,mode:"independent"},144).to({_off:true},1).wait(270).to({_off:false,x:296,alpha:1,mode:"synched",startPosition:0},0).to({x:40,alpha:0,mode:"independent"},135).to({_off:true},1).wait(138));

	// marker
	this.instance_10 = new lib.marker();
	this.instance_10.parent = this;
	this.instance_10.setTransform(33.1,140.05,1,1,0,0,0,20.1,145);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({x:356.05},83,cjs.Ease.get(1)).to({_off:true},1).wait(339).to({_off:false,x:33.1},0).to({x:356.05},83,cjs.Ease.get(1)).to({_off:true},1).wait(318));

	// Слой_13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AikWRMAAAgshIFJAAMAAAAshg");
	var mask_graphics_1 = new cjs.Graphics().p("AjLWRMAAAgshIGXAAMAAAAshg");
	var mask_graphics_2 = new cjs.Graphics().p("AjxWRMAAAgshIHjAAMAAAAshg");
	var mask_graphics_3 = new cjs.Graphics().p("AkXWRMAAAgshIIvAAMAAAAshg");
	var mask_graphics_4 = new cjs.Graphics().p("Ak8WRMAAAgshIJ5AAMAAAAshg");
	var mask_graphics_5 = new cjs.Graphics().p("AlhWRMAAAgshILDAAMAAAAshg");
	var mask_graphics_6 = new cjs.Graphics().p("AmGWRMAAAgshIMMAAMAAAAshg");
	var mask_graphics_7 = new cjs.Graphics().p("AmqWRMAAAgshINUAAMAAAAshg");
	var mask_graphics_8 = new cjs.Graphics().p("AnNWRMAAAgshIObAAMAAAAshg");
	var mask_graphics_9 = new cjs.Graphics().p("AnwWRMAAAgshIPhAAMAAAAshg");
	var mask_graphics_10 = new cjs.Graphics().p("AoTWRMAAAgshIQnAAMAAAAshg");
	var mask_graphics_11 = new cjs.Graphics().p("Ao1WRMAAAgshIRqAAMAAAAshg");
	var mask_graphics_12 = new cjs.Graphics().p("ApWWRMAAAgshIStAAMAAAAshg");
	var mask_graphics_13 = new cjs.Graphics().p("Ap3WRMAAAgshITvAAMAAAAshg");
	var mask_graphics_14 = new cjs.Graphics().p("AqYWRMAAAgshIUxAAMAAAAshg");
	var mask_graphics_15 = new cjs.Graphics().p("Aq4WRMAAAgshIVxAAMAAAAshg");
	var mask_graphics_16 = new cjs.Graphics().p("ArYWRMAAAgshIWxAAMAAAAshg");
	var mask_graphics_17 = new cjs.Graphics().p("Ar3WRMAAAgshIXvAAMAAAAshg");
	var mask_graphics_18 = new cjs.Graphics().p("AsWWRMAAAgshIYtAAMAAAAshg");
	var mask_graphics_19 = new cjs.Graphics().p("As0WRMAAAgshIZpAAMAAAAshg");
	var mask_graphics_20 = new cjs.Graphics().p("AtSWRMAAAgshIalAAMAAAAshg");
	var mask_graphics_21 = new cjs.Graphics().p("AtvWRMAAAgshIbfAAMAAAAshg");
	var mask_graphics_22 = new cjs.Graphics().p("AuMWRMAAAgshIcZAAMAAAAshg");
	var mask_graphics_23 = new cjs.Graphics().p("AuoWRMAAAgshIdRAAMAAAAshg");
	var mask_graphics_24 = new cjs.Graphics().p("AvEWRMAAAgshIeJAAMAAAAshg");
	var mask_graphics_25 = new cjs.Graphics().p("AvgWRMAAAgshIfBAAMAAAAshg");
	var mask_graphics_26 = new cjs.Graphics().p("Av7WRMAAAgshIf3AAMAAAAshg");
	var mask_graphics_27 = new cjs.Graphics().p("AwVWRMAAAgshMAgrAAAMAAAAshg");
	var mask_graphics_28 = new cjs.Graphics().p("AwvWRMAAAgshMAhfAAAMAAAAshg");
	var mask_graphics_29 = new cjs.Graphics().p("AxJWRMAAAgshMAiTAAAMAAAAshg");
	var mask_graphics_30 = new cjs.Graphics().p("AxiWRMAAAgshMAjFAAAMAAAAshg");
	var mask_graphics_31 = new cjs.Graphics().p("Ax7WRMAAAgshMAj3AAAMAAAAshg");
	var mask_graphics_32 = new cjs.Graphics().p("AyTWRMAAAgshMAknAAAMAAAAshg");
	var mask_graphics_33 = new cjs.Graphics().p("AyrWRMAAAgshMAlXAAAMAAAAshg");
	var mask_graphics_34 = new cjs.Graphics().p("AzCWRMAAAgshMAmFAAAMAAAAshg");
	var mask_graphics_35 = new cjs.Graphics().p("AzZWRMAAAgshMAmzAAAMAAAAshg");
	var mask_graphics_36 = new cjs.Graphics().p("AzvWRMAAAgshMAnfAAAMAAAAshg");
	var mask_graphics_37 = new cjs.Graphics().p("A0FWRMAAAgshMAoLAAAMAAAAshg");
	var mask_graphics_38 = new cjs.Graphics().p("A0aWRMAAAgshMAo1AAAMAAAAshg");
	var mask_graphics_39 = new cjs.Graphics().p("A0vWRMAAAgshMApfAAAMAAAAshg");
	var mask_graphics_40 = new cjs.Graphics().p("A1DWRMAAAgshMAqIAAAMAAAAshg");
	var mask_graphics_41 = new cjs.Graphics().p("A1XWRMAAAgshMAqvAAAMAAAAshg");
	var mask_graphics_42 = new cjs.Graphics().p("A1rWRMAAAgshMArXAAAMAAAAshg");
	var mask_graphics_43 = new cjs.Graphics().p("A1+WRMAAAgshMAr9AAAMAAAAshg");
	var mask_graphics_44 = new cjs.Graphics().p("A2RWRMAAAgshMAsjAAAMAAAAshg");
	var mask_graphics_45 = new cjs.Graphics().p("A2jWRMAAAgshMAtHAAAMAAAAshg");
	var mask_graphics_46 = new cjs.Graphics().p("A21WRMAAAgshMAtqAAAMAAAAshg");
	var mask_graphics_47 = new cjs.Graphics().p("A3GWRMAAAgshMAuNAAAMAAAAshg");
	var mask_graphics_48 = new cjs.Graphics().p("A3WWRMAAAgshMAutAAAMAAAAshg");
	var mask_graphics_49 = new cjs.Graphics().p("A3nWRMAAAgshMAvOAAAMAAAAshg");
	var mask_graphics_50 = new cjs.Graphics().p("A32WRMAAAgshMAvtAAAMAAAAshg");
	var mask_graphics_51 = new cjs.Graphics().p("A4GWRMAAAgshMAwMAAAMAAAAshg");
	var mask_graphics_52 = new cjs.Graphics().p("A4UWRMAAAgshMAwpAAAMAAAAshg");
	var mask_graphics_53 = new cjs.Graphics().p("A4jWRMAAAgshMAxHAAAMAAAAshg");
	var mask_graphics_54 = new cjs.Graphics().p("A4wWRMAAAgshMAxhAAAMAAAAshg");
	var mask_graphics_55 = new cjs.Graphics().p("A4+WRMAAAgshMAx9AAAMAAAAshg");
	var mask_graphics_56 = new cjs.Graphics().p("A5LWRMAAAgshMAyXAAAMAAAAshg");
	var mask_graphics_57 = new cjs.Graphics().p("A5XWRMAAAgshMAyvAAAMAAAAshg");
	var mask_graphics_58 = new cjs.Graphics().p("A5jWRMAAAgshMAzHAAAMAAAAshg");
	var mask_graphics_59 = new cjs.Graphics().p("A5vWRMAAAgshMAzeAAAMAAAAshg");
	var mask_graphics_60 = new cjs.Graphics().p("A56WRMAAAgshMAz1AAAMAAAAshg");
	var mask_graphics_61 = new cjs.Graphics().p("A6EWRMAAAgshMA0JAAAMAAAAshg");
	var mask_graphics_62 = new cjs.Graphics().p("A6OWRMAAAgshMA0dAAAMAAAAshg");
	var mask_graphics_63 = new cjs.Graphics().p("A6YWRMAAAgshMA0xAAAMAAAAshg");
	var mask_graphics_64 = new cjs.Graphics().p("A6hWRMAAAgshMA1DAAAMAAAAshg");
	var mask_graphics_65 = new cjs.Graphics().p("A6qWRMAAAgshMA1VAAAMAAAAshg");
	var mask_graphics_66 = new cjs.Graphics().p("A6yWRMAAAgshMA1lAAAMAAAAshg");
	var mask_graphics_67 = new cjs.Graphics().p("A66WRMAAAgshMA11AAAMAAAAshg");
	var mask_graphics_68 = new cjs.Graphics().p("A7BWRMAAAgshMA2DAAAMAAAAshg");
	var mask_graphics_69 = new cjs.Graphics().p("A7IWRMAAAgshMA2RAAAMAAAAshg");
	var mask_graphics_70 = new cjs.Graphics().p("A7OWRMAAAgshMA2dAAAMAAAAshg");
	var mask_graphics_71 = new cjs.Graphics().p("A7UWRMAAAgshMA2pAAAMAAAAshg");
	var mask_graphics_72 = new cjs.Graphics().p("A7ZWRMAAAgshMA2zAAAMAAAAshg");
	var mask_graphics_73 = new cjs.Graphics().p("A7eWRMAAAgshMA29AAAMAAAAshg");
	var mask_graphics_74 = new cjs.Graphics().p("A7jWRMAAAgshMA3HAAAMAAAAshg");
	var mask_graphics_75 = new cjs.Graphics().p("A7nWRMAAAgshMA3PAAAMAAAAshg");
	var mask_graphics_76 = new cjs.Graphics().p("A7qWRMAAAgshMA3VAAAMAAAAshg");
	var mask_graphics_77 = new cjs.Graphics().p("A7tWRMAAAgshMA3bAAAMAAAAshg");
	var mask_graphics_78 = new cjs.Graphics().p("A7wWRMAAAgshMA3hAAAMAAAAshg");
	var mask_graphics_79 = new cjs.Graphics().p("A7yWRMAAAgshMA3lAAAMAAAAshg");
	var mask_graphics_80 = new cjs.Graphics().p("A70WRMAAAgshMA3pAAAMAAAAshg");
	var mask_graphics_81 = new cjs.Graphics().p("A71WRMAAAgshMA3rAAAMAAAAshg");
	var mask_graphics_82 = new cjs.Graphics().p("A72WRMAAAgshMA3sAAAMAAAAshg");
	var mask_graphics_83 = new cjs.Graphics().p("A72WRMAAAgshMA3tAAAMAAAAshg");
	var mask_graphics_423 = new cjs.Graphics().p("AikWRMAAAgshIFJAAMAAAAshg");
	var mask_graphics_424 = new cjs.Graphics().p("AjLWRMAAAgshIGXAAMAAAAshg");
	var mask_graphics_425 = new cjs.Graphics().p("AjxWRMAAAgshIHjAAMAAAAshg");
	var mask_graphics_426 = new cjs.Graphics().p("AkXWRMAAAgshIIvAAMAAAAshg");
	var mask_graphics_427 = new cjs.Graphics().p("Ak8WRMAAAgshIJ5AAMAAAAshg");
	var mask_graphics_428 = new cjs.Graphics().p("AlhWRMAAAgshILDAAMAAAAshg");
	var mask_graphics_429 = new cjs.Graphics().p("AmGWRMAAAgshIMMAAMAAAAshg");
	var mask_graphics_430 = new cjs.Graphics().p("AmqWRMAAAgshINUAAMAAAAshg");
	var mask_graphics_431 = new cjs.Graphics().p("AnNWRMAAAgshIObAAMAAAAshg");
	var mask_graphics_432 = new cjs.Graphics().p("AnwWRMAAAgshIPhAAMAAAAshg");
	var mask_graphics_433 = new cjs.Graphics().p("AoTWRMAAAgshIQnAAMAAAAshg");
	var mask_graphics_434 = new cjs.Graphics().p("Ao1WRMAAAgshIRqAAMAAAAshg");
	var mask_graphics_435 = new cjs.Graphics().p("ApWWRMAAAgshIStAAMAAAAshg");
	var mask_graphics_436 = new cjs.Graphics().p("Ap3WRMAAAgshITvAAMAAAAshg");
	var mask_graphics_437 = new cjs.Graphics().p("AqYWRMAAAgshIUxAAMAAAAshg");
	var mask_graphics_438 = new cjs.Graphics().p("Aq4WRMAAAgshIVxAAMAAAAshg");
	var mask_graphics_439 = new cjs.Graphics().p("ArYWRMAAAgshIWxAAMAAAAshg");
	var mask_graphics_440 = new cjs.Graphics().p("Ar3WRMAAAgshIXvAAMAAAAshg");
	var mask_graphics_441 = new cjs.Graphics().p("AsWWRMAAAgshIYtAAMAAAAshg");
	var mask_graphics_442 = new cjs.Graphics().p("As0WRMAAAgshIZpAAMAAAAshg");
	var mask_graphics_443 = new cjs.Graphics().p("AtSWRMAAAgshIalAAMAAAAshg");
	var mask_graphics_444 = new cjs.Graphics().p("AtvWRMAAAgshIbfAAMAAAAshg");
	var mask_graphics_445 = new cjs.Graphics().p("AuMWRMAAAgshIcZAAMAAAAshg");
	var mask_graphics_446 = new cjs.Graphics().p("AuoWRMAAAgshIdRAAMAAAAshg");
	var mask_graphics_447 = new cjs.Graphics().p("AvEWRMAAAgshIeJAAMAAAAshg");
	var mask_graphics_448 = new cjs.Graphics().p("AvgWRMAAAgshIfBAAMAAAAshg");
	var mask_graphics_449 = new cjs.Graphics().p("Av7WRMAAAgshIf3AAMAAAAshg");
	var mask_graphics_450 = new cjs.Graphics().p("AwVWRMAAAgshMAgrAAAMAAAAshg");
	var mask_graphics_451 = new cjs.Graphics().p("AwvWRMAAAgshMAhfAAAMAAAAshg");
	var mask_graphics_452 = new cjs.Graphics().p("AxJWRMAAAgshMAiTAAAMAAAAshg");
	var mask_graphics_453 = new cjs.Graphics().p("AxiWRMAAAgshMAjFAAAMAAAAshg");
	var mask_graphics_454 = new cjs.Graphics().p("Ax7WRMAAAgshMAj3AAAMAAAAshg");
	var mask_graphics_455 = new cjs.Graphics().p("AyTWRMAAAgshMAknAAAMAAAAshg");
	var mask_graphics_456 = new cjs.Graphics().p("AyrWRMAAAgshMAlXAAAMAAAAshg");
	var mask_graphics_457 = new cjs.Graphics().p("AzCWRMAAAgshMAmFAAAMAAAAshg");
	var mask_graphics_458 = new cjs.Graphics().p("AzZWRMAAAgshMAmzAAAMAAAAshg");
	var mask_graphics_459 = new cjs.Graphics().p("AzvWRMAAAgshMAnfAAAMAAAAshg");
	var mask_graphics_460 = new cjs.Graphics().p("A0FWRMAAAgshMAoLAAAMAAAAshg");
	var mask_graphics_461 = new cjs.Graphics().p("A0aWRMAAAgshMAo1AAAMAAAAshg");
	var mask_graphics_462 = new cjs.Graphics().p("A0vWRMAAAgshMApfAAAMAAAAshg");
	var mask_graphics_463 = new cjs.Graphics().p("A1DWRMAAAgshMAqIAAAMAAAAshg");
	var mask_graphics_464 = new cjs.Graphics().p("A1XWRMAAAgshMAqvAAAMAAAAshg");
	var mask_graphics_465 = new cjs.Graphics().p("A1rWRMAAAgshMArXAAAMAAAAshg");
	var mask_graphics_466 = new cjs.Graphics().p("A1+WRMAAAgshMAr9AAAMAAAAshg");
	var mask_graphics_467 = new cjs.Graphics().p("A2RWRMAAAgshMAsjAAAMAAAAshg");
	var mask_graphics_468 = new cjs.Graphics().p("A2jWRMAAAgshMAtHAAAMAAAAshg");
	var mask_graphics_469 = new cjs.Graphics().p("A21WRMAAAgshMAtqAAAMAAAAshg");
	var mask_graphics_470 = new cjs.Graphics().p("A3GWRMAAAgshMAuNAAAMAAAAshg");
	var mask_graphics_471 = new cjs.Graphics().p("A3WWRMAAAgshMAutAAAMAAAAshg");
	var mask_graphics_472 = new cjs.Graphics().p("A3nWRMAAAgshMAvOAAAMAAAAshg");
	var mask_graphics_473 = new cjs.Graphics().p("A32WRMAAAgshMAvtAAAMAAAAshg");
	var mask_graphics_474 = new cjs.Graphics().p("A4GWRMAAAgshMAwMAAAMAAAAshg");
	var mask_graphics_475 = new cjs.Graphics().p("A4UWRMAAAgshMAwpAAAMAAAAshg");
	var mask_graphics_476 = new cjs.Graphics().p("A4jWRMAAAgshMAxHAAAMAAAAshg");
	var mask_graphics_477 = new cjs.Graphics().p("A4wWRMAAAgshMAxhAAAMAAAAshg");
	var mask_graphics_478 = new cjs.Graphics().p("A4+WRMAAAgshMAx9AAAMAAAAshg");
	var mask_graphics_479 = new cjs.Graphics().p("A5LWRMAAAgshMAyXAAAMAAAAshg");
	var mask_graphics_480 = new cjs.Graphics().p("A5XWRMAAAgshMAyvAAAMAAAAshg");
	var mask_graphics_481 = new cjs.Graphics().p("A5jWRMAAAgshMAzHAAAMAAAAshg");
	var mask_graphics_482 = new cjs.Graphics().p("A5vWRMAAAgshMAzeAAAMAAAAshg");
	var mask_graphics_483 = new cjs.Graphics().p("A56WRMAAAgshMAz1AAAMAAAAshg");
	var mask_graphics_484 = new cjs.Graphics().p("A6EWRMAAAgshMA0JAAAMAAAAshg");
	var mask_graphics_485 = new cjs.Graphics().p("A6OWRMAAAgshMA0dAAAMAAAAshg");
	var mask_graphics_486 = new cjs.Graphics().p("A6YWRMAAAgshMA0xAAAMAAAAshg");
	var mask_graphics_487 = new cjs.Graphics().p("A6hWRMAAAgshMA1DAAAMAAAAshg");
	var mask_graphics_488 = new cjs.Graphics().p("A6qWRMAAAgshMA1VAAAMAAAAshg");
	var mask_graphics_489 = new cjs.Graphics().p("A6yWRMAAAgshMA1lAAAMAAAAshg");
	var mask_graphics_490 = new cjs.Graphics().p("A66WRMAAAgshMA11AAAMAAAAshg");
	var mask_graphics_491 = new cjs.Graphics().p("A7BWRMAAAgshMA2DAAAMAAAAshg");
	var mask_graphics_492 = new cjs.Graphics().p("A7IWRMAAAgshMA2RAAAMAAAAshg");
	var mask_graphics_493 = new cjs.Graphics().p("A7OWRMAAAgshMA2dAAAMAAAAshg");
	var mask_graphics_494 = new cjs.Graphics().p("A7UWRMAAAgshMA2pAAAMAAAAshg");
	var mask_graphics_495 = new cjs.Graphics().p("A7ZWRMAAAgshMA2zAAAMAAAAshg");
	var mask_graphics_496 = new cjs.Graphics().p("A7eWRMAAAgshMA29AAAMAAAAshg");
	var mask_graphics_497 = new cjs.Graphics().p("A7jWRMAAAgshMA3HAAAMAAAAshg");
	var mask_graphics_498 = new cjs.Graphics().p("A7nWRMAAAgshMA3PAAAMAAAAshg");
	var mask_graphics_499 = new cjs.Graphics().p("A7qWRMAAAgshMA3VAAAMAAAAshg");
	var mask_graphics_500 = new cjs.Graphics().p("A7tWRMAAAgshMA3bAAAMAAAAshg");
	var mask_graphics_501 = new cjs.Graphics().p("A7wWRMAAAgshMA3hAAAMAAAAshg");
	var mask_graphics_502 = new cjs.Graphics().p("A7yWRMAAAgshMA3lAAAMAAAAshg");
	var mask_graphics_503 = new cjs.Graphics().p("A70WRMAAAgshMA3pAAAMAAAAshg");
	var mask_graphics_504 = new cjs.Graphics().p("A71WRMAAAgshMA3rAAAMAAAAshg");
	var mask_graphics_505 = new cjs.Graphics().p("A72WRMAAAgshMA3sAAAMAAAAshg");
	var mask_graphics_506 = new cjs.Graphics().p("A72WRMAAAgshMA3tAAAMAAAAshg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:16.025,y:141}).wait(1).to({graphics:mask_graphics_1,x:19.9,y:141}).wait(1).to({graphics:mask_graphics_2,x:23.725,y:141}).wait(1).to({graphics:mask_graphics_3,x:27.5,y:141}).wait(1).to({graphics:mask_graphics_4,x:31.225,y:141}).wait(1).to({graphics:mask_graphics_5,x:34.925,y:141}).wait(1).to({graphics:mask_graphics_6,x:38.55,y:141}).wait(1).to({graphics:mask_graphics_7,x:42.15,y:141}).wait(1).to({graphics:mask_graphics_8,x:45.7,y:141}).wait(1).to({graphics:mask_graphics_9,x:49.2,y:141}).wait(1).to({graphics:mask_graphics_10,x:52.65,y:141}).wait(1).to({graphics:mask_graphics_11,x:56.05,y:141}).wait(1).to({graphics:mask_graphics_12,x:59.375,y:141}).wait(1).to({graphics:mask_graphics_13,x:62.675,y:141}).wait(1).to({graphics:mask_graphics_14,x:65.95,y:141}).wait(1).to({graphics:mask_graphics_15,x:69.175,y:141}).wait(1).to({graphics:mask_graphics_16,x:72.325,y:141}).wait(1).to({graphics:mask_graphics_17,x:75.45,y:141}).wait(1).to({graphics:mask_graphics_18,x:78.525,y:141}).wait(1).to({graphics:mask_graphics_19,x:81.55,y:141}).wait(1).to({graphics:mask_graphics_20,x:84.55,y:141}).wait(1).to({graphics:mask_graphics_21,x:87.475,y:141}).wait(1).to({graphics:mask_graphics_22,x:90.35,y:141}).wait(1).to({graphics:mask_graphics_23,x:93.2,y:141}).wait(1).to({graphics:mask_graphics_24,x:96,y:141}).wait(1).to({graphics:mask_graphics_25,x:98.75,y:141}).wait(1).to({graphics:mask_graphics_26,x:101.425,y:141}).wait(1).to({graphics:mask_graphics_27,x:104.1,y:141}).wait(1).to({graphics:mask_graphics_28,x:106.7,y:141}).wait(1).to({graphics:mask_graphics_29,x:109.25,y:141}).wait(1).to({graphics:mask_graphics_30,x:111.775,y:141}).wait(1).to({graphics:mask_graphics_31,x:114.225,y:141}).wait(1).to({graphics:mask_graphics_32,x:116.65,y:141}).wait(1).to({graphics:mask_graphics_33,x:119.025,y:141}).wait(1).to({graphics:mask_graphics_34,x:121.35,y:141}).wait(1).to({graphics:mask_graphics_35,x:123.625,y:141}).wait(1).to({graphics:mask_graphics_36,x:125.85,y:141}).wait(1).to({graphics:mask_graphics_37,x:128.025,y:141}).wait(1).to({graphics:mask_graphics_38,x:130.175,y:141}).wait(1).to({graphics:mask_graphics_39,x:132.25,y:141}).wait(1).to({graphics:mask_graphics_40,x:134.3,y:141}).wait(1).to({graphics:mask_graphics_41,x:136.3,y:141}).wait(1).to({graphics:mask_graphics_42,x:138.225,y:141}).wait(1).to({graphics:mask_graphics_43,x:140.125,y:141}).wait(1).to({graphics:mask_graphics_44,x:141.975,y:141}).wait(1).to({graphics:mask_graphics_45,x:143.775,y:141}).wait(1).to({graphics:mask_graphics_46,x:145.55,y:141}).wait(1).to({graphics:mask_graphics_47,x:147.25,y:141}).wait(1).to({graphics:mask_graphics_48,x:148.925,y:141}).wait(1).to({graphics:mask_graphics_49,x:150.55,y:141}).wait(1).to({graphics:mask_graphics_50,x:152.125,y:141}).wait(1).to({graphics:mask_graphics_51,x:153.65,y:141}).wait(1).to({graphics:mask_graphics_52,x:155.125,y:141}).wait(1).to({graphics:mask_graphics_53,x:156.55,y:141}).wait(1).to({graphics:mask_graphics_54,x:157.925,y:141}).wait(1).to({graphics:mask_graphics_55,x:159.275,y:141}).wait(1).to({graphics:mask_graphics_56,x:160.575,y:141}).wait(1).to({graphics:mask_graphics_57,x:161.8,y:141}).wait(1).to({graphics:mask_graphics_58,x:163,y:141}).wait(1).to({graphics:mask_graphics_59,x:164.15,y:141}).wait(1).to({graphics:mask_graphics_60,x:165.25,y:141}).wait(1).to({graphics:mask_graphics_61,x:166.325,y:141}).wait(1).to({graphics:mask_graphics_62,x:167.325,y:141}).wait(1).to({graphics:mask_graphics_63,x:168.275,y:141}).wait(1).to({graphics:mask_graphics_64,x:169.2,y:141}).wait(1).to({graphics:mask_graphics_65,x:170.075,y:141}).wait(1).to({graphics:mask_graphics_66,x:170.9,y:141}).wait(1).to({graphics:mask_graphics_67,x:171.675,y:141}).wait(1).to({graphics:mask_graphics_68,x:172.4,y:141}).wait(1).to({graphics:mask_graphics_69,x:173.075,y:141}).wait(1).to({graphics:mask_graphics_70,x:173.7,y:141}).wait(1).to({graphics:mask_graphics_71,x:174.3,y:141}).wait(1).to({graphics:mask_graphics_72,x:174.825,y:141}).wait(1).to({graphics:mask_graphics_73,x:175.325,y:141}).wait(1).to({graphics:mask_graphics_74,x:175.775,y:141}).wait(1).to({graphics:mask_graphics_75,x:176.175,y:141}).wait(1).to({graphics:mask_graphics_76,x:176.525,y:141}).wait(1).to({graphics:mask_graphics_77,x:176.825,y:141}).wait(1).to({graphics:mask_graphics_78,x:177.1,y:141}).wait(1).to({graphics:mask_graphics_79,x:177.3,y:141}).wait(1).to({graphics:mask_graphics_80,x:177.475,y:141}).wait(1).to({graphics:mask_graphics_81,x:177.575,y:141}).wait(1).to({graphics:mask_graphics_82,x:177.65,y:141}).wait(1).to({graphics:mask_graphics_83,x:177.6907,y:141}).wait(1).to({graphics:null,x:0,y:0}).wait(339).to({graphics:mask_graphics_423,x:16.025,y:141}).wait(1).to({graphics:mask_graphics_424,x:19.9,y:141}).wait(1).to({graphics:mask_graphics_425,x:23.725,y:141}).wait(1).to({graphics:mask_graphics_426,x:27.5,y:141}).wait(1).to({graphics:mask_graphics_427,x:31.225,y:141}).wait(1).to({graphics:mask_graphics_428,x:34.925,y:141}).wait(1).to({graphics:mask_graphics_429,x:38.55,y:141}).wait(1).to({graphics:mask_graphics_430,x:42.15,y:141}).wait(1).to({graphics:mask_graphics_431,x:45.7,y:141}).wait(1).to({graphics:mask_graphics_432,x:49.2,y:141}).wait(1).to({graphics:mask_graphics_433,x:52.65,y:141}).wait(1).to({graphics:mask_graphics_434,x:56.05,y:141}).wait(1).to({graphics:mask_graphics_435,x:59.375,y:141}).wait(1).to({graphics:mask_graphics_436,x:62.675,y:141}).wait(1).to({graphics:mask_graphics_437,x:65.95,y:141}).wait(1).to({graphics:mask_graphics_438,x:69.175,y:141}).wait(1).to({graphics:mask_graphics_439,x:72.325,y:141}).wait(1).to({graphics:mask_graphics_440,x:75.45,y:141}).wait(1).to({graphics:mask_graphics_441,x:78.525,y:141}).wait(1).to({graphics:mask_graphics_442,x:81.55,y:141}).wait(1).to({graphics:mask_graphics_443,x:84.55,y:141}).wait(1).to({graphics:mask_graphics_444,x:87.475,y:141}).wait(1).to({graphics:mask_graphics_445,x:90.35,y:141}).wait(1).to({graphics:mask_graphics_446,x:93.2,y:141}).wait(1).to({graphics:mask_graphics_447,x:96,y:141}).wait(1).to({graphics:mask_graphics_448,x:98.75,y:141}).wait(1).to({graphics:mask_graphics_449,x:101.425,y:141}).wait(1).to({graphics:mask_graphics_450,x:104.1,y:141}).wait(1).to({graphics:mask_graphics_451,x:106.7,y:141}).wait(1).to({graphics:mask_graphics_452,x:109.25,y:141}).wait(1).to({graphics:mask_graphics_453,x:111.775,y:141}).wait(1).to({graphics:mask_graphics_454,x:114.225,y:141}).wait(1).to({graphics:mask_graphics_455,x:116.65,y:141}).wait(1).to({graphics:mask_graphics_456,x:119.025,y:141}).wait(1).to({graphics:mask_graphics_457,x:121.35,y:141}).wait(1).to({graphics:mask_graphics_458,x:123.625,y:141}).wait(1).to({graphics:mask_graphics_459,x:125.85,y:141}).wait(1).to({graphics:mask_graphics_460,x:128.025,y:141}).wait(1).to({graphics:mask_graphics_461,x:130.175,y:141}).wait(1).to({graphics:mask_graphics_462,x:132.25,y:141}).wait(1).to({graphics:mask_graphics_463,x:134.3,y:141}).wait(1).to({graphics:mask_graphics_464,x:136.3,y:141}).wait(1).to({graphics:mask_graphics_465,x:138.225,y:141}).wait(1).to({graphics:mask_graphics_466,x:140.125,y:141}).wait(1).to({graphics:mask_graphics_467,x:141.975,y:141}).wait(1).to({graphics:mask_graphics_468,x:143.775,y:141}).wait(1).to({graphics:mask_graphics_469,x:145.55,y:141}).wait(1).to({graphics:mask_graphics_470,x:147.25,y:141}).wait(1).to({graphics:mask_graphics_471,x:148.925,y:141}).wait(1).to({graphics:mask_graphics_472,x:150.55,y:141}).wait(1).to({graphics:mask_graphics_473,x:152.125,y:141}).wait(1).to({graphics:mask_graphics_474,x:153.65,y:141}).wait(1).to({graphics:mask_graphics_475,x:155.125,y:141}).wait(1).to({graphics:mask_graphics_476,x:156.55,y:141}).wait(1).to({graphics:mask_graphics_477,x:157.925,y:141}).wait(1).to({graphics:mask_graphics_478,x:159.275,y:141}).wait(1).to({graphics:mask_graphics_479,x:160.575,y:141}).wait(1).to({graphics:mask_graphics_480,x:161.8,y:141}).wait(1).to({graphics:mask_graphics_481,x:163,y:141}).wait(1).to({graphics:mask_graphics_482,x:164.15,y:141}).wait(1).to({graphics:mask_graphics_483,x:165.25,y:141}).wait(1).to({graphics:mask_graphics_484,x:166.325,y:141}).wait(1).to({graphics:mask_graphics_485,x:167.325,y:141}).wait(1).to({graphics:mask_graphics_486,x:168.275,y:141}).wait(1).to({graphics:mask_graphics_487,x:169.2,y:141}).wait(1).to({graphics:mask_graphics_488,x:170.075,y:141}).wait(1).to({graphics:mask_graphics_489,x:170.9,y:141}).wait(1).to({graphics:mask_graphics_490,x:171.675,y:141}).wait(1).to({graphics:mask_graphics_491,x:172.4,y:141}).wait(1).to({graphics:mask_graphics_492,x:173.075,y:141}).wait(1).to({graphics:mask_graphics_493,x:173.7,y:141}).wait(1).to({graphics:mask_graphics_494,x:174.3,y:141}).wait(1).to({graphics:mask_graphics_495,x:174.825,y:141}).wait(1).to({graphics:mask_graphics_496,x:175.325,y:141}).wait(1).to({graphics:mask_graphics_497,x:175.775,y:141}).wait(1).to({graphics:mask_graphics_498,x:176.175,y:141}).wait(1).to({graphics:mask_graphics_499,x:176.525,y:141}).wait(1).to({graphics:mask_graphics_500,x:176.825,y:141}).wait(1).to({graphics:mask_graphics_501,x:177.1,y:141}).wait(1).to({graphics:mask_graphics_502,x:177.3,y:141}).wait(1).to({graphics:mask_graphics_503,x:177.475,y:141}).wait(1).to({graphics:mask_graphics_504,x:177.575,y:141}).wait(1).to({graphics:mask_graphics_505,x:177.65,y:141}).wait(1).to({graphics:mask_graphics_506,x:177.6907,y:141}).wait(1).to({graphics:null,x:0,y:0}).wait(318));

	// pc12
	this.instance_11 = new lib.pc12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(168,140,1,1,0,0,0,168,140);

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(123).to({alpha:0},16).to({_off:true},1).wait(283).to({_off:false,alpha:1},0).wait(115).to({alpha:0},16).to({_off:true},1).wait(270));

	// pc11
	this.instance_12 = new lib.pc11();
	this.instance_12.parent = this;
	this.instance_12.setTransform(168,140,1,1,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},84).wait(339).to({_off:false},0).to({_off:true},84).wait(318));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-181,134.6,866,150.9);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_KitchenCabinets1.1_atlas_P_.png", id:"336x280_KitchenCabinets1.1_atlas_P_"},
		{src:"images/336x280_KitchenCabinets1.1_atlas_NP_.jpg", id:"336x280_KitchenCabinets1.1_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;