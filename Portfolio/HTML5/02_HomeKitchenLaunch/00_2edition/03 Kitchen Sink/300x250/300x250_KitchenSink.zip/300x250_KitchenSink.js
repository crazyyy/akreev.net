(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_KitchenSink_atlas_P_", frames: [[0,0,98,28]]},
		{name:"300x250_KitchenSink_atlas_NP_", frames: [[593,282,336,280],[594,0,336,280],[0,0,592,280],[0,282,591,280]]}
];


// symbols:



(lib.NewAgelogo = function() {
	this.initialize(ss["300x250_KitchenSink_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["300x250_KitchenSink_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen12 = function() {
	this.initialize(ss["300x250_KitchenSink_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["300x250_KitchenSink_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.screen31 = function() {
	this.initialize(ss["300x250_KitchenSink_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AASAyIgZghIgNAMIAAAVIgLAAIAAhjIALAAIAABBIAmglIAOAAIggAfIAgAog");
	this.shape.setTransform(165.25,1.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AATAlIAAguQgBgKgEgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_1.setTransform(156.8,3.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgFAxIAAhHIAKAAIAABHgAgFgjQgBgCAAgDQAAgDABgDQADgCACAAQADAAACACQADADAAADQAAADgDACQgCACgDAAQgCAAgDgCg");
	this.shape_2.setTransform(150.95,1.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQADgEADgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_3.setTransform(145.65,3.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAGADAFAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADAEAEABQAEADAFAAQAGAAAHgEQAFgDAEgFIAAgfQgEgFgFgEQgHgDgGAAQgFAAgEACg");
	this.shape_4.setTransform(133.8,1.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_5.setTransform(127.625,3.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_6.setTransform(120.6,3.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAGADAFAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAEADAFAAQAGAAAHgEQAGgDADgFIAAgfQgDgFgGgEQgHgDgGAAQgFAAgEACg");
	this.shape_7.setTransform(112.3,1.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_8.setTransform(104.05,3.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgKAKIgFgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_9.setTransform(95.75,3.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_10.setTransform(89.825,2.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQADgEADgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_11.setTransform(84,3.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_12.setTransform(72.475,3.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgCgDgCgCQgCgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAEgFIAHgDIAHgDIAHgCQALABAGAFQAGAGAAAMIAAAyg");
	this.shape_13.setTransform(64.1,1.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_14.setTransform(57.775,2.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADAEAEABQAFADAEAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_15.setTransform(47.1,1.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_16.setTransform(38.85,3.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_17.setTransform(30.375,3.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgYAyIgFAAIACgLIADABIADABQAEAAADgCQACgCACgEIAFgLIgehIIAMAAIAXA7IAYg7IAMAAIgkBWQgCAIgGADQgFADgHABIgEgBg");
	this.shape_18.setTransform(22.425,4.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_19.setTransform(14.525,3.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_20.setTransform(6.175,1.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_21.setTransform(-6.575,3.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAwQgKgEgGgHQgHgGgFgKQgDgJAAgMQAAgLADgJQAFgKAHgHQAGgHAKgDQAKgEAJAAQANAAAKAFQAJAFAHAJIgKAGQgFgGgIgEQgHgEgJAAQgHAAgHADQgIADgEAGQgGAFgCAHQgEAIAAAIQAAAJAEAHQACAIAGAFQAFAFAHAEQAHADAHAAIAJgBIAHgDIAGgDIAFgEIAAgVIghAAIAAgKIAtAAIAAAjQgHAIgKAFQgKAFgMAAQgJAAgKgEg");
	this.shape_22.setTransform(-16.25,1.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t32, new cjs.Rectangle(-23.6,-7,194.4,19), null);


(lib.t31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkBIQgPgGgMgLIASgZQAJAIAMAGQAMAGAQAAQANAAAHgFQAGgFAAgHQgBgGgFgEQgHgEgKgCIgUgFQgMgDgKgEQgKgFgGgJQgGgIAAgOQAAgOAGgKQAIgLANgGQANgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGADAKADIAUAFQALADALAFQAJAFAHAIQAGAJAAAOQABAOgIALQgGAMgOAFQgOAHgUAAQgWAAgQgHg");
	this.shape.setTransform(167.1,57.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAZBNIgtg+IgMAPIAAAvIghAAIAAiZIAhAAIAABFIA1hFIApAAIg9BIIBBBRg");
	this.shape_1.setTransform(153.725,57.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAlBNIhIhjIAABjIghAAIAAiZIAiAAIBGBgIAAhgIAhAAIAACZg");
	this.shape_2.setTransform(137.275,57.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgPBNIAAiZIAgAAIAACZg");
	this.shape_3.setTransform(125.75,57.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgjBIQgQgGgLgLIASgZQAHAIANAGQANAGAOAAQAOAAAHgFQAGgFAAgHQAAgGgGgEQgHgEgKgCIgUgFQgLgDgLgEQgKgFgGgJQgGgIgBgOQABgOAGgKQAIgLAMgGQAOgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgMgEQgMgEgKAAQgKAAgGAEQgGAEAAAHQABAGAGADQAGADAKADIAUAFQAMADAJAFQAKAFAHAIQAGAJAAAOQABAOgIALQgGAMgOAFQgOAHgUAAQgWAAgPgHg");
	this.shape_4.setTransform(115.6,57.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgwBNIAAiZIAhAAIAAB8IBAAAIAAAdg");
	this.shape_5.setTransform(97.375,57.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBJAAIAAAcIhJAAIAAAjIBKAAIAAAdg");
	this.shape_6.setTransform(84.65,57.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBJAAIAAAcIhJAAIAAAjIBKAAIAAAdg");
	this.shape_7.setTransform(71.25,57.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_8.setTransform(57.575,57.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkBIQgPgGgMgLIASgZQAJAIAMAGQAMAGAQAAQANAAAHgFQAGgFAAgHQgBgGgFgEQgHgEgKgCIgUgFQgMgDgKgEQgJgFgHgJQgGgIAAgOQAAgOAHgKQAGgLAOgGQANgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgLgEQgMgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGADAKADIAUAFQALADALAFQAKAFAGAIQAGAJAAAOQAAAOgGALQgIAMgNAFQgNAHgVAAQgWAAgQgHg");
	this.shape_9.setTransform(43.9,57.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgkBJQgPgHgMgLIASgaQAJAJAMAGQAMAGAQAAQANAAAHgFQAGgFAAgGQgBgIgFgDQgHgEgKgCIgUgFQgMgDgKgFQgKgEgGgIQgGgJAAgPQAAgNAGgKQAIgKANgHQANgGARAAQASAAAPAFQAPAGAMAKIgSAYQgKgIgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGAEAKACIAUAFQALADALAFQAJAFAHAIQAGAJAAAOQABAOgIALQgGALgOAHQgOAGgUAAQgWAAgQgGg");
	this.shape_10.setTransform(213.45,34.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgjBJQgQgHgLgLIASgaQAHAJANAGQAMAGAPAAQAOAAAGgFQAHgFAAgGQAAgIgHgDQgGgEgKgCIgUgFQgLgDgKgFQgLgEgGgIQgGgJgBgPQABgNAGgKQAIgKAMgHQAOgGARAAQASAAAPAFQAPAGALAKIgSAYQgJgIgMgEQgMgEgKAAQgKAAgGAEQgGAEAAAHQABAGAGADQAGAEAKACIAUAFQAMADAJAFQAKAFAHAIQAGAJABAOQAAAOgIALQgGALgOAHQgOAGgUAAQgWAAgPgGg");
	this.shape_11.setTransform(199.65,34.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag1BNIAAiZIBsAAIAAAdIhMAAIAAAgIBJAAIAAAcIhJAAIAAAjIBMAAIAAAdg");
	this.shape_12.setTransform(186.4,34.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgwBNIAAiZIAhAAIAAB8IBAAAIAAAdg");
	this.shape_13.setTransform(173.925,34.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAlBNIhIhjIAABjIghAAIAAiZIAiAAIBGBgIAAhgIAhAAIAACZg");
	this.shape_14.setTransform(159.275,34.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgQBNIAAiZIAgAAIAACZg");
	this.shape_15.setTransform(147.75,34.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAqBNIgJgaIhAAAIgKAaIglAAIA6iZIApAAIA6CZgAAYAWIgYhBIgWBBIAuAAg");
	this.shape_16.setTransform(136.7,34.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_17.setTransform(122.125,34.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgkBJQgQgHgLgLIASgaQAIAJANAGQANAGAPAAQANAAAGgFQAHgFAAgGQAAgIgHgDQgGgEgKgCIgUgFQgLgDgKgFQgKgEgHgIQgGgJgBgPQABgNAHgKQAGgKANgHQAOgGARAAQASAAAPAFQAPAGALAKIgSAYQgJgIgLgEQgMgEgLAAQgLAAgFAEQgGAEAAAHQABAGAGADQAGAEAKACIAVAFQAKADALAFQAKAFAGAIQAGAJABAOQgBAOgGALQgIALgNAHQgNAGgVAAQgVAAgRgGg");
	this.shape_18.setTransform(108.45,34.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAyBNIAAhuIgrBuIgNAAIgrhuIAABuIghAAIAAiZIAuAAIAkBfIAlhfIAuAAIAACZg");
	this.shape_19.setTransform(85.925,34.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgmBGQgPgIgIgPQgHgOAAgTIAAhbIAhAAIAABaQAAAQAJAKQAJAKARAAQASAAAJgKQAJgKAAgQIAAhaIAhAAIAABbQAAATgHAOQgIAPgPAIQgQAIgXAAQgWAAgQgIg");
	this.shape_20.setTransform(67.625,34.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgQBNIAAiZIAgAAIAACZg");
	this.shape_21.setTransform(56.05,34.475);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAyBNIAAhuIgrBuIgNAAIgrhuIAABuIghAAIAAiZIAuAAIAkBfIAlhfIAuAAIAACZg");
	this.shape_22.setTransform(43.075,34.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBIAAIAAAcIhIAAIAAAjIBKAAIAAAdg");
	this.shape_23.setTransform(26.8,34.475);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAZBNIgdg3IgYAAIAAA3IghAAIAAiZIBHAAQAQAAALAHQAMAGAGALQAGALAAAPQAAANgFAKQgFAIgHAGQgIAFgIACIAiA7gAgcgFIAhAAQAKgBAGgFQAHgFAAgKQAAgKgHgFQgGgGgKAAIghAAg");
	this.shape_24.setTransform(12.775,34.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("Ag9BNIAAiZIBHAAQARABALAGQAMAHAGALQAGALAAAOQAAANgGALQgGALgMAGQgLAHgRAAIgmAAIAAA3gAgcgGIAiAAQAJAAAHgFQAGgGAAgJQAAgKgGgFQgHgGgJAAIgiAAg");
	this.shape_25.setTransform(-1.625,34.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t31, new cjs.Rectangle(-11.3,22,233.9,50), null);


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AASAyIgZggIgMALIAAAVIgMAAIAAhjIAMAAIAABBIAlgmIAOAAIggAhIAgAng");
	this.shape.setTransform(161.85,16.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_1.setTransform(153.4,18.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgFAxIAAhIIALAAIAABIgAgFgjQgCgCAAgDQAAgDACgCQADgDACAAQADAAACADQACACABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_2.setTransform(147.55,16.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_3.setTransform(142.25,18.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_4.setTransform(130.725,18.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_5.setTransform(122.9,18.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAGgDQAGgEADgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_6.setTransform(115.4,18.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_7.setTransform(106.925,18.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgBgDgCgCQgDgCgDgBIgHAAIgFAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAEgEIAHgFIAHgCIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_8.setTransform(98.5,16.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgJAAIAAgwQAAgHgDgEQgEgEgHAAQgFAAgGADQgFAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIAEgEIAFgEIAGgDIAIgBQAJAAAEAEQAEAEACAFIAEgEIAFgFIAHgDIAIgBQAKAAAFAFQAFAGAAALIAAAzg");
	this.shape_9.setTransform(88.3,18.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgFAFgEQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_10.setTransform(80.175,18.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAGgDADgEIAAgOQgDgEgGgCQgFgCgFAAQgIAAgFAEg");
	this.shape_11.setTransform(73.15,18.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_12.setTransform(67.8,16.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgEg");
	this.shape_13.setTransform(59.075,17.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgHADQgGAEgHAAQgMAAgFgGg");
	this.shape_14.setTransform(52.75,18.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_15.setTransform(44.275,18.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgRAFIAAgJIAjAAIAAAJg");
	this.shape_16.setTransform(37.75,18.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgNAwQgHgDgEgFQgEgEgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgDQAGgDAHAAQAHABAGADQAHADAEAGIAAgmIALAAIAABjIgLAAIAAgLQgEAGgGADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDAEgCAEQgBAFAAAGQAAAGABAFQACAFADAEQADADAEACQAFADAEAAQAGAAAHgEQAFgDAEgFIAAggQgEgFgFgDQgHgDgGAAQgEAAgFACg");
	this.shape_17.setTransform(30.95,16.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AATAlIAAguQgBgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_18.setTransform(22.7,18.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_19.setTransform(14.4,18.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgEg");
	this.shape_20.setTransform(8.475,17.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgDgCQgEgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgIAAgHgDg");
	this.shape_21.setTransform(2.65,18.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgRAlIAAhIIAMAAIAAAMQAEgFAFgEQAGgEAIAAIAAALIgFAAIgFABIgGADIgEADIgDAFIAAAyg");
	this.shape_22.setTransform(-6.725,18.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_23.setTransform(-13.925,18.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AASAyIgZghIgMAMIAAAVIgMAAIAAhjIAMAAIAABBIAlglIAOAAIggAfIAgAog");
	this.shape_24.setTransform(157.35,1.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_25.setTransform(148.9,3.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_26.setTransform(143.05,1.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_27.setTransform(137.75,3.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAHADAEAHIAAgnIALAAIAABjIgLAAIAAgLQgEAGgGADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAFADAEAAQAGAAAHgEQAFgDAEgFIAAgfQgEgFgFgEQgHgDgGAAQgEAAgFACg");
	this.shape_28.setTransform(125.9,1.95);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_29.setTransform(119.725,3.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFgBAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_30.setTransform(112.7,3.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgNAwQgGgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQADgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAHADAEAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAEADAFAAQAHAAAFgEQAGgDAEgFIAAgfQgEgFgGgEQgFgDgHAAQgFAAgEACg");
	this.shape_31.setTransform(104.4,1.95);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AATAlIAAguQgBgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_32.setTransform(96.15,3.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAGACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_33.setTransform(87.85,3.225);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_34.setTransform(81.925,2.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_35.setTransform(76.1,3.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_36.setTransform(66.625,2.35);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_37.setTransform(60.25,3.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQACACACAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgIADQgGAEgHAAQgMAAgFgGg");
	this.shape_38.setTransform(52,3.325);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_39.setTransform(43.525,3.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgJAAIAAgwQAAgHgEgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAFgEIAHgDIAIgBQAIAAAEAEQAEAEACAFIAEgEIAFgFIAIgDIAHgBQAKAAAFAFQAFAGABALIAAAzg");
	this.shape_40.setTransform(33.2,3.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_41.setTransform(25.075,3.15);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_42.setTransform(17.975,3.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAFADAEAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_43.setTransform(9.2,1.95);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_44.setTransform(0.95,3.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgRAwQgHgDgGgFQgEgGgDgHQgDgIAAgJIAAg8IAMAAIAAA8QAAANAIAJQAHAHANABQAOgBAHgHQAIgJAAgNIAAg8IAMAAIAAA8QAAAJgDAIQgDAHgFAGQgEAFgIADQgIADgKAAQgJAAgIgDg");
	this.shape_45.setTransform(-8.45,1.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(-20.2,-7,187.6,34), null);


(lib.t21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag1BNIAAiZIBsAAIAAAdIhMAAIAAAgIBJAAIAAAcIhJAAIAAAjIBMAAIAAAdg");
	this.shape.setTransform(215.65,57.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_1.setTransform(201.975,57.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgjBIQgRgGgKgLIASgZQAIAIAMAGQAMAGAPAAQAOAAAGgFQAHgFAAgHQAAgGgHgEQgGgEgKgCIgUgFQgLgDgKgEQgKgFgHgJQgGgIgBgOQABgOAGgKQAIgLAMgGQAOgGARAAQASAAAPAFQAPAGALAKIgSAZQgJgJgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGADAKADIAVAFQAKADAKAFQAKAFAHAIQAGAJABAOQAAAOgIALQgHAMgNAFQgNAHgVAAQgVAAgQgHg");
	this.shape_2.setTransform(188.3,57.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAqBNIgJgaIhAAAIgKAaIglAAIA6iZIApAAIA6CZgAAYAWIgYhBIgWBBIAuAAg");
	this.shape_3.setTransform(173.6,57.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_4.setTransform(159.025,57.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAZBNIgdg3IgYAAIAAA3IghAAIAAiZIBHAAQAQAAALAHQAMAGAGALQAGALAAAPQAAANgFAKQgFAIgHAGQgIAFgIACIAiA7gAgcgFIAhAAQAKgBAGgFQAHgFAAgKQAAgKgHgFQgGgGgKAAIghAAg");
	this.shape_5.setTransform(139.375,57.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgmBGQgPgIgIgOQgHgPAAgTIAAhbIAhAAIAABaQAAARAJAJQAJAKARAAQASAAAJgKQAJgJAAgRIAAhaIAhAAIAABbQAAATgHAPQgIAOgPAIQgQAIgXAAQgWAAgQgIg");
	this.shape_6.setTransform(123.175,57.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgpBFQgRgKgLgSQgKgSAAgXQAAgWAKgSQALgSARgKQASgKAXAAQAYAAARAKQATAKAJASQALASAAAWQAAAXgLASQgJASgTAKQgRAKgYAAQgXAAgSgKgAgYgrQgKAHgGALQgGAMABANQgBAPAGALQAGALAKAHQALAGANAAQAOAAALgGQAKgHAGgLQAFgLABgPQgBgNgFgMQgGgLgKgHQgLgGgOAAQgNAAgLAGg");
	this.shape_7.setTransform(105.95,57.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgPBNIAAg/Ig7haIAlAAIAlA+IAmg+IAlAAIg7BaIAAA/g");
	this.shape_8.setTransform(89.725,57.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_9.setTransform(69.675,57.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgPBNIAAiZIAfAAIAACZg");
	this.shape_10.setTransform(59.85,57.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgmBGQgPgIgIgOQgHgPAAgTIAAhbIAhAAIAABaQAAARAJAJQAJAKARAAQASAAAJgKQAJgJAAgRIAAhaIAhAAIAABbQAAATgHAPQgIAOgPAIQgQAIgXAAQgWAAgQgIg");
	this.shape_11.setTransform(48.225,57.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgjBIQgQgGgLgLIASgZQAHAIANAGQANAGAOAAQAOAAAHgFQAGgFAAgHQAAgGgGgEQgHgEgKgCIgUgFQgLgDgKgEQgLgFgGgJQgGgIgBgOQABgOAGgKQAHgLANgGQAOgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgMgEQgMgEgKAAQgKAAgGAEQgGAEAAAHQABAGAGADQAGADAKADIAUAFQAMADAJAFQAKAFAHAIQAGAJAAAOQABAOgIALQgGAMgOAFQgOAHgUAAQgWAAgPgHg");
	this.shape_12.setTransform(32.8,57.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgpBFQgRgKgLgSQgKgSAAgXQAAgWAKgSQALgSARgKQATgKAWAAQAXAAATAKQARAKALASQAKASAAAWQAAAXgKASQgLASgRAKQgTAKgXAAQgWAAgTgKgAgYgrQgKAHgGALQgFAMAAANQAAAPAFALQAGALAKAHQALAGANAAQAPAAAKgGQAKgHAGgLQAGgLgBgPQABgNgGgMQgGgLgKgHQgKgGgPAAQgNAAgLAGg");
	this.shape_13.setTransform(11.3,57.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_14.setTransform(-4.225,57.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgkBJQgPgHgMgLIASgaQAJAJAMAGQAMAGAQAAQANAAAHgFQAGgFAAgGQgBgIgFgDQgHgEgKgCIgUgFQgMgDgKgFQgKgEgGgIQgGgJAAgPQAAgNAGgKQAIgKANgHQANgGARAAQASAAAPAFQAPAGAMAKIgSAYQgKgIgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGAEAKACIAUAFQALADALAFQAJAFAHAIQAGAJAAAOQABAOgIALQgGALgOAHQgOAGgUAAQgWAAgQgGg");
	this.shape_15.setTransform(219.3,34.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag1BNIAAiZIBrAAIAAAdIhKAAIAAAgIBJAAIAAAcIhJAAIAAAjIBKAAIAAAdg");
	this.shape_16.setTransform(206.05,34.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgwBNIAAiZIAhAAIAAB8IBAAAIAAAdg");
	this.shape_17.setTransform(193.575,34.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgPBNIAAg/Ig7haIAlAAIAlA+IAmg+IAlAAIg7BaIAAA/g");
	this.shape_18.setTransform(179.875,34.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_19.setTransform(165.725,34.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgjBJQgQgHgLgLIASgaQAHAJANAGQANAGAOAAQAOAAAHgFQAGgFAAgGQAAgIgGgDQgHgEgKgCIgUgFQgLgDgLgFQgKgEgGgIQgGgJgBgPQABgNAGgKQAHgKANgHQAOgGARAAQASAAAPAFQAPAGAMAKIgSAYQgKgIgMgEQgMgEgKAAQgKAAgGAEQgGAEAAAHQABAGAGADQAGAEAKACIAUAFQAMADAJAFQAKAFAHAIQAGAJAAAOQABAOgIALQgGALgOAHQgOAGgUAAQgWAAgPgGg");
	this.shape_20.setTransform(152.05,34.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAZBNIgtg+IgMAPIAAAvIghAAIAAiZIAhAAIAABFIA1hFIApAAIg9BIIBBBRg");
	this.shape_21.setTransform(132.775,34.475);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAlBNIhIhjIAABjIghAAIAAiZIAiAAIBGBgIAAhgIAhAAIAACZg");
	this.shape_22.setTransform(116.325,34.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgQBNIAAiZIAhAAIAACZg");
	this.shape_23.setTransform(104.8,34.475);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgkBJQgPgHgMgLIASgaQAJAJAMAGQAMAGAQAAQANAAAHgFQAGgFAAgGQgBgIgFgDQgHgEgKgCIgUgFQgMgDgKgFQgKgEgGgIQgGgJAAgPQAAgNAGgKQAIgKANgHQANgGARAAQASAAAPAFQAPAGAMAKIgSAYQgKgIgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGAEAKACIAUAFQALADALAFQAJAFAHAIQAGAJAAAOQABAOgIALQgGALgOAHQgOAGgUAAQgWAAgQgGg");
	this.shape_24.setTransform(94.65,34.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAlBNIhIhjIAABjIghAAIAAiZIAiAAIBGBgIAAhgIAhAAIAACZg");
	this.shape_25.setTransform(73.575,34.475);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBIAAIAAAcIhIAAIAAAjIBKAAIAAAdg");
	this.shape_26.setTransform(58.75,34.475);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAlBNIAAhBIhIAAIAABBIghAAIAAiZIAhAAIAAA9IBIAAIAAg9IAgAAIAACZg");
	this.shape_27.setTransform(43.4,34.475);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AggBFQgSgKgLgRQgLgSAAgYQAAgXALgRQALgSASgKQATgKAWAAQARAAAMAFQAMAGAJAIQAIAIAGAKIgcAOQgFgJgKgHQgJgGgMAAQgNAAgLAGQgLAHgGALQgGAMAAANQAAAPAGALQAGALALAHQALAGANAAQAMAAAJgGQAKgGAFgKIAcAOQgGAJgIAJQgJAJgMAFQgMAFgRAAQgWAAgTgKg");
	this.shape_28.setTransform(27.275,34.475);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_29.setTransform(12.475,34.475);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgQBNIAAiZIAhAAIAACZg");
	this.shape_30.setTransform(2.65,34.475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAZBNIgtg+IgMAPIAAAvIghAAIAAiZIAhAAIAABFIA1hFIApAAIg9BIIBBBRg");
	this.shape_31.setTransform(-7.075,34.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t21, new cjs.Rectangle(-17.2,22,245.6,50), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AASAyIgZghIgNAMIAAAVIgLAAIAAhjIALAAIAABBIAmglIAOAAIggAfIAgAog");
	this.shape.setTransform(165.25,1.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AATAlIAAguQgBgKgEgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_1.setTransform(156.8,3.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgFAxIAAhHIAKAAIAABHgAgFgjQgBgCAAgDQAAgDABgDQADgCACAAQADAAACACQADADAAADQAAADgDACQgCACgDAAQgCAAgDgCg");
	this.shape_2.setTransform(150.95,1.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQADgEADgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_3.setTransform(145.65,3.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAGADAFAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADAEAEABQAEADAFAAQAGAAAHgEQAFgDAEgFIAAgfQgEgFgFgEQgHgDgGAAQgFAAgEACg");
	this.shape_4.setTransform(133.8,1.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_5.setTransform(127.625,3.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_6.setTransform(120.6,3.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAGADAFAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAEADAFAAQAGAAAHgEQAGgDADgFIAAgfQgDgFgGgEQgHgDgGAAQgFAAgEACg");
	this.shape_7.setTransform(112.3,1.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_8.setTransform(104.05,3.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgKAKIgFgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_9.setTransform(95.75,3.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_10.setTransform(89.825,2.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQADgEADgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_11.setTransform(84,3.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_12.setTransform(72.475,3.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgCgDgCgCQgCgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAEgFIAHgDIAHgDIAHgCQALABAGAFQAGAGAAAMIAAAyg");
	this.shape_13.setTransform(64.1,1.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_14.setTransform(57.775,2.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADAEAEABQAFADAEAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_15.setTransform(47.1,1.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_16.setTransform(38.85,3.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_17.setTransform(30.375,3.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgYAyIgFAAIACgLIADABIADABQAEAAADgCQACgCACgEIAFgLIgehIIAMAAIAXA7IAYg7IAMAAIgkBWQgCAIgGADQgFADgHABIgEgBg");
	this.shape_18.setTransform(22.425,4.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_19.setTransform(14.525,3.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_20.setTransform(6.175,1.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_21.setTransform(-6.575,3.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAwQgKgEgGgHQgHgGgFgKQgDgJAAgMQAAgLADgJQAFgKAHgHQAGgHAKgDQAKgEAJAAQANAAAKAFQAJAFAHAJIgKAGQgFgGgIgEQgHgEgJAAQgHAAgHADQgIADgEAGQgGAFgCAHQgEAIAAAIQAAAJAEAHQACAIAGAFQAFAFAHAEQAHADAHAAIAJgBIAHgDIAGgDIAFgEIAAgVIghAAIAAgKIAtAAIAAAjQgHAIgKAFQgKAFgMAAQgJAAgKgEg");
	this.shape_22.setTransform(-16.25,1.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-23.6,-7,194.4,19), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkBIQgPgGgMgLIASgZQAJAIAMAGQAMAGAQAAQANAAAHgFQAGgFAAgHQgBgGgFgEQgHgEgKgCIgUgFQgMgDgKgEQgKgFgGgJQgGgIAAgOQAAgOAGgKQAIgLANgGQANgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGADAKADIAUAFQALADALAFQAJAFAHAIQAGAJAAAOQABAOgIALQgGAMgOAFQgOAHgUAAQgWAAgQgHg");
	this.shape.setTransform(167.1,57.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAZBNIgtg+IgMAPIAAAvIghAAIAAiZIAhAAIAABFIA1hFIApAAIg9BIIBBBRg");
	this.shape_1.setTransform(153.725,57.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAlBNIhIhjIAABjIghAAIAAiZIAiAAIBGBgIAAhgIAhAAIAACZg");
	this.shape_2.setTransform(137.275,57.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgPBNIAAiZIAgAAIAACZg");
	this.shape_3.setTransform(125.75,57.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgjBIQgQgGgLgLIASgZQAHAIANAGQANAGAOAAQAOAAAHgFQAGgFAAgHQAAgGgGgEQgHgEgKgCIgUgFQgLgDgLgEQgKgFgGgJQgGgIgBgOQABgOAGgKQAIgLAMgGQAOgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgMgEQgMgEgKAAQgKAAgGAEQgGAEAAAHQABAGAGADQAGADAKADIAUAFQAMADAJAFQAKAFAHAIQAGAJAAAOQABAOgIALQgGAMgOAFQgOAHgUAAQgWAAgPgHg");
	this.shape_4.setTransform(115.6,57.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgwBNIAAiZIAhAAIAAB8IBAAAIAAAdg");
	this.shape_5.setTransform(97.375,57.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBJAAIAAAcIhJAAIAAAjIBKAAIAAAdg");
	this.shape_6.setTransform(84.65,57.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBJAAIAAAcIhJAAIAAAjIBKAAIAAAdg");
	this.shape_7.setTransform(71.25,57.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_8.setTransform(57.575,57.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkBIQgPgGgMgLIASgZQAJAIAMAGQAMAGAQAAQANAAAHgFQAGgFAAgHQgBgGgFgEQgHgEgKgCIgUgFQgMgDgKgEQgJgFgHgJQgGgIAAgOQAAgOAHgKQAGgLAOgGQANgGARAAQASAAAPAFQAPAGAMAKIgSAZQgKgJgLgEQgMgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGADAKADIAUAFQALADALAFQAKAFAGAIQAGAJAAAOQAAAOgGALQgIAMgNAFQgNAHgVAAQgWAAgQgHg");
	this.shape_9.setTransform(43.9,57.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgkBJQgPgHgMgLIASgaQAJAJAMAGQAMAGAQAAQANAAAHgFQAGgFAAgGQgBgIgFgDQgHgEgKgCIgUgFQgMgDgKgFQgKgEgGgIQgGgJAAgPQAAgNAGgKQAIgKANgHQANgGARAAQASAAAPAFQAPAGAMAKIgSAYQgKgIgMgEQgLgEgLAAQgKAAgGAEQgGAEAAAHQAAAGAHADQAGAEAKACIAUAFQALADALAFQAJAFAHAIQAGAJAAAOQABAOgIALQgGALgOAHQgOAGgUAAQgWAAgQgGg");
	this.shape_10.setTransform(213.45,34.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgjBJQgQgHgLgLIASgaQAHAJANAGQAMAGAPAAQAOAAAGgFQAHgFAAgGQAAgIgHgDQgGgEgKgCIgUgFQgLgDgKgFQgLgEgGgIQgGgJgBgPQABgNAGgKQAIgKAMgHQAOgGARAAQASAAAPAFQAPAGALAKIgSAYQgJgIgMgEQgMgEgKAAQgKAAgGAEQgGAEAAAHQABAGAGADQAGAEAKACIAUAFQAMADAJAFQAKAFAHAIQAGAJABAOQAAAOgIALQgGALgOAHQgOAGgUAAQgWAAgPgGg");
	this.shape_11.setTransform(199.65,34.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag1BNIAAiZIBsAAIAAAdIhMAAIAAAgIBJAAIAAAcIhJAAIAAAjIBMAAIAAAdg");
	this.shape_12.setTransform(186.4,34.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgwBNIAAiZIAhAAIAAB8IBAAAIAAAdg");
	this.shape_13.setTransform(173.925,34.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAlBNIhIhjIAABjIghAAIAAiZIAiAAIBGBgIAAhgIAhAAIAACZg");
	this.shape_14.setTransform(159.275,34.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgQBNIAAiZIAgAAIAACZg");
	this.shape_15.setTransform(147.75,34.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAqBNIgJgaIhAAAIgKAaIglAAIA6iZIApAAIA6CZgAAYAWIgYhBIgWBBIAuAAg");
	this.shape_16.setTransform(136.7,34.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgPBNIAAh8IgtAAIAAgdIB5AAIAAAdIgsAAIAAB8g");
	this.shape_17.setTransform(122.125,34.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgkBJQgQgHgLgLIASgaQAIAJANAGQANAGAPAAQANAAAGgFQAHgFAAgGQAAgIgHgDQgGgEgKgCIgUgFQgLgDgKgFQgKgEgHgIQgGgJgBgPQABgNAHgKQAGgKANgHQAOgGARAAQASAAAPAFQAPAGALAKIgSAYQgJgIgLgEQgMgEgLAAQgLAAgFAEQgGAEAAAHQABAGAGADQAGAEAKACIAVAFQAKADALAFQAKAFAGAIQAGAJABAOQgBAOgGALQgIALgNAHQgNAGgVAAQgVAAgRgGg");
	this.shape_18.setTransform(108.45,34.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAyBNIAAhuIgrBuIgNAAIgrhuIAABuIghAAIAAiZIAuAAIAkBfIAlhfIAuAAIAACZg");
	this.shape_19.setTransform(85.925,34.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgmBGQgPgIgIgPQgHgOAAgTIAAhbIAhAAIAABaQAAAQAJAKQAJAKARAAQASAAAJgKQAJgKAAgQIAAhaIAhAAIAABbQAAATgHAOQgIAPgPAIQgQAIgXAAQgWAAgQgIg");
	this.shape_20.setTransform(67.625,34.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgQBNIAAiZIAgAAIAACZg");
	this.shape_21.setTransform(56.05,34.475);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAyBNIAAhuIgrBuIgNAAIgrhuIAABuIghAAIAAiZIAuAAIAkBfIAlhfIAuAAIAACZg");
	this.shape_22.setTransform(43.075,34.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("Ag2BNIAAiZIBsAAIAAAdIhKAAIAAAgIBIAAIAAAcIhIAAIAAAjIBKAAIAAAdg");
	this.shape_23.setTransform(26.8,34.475);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAZBNIgdg3IgYAAIAAA3IghAAIAAiZIBHAAQAQAAALAHQAMAGAGALQAGALAAAPQAAANgFAKQgFAIgHAGQgIAFgIACIAiA7gAgcgFIAhAAQAKgBAGgFQAHgFAAgKQAAgKgHgFQgGgGgKAAIghAAg");
	this.shape_24.setTransform(12.775,34.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("Ag9BNIAAiZIBHAAQARABALAGQAMAHAGALQAGALAAAOQAAANgGALQgGALgMAGQgLAHgRAAIgmAAIAAA3gAgcgGIAiAAQAJAAAHgFQAGgGAAgJQAAgKgGgFQgHgGgJAAIgiAAg");
	this.shape_25.setTransform(-1.625,34.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-11.3,22,233.9,50), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape.setTransform(535.2,71.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(535.2,71.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_2.setTransform(535.2,71.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_3.setTransform(535.2,71.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_4.setTransform(535.2,71.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_5.setTransform(535.2,71.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_6.setTransform(535.2,71.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_7.setTransform(535.2,71.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_8.setTransform(535.2,71.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_9.setTransform(535.2,71.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},44).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(98));

	// Слой_2 - копия: 2 - копия
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_10.setTransform(535.2,211.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.875)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_11.setTransform(535.2,211.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.749)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(535.2,211.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.624)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_13.setTransform(535.2,211.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.502)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_14.setTransform(535.2,211.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.376)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_15.setTransform(535.2,211.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.251)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_16.setTransform(535.2,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.125)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_17.setTransform(535.2,211.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_18.setTransform(535.2,211.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10}]}).to({state:[{t:this.shape_10}]},39).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).wait(104));

	// Слой_3 - копия: 2
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_19.setTransform(415.35,71.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.89)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_20.setTransform(415.35,71.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.776)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_21.setTransform(415.35,71.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.667)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(415.35,71.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.557)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_23.setTransform(415.35,71.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.443)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_24.setTransform(415.35,71.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.333)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_25.setTransform(415.35,71.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.224)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_26.setTransform(415.35,71.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.11)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_27.setTransform(415.35,71.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_28.setTransform(415.35,71.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19}]}).to({state:[{t:this.shape_19}]},35).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).wait(107));

	// Слой_2 - копия: 2
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_29.setTransform(415.35,211.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.875)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_30.setTransform(415.35,211.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.749)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_31.setTransform(415.35,211.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.624)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_32.setTransform(415.35,211.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.502)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(415.35,211.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.376)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_34.setTransform(415.35,211.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.251)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_35.setTransform(415.35,211.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.125)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_36.setTransform(415.35,211.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_37.setTransform(415.35,211.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29}]}).to({state:[{t:this.shape_29}]},30).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_38.setTransform(295.9,210.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.89)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_39.setTransform(295.9,210.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.776)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_40.setTransform(295.9,210.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.667)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_41.setTransform(295.9,210.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.557)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_42.setTransform(295.9,210.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.443)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_43.setTransform(295.9,210.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.333)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_44.setTransform(295.9,210.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.224)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_45.setTransform(295.9,210.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.11)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_46.setTransform(295.9,210.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0)").s().p("ApXK+IAA17ISvAAIAAV7g");
	this.shape_47.setTransform(295.9,210.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38}]}).to({state:[{t:this.shape_38}]},25).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).wait(117));

	// Слой_2 - копия: 2
	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_48.setTransform(295.9,69.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.875)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_49.setTransform(295.9,70);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.749)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_50.setTransform(295.9,70);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.624)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_51.setTransform(295.9,69.95);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.502)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_52.setTransform(295.9,69.95);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.376)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(295.9,69.95);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.251)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_54.setTransform(295.9,69.95);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.125)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_55.setTransform(295.9,69.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_56.setTransform(295.9,69.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48,p:{y:69.9}}]}).to({state:[{t:this.shape_48,p:{y:70}}]},20).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).wait(123));

	// Слой_3 - копия
	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_57.setTransform(177.2,71.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.89)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_58.setTransform(177.2,71.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.776)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_59.setTransform(177.2,71.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.667)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_60.setTransform(177.2,71.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.557)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_61.setTransform(177.2,71.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.443)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_62.setTransform(177.2,71.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.333)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(177.2,71.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.224)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_64.setTransform(177.2,71.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.11)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_65.setTransform(177.2,71.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0)").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_66.setTransform(177.2,71.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_57}]}).to({state:[{t:this.shape_57}]},15).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).wait(127));

	// Слой_2 - копия
	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_67.setTransform(177.2,211.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.875)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_68.setTransform(177.2,211.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.749)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_69.setTransform(177.2,211.3);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.624)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_70.setTransform(177.2,211.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.502)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_71.setTransform(177.2,211.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.376)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_72.setTransform(177.2,211.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0.251)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_73.setTransform(177.2,211.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(255,255,255,0.125)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(177.2,211.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0)").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_75.setTransform(177.2,211.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_67}]}).to({state:[{t:this.shape_67}]},10).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).wait(133));

	// Слой_3
	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_76.setTransform(60,210.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.89)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_77.setTransform(60,210.15);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.776)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_78.setTransform(60,210.15);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.667)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_79.setTransform(60,210.15);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.557)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_80.setTransform(60,210.15);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.443)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_81.setTransform(60,210.15);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0.333)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_82.setTransform(60,210.15);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,255,255,0.224)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_83.setTransform(60,210.15);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(255,255,255,0.11)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(60,210.15);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_85.setTransform(60,210.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_76}]}).to({state:[{t:this.shape_76}]},5).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).wait(137));

	// Слой_2
	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_86.setTransform(60,69.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.875)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_87.setTransform(60,69.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.749)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_88.setTransform(60,69.9);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.624)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_89.setTransform(60,69.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.502)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_90.setTransform(60,69.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.376)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_91.setTransform(60,69.9);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.251)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_92.setTransform(60,69.9);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0.125)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_93.setTransform(60,69.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_94.setTransform(60,69.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_86}]}).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).wait(143));

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.2,595.3,281.7);


(lib.pc12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen12();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc12, new cjs.Rectangle(0,0,336,280), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,280), null);


(lib.pc3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen31();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc3, new cjs.Rectangle(0,0,591,280), null);


(lib.marker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAagtIBrAtIhrAugAiEAAIBogsIAABZg");
	this.shape.setTransform(20.0132,255.4238,0.8834,0.8834);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0F0F0F").s().p("Ah1B2QgxgwAAhGQAAhEAxgyQAwgwBFAAQBGAAAxAwQAwAyAABEQAABGgwAwQgxAxhGAAQhFAAgwgxg");
	this.shape_1.setTransform(20.075,255.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.498)").s().p("AiNCOQg6g6AAhUQAAhSA6g7QA7g7BSABQBUgBA6A7QA6A7AABSQAABUg6A6Qg6A6hUAAQhSAAg7g6g");
	this.shape_2.setTransform(20.05,255.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgOWqMAAAgtTIAdAAMAAAAtTg");
	this.shape_3.setTransform(20.05,144.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.marker, new cjs.Rectangle(0,0,40.1,290), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,98,28), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape.setTransform(83.525,17.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_1.setTransform(73.675,17.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAdAyIg5hPIAABPIgNAAIAAhjIAOAAIA4BNIAAhNIAMAAIAABjg");
	this.shape_2.setTransform(64.1,15.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgEQAGgEAHAAQAHAAAGADQAGACAEAFQAEAFADAIQACAGAAAJQAAAJgCAGQgDAHgEAFQgEAFgGACQgGAEgHAAQgHAAgGgEQgGgDgFgHIAAAngAgNgkQgGADgDAFIAAAfQADAFAGAEQAGAEAHAAQAEAAAFgDQAEgCADgDIAFgIQABgGAAgGQAAgGgBgFQgCgFgDgEQgDgDgEgCQgFgDgEAAQgHAAgGAEg");
	this.shape_3.setTransform(50.825,18.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_4.setTransform(41.975,17.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_5.setTransform(33.55,15.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVAvQgJgEgHgHIAIgKIAGAGIAHAEIAIADIAJABQAHAAAFgBQAEgCADgCIAEgGIABgGQAAgFgDgDIgGgFIgKgEIgKgDIgLgDQgFgBgEgDQgEgDgDgFQgCgEAAgHQAAgGACgFQADgFAEgEQAFgEAGgCQAHgCAGAAQAMAAAIAEQAJADAGAHIgHAJQgGgGgHgDQgIgDgHAAQgJAAgGAFQgFAEAAAHQAAAEACADIAHAFIAJADIAKADIALAEQAFACAFACQAEAEACAEQADAFAAAHQAAAGgCAFQgCAFgFAEQgEAEgHADQgHADgKAAQgMAAgKgFg");
	this.shape_6.setTransform(24.925,15.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_7.setTransform(54.8207,16.3109,0.8366,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(0,0,109.6,32.7), null);


// stage content:
(lib._300x250_KitchenSink = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_765 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(765).call(this.frame_765).wait(57));

	// btn
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(150,179.45,0.8929,0.8929,0,0,0,54.8,16.3);
	this.instance.alpha = 0.0117;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(50).to({_off:false},0).to({regY:16.4,y:182.2,alpha:1},8,cjs.Ease.get(1)).wait(66).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(47).to({_off:false,y:189.35},0).to({regY:16.3,y:191.95,alpha:1},8,cjs.Ease.get(1)).wait(65).to({alpha:0.0117},13,cjs.Ease.get(-1)).to({_off:true},1).wait(59).to({_off:false,y:179.45},0).to({regY:16.4,y:182.2,alpha:1},8,cjs.Ease.get(1)).wait(62).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(50).to({_off:false,regY:16.3,y:179.45},0).to({regY:16.4,y:182.2,alpha:1},8,cjs.Ease.get(1)).wait(66).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(47).to({_off:false,y:189.35},0).to({regY:16.3,y:191.95,alpha:1},8,cjs.Ease.get(1)).wait(65).to({alpha:0.0117},13,cjs.Ease.get(-1)).to({_off:true},1).wait(59).to({_off:false,y:179.45},0).to({regY:16.4,y:182.2,alpha:1},8,cjs.Ease.get(1)).wait(62).to({alpha:0.0117},11,cjs.Ease.get(-1)).wait(1));

	// Слой_23
	this.instance_1 = new lib.logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,66.95,0.7143,0.7143,0,0,0,49.1,14.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).to({regY:14.2,y:59,alpha:1},8,cjs.Ease.get(1)).wait(66).to({alpha:0},11).to({_off:true},1).wait(47).to({_off:false,regY:14.1,y:66.95},0).to({regY:14.2,y:59,alpha:1},8,cjs.Ease.get(1)).wait(65).to({alpha:0},13).to({_off:true},1).wait(59).to({_off:false,regY:14.1,y:66.95},0).to({regY:14.2,y:59,alpha:1},8,cjs.Ease.get(1)).wait(62).to({alpha:0},11).to({_off:true},1).wait(50).to({_off:false,regY:14.1,y:66.95},0).to({regY:14.2,y:59,alpha:1},8,cjs.Ease.get(1)).wait(66).to({alpha:0},11).to({_off:true},1).wait(47).to({_off:false,regY:14.1,y:66.95},0).to({regY:14.2,y:59,alpha:1},8,cjs.Ease.get(1)).wait(65).to({alpha:0},13).to({_off:true},1).wait(59).to({_off:false,regY:14.1,y:66.95},0).to({regY:14.2,y:59,alpha:1},8,cjs.Ease.get(1)).wait(62).to({alpha:0},11).wait(1));

	// t12
	this.instance_2 = new lib.t12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150,162.5,0.8929,0.8929,0,0,0,73.6,17);
	this.instance_2.alpha = 0.0117;
	this.instance_2._off = true;

	this.instance_3 = new lib.t22();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,162.5,0.8929,0.8929,0,0,0,73.6,17);
	this.instance_3.alpha = 0.0117;
	this.instance_3._off = true;

	this.instance_4 = new lib.t32();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,162.5,0.8929,0.8929,0,0,0,73.6,17);
	this.instance_4.alpha = 0.0117;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(46).to({_off:false},0).to({regY:17.1,y:154.8,alpha:1},8,cjs.Ease.get(1)).wait(70).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(321).to({_off:false,regY:17,y:162.5},0).to({regY:17.1,y:154.8,alpha:1},8,cjs.Ease.get(1)).wait(70).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(275));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(179).to({_off:false},0).to({regY:17.1,y:154.8,alpha:1},8).wait(69).to({alpha:0.0117},13).to({_off:true},1).wait(320).to({_off:false,regY:17,y:162.5},0).to({regY:17.1,y:154.8,alpha:1},8).wait(69).to({alpha:0.0117},13).to({_off:true},1).wait(141));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(325).to({_off:false},0).to({regY:17.1,y:154.8,alpha:1},8).wait(66).to({alpha:0.0117},11).to({_off:true},1).wait(325).to({_off:false,regY:17,y:162.5},0).to({regY:17.1,y:154.8,alpha:1},8).wait(66).to({alpha:0.0117},11).wait(1));

	// t11
	this.instance_5 = new lib.t11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150,133.1,0.8929,0.8929,0,0,0,105.6,41.1);
	this.instance_5.alpha = 0.0117;
	this.instance_5._off = true;

	this.instance_6 = new lib.t21();
	this.instance_6.parent = this;
	this.instance_6.setTransform(150,133.1,0.8929,0.8929,0,0,0,105.6,41.1);
	this.instance_6.alpha = 0.0117;
	this.instance_6._off = true;

	this.instance_7 = new lib.t31();
	this.instance_7.parent = this;
	this.instance_7.setTransform(150,133.1,0.8929,0.8929,0,0,0,105.6,41.1);
	this.instance_7.alpha = 0.0117;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(43).to({_off:false},0).to({regY:41,y:105.65,alpha:1},8,cjs.Ease.get(1)).wait(73).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(318).to({_off:false,regY:41.1,y:133.1},0).to({regY:41,y:105.65,alpha:1},8,cjs.Ease.get(1)).wait(73).to({alpha:0.0117},11,cjs.Ease.get(-1)).to({_off:true},1).wait(275));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(176).to({_off:false},0).to({regY:41,y:105.65,alpha:1},8).wait(72).to({alpha:0.0117},13).to({_off:true},1).wait(317).to({_off:false,regY:41.1,y:133.1},0).to({regY:41,y:105.65,alpha:1},8).wait(72).to({alpha:0.0117},13).to({_off:true},1).wait(141));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(322).to({_off:false},0).to({regY:41,y:105.65,alpha:1},8).wait(69).to({alpha:0.0117},11).to({_off:true},1).wait(322).to({_off:false,regY:41.1,y:133.1},0).to({regY:41,y:105.65,alpha:1},8).wait(69).to({alpha:0.0117},11).wait(1));

	// Слой_14
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AyVAJIAAgRMAkrAAAIAAARg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AyVExIAAphMAkrAAAIAAJhg");
	this.shape_1.setTransform(150,125.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AyVIkIAAxHMAkrAAAIAARHg");
	this.shape_2.setTransform(150,125.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AyVLgIAA2/MAkrAAAIAAW/g");
	this.shape_3.setTransform(150,125.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AyVNnIAA7NMAkrAAAIAAbNg");
	this.shape_4.setTransform(150,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AyVO4IAA9vMAkrAAAIAAdvg");
	this.shape_5.setTransform(150,125.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_6.setTransform(150,125.025);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.992)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_7.setTransform(150,125.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.969)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_8.setTransform(150,125.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.925)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_9.setTransform(150,125.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.867)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_10.setTransform(150,125.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.792)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_11.setTransform(150,125.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.702)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_12.setTransform(150,125.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.596)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_13.setTransform(150,125.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.471)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_14.setTransform(150,125.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.329)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_15.setTransform(150,125.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.173)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_16.setTransform(150,125.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_17.setTransform(150,125.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AyVCqIAAlUMAkrAAAIAAFUg");
	this.shape_18.setTransform(150,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AyVFMIAAqXMAkrAAAIAAKXg");
	this.shape_19.setTransform(150,125.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AyVHuIAAvbMAkrAAAIAAPbg");
	this.shape_20.setTransform(150,125.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AyVKPIAA0dMAkrAAAIAAUdg");
	this.shape_21.setTransform(150,125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AyVMxIAA5hMAkrAAAIAAZhg");
	this.shape_22.setTransform(150,125.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.922)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_23.setTransform(150,125.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.847)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_24.setTransform(150,125.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.769)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_25.setTransform(150,125.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.694)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_26.setTransform(150,125.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.616)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_27.setTransform(150,125.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.537)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_28.setTransform(150,125.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.463)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_29.setTransform(150,125.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.384)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_30.setTransform(150,125.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.306)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_31.setTransform(150,125.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.231)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_32.setTransform(150,125.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.153)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_33.setTransform(150,125.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.078)").s().p("AyVPTIAA+lMAkrAAAIAAelg");
	this.shape_34.setTransform(150,125.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},40).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},78).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},37).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},77).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},49).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},74).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[]},1).to({state:[{t:this.shape}]},40).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},78).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},37).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},77).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_17}]},1).to({state:[]},1).to({state:[{t:this.shape}]},49).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},74).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_6}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(40).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(145).to({_off:false},0).to({_off:true},1).wait(131).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(145).to({_off:false},0).to({_off:true},1).wait(91));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(46).to({_off:false},0).wait(78).to({_off:true},1).wait(54).to({_off:false},0).wait(77).to({_off:true},1).wait(68).to({_off:false},0).wait(85).to({_off:true},1).wait(46).to({_off:false},0).wait(78).to({_off:true},1).wait(54).to({_off:false},0).wait(77).to({_off:true},1).wait(68).to({_off:false},0).wait(86));

	// screen31.jpg
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(0,0,0,0.004)").s().p("A4VUTMAAAgolMAwrAAAMAAAAolg");
	this.shape_35.setTransform(150,125.025);
	this.shape_35._off = true;

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(0,0,0,0.063)").s().p("A4NUMMAAAgoXMAwbAAAMAAAAoXg");
	this.shape_36.setTransform(150.025,125.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(0,0,0,0.114)").s().p("A4GUHMAAAgoNMAwNAAAMAAAAoNg");
	this.shape_37.setTransform(150.025,125.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(0,0,0,0.153)").s().p("A4BUDMAAAgoEMAwDAAAMAAAAoEg");
	this.shape_38.setTransform(150.025,125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(0,0,0,0.176)").s().p("A39UAMAAAgn/MAv7AAAMAAAAn/g");
	this.shape_39.setTransform(150.025,125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(0,0,0,0.196)").s().p("A37T9MAAAgn6MAv3AAAMAAAAn6g");
	this.shape_40.setTransform(150,125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(0,0,0,0.2)").s().p("A36T9MAAAgn5MAv1AAAMAAAAn5g");
	this.shape_41.setTransform(150.025,125);
	this.shape_41._off = true;

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(0,0,0,0.192)").s().p("A37T9MAAAgn6MAv3AAAMAAAAn6g");
	this.shape_42.setTransform(150.025,125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(0,0,0,0.184)").s().p("A38T+MAAAgn8MAv5AAAMAAAAn8g");
	this.shape_43.setTransform(150.025,125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(0,0,0,0.173)").s().p("A3+UAMAAAgn/MAv9AAAMAAAAn/g");
	this.shape_44.setTransform(150.025,125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(0,0,0,0.161)").s().p("A4AUCMAAAgoDMAwBAAAMAAAAoDg");
	this.shape_45.setTransform(150.025,125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(0,0,0,0.141)").s().p("A4CUEMAAAgoGMAwFAAAMAAAAoGg");
	this.shape_46.setTransform(150.025,125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(0,0,0,0.122)").s().p("A4FUGMAAAgoLMAwLAAAMAAAAoLg");
	this.shape_47.setTransform(150,125.025);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(0,0,0,0.098)").s().p("A4JUJMAAAgoRMAwTAAAMAAAAoRg");
	this.shape_48.setTransform(150,125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(0,0,0,0.071)").s().p("A4MUMMAAAgoWMAwZAAAMAAAAoWg");
	this.shape_49.setTransform(150,125);
	this.shape_49._off = true;

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(0,0,0,0.039)").s().p("A4QUPMAAAgodMAwiAAAMAAAAodg");
	this.shape_50.setTransform(150,125);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(0,0,0,0.035)").s().p("A4QUPMAAAgodMAwiAAAMAAAAodg");
	this.shape_51.setTransform(150,125.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(0,0,0,0.102)").s().p("A4IUIMAAAgoPMAwRAAAMAAAAoPg");
	this.shape_52.setTransform(150.025,125.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(0,0,0,0.133)").s().p("A4DUEMAAAgoHMAwHAAAMAAAAoHg");
	this.shape_53.setTransform(150.025,125.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(0,0,0,0.169)").s().p("A3/UBMAAAgoBMAv/AAAMAAAAoBg");
	this.shape_54.setTransform(150.025,125);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(0,0,0,0.169)").s().p("A3+UBMAAAgoBMAv9AAAMAAAAoBg");
	this.shape_55.setTransform(150.025,125);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(0,0,0,0.153)").s().p("A4AUCMAAAgoDMAwBAAAMAAAAoDg");
	this.shape_56.setTransform(150.025,125);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(0,0,0,0.141)").s().p("A4DUEMAAAgoHMAwGAAAMAAAAoHg");
	this.shape_57.setTransform(150,125.025);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(0,0,0,0.125)").s().p("A4EUFMAAAgoJMAwJAAAMAAAAoJg");
	this.shape_58.setTransform(150,125);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(0,0,0,0.11)").s().p("A4GUHMAAAgoNMAwOAAAMAAAAoNg");
	this.shape_59.setTransform(150,125);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(0,0,0,0.094)").s().p("A4JUJMAAAgoRMAwTAAAMAAAAoRg");
	this.shape_60.setTransform(150.025,125.025);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(0,0,0,0.078)").s().p("A4LUKMAAAgoTMAwXAAAMAAAAoTg");
	this.shape_61.setTransform(150.025,125.025);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(0,0,0,0.051)").s().p("A4PUOMAAAgobMAwfAAAMAAAAobg");
	this.shape_62.setTransform(150,125.025);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(0,0,0,0.035)").s().p("A4RUPMAAAgodMAwjAAAMAAAAodg");
	this.shape_63.setTransform(150,125.025);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(0,0,0,0.02)").s().p("A4TURMAAAgohMAwnAAAMAAAAohg");
	this.shape_64.setTransform(150,125.025);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(0,0,0,0.18)").s().p("A39T/MAAAgn9MAv7AAAMAAAAn9g");
	this.shape_65.setTransform(150.025,125);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(0,0,0,0.165)").s().p("A3/UBMAAAgoBMAv/AAAMAAAAoBg");
	this.shape_66.setTransform(150.025,125);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(0,0,0,0.145)").s().p("A4CUDMAAAgoFMAwEAAAMAAAAoFg");
	this.shape_67.setTransform(150,125);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(0,0,0,0.129)").s().p("A4EUFMAAAgoJMAwJAAAMAAAAoJg");
	this.shape_68.setTransform(150,125);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(0,0,0,0.075)").s().p("A4LULMAAAgoVMAwXAAAMAAAAoVg");
	this.shape_69.setTransform(150.025,125.025);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(0,0,0,0.059)").s().p("A4OUNMAAAgoZMAwdAAAMAAAAoZg");
	this.shape_70.setTransform(150.025,125.025);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(0,0,0,0.039)").s().p("A4QUPMAAAgodMAwhAAAMAAAAodg");
	this.shape_71.setTransform(150,125.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(0,0,0,0.024)").s().p("A4TURMAAAgohMAwmAAAMAAAAohg");
	this.shape_72.setTransform(150,125.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_35}]},40).to({state:[{t:this.shape_36,p:{y:125.025}}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},78).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},37).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},77).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_36,p:{y:125}}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},49).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},74).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},40).to({state:[{t:this.shape_36,p:{y:125.025}}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},78).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},37).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},77).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_36,p:{y:125}}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_35}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},49).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},74).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_35}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(40).to({_off:false},0).to({_off:true},1).wait(94).to({_off:false},0).to({_off:true},1).wait(37).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(90).to({_off:false},0).to({_off:true},1).wait(40).to({_off:false},0).to({_off:true},1).wait(94).to({_off:false},0).to({_off:true},1).wait(37).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(90).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(46).to({_off:false},0).wait(79).to({_off:true},1).wait(53).to({_off:false},0).wait(77).to({_off:true},1).wait(68).to({_off:false},0).wait(74).to({_off:true},1).wait(57).to({_off:false},0).wait(79).to({_off:true},1).wait(53).to({_off:false},0).wait(77).to({_off:true},1).wait(68).to({_off:false},0).wait(74).to({_off:true},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.shape_49).wait(133).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(145).to({_off:false},0).to({_off:true},1).wait(222).to({_off:false},0).to({_off:true},1).wait(41).to({_off:false},0).to({_off:true},1).wait(145).to({_off:false},0).to({_off:true},1).wait(89));

	// Слой_21
	this.instance_8 = new lib.pc3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(305.8,125,0.8929,0.8929,0,0,0,342.5,140);
	this.instance_8.alpha = 0.0117;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(256).to({_off:false},0).to({x:286.25,alpha:1},13).to({x:95.1},130).to({regX:342.4,x:78.05,alpha:0},11).to({_off:true},1).wait(256).to({_off:false,regX:342.5,x:305.8,alpha:0.0117},0).to({x:286.25,alpha:1},13).to({x:95.1},130).to({regX:342.4,x:78.05,alpha:0},11).wait(1));

	// marker
	this.instance_9 = new lib.marker();
	this.instance_9.parent = this;
	this.instance_9.setTransform(29.55,125.05,0.8929,0.8929,0,0,0,20.1,145);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(132).to({_off:false},0).to({x:317.9},83,cjs.Ease.get(1)).to({_off:true},1).wait(327).to({_off:false,x:29.55},0).to({x:317.9},83,cjs.Ease.get(1)).to({_off:true},1).wait(195));

	// Слой_13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_132 = new cjs.Graphics().p("AiTT4MAAAgnvIEnAAMAAAAnvg");
	var mask_graphics_133 = new cjs.Graphics().p("Ai1T4MAAAgnvIFrAAMAAAAnvg");
	var mask_graphics_134 = new cjs.Graphics().p("AjXT4MAAAgnvIGvAAMAAAAnvg");
	var mask_graphics_135 = new cjs.Graphics().p("Aj5T4MAAAgnvIHzAAMAAAAnvg");
	var mask_graphics_136 = new cjs.Graphics().p("AkaT4MAAAgnvII1AAMAAAAnvg");
	var mask_graphics_137 = new cjs.Graphics().p("Ak7T4MAAAgnvIJ3AAMAAAAnvg");
	var mask_graphics_138 = new cjs.Graphics().p("AlcT4MAAAgnvIK5AAMAAAAnvg");
	var mask_graphics_139 = new cjs.Graphics().p("Al8T4MAAAgnvIL5AAMAAAAnvg");
	var mask_graphics_140 = new cjs.Graphics().p("AmcT4MAAAgnvIM5AAMAAAAnvg");
	var mask_graphics_141 = new cjs.Graphics().p("Am7T4MAAAgnvIN3AAMAAAAnvg");
	var mask_graphics_142 = new cjs.Graphics().p("AnaT4MAAAgnvIO0AAMAAAAnvg");
	var mask_graphics_143 = new cjs.Graphics().p("An4T4MAAAgnvIPxAAMAAAAnvg");
	var mask_graphics_144 = new cjs.Graphics().p("AoWT4MAAAgnvIQtAAMAAAAnvg");
	var mask_graphics_145 = new cjs.Graphics().p("Ao0T4MAAAgnvIRpAAMAAAAnvg");
	var mask_graphics_146 = new cjs.Graphics().p("ApRT4MAAAgnvISjAAMAAAAnvg");
	var mask_graphics_147 = new cjs.Graphics().p("ApuT4MAAAgnvITdAAMAAAAnvg");
	var mask_graphics_148 = new cjs.Graphics().p("AqKT4MAAAgnvIUVAAMAAAAnvg");
	var mask_graphics_149 = new cjs.Graphics().p("AqmT4MAAAgnvIVMAAMAAAAnvg");
	var mask_graphics_150 = new cjs.Graphics().p("ArBT4MAAAgnvIWDAAMAAAAnvg");
	var mask_graphics_151 = new cjs.Graphics().p("ArcT4MAAAgnvIW5AAMAAAAnvg");
	var mask_graphics_152 = new cjs.Graphics().p("Ar3T4MAAAgnvIXvAAMAAAAnvg");
	var mask_graphics_153 = new cjs.Graphics().p("AsRT4MAAAgnvIYjAAMAAAAnvg");
	var mask_graphics_154 = new cjs.Graphics().p("AsrT4MAAAgnvIZXAAMAAAAnvg");
	var mask_graphics_155 = new cjs.Graphics().p("AtET4MAAAgnvIaJAAMAAAAnvg");
	var mask_graphics_156 = new cjs.Graphics().p("AtdT4MAAAgnvIa7AAMAAAAnvg");
	var mask_graphics_157 = new cjs.Graphics().p("At2T4MAAAgnvIbsAAMAAAAnvg");
	var mask_graphics_158 = new cjs.Graphics().p("AuOT4MAAAgnvIcdAAMAAAAnvg");
	var mask_graphics_159 = new cjs.Graphics().p("AulT4MAAAgnvIdLAAMAAAAnvg");
	var mask_graphics_160 = new cjs.Graphics().p("Au9T4MAAAgnvId6AAMAAAAnvg");
	var mask_graphics_161 = new cjs.Graphics().p("AvUT4MAAAgnvIeoAAMAAAAnvg");
	var mask_graphics_162 = new cjs.Graphics().p("AvqT4MAAAgnvIfVAAMAAAAnvg");
	var mask_graphics_163 = new cjs.Graphics().p("AwAT4MAAAgnvMAgBAAAMAAAAnvg");
	var mask_graphics_164 = new cjs.Graphics().p("AwWT4MAAAgnvMAgtAAAMAAAAnvg");
	var mask_graphics_165 = new cjs.Graphics().p("AwrT4MAAAgnvMAhXAAAMAAAAnvg");
	var mask_graphics_166 = new cjs.Graphics().p("Aw/T4MAAAgnvMAh/AAAMAAAAnvg");
	var mask_graphics_167 = new cjs.Graphics().p("AxUT4MAAAgnvMAipAAAMAAAAnvg");
	var mask_graphics_168 = new cjs.Graphics().p("AxoT4MAAAgnvMAjQAAAMAAAAnvg");
	var mask_graphics_169 = new cjs.Graphics().p("Ax7T4MAAAgnvMAj3AAAMAAAAnvg");
	var mask_graphics_170 = new cjs.Graphics().p("AyOT4MAAAgnvMAkdAAAMAAAAnvg");
	var mask_graphics_171 = new cjs.Graphics().p("AyhT4MAAAgnvMAlDAAAMAAAAnvg");
	var mask_graphics_172 = new cjs.Graphics().p("AyzT4MAAAgnvMAlnAAAMAAAAnvg");
	var mask_graphics_173 = new cjs.Graphics().p("AzFT4MAAAgnvMAmLAAAMAAAAnvg");
	var mask_graphics_174 = new cjs.Graphics().p("AzWT4MAAAgnvMAmtAAAMAAAAnvg");
	var mask_graphics_175 = new cjs.Graphics().p("AznT4MAAAgnvMAnPAAAMAAAAnvg");
	var mask_graphics_176 = new cjs.Graphics().p("Az4T4MAAAgnvMAnxAAAMAAAAnvg");
	var mask_graphics_177 = new cjs.Graphics().p("A0IT4MAAAgnvMAoRAAAMAAAAnvg");
	var mask_graphics_178 = new cjs.Graphics().p("A0YT4MAAAgnvMAoxAAAMAAAAnvg");
	var mask_graphics_179 = new cjs.Graphics().p("A0nT4MAAAgnvMApPAAAMAAAAnvg");
	var mask_graphics_180 = new cjs.Graphics().p("A02T4MAAAgnvMAptAAAMAAAAnvg");
	var mask_graphics_181 = new cjs.Graphics().p("A1ET4MAAAgnvMAqKAAAMAAAAnvg");
	var mask_graphics_182 = new cjs.Graphics().p("A1ST4MAAAgnvMAqmAAAMAAAAnvg");
	var mask_graphics_183 = new cjs.Graphics().p("A1gT4MAAAgnvMArBAAAMAAAAnvg");
	var mask_graphics_184 = new cjs.Graphics().p("A1tT4MAAAgnvMArbAAAMAAAAnvg");
	var mask_graphics_185 = new cjs.Graphics().p("A16T4MAAAgnvMAr1AAAMAAAAnvg");
	var mask_graphics_186 = new cjs.Graphics().p("A2GT4MAAAgnvMAsNAAAMAAAAnvg");
	var mask_graphics_187 = new cjs.Graphics().p("A2ST4MAAAgnvMAslAAAMAAAAnvg");
	var mask_graphics_188 = new cjs.Graphics().p("A2eT4MAAAgnvMAs9AAAMAAAAnvg");
	var mask_graphics_189 = new cjs.Graphics().p("A2pT4MAAAgnvMAtTAAAMAAAAnvg");
	var mask_graphics_190 = new cjs.Graphics().p("A20T4MAAAgnvMAtpAAAMAAAAnvg");
	var mask_graphics_191 = new cjs.Graphics().p("A2+T4MAAAgnvMAt9AAAMAAAAnvg");
	var mask_graphics_192 = new cjs.Graphics().p("A3IT4MAAAgnvMAuRAAAMAAAAnvg");
	var mask_graphics_193 = new cjs.Graphics().p("A3RT4MAAAgnvMAujAAAMAAAAnvg");
	var mask_graphics_194 = new cjs.Graphics().p("A3aT4MAAAgnvMAu1AAAMAAAAnvg");
	var mask_graphics_195 = new cjs.Graphics().p("A3jT4MAAAgnvMAvHAAAMAAAAnvg");
	var mask_graphics_196 = new cjs.Graphics().p("A3rT4MAAAgnvMAvXAAAMAAAAnvg");
	var mask_graphics_197 = new cjs.Graphics().p("A3zT4MAAAgnvMAvnAAAMAAAAnvg");
	var mask_graphics_198 = new cjs.Graphics().p("A36T4MAAAgnvMAv1AAAMAAAAnvg");
	var mask_graphics_199 = new cjs.Graphics().p("A4BT4MAAAgnvMAwDAAAMAAAAnvg");
	var mask_graphics_200 = new cjs.Graphics().p("A4HT4MAAAgnvMAwPAAAMAAAAnvg");
	var mask_graphics_201 = new cjs.Graphics().p("A4OT4MAAAgnvMAwdAAAMAAAAnvg");
	var mask_graphics_202 = new cjs.Graphics().p("A4TT4MAAAgnvMAwnAAAMAAAAnvg");
	var mask_graphics_203 = new cjs.Graphics().p("A4YT4MAAAgnvMAwyAAAMAAAAnvg");
	var mask_graphics_204 = new cjs.Graphics().p("A4dT4MAAAgnvMAw8AAAMAAAAnvg");
	var mask_graphics_205 = new cjs.Graphics().p("A4iT4MAAAgnvMAxFAAAMAAAAnvg");
	var mask_graphics_206 = new cjs.Graphics().p("A4mT4MAAAgnvMAxNAAAMAAAAnvg");
	var mask_graphics_207 = new cjs.Graphics().p("A4pT4MAAAgnvMAxTAAAMAAAAnvg");
	var mask_graphics_208 = new cjs.Graphics().p("A4sT4MAAAgnvMAxZAAAMAAAAnvg");
	var mask_graphics_209 = new cjs.Graphics().p("A4vT4MAAAgnvMAxfAAAMAAAAnvg");
	var mask_graphics_210 = new cjs.Graphics().p("A4xT4MAAAgnvMAxjAAAMAAAAnvg");
	var mask_graphics_211 = new cjs.Graphics().p("A4zT4MAAAgnvMAxoAAAMAAAAnvg");
	var mask_graphics_212 = new cjs.Graphics().p("A41T4MAAAgnvMAxrAAAMAAAAnvg");
	var mask_graphics_213 = new cjs.Graphics().p("A42T4MAAAgnvMAxtAAAMAAAAnvg");
	var mask_graphics_214 = new cjs.Graphics().p("A42T4MAAAgnvMAxuAAAMAAAAnvg");
	var mask_graphics_215 = new cjs.Graphics().p("A43T4MAAAgnvMAxvAAAMAAAAnvg");
	var mask_graphics_543 = new cjs.Graphics().p("AiTT4MAAAgnvIEnAAMAAAAnvg");
	var mask_graphics_544 = new cjs.Graphics().p("Ai1T4MAAAgnvIFrAAMAAAAnvg");
	var mask_graphics_545 = new cjs.Graphics().p("AjXT4MAAAgnvIGvAAMAAAAnvg");
	var mask_graphics_546 = new cjs.Graphics().p("Aj5T4MAAAgnvIHzAAMAAAAnvg");
	var mask_graphics_547 = new cjs.Graphics().p("AkaT4MAAAgnvII1AAMAAAAnvg");
	var mask_graphics_548 = new cjs.Graphics().p("Ak7T4MAAAgnvIJ3AAMAAAAnvg");
	var mask_graphics_549 = new cjs.Graphics().p("AlcT4MAAAgnvIK5AAMAAAAnvg");
	var mask_graphics_550 = new cjs.Graphics().p("Al8T4MAAAgnvIL5AAMAAAAnvg");
	var mask_graphics_551 = new cjs.Graphics().p("AmcT4MAAAgnvIM5AAMAAAAnvg");
	var mask_graphics_552 = new cjs.Graphics().p("Am7T4MAAAgnvIN3AAMAAAAnvg");
	var mask_graphics_553 = new cjs.Graphics().p("AnaT4MAAAgnvIO0AAMAAAAnvg");
	var mask_graphics_554 = new cjs.Graphics().p("An4T4MAAAgnvIPxAAMAAAAnvg");
	var mask_graphics_555 = new cjs.Graphics().p("AoWT4MAAAgnvIQtAAMAAAAnvg");
	var mask_graphics_556 = new cjs.Graphics().p("Ao0T4MAAAgnvIRpAAMAAAAnvg");
	var mask_graphics_557 = new cjs.Graphics().p("ApRT4MAAAgnvISjAAMAAAAnvg");
	var mask_graphics_558 = new cjs.Graphics().p("ApuT4MAAAgnvITdAAMAAAAnvg");
	var mask_graphics_559 = new cjs.Graphics().p("AqKT4MAAAgnvIUVAAMAAAAnvg");
	var mask_graphics_560 = new cjs.Graphics().p("AqmT4MAAAgnvIVMAAMAAAAnvg");
	var mask_graphics_561 = new cjs.Graphics().p("ArBT4MAAAgnvIWDAAMAAAAnvg");
	var mask_graphics_562 = new cjs.Graphics().p("ArcT4MAAAgnvIW5AAMAAAAnvg");
	var mask_graphics_563 = new cjs.Graphics().p("Ar3T4MAAAgnvIXvAAMAAAAnvg");
	var mask_graphics_564 = new cjs.Graphics().p("AsRT4MAAAgnvIYjAAMAAAAnvg");
	var mask_graphics_565 = new cjs.Graphics().p("AsrT4MAAAgnvIZXAAMAAAAnvg");
	var mask_graphics_566 = new cjs.Graphics().p("AtET4MAAAgnvIaJAAMAAAAnvg");
	var mask_graphics_567 = new cjs.Graphics().p("AtdT4MAAAgnvIa7AAMAAAAnvg");
	var mask_graphics_568 = new cjs.Graphics().p("At2T4MAAAgnvIbsAAMAAAAnvg");
	var mask_graphics_569 = new cjs.Graphics().p("AuOT4MAAAgnvIcdAAMAAAAnvg");
	var mask_graphics_570 = new cjs.Graphics().p("AulT4MAAAgnvIdLAAMAAAAnvg");
	var mask_graphics_571 = new cjs.Graphics().p("Au9T4MAAAgnvId6AAMAAAAnvg");
	var mask_graphics_572 = new cjs.Graphics().p("AvUT4MAAAgnvIeoAAMAAAAnvg");
	var mask_graphics_573 = new cjs.Graphics().p("AvqT4MAAAgnvIfVAAMAAAAnvg");
	var mask_graphics_574 = new cjs.Graphics().p("AwAT4MAAAgnvMAgBAAAMAAAAnvg");
	var mask_graphics_575 = new cjs.Graphics().p("AwWT4MAAAgnvMAgtAAAMAAAAnvg");
	var mask_graphics_576 = new cjs.Graphics().p("AwrT4MAAAgnvMAhXAAAMAAAAnvg");
	var mask_graphics_577 = new cjs.Graphics().p("Aw/T4MAAAgnvMAh/AAAMAAAAnvg");
	var mask_graphics_578 = new cjs.Graphics().p("AxUT4MAAAgnvMAipAAAMAAAAnvg");
	var mask_graphics_579 = new cjs.Graphics().p("AxoT4MAAAgnvMAjQAAAMAAAAnvg");
	var mask_graphics_580 = new cjs.Graphics().p("Ax7T4MAAAgnvMAj3AAAMAAAAnvg");
	var mask_graphics_581 = new cjs.Graphics().p("AyOT4MAAAgnvMAkdAAAMAAAAnvg");
	var mask_graphics_582 = new cjs.Graphics().p("AyhT4MAAAgnvMAlDAAAMAAAAnvg");
	var mask_graphics_583 = new cjs.Graphics().p("AyzT4MAAAgnvMAlnAAAMAAAAnvg");
	var mask_graphics_584 = new cjs.Graphics().p("AzFT4MAAAgnvMAmLAAAMAAAAnvg");
	var mask_graphics_585 = new cjs.Graphics().p("AzWT4MAAAgnvMAmtAAAMAAAAnvg");
	var mask_graphics_586 = new cjs.Graphics().p("AznT4MAAAgnvMAnPAAAMAAAAnvg");
	var mask_graphics_587 = new cjs.Graphics().p("Az4T4MAAAgnvMAnxAAAMAAAAnvg");
	var mask_graphics_588 = new cjs.Graphics().p("A0IT4MAAAgnvMAoRAAAMAAAAnvg");
	var mask_graphics_589 = new cjs.Graphics().p("A0YT4MAAAgnvMAoxAAAMAAAAnvg");
	var mask_graphics_590 = new cjs.Graphics().p("A0nT4MAAAgnvMApPAAAMAAAAnvg");
	var mask_graphics_591 = new cjs.Graphics().p("A02T4MAAAgnvMAptAAAMAAAAnvg");
	var mask_graphics_592 = new cjs.Graphics().p("A1ET4MAAAgnvMAqKAAAMAAAAnvg");
	var mask_graphics_593 = new cjs.Graphics().p("A1ST4MAAAgnvMAqmAAAMAAAAnvg");
	var mask_graphics_594 = new cjs.Graphics().p("A1gT4MAAAgnvMArBAAAMAAAAnvg");
	var mask_graphics_595 = new cjs.Graphics().p("A1tT4MAAAgnvMArbAAAMAAAAnvg");
	var mask_graphics_596 = new cjs.Graphics().p("A16T4MAAAgnvMAr1AAAMAAAAnvg");
	var mask_graphics_597 = new cjs.Graphics().p("A2GT4MAAAgnvMAsNAAAMAAAAnvg");
	var mask_graphics_598 = new cjs.Graphics().p("A2ST4MAAAgnvMAslAAAMAAAAnvg");
	var mask_graphics_599 = new cjs.Graphics().p("A2eT4MAAAgnvMAs9AAAMAAAAnvg");
	var mask_graphics_600 = new cjs.Graphics().p("A2pT4MAAAgnvMAtTAAAMAAAAnvg");
	var mask_graphics_601 = new cjs.Graphics().p("A20T4MAAAgnvMAtpAAAMAAAAnvg");
	var mask_graphics_602 = new cjs.Graphics().p("A2+T4MAAAgnvMAt9AAAMAAAAnvg");
	var mask_graphics_603 = new cjs.Graphics().p("A3IT4MAAAgnvMAuRAAAMAAAAnvg");
	var mask_graphics_604 = new cjs.Graphics().p("A3RT4MAAAgnvMAujAAAMAAAAnvg");
	var mask_graphics_605 = new cjs.Graphics().p("A3aT4MAAAgnvMAu1AAAMAAAAnvg");
	var mask_graphics_606 = new cjs.Graphics().p("A3jT4MAAAgnvMAvHAAAMAAAAnvg");
	var mask_graphics_607 = new cjs.Graphics().p("A3rT4MAAAgnvMAvXAAAMAAAAnvg");
	var mask_graphics_608 = new cjs.Graphics().p("A3zT4MAAAgnvMAvnAAAMAAAAnvg");
	var mask_graphics_609 = new cjs.Graphics().p("A36T4MAAAgnvMAv1AAAMAAAAnvg");
	var mask_graphics_610 = new cjs.Graphics().p("A4BT4MAAAgnvMAwDAAAMAAAAnvg");
	var mask_graphics_611 = new cjs.Graphics().p("A4HT4MAAAgnvMAwPAAAMAAAAnvg");
	var mask_graphics_612 = new cjs.Graphics().p("A4OT4MAAAgnvMAwdAAAMAAAAnvg");
	var mask_graphics_613 = new cjs.Graphics().p("A4TT4MAAAgnvMAwnAAAMAAAAnvg");
	var mask_graphics_614 = new cjs.Graphics().p("A4YT4MAAAgnvMAwyAAAMAAAAnvg");
	var mask_graphics_615 = new cjs.Graphics().p("A4dT4MAAAgnvMAw8AAAMAAAAnvg");
	var mask_graphics_616 = new cjs.Graphics().p("A4iT4MAAAgnvMAxFAAAMAAAAnvg");
	var mask_graphics_617 = new cjs.Graphics().p("A4mT4MAAAgnvMAxNAAAMAAAAnvg");
	var mask_graphics_618 = new cjs.Graphics().p("A4pT4MAAAgnvMAxTAAAMAAAAnvg");
	var mask_graphics_619 = new cjs.Graphics().p("A4sT4MAAAgnvMAxZAAAMAAAAnvg");
	var mask_graphics_620 = new cjs.Graphics().p("A4vT4MAAAgnvMAxfAAAMAAAAnvg");
	var mask_graphics_621 = new cjs.Graphics().p("A4xT4MAAAgnvMAxjAAAMAAAAnvg");
	var mask_graphics_622 = new cjs.Graphics().p("A4zT4MAAAgnvMAxoAAAMAAAAnvg");
	var mask_graphics_623 = new cjs.Graphics().p("A41T4MAAAgnvMAxrAAAMAAAAnvg");
	var mask_graphics_624 = new cjs.Graphics().p("A42T4MAAAgnvMAxtAAAMAAAAnvg");
	var mask_graphics_625 = new cjs.Graphics().p("A42T4MAAAgnvMAxuAAAMAAAAnvg");
	var mask_graphics_626 = new cjs.Graphics().p("A43T4MAAAgnvMAxvAAAMAAAAnvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(132).to({graphics:mask_graphics_132,x:14.308,y:125.8922}).wait(1).to({graphics:mask_graphics_133,x:17.75,y:125.875}).wait(1).to({graphics:mask_graphics_134,x:21.175,y:125.875}).wait(1).to({graphics:mask_graphics_135,x:24.55,y:125.875}).wait(1).to({graphics:mask_graphics_136,x:27.875,y:125.875}).wait(1).to({graphics:mask_graphics_137,x:31.175,y:125.875}).wait(1).to({graphics:mask_graphics_138,x:34.425,y:125.875}).wait(1).to({graphics:mask_graphics_139,x:37.625,y:125.875}).wait(1).to({graphics:mask_graphics_140,x:40.8,y:125.875}).wait(1).to({graphics:mask_graphics_141,x:43.925,y:125.875}).wait(1).to({graphics:mask_graphics_142,x:47,y:125.875}).wait(1).to({graphics:mask_graphics_143,x:50.025,y:125.875}).wait(1).to({graphics:mask_graphics_144,x:53,y:125.875}).wait(1).to({graphics:mask_graphics_145,x:55.95,y:125.875}).wait(1).to({graphics:mask_graphics_146,x:58.875,y:125.875}).wait(1).to({graphics:mask_graphics_147,x:61.75,y:125.875}).wait(1).to({graphics:mask_graphics_148,x:64.575,y:125.875}).wait(1).to({graphics:mask_graphics_149,x:67.35,y:125.875}).wait(1).to({graphics:mask_graphics_150,x:70.1,y:125.875}).wait(1).to({graphics:mask_graphics_151,x:72.8,y:125.875}).wait(1).to({graphics:mask_graphics_152,x:75.475,y:125.875}).wait(1).to({graphics:mask_graphics_153,x:78.1,y:125.875}).wait(1).to({graphics:mask_graphics_154,x:80.675,y:125.875}).wait(1).to({graphics:mask_graphics_155,x:83.2,y:125.875}).wait(1).to({graphics:mask_graphics_156,x:85.7,y:125.875}).wait(1).to({graphics:mask_graphics_157,x:88.15,y:125.875}).wait(1).to({graphics:mask_graphics_158,x:90.55,y:125.875}).wait(1).to({graphics:mask_graphics_159,x:92.925,y:125.875}).wait(1).to({graphics:mask_graphics_160,x:95.25,y:125.875}).wait(1).to({graphics:mask_graphics_161,x:97.55,y:125.875}).wait(1).to({graphics:mask_graphics_162,x:99.775,y:125.875}).wait(1).to({graphics:mask_graphics_163,x:101.975,y:125.875}).wait(1).to({graphics:mask_graphics_164,x:104.15,y:125.875}).wait(1).to({graphics:mask_graphics_165,x:106.25,y:125.875}).wait(1).to({graphics:mask_graphics_166,x:108.325,y:125.875}).wait(1).to({graphics:mask_graphics_167,x:110.375,y:125.875}).wait(1).to({graphics:mask_graphics_168,x:112.35,y:125.875}).wait(1).to({graphics:mask_graphics_169,x:114.3,y:125.875}).wait(1).to({graphics:mask_graphics_170,x:116.2,y:125.875}).wait(1).to({graphics:mask_graphics_171,x:118.075,y:125.875}).wait(1).to({graphics:mask_graphics_172,x:119.9,y:125.875}).wait(1).to({graphics:mask_graphics_173,x:121.675,y:125.875}).wait(1).to({graphics:mask_graphics_174,x:123.4,y:125.875}).wait(1).to({graphics:mask_graphics_175,x:125.1,y:125.875}).wait(1).to({graphics:mask_graphics_176,x:126.75,y:125.875}).wait(1).to({graphics:mask_graphics_177,x:128.375,y:125.875}).wait(1).to({graphics:mask_graphics_178,x:129.925,y:125.875}).wait(1).to({graphics:mask_graphics_179,x:131.475,y:125.875}).wait(1).to({graphics:mask_graphics_180,x:132.95,y:125.875}).wait(1).to({graphics:mask_graphics_181,x:134.4,y:125.875}).wait(1).to({graphics:mask_graphics_182,x:135.8,y:125.875}).wait(1).to({graphics:mask_graphics_183,x:137.175,y:125.875}).wait(1).to({graphics:mask_graphics_184,x:138.475,y:125.875}).wait(1).to({graphics:mask_graphics_185,x:139.775,y:125.875}).wait(1).to({graphics:mask_graphics_186,x:141,y:125.875}).wait(1).to({graphics:mask_graphics_187,x:142.2,y:125.875}).wait(1).to({graphics:mask_graphics_188,x:143.35,y:125.875}).wait(1).to({graphics:mask_graphics_189,x:144.45,y:125.875}).wait(1).to({graphics:mask_graphics_190,x:145.525,y:125.875}).wait(1).to({graphics:mask_graphics_191,x:146.55,y:125.875}).wait(1).to({graphics:mask_graphics_192,x:147.525,y:125.875}).wait(1).to({graphics:mask_graphics_193,x:148.475,y:125.875}).wait(1).to({graphics:mask_graphics_194,x:149.375,y:125.875}).wait(1).to({graphics:mask_graphics_195,x:150.25,y:125.875}).wait(1).to({graphics:mask_graphics_196,x:151.05,y:125.875}).wait(1).to({graphics:mask_graphics_197,x:151.825,y:125.875}).wait(1).to({graphics:mask_graphics_198,x:152.575,y:125.875}).wait(1).to({graphics:mask_graphics_199,x:153.25,y:125.875}).wait(1).to({graphics:mask_graphics_200,x:153.9,y:125.875}).wait(1).to({graphics:mask_graphics_201,x:154.525,y:125.875}).wait(1).to({graphics:mask_graphics_202,x:155.075,y:125.875}).wait(1).to({graphics:mask_graphics_203,x:155.6,y:125.875}).wait(1).to({graphics:mask_graphics_204,x:156.1,y:125.875}).wait(1).to({graphics:mask_graphics_205,x:156.525,y:125.875}).wait(1).to({graphics:mask_graphics_206,x:156.925,y:125.875}).wait(1).to({graphics:mask_graphics_207,x:157.275,y:125.875}).wait(1).to({graphics:mask_graphics_208,x:157.6,y:125.875}).wait(1).to({graphics:mask_graphics_209,x:157.875,y:125.875}).wait(1).to({graphics:mask_graphics_210,x:158.1,y:125.875}).wait(1).to({graphics:mask_graphics_211,x:158.3,y:125.875}).wait(1).to({graphics:mask_graphics_212,x:158.425,y:125.875}).wait(1).to({graphics:mask_graphics_213,x:158.55,y:125.875}).wait(1).to({graphics:mask_graphics_214,x:158.6,y:125.875}).wait(1).to({graphics:mask_graphics_215,x:158.6376,y:125.8922}).wait(1).to({graphics:null,x:0,y:0}).wait(327).to({graphics:mask_graphics_543,x:14.308,y:125.8922}).wait(1).to({graphics:mask_graphics_544,x:17.75,y:125.875}).wait(1).to({graphics:mask_graphics_545,x:21.175,y:125.875}).wait(1).to({graphics:mask_graphics_546,x:24.55,y:125.875}).wait(1).to({graphics:mask_graphics_547,x:27.875,y:125.875}).wait(1).to({graphics:mask_graphics_548,x:31.175,y:125.875}).wait(1).to({graphics:mask_graphics_549,x:34.425,y:125.875}).wait(1).to({graphics:mask_graphics_550,x:37.625,y:125.875}).wait(1).to({graphics:mask_graphics_551,x:40.8,y:125.875}).wait(1).to({graphics:mask_graphics_552,x:43.925,y:125.875}).wait(1).to({graphics:mask_graphics_553,x:47,y:125.875}).wait(1).to({graphics:mask_graphics_554,x:50.025,y:125.875}).wait(1).to({graphics:mask_graphics_555,x:53,y:125.875}).wait(1).to({graphics:mask_graphics_556,x:55.95,y:125.875}).wait(1).to({graphics:mask_graphics_557,x:58.875,y:125.875}).wait(1).to({graphics:mask_graphics_558,x:61.75,y:125.875}).wait(1).to({graphics:mask_graphics_559,x:64.575,y:125.875}).wait(1).to({graphics:mask_graphics_560,x:67.35,y:125.875}).wait(1).to({graphics:mask_graphics_561,x:70.1,y:125.875}).wait(1).to({graphics:mask_graphics_562,x:72.8,y:125.875}).wait(1).to({graphics:mask_graphics_563,x:75.475,y:125.875}).wait(1).to({graphics:mask_graphics_564,x:78.1,y:125.875}).wait(1).to({graphics:mask_graphics_565,x:80.675,y:125.875}).wait(1).to({graphics:mask_graphics_566,x:83.2,y:125.875}).wait(1).to({graphics:mask_graphics_567,x:85.7,y:125.875}).wait(1).to({graphics:mask_graphics_568,x:88.15,y:125.875}).wait(1).to({graphics:mask_graphics_569,x:90.55,y:125.875}).wait(1).to({graphics:mask_graphics_570,x:92.925,y:125.875}).wait(1).to({graphics:mask_graphics_571,x:95.25,y:125.875}).wait(1).to({graphics:mask_graphics_572,x:97.55,y:125.875}).wait(1).to({graphics:mask_graphics_573,x:99.775,y:125.875}).wait(1).to({graphics:mask_graphics_574,x:101.975,y:125.875}).wait(1).to({graphics:mask_graphics_575,x:104.15,y:125.875}).wait(1).to({graphics:mask_graphics_576,x:106.25,y:125.875}).wait(1).to({graphics:mask_graphics_577,x:108.325,y:125.875}).wait(1).to({graphics:mask_graphics_578,x:110.375,y:125.875}).wait(1).to({graphics:mask_graphics_579,x:112.35,y:125.875}).wait(1).to({graphics:mask_graphics_580,x:114.3,y:125.875}).wait(1).to({graphics:mask_graphics_581,x:116.2,y:125.875}).wait(1).to({graphics:mask_graphics_582,x:118.075,y:125.875}).wait(1).to({graphics:mask_graphics_583,x:119.9,y:125.875}).wait(1).to({graphics:mask_graphics_584,x:121.675,y:125.875}).wait(1).to({graphics:mask_graphics_585,x:123.4,y:125.875}).wait(1).to({graphics:mask_graphics_586,x:125.1,y:125.875}).wait(1).to({graphics:mask_graphics_587,x:126.75,y:125.875}).wait(1).to({graphics:mask_graphics_588,x:128.375,y:125.875}).wait(1).to({graphics:mask_graphics_589,x:129.925,y:125.875}).wait(1).to({graphics:mask_graphics_590,x:131.475,y:125.875}).wait(1).to({graphics:mask_graphics_591,x:132.95,y:125.875}).wait(1).to({graphics:mask_graphics_592,x:134.4,y:125.875}).wait(1).to({graphics:mask_graphics_593,x:135.8,y:125.875}).wait(1).to({graphics:mask_graphics_594,x:137.175,y:125.875}).wait(1).to({graphics:mask_graphics_595,x:138.475,y:125.875}).wait(1).to({graphics:mask_graphics_596,x:139.775,y:125.875}).wait(1).to({graphics:mask_graphics_597,x:141,y:125.875}).wait(1).to({graphics:mask_graphics_598,x:142.2,y:125.875}).wait(1).to({graphics:mask_graphics_599,x:143.35,y:125.875}).wait(1).to({graphics:mask_graphics_600,x:144.45,y:125.875}).wait(1).to({graphics:mask_graphics_601,x:145.525,y:125.875}).wait(1).to({graphics:mask_graphics_602,x:146.55,y:125.875}).wait(1).to({graphics:mask_graphics_603,x:147.525,y:125.875}).wait(1).to({graphics:mask_graphics_604,x:148.475,y:125.875}).wait(1).to({graphics:mask_graphics_605,x:149.375,y:125.875}).wait(1).to({graphics:mask_graphics_606,x:150.25,y:125.875}).wait(1).to({graphics:mask_graphics_607,x:151.05,y:125.875}).wait(1).to({graphics:mask_graphics_608,x:151.825,y:125.875}).wait(1).to({graphics:mask_graphics_609,x:152.575,y:125.875}).wait(1).to({graphics:mask_graphics_610,x:153.25,y:125.875}).wait(1).to({graphics:mask_graphics_611,x:153.9,y:125.875}).wait(1).to({graphics:mask_graphics_612,x:154.525,y:125.875}).wait(1).to({graphics:mask_graphics_613,x:155.075,y:125.875}).wait(1).to({graphics:mask_graphics_614,x:155.6,y:125.875}).wait(1).to({graphics:mask_graphics_615,x:156.1,y:125.875}).wait(1).to({graphics:mask_graphics_616,x:156.525,y:125.875}).wait(1).to({graphics:mask_graphics_617,x:156.925,y:125.875}).wait(1).to({graphics:mask_graphics_618,x:157.275,y:125.875}).wait(1).to({graphics:mask_graphics_619,x:157.6,y:125.875}).wait(1).to({graphics:mask_graphics_620,x:157.875,y:125.875}).wait(1).to({graphics:mask_graphics_621,x:158.1,y:125.875}).wait(1).to({graphics:mask_graphics_622,x:158.3,y:125.875}).wait(1).to({graphics:mask_graphics_623,x:158.425,y:125.875}).wait(1).to({graphics:mask_graphics_624,x:158.55,y:125.875}).wait(1).to({graphics:mask_graphics_625,x:158.6,y:125.875}).wait(1).to({graphics:mask_graphics_626,x:158.6376,y:125.8922}).wait(1).to({graphics:null,x:0,y:0}).wait(195));

	// pc12
	this.instance_10 = new lib.pc12();
	this.instance_10.parent = this;
	this.instance_10.setTransform(150,125,0.8929,0.8929,0,0,0,168,140);
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(132).to({_off:false},0).wait(121).to({alpha:0},16).to({_off:true},1).wait(273).to({_off:false,alpha:1},0).wait(121).to({alpha:0},16).to({_off:true},1).wait(141));

	// pc11
	this.instance_11 = new lib.pc11();
	this.instance_11.parent = this;
	this.instance_11.setTransform(150,125,0.8929,0.8929,0,0,0,168,140);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(132).to({_off:false},0).to({_off:true},84).wait(327).to({_off:false},0).to({_off:true},84).wait(195));

	// screen21.jpg - копия
	this.instance_12 = new lib.pc21("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(264.3,125,0.8929,0.8929,0,0,0,296,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({regX:295.9,x:262.5,alpha:0.9883,startPosition:1},1).to({x:35.65,alpha:0,mode:"independent"},135).to({_off:true},1).wait(274).to({_off:false,regX:296,x:264.3,alpha:1,mode:"synched",startPosition:0},0).to({regX:295.9,x:262.5,alpha:0.9883,startPosition:1},1).to({x:35.65,alpha:0,mode:"independent"},135).to({_off:true},1).wait(274));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.6,120.2,610.1,134.7);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_KitchenSink_atlas_P_.png", id:"300x250_KitchenSink_atlas_P_"},
		{src:"images/300x250_KitchenSink_atlas_NP_.jpg", id:"300x250_KitchenSink_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;