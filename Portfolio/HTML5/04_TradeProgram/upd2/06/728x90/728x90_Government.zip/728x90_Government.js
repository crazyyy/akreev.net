(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_Government_atlas_P_", frames: [[0,128,143,51],[0,0,380,126]]},
		{name:"728x90_Government_atlas_NP_", frames: [[394,45,49,43],[452,0,54,44],[394,0,56,43],[0,0,392,280]]}
];


// symbols:



(lib.Растровоеизображение10 = function() {
	this.initialize(ss["728x90_Government_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение11 = function() {
	this.initialize(ss["728x90_Government_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["728x90_Government_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.logoblack = function() {
	this.initialize(ss["728x90_Government_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen1111111 = function() {
	this.initialize(ss["728x90_Government_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen211111 = function() {
	this.initialize(ss["728x90_Government_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAGQgCgDAAgDQAAgDACgCQADgCACAAQADAAADACQACACAAADQAAADgCADQgDACgDAAQgCAAgDgCg");
	this.shape.setTransform(607.175,-101.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIACgIQACgEADgDQADgDAFgBQAGgCAFAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIAKADIALADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_1.setTransform(601.85,-104.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAHADAEAHIAAgnIALAAIAABjIgLAAIAAgLQgEAGgGADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAFADAEAAQAGAAAHgEQAFgDAEgFIAAgfQgEgFgFgEQgHgDgGAAQgEAAgFACg");
	this.shape_2.setTransform(593.9,-106.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_3.setTransform(588.075,-106.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgDgCAAgDQAAgDADgDQACgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(584.7,-106.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgGADQgHAEgHAAQgLAAgGgGg");
	this.shape_5.setTransform(578.9,-104.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_6.setTransform(570.625,-106.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_7.setTransform(557.975,-104.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgFAkIgehHIAMAAIAXA6IAYg6IAMAAIgeBHg");
	this.shape_8.setTransform(550.075,-104.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgFAxIAAhHIAKAAIAABHgAgFgjQgBgCAAgDQAAgDABgDQADgCACAAQADAAACACQADADAAADQAAADgDACQgCACgDAAQgCAAgDgCg");
	this.shape_9.setTransform(544.7,-106.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_10.setTransform(540.825,-105.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_11.setTransform(536.9,-106.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape_12.setTransform(531.6,-104.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_13.setTransform(524.05,-104.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_14.setTransform(515.675,-104.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape_15.setTransform(507.85,-104.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_16.setTransform(498.375,-105.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_17.setTransform(491.925,-104.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgPAxQgIgCgGgGIAGgJQAEAGAGACQAFACAIAAIAIgBQAEgBAEgCQADgDABgEQACgEAAgGIAAgKQgDAFgHAEQgGADgGAAQgIABgGgDQgFgDgFgFQgEgFgDgGQgCgHAAgIQAAgJACgHQACgHAFgFQAEgEAGgDQAGgDAIAAQAFAAAHADQAGAEAEAGIAAgLIAMAAIAABGQAAAJgDAGQgDAGgFADQgEADgHACQgGACgGAAQgJAAgGgDgAgIgnQgEACgDAEQgDAEgBAFQgCAFAAAGQAAAGACAFQABAEADADQADAFAEACQAFABAEAAIAHgBIAFgCIAGgEIADgEIAAgfIgDgEIgGgEIgFgDIgHgBQgEAAgFACg");
	this.shape_18.setTransform(483.15,-103.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAFADAEAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_19.setTransform(474.5,-106.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQABACAEAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgFAFgHADQgGAEgHAAQgMAAgFgGg");
	this.shape_20.setTransform(466.3,-104.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_21.setTransform(458.025,-106.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_22.setTransform(447.525,-104.85);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_23.setTransform(440.325,-104.775);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgEAHIgFgDIgEgBQgGAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_24.setTransform(434.45,-106.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgDgCQgEgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAFgCAFAAQAJAAAHADQAHADAEAEIgGAIQgDgEgGgCQgFgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIALADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgIAAgHgDg");
	this.shape_25.setTransform(424.3,-104.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_26.setTransform(418.725,-105.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_27.setTransform(412.875,-104.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAFgDQAGgEADgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_28.setTransform(404.95,-104.675);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAwQgHgCgEgFQgEgFgCgHQgDgIAAgIQAAgJADgGQACgHAEgFQAEgFAGgCQAGgEAHAAQAHAAAGAEQAGADAFAHIAAgnIALAAIAABjIgLAAIAAgLQgFAGgFADQgHAEgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAEADAFAAQAGAAAHgEQAGgDADgFIAAgfQgDgFgGgEQgHgDgGAAQgFAAgEACg");
	this.shape_29.setTransform(396.25,-106.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJQABgGAAgFQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_30.setTransform(387.825,-104.775);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_31.setTransform(381.475,-104.85);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgFQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGACQgGADgHAAQgHABgGgEQgGgEgFgFIAAAmgAgNglQgGAEgDAFIAAAgQADAEAGAEQAGAEAHgBQAEABAFgDQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgDQgDgEgEgDQgFgCgEAAQgHAAgGADg");
	this.shape_32.setTransform(374.525,-103.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAgwQAAgHgDgEQgDgEgHAAQgGAAgEADQgGAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIADgEIAGgEIAHgDIAHgBQAJAAAFAEQADAEACAFIAEgEIAGgFIAGgDIAIgBQAKAAAFAFQAGAGAAALIAAAzg");
	this.shape_33.setTransform(360.05,-104.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQACACACAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgIADQgGAEgHAAQgMAAgFgGg");
	this.shape_34.setTransform(349.9,-104.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgCgCgBgDQABgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_35.setTransform(344.05,-106.05);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgKAAIAAgwQgBgHgDgEQgDgEgHAAQgGAAgEADQgGAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIADgEIAGgEIAHgDIAIgBQAIAAAEAEQAEAEACAFIAEgEIAGgFIAHgDIAHgBQAKAAAFAFQAGAGAAALIAAAzg");
	this.shape_36.setTransform(336.3,-104.875);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_37.setTransform(326.025,-104.775);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_38.setTransform(319.725,-104.85);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgjAyIAAhjIAoAAQAHAAAGADQAGACADAEQAEAEADAGQACAFAAAGQAAAGgCAFQgDAGgEADQgEAFgGACQgFACgHAAIgcAAIAAAogAgXAAIAaAAQAJAAAFgFQAGgGAAgIQAAgIgGgGQgFgFgJAAIgaAAg");
	this.shape_39.setTransform(312.8,-106.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(306,-115,305,19), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAGQgCgDAAgDQAAgDACgCQADgCACAAQADAAADACQACACAAADQAAADgCADQgDACgDAAQgCAAgDgCg");
	this.shape.setTransform(623.825,-100.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgYAyIgFAAIACgLIADABIADABQAEAAADgCQACgCACgEIAFgLIgehIIAMAAIAXA7IAYg7IAMAAIgkBWQgCAIgGADQgFADgHABIgEgBg");
	this.shape_1.setTransform(618.425,-102.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAEgCAGAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgFACgHAAQgIAAgHgDg");
	this.shape_2.setTransform(611.15,-103.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAFgDAEgEIAAgOQgEgEgFgCQgFgCgFAAQgIAAgFAEg");
	this.shape_3.setTransform(603.6,-103.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_4.setTransform(595.625,-103.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_5.setTransform(583.275,-103.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgOAwQgFgDgFgEQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgDAIgBQAFAAAHAEQAGAEAEAGIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHAEQgGADgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgBAEQgCAGAAAGQAAAGACAFQABAFADAEQADADAEADQAFACAEAAQAHAAAFgEQAHgDACgEIAAggQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_6.setTransform(574.5,-105.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAGgDADgEIAAgOQgDgEgGgCQgFgCgFAAQgIAAgFAEg");
	this.shape_7.setTransform(566.25,-103.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgKAAIAAgwQAAgHgEgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIADgEIAGgEIAHgDIAIgBQAIAAAEAEQAEAEACAFIAEgEIAGgFIAHgDIAHgBQAKAAAFAFQAFAGABALIAAAzg");
	this.shape_8.setTransform(556.45,-103.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgIAMIAHgGQABgEABgCIgBAAQgEAAgCgCQgBgDAAgDQgBgDADgDQACgCADAAQADAAADADQADADAAAFQAAAGgEAHQgDAFgFAEg");
	this.shape_9.setTransform(544.8,-99.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgQAxQgHgCgGgGIAGgJQAEAGAGACQAFACAIAAIAIgBQAEgBAEgCQADgDABgEQACgEAAgGIAAgKQgDAFgHAEQgGADgGAAQgIAAgGgCQgFgDgFgFQgEgFgDgGQgCgHAAgIQAAgJACgHQACgHAFgFQAEgEAGgDQAGgDAIAAQAFAAAHADQAGAEAEAGIAAgLIAMAAIAABFQAAAJgDAHQgDAFgFAEQgEADgHACQgGACgGAAQgJAAgHgDgAgIgnQgEACgDAEQgDAEgBAFQgCAFAAAGQAAAGACAFQABAEADADQADAFAEABQAFACAEAAIAHgBIAFgCIAGgEIADgEIAAgfIgDgEIgGgEIgFgDIgHgBQgEAAgFACg");
	this.shape_10.setTransform(538.5,-102.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_11.setTransform(530.25,-103.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgDgCAAgDQAAgEADgCQACgCACAAQADAAACACQACACAAAEQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_12.setTransform(524.4,-105.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape_13.setTransform(519.1,-103.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEgBgGQABgGACgEQACgEAEgDQAEgDAEgBIAJgCQAHAAAFADQAHACAEAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgKAKIgFgIQAMgMARAAQAFAAAFABQAFACAEADQAEADACAEQACAFABAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEAAAHQAAAHAFAFQAFAEAIAAQAFAAAGgCQAFgDADgEIAAgOQgDgEgFgCQgGgCgFAAQgIAAgFAEg");
	this.shape_14.setTransform(511.55,-103.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AATAyIAAgwQAAgDgBgDQgCgEgCgCQgCgCgDAAIgGgBIgGABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAFgFIAGgDIAHgDIAHgCQALABAGAFQAGAGAAAMIAAAyg");
	this.shape_15.setTransform(503.65,-105.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_16.setTransform(495.875,-103.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAFIgDADIAAAzg");
	this.shape_17.setTransform(489.975,-103.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQACACACAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_18.setTransform(483,-103.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgGAHgEQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgDQgGgEgFgGIAAAngAgNglQgGAEgDAFIAAAfQADAFAGAEQAGAEAHgBQAEAAAFgCQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgEQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_19.setTransform(474.775,-102.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAwQgGgDgFgEQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgDAHgBQAHAAAGAEQAHAEADAGIAAgnIAMAAIAABjIgMAAIAAgLQgEAGgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADADAEADQAEACAFAAQAHAAAFgEQAHgDACgEIAAggQgCgFgHgEQgFgDgHAAQgFAAgEACg");
	this.shape_20.setTransform(461.8,-105.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_21.setTransform(453.55,-103.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQADAFgBAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_22.setTransform(445.25,-103.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgLgDQgEgCgEgEQgDgDAAgHIACgIQACgEADgDQADgDAFgBQAGgCAFAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIAKADIALADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_23.setTransform(434,-103.775);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_24.setTransform(428.875,-105.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgCgEAAgGQAAgGACgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAFgDAEgEIAAgOQgEgEgFgCQgFgCgFAAQgIAAgFAEg");
	this.shape_25.setTransform(423.05,-103.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgEgCQgDgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIACgIQABgEAEgDQAEgDAEgBQAFgCAGAAQAJAAAHADQAHADAEAEIgFAIQgEgEgFgCQgGgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape_26.setTransform(415.7,-103.775);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_27.setTransform(407.975,-103.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgGAHgEQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgDQgGgEgFgGIAAAngAgNglQgGAEgDAFIAAAfQADAFAGAEQAGAEAHgBQAEAAAFgCQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgEQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_28.setTransform(399.625,-102.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_29.setTransform(390.775,-103.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAFIgDADIAAAzg");
	this.shape_30.setTransform(384.425,-103.85);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgGAHgEQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgDQgGgEgFgGIAAAngAgNglQgGAEgDAFIAAAfQADAFAGAEQAGAEAHgBQAEAAAFgCQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgEQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_31.setTransform(377.475,-102.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_32.setTransform(366.875,-104.65);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_33.setTransform(360.5,-103.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_34.setTransform(352.125,-103.775);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgGAEgDAEIAAA0IgKAAIAAgwQAAgHgCgEQgEgEgHAAQgFAAgFADQgGAEgDAEIAAA0IgMAAIAAhHIAMAAIAAAKIADgEIAGgEIAGgDIAIgBQAJAAAFAEQADAEACAFIAEgEIAFgFIAHgDIAIgBQAKAAAFAFQAGAGgBALIAAAzg");
	this.shape_35.setTransform(341.85,-103.875);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_36.setTransform(331.65,-103.875);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAFIgDADIAAAzg");
	this.shape_37.setTransform(325.425,-103.85);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_38.setTransform(318.325,-103.775);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgFAkIgehHIAMAAIAXA6IAYg6IAMAAIgeBHg");
	this.shape_39.setTransform(310.425,-103.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_40.setTransform(302.425,-103.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgNAwQgJgEgHgHQgIgGgDgKQgFgJAAgMQAAgLAFgJQADgKAIgHQAHgHAJgDQAKgEAJAAQANAAAKAFQAJAFAHAJIgKAGQgFgGgHgEQgIgEgJAAQgHAAgIADQgGADgFAGQgFAFgEAHQgCAIAAAIQAAAJACAHQAEAIAFAFQAEAFAIAEQAHADAHAAIAJgBIAHgDIAGgDIAFgEIAAgVIgiAAIAAgKIAuAAIAAAjQgGAIgLAFQgJAFgNAAQgJAAgKgEg");
	this.shape_41.setTransform(292.75,-105.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(285.4,-114,342.30000000000007,19), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgKA1IAAhVIggAAIAAgUIBVAAIAAAUIggAAIAABVg");
	this.shape.setTransform(645.35,-41.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_1.setTransform(634.875,-41.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_2.setTransform(624.525,-41.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAjA1IAAhMIgeBMIgJAAIgehMIAABMIgXAAIAAhpIAgAAIAZBBIAahBIAgAAIAABpg");
	this.shape_3.setTransform(612.85,-41.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_4.setTransform(600.175,-41.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_5.setTransform(589.425,-41.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_6.setTransform(579.525,-41.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgNA1IgphpIAZAAIAdBQIAehQIAZAAIgpBpg");
	this.shape_7.setTransform(569.225,-41.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_8.setTransform(557.625,-41.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgWAwQgMgGgIgNQgIgMAAgRQAAgQAIgMQAIgNAMgGQANgHAPAAQALAAAIADQAJADAGAGQAGAFAEAHIgTAKQgDgGgHgEQgGgEgJAAQgJAAgHAFQgIAEgEAIQgFAIAAAJQAAAKAFAIQAEAIAIAEQAHAFAJAAQAHAAAGgDQAGgCADgDIAAgNIgcAAIAAgTIAzAAIAAAoQgIAJgLAGQgLAFgPAAQgPAAgNgHg");
	this.shape_9.setTransform(545.65,-41.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAZA1IAAgtIgxAAIAAAtIgXAAIAAhpIAXAAIAAApIAxAAIAAgpIAXAAIAABpg");
	this.shape_10.setTransform(530.05,-41.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgLA1IAAhVIgeAAIAAgUIBTAAIAAAUIgeAAIAABVg");
	this.shape_11.setTransform(519.55,-41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKA1IAAhpIAVAAIAABpg");
	this.shape_12.setTransform(512.7,-41.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_13.setTransform(503.125,-41.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgYAyQgMgEgHgIIAMgSQAGAGAJAFQAIAEAKAAQAKAAAEgEQAFgDAAgFQAAgEgFgDQgEgCgHgCIgOgEIgPgFQgHgDgEgGQgEgGgBgKQABgJAEgHQAFgHAJgFQAJgEAMAAQANAAAKAEQALAEAIAHIgNARQgHgGgIgDQgIgDgHAAQgHAAgEADQgEADAAAFQAAAEAEACIAMAEIANAEQAIACAHADQAHAEAFAFQAEAGAAAKQAAAKgFAHQgEAIgKAFQgJAEgPAAQgOAAgLgFg");
	this.shape_14.setTransform(486.825,-41.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AASA1IgggrIgIAKIAAAhIgXAAIAAhpIAXAAIAAAvIAlgvIAcAAIgrAyIAuA3g");
	this.shape_15.setTransform(477.525,-41.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_16.setTransform(466.975,-41.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_17.setTransform(455.475,-41.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_18.setTransform(441.975,-41.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgQAdQgHgEgGgIQgEgHAAgKQAAgIAEgIQAGgIAHgEQAIgEAIgBQAJABAIAEQAIAEAFAIQAEAIAAAIQAAAKgEAHQgFAIgIAEQgIAFgJAAQgIAAgIgFgAgNgYQgHAEgEAGQgDAHgBAHQABAIADAGQAEAHAHAEQAGAEAHAAQAIAAAGgEQAHgEAEgHQADgGABgIQgBgHgDgHQgEgGgHgEQgGgEgIABQgHgBgGAEgAAKATIgKgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAAEADQADADAAAFQAAAFgCACIgDADIgFABIALAPgAgGAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQADgDAAgDQAAgCgDgDQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIgJAAg");
	this.shape_19.setTransform(426.6,-43.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_20.setTransform(418.125,-41.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgWAwQgMgGgIgNQgIgMAAgRQAAgQAIgMQAIgNAMgGQANgHAPAAQALAAAJADQAHADAHAGQAGAFAEAHIgTAKQgEgGgGgEQgGgEgJAAQgJAAgIAFQgHAEgFAIQgDAIAAAJQAAAKADAIQAFAIAHAEQAIAFAJAAQAHAAAGgDQAGgCAEgDIAAgNIgcAAIAAgTIAyAAIAAAoQgIAJgMAGQgLAFgOAAQgPAAgNgHg");
	this.shape_21.setTransform(407.45,-41.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAeA1IgHgSIgtAAIgHASIgZAAIAphpIAbAAIApBpgAARAPIgRgtIgQAtIAhAAg");
	this.shape_22.setTransform(396.325,-41.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_23.setTransform(383.475,-41.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_24.setTransform(371.625,-41.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_25.setTransform(360.975,-41.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(353.1,-51,299,20), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen211111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,392,280);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen1111111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,380,126), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape.setTransform(16.9,45.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAFgDQAGgEADgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(9.4,45.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_2.setTransform(-2.8,44.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_3.setTransform(-9.125,44.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(-13.05,44.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(-20.225,45.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_6.setTransform(-31.825,44.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(-37.675,45.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(-45.725,45.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(-54.1,45.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(-62.4,45.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(-70.875,45.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgMAwQgKgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAKgDQAJgEAKAAQAGAAAGACIAKAEQAFACADAEIAHAIIgKAGQgEgHgHgEQgIgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAIgEQAHgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgJgEg");
	this.shape_12.setTransform(-80.05,44.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApJCAQgqAAAAgqIAAirQAAgqAqAAISUAAQApAAAAAqIAACrQAAAqgpAAg");
	this.shape_13.setTransform(-32.4,44.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-95.2,32,125.6,25.700000000000003), null);


(lib.biglogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logoblack();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6129,0.6129);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.biglogo, new cjs.Rectangle(0,0,87.7,31.3), null);


(lib._5Multiple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение11();
	this.instance.parent = this;
	this.instance.setTransform(-28,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._5Multiple, new cjs.Rectangle(-28,-23,54,44), null);


(lib._4Quotes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение10();
	this.instance.parent = this;
	this.instance.setTransform(-25,-22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._4Quotes, new cjs.Rectangle(-25,-22,49,43), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgHAWQgFgCgCgDQgDgDgCgEQgCgFAAgFIACgIQACgEADgEIAHgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape.setTransform(87.95,-82.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAfIAAg9IAGAAIAAA9g");
	this.shape_1.setTransform(84.35,-83.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgGAdQgEgCgDgDIAAAGIgHAAIAAg8IAHAAIAAAXQADgDAEgCQAEgCADAAIAIABQAEACACADIAEAHQACAEAAAFQAAAFgCAFQgBAEgDADQgCADgEACIgIABQgEAAgDgCgAgHgGQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgDIABgHIgBgHQgBgCgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_2.setTransform(80.725,-83.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgCgDABgDQgBgEACgDQABgCACgBIAGgDIAFgBQADAAAEABQAEACADACIAAgHQAAgFgDgCQgDgCgFAAQgIAAgFAGIgEgFQAIgHAJAAIAHAAIAFADQADACACADIABAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgDACAAAFQAAAEADADQACACAFAAIAHgBQACgBADgDIAAgJIgFgEIgHAAQgFAAgCACg");
	this.shape_3.setTransform(75.45,-82.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgDAfIAAg9IAGAAIAAA9g");
	this.shape_4.setTransform(72.1,-83.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_5.setTransform(70.025,-83.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgCgDABgDQgBgEACgDQABgCACgBIAGgDIAFgBQADAAAEABQAEACADACIAAgHQAAgFgDgCQgDgCgFAAQgIAAgFAGIgEgFQAIgHAJAAIAHAAIAFADQADACACADIABAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgDACAAAFQAAAEADADQACACAFAAIAHgBQACgBADgDIAAgJIgFgEIgHAAQgFAAgCACg");
	this.shape_6.setTransform(66.45,-82.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgDAWIgSgrIAHAAIAOAjIAPgjIAHAAIgSArg");
	this.shape_7.setTransform(61.875,-82.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgIAWQgCAAgDgCQgCgCgBgDQgCgDABgDQgBgEACgDQABgCACgBIAFgDIAGgBQADAAAFABQADACADACIAAgHQAAgFgDgCQgEgCgFAAQgHAAgFAGIgEgFQAIgHAJAAIAHAAIAFADQADACACADIABAHIAAAdIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgCACAAAFQAAAEACADQAEACAEAAIAHgBQADgBACgDIAAgJIgFgEIgHAAQgEAAgEACg");
	this.shape_8.setTransform(57.1,-82.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_9.setTransform(50.175,-82.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAMAXIAAgcQgBgGgCgDQgDgCgEAAIgEABIgDABIgDADIgDACIAAAgIgGAAIAAgsIAGAAIAAAHIADgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_10.setTransform(45.55,-82.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgJAWQgDgCgDgEIgFgHQgBgEAAgFIABgIIAFgIIAGgFQAFgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQABACAEACQADABACAAQADAAADgBIAFgEIADgGIAAgGIAAgGIgDgFIgFgEQgDgBgDAAQgCAAgDABg");
	this.shape_11.setTransform(40.4,-82.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_12.setTransform(36.725,-83.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_13.setTransform(34.375,-82.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_14.setTransform(30.525,-81.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgIAWQgEgCgEgEIgDgHQgCgEAAgFIACgIIADgIIAIgFQAEgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQABACADACQADABADAAQAEAAACgBIAFgEIACgGIACgGIgCgGIgCgFIgFgEQgCgBgEAAQgDAAgDABg");
	this.shape_15.setTransform(25.15,-82.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_16.setTransform(90.575,-92.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAMAXIAAgcQAAgGgDgDQgDgCgFAAIgCABIgEABIgEADIgCACIAAAgIgHAAIAAgsIAHAAIAAAHIADgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_17.setTransform(86.65,-91.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgHAWQgEgCgEgDQgDgDgBgEQgBgFAAgFIABgIQABgEADgEIAHgFQAEgBAEAAQAFAAAEABQAEACADAEQADADABAEQABAFAAAEIAAABIgjAAIACAGQABADACACIAFADQADACACAAQAFAAADgCIAHgEIACAFQgDADgEACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgDAFIgCAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_18.setTransform(81.5,-91.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAXAXIAAgeQAAgEgCgCQgBgDgFAAQgDAAgEACIgFAFIAAAgIgGAAIAAgeQAAgEgBgCQgCgDgFAAQgDAAgDACQgEACgBADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIADgCIAEgCIAFgBQAFAAADACQACADABADIACgDIAEgCIAEgCIAFgBQAGAAADADQADAEAAAHIAAAfg");
	this.shape_19.setTransform(75.125,-91.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgPAfIgCAAIABgHIACABIACAAIADgBQABAAAAAAQABgBAAAAQAAgBABAAQAAgBAAgBIADgGIgSgsIAHAAIAOAjIAPgjIAHAAIgWA0QgBAFgEACQgDACgEAAIgDAAg");
	this.shape_20.setTransform(69.175,-90.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgHAWQgEAAgBgCQgDgCgBgDQgCgDAAgDQAAgEACgDQABgCADgBIAFgDIAFgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgDgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAFADQADACABADIACAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQADACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgDACg");
	this.shape_21.setTransform(64.35,-91.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_22.setTransform(59.575,-90.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgHAWQgEgCgEgDQgDgDgBgEQgBgFAAgFIABgIQABgEADgEIAHgFQAEgBAEAAQAFAAAEABQAEACADAEQADADABAEQABAFAAAEIAAABIgjAAIACAGQABADACACIAFADQADACACAAQAFAAADgCIAHgEIACAFQgDADgEACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgDAFIgCAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_23.setTransform(51.8,-91.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgDAfIAAg9IAHAAIAAA9g");
	this.shape_24.setTransform(48.15,-92.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_25.setTransform(44.625,-90.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_26.setTransform(40.825,-92.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_27.setTransform(38.475,-92.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgDAfIAAg9IAHAAIAAA9g");
	this.shape_28.setTransform(36.1,-92.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOATQgDgDAAgHIAAgfIAGAAIAAAdIABAEIACAEIAEABIADABQAEAAADgCQAEgCACgDIAAggIAHAAIAAAsIgHAAIAAgHIgHAGQgFACgEAAQgGAAgEgEg");
	this.shape_29.setTransform(32.5,-91.475);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAXAfIAAgyIgVAyIgDAAIgUgyIAAAyIgIAAIAAg9IALAAIASAuIATguIALAAIAAA9g");
	this.shape_30.setTransform(26.225,-92.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgPAfIgCAAIABgHIACABIACAAIADgBQACgBABgDIADgGIgSgsIAHAAIAOAjIAPgjIAHAAIgWA0QgBAFgEACQgDACgEAAIgDAAg");
	this.shape_31.setTransform(69.825,-53.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgKAXIAAgsIAHAAIAAAHQADgDADgCQADgDAFAAIAAAHIgDAAIgDABIgEABIgCADIgCACIAAAfg");
	this.shape_32.setTransform(66.275,-54.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgHAWQgEgCgDgDQgEgDgBgEQgCgFABgFIABgIQABgEAEgEIAGgFQAFgBADAAQAGAAADABQAEACADAEQADADABAEQACAFAAAEIAAABIgjAAIABAGQABADACACIAFADQADACACAAQAFAAADgCIAHgEIACAFQgDADgEACQgFABgFAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgCgFIgGgDQgCgCgEAAQgCAAgDACg");
	this.shape_33.setTransform(61.9,-54.575);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAWIgSgrIAHAAIAOAjIAPgjIAHAAIgSArg");
	this.shape_34.setTransform(57.075,-54.575);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_35.setTransform(53.725,-55.35);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgCAfIAAg9IAFAAIAAA9g");
	this.shape_36.setTransform(51.7,-55.425);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgDgDgBgEQgCgFAAgFIACgIQABgEADgEIAIgFQAEgBAEAAQAFAAAEABQADACADAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAEAAAEgCIAHgEIADAFQgDADgFACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgCAAgDACg");
	this.shape_37.setTransform(48,-54.575);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_38.setTransform(42.625,-55.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_39.setTransform(34.925,-55.375);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AALAXIAAgcQAAgGgCgDQgDgCgEAAIgEABIgDABIgDADIgDACIAAAgIgGAAIAAgsIAGAAIAAAHIADgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_40.setTransform(29.9,-54.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgIAWQgCAAgCgCQgDgCgBgDQgBgDgBgDQABgEABgDQABgCADgBIAEgDIAGgBQAEAAAEABQADACADACIAAgHQAAgFgEgCQgDgCgFAAQgGAAgGAGIgEgFQAHgHAKAAIAHAAIAGADQACACABADIABAHIAAAdIgGAAIAAgFQgGAGgIAAIgGgBgAgIACQgCACAAAFQAAAEACADQAEACAEAAIAHgBQADgBACgDIAAgJIgFgEIgHAAQgEAAgEACg");
	this.shape_41.setTransform(24.8,-54.575);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgJAeQgEgBgEgEIADgFQADADADACQAEABAEAAIAFgBIAEgCIAEgEIABgGIAAgHIgGAGQgEACgEAAIgIgBQgEgCgCgDQgDgDgBgEQgCgDAAgGQAAgFACgEQABgFADgDQACgDAEgBQADgCAFAAQADAAAEACQAEACADAEIAAgHIAHAAIAAAqQAAAGgCAEQgCADgDADIgHADIgHABQgFAAgEgCgAgEgXQgDABgCACIgDAFIgBAHIABAHIADAEQACADADABQACABADAAIAEAAIADgCIAEgCIACgDIAAgTIgCgCIgEgDIgDgBIgEgBQgDAAgCACg");
	this.shape_42.setTransform(88.025,-62.925);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AALAXIAAgcQAAgGgCgDQgDgCgFAAIgCABIgEABIgEADIgBACIAAAgIgIAAIAAgsIAIAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_43.setTransform(82.95,-63.825);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_44.setTransform(79.375,-64.55);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_45.setTransform(75.875,-62.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_46.setTransform(70.625,-62.975);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_47.setTransform(66.775,-64.55);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("AAMAfIAAgeIgBgDIgCgEIgDgBIgFgBIgDABIgDABIgDADIgDACIAAAgIgHAAIAAg9IAHAAIAAAYIADgDIAEgDIAEgBIAFgBQAGAAAEAEQAEADgBAHIAAAfg");
	this.shape_48.setTransform(63.25,-64.625);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_49.setTransform(58.475,-63.775);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#333333").s().p("AgHAWQgEgCgDgDQgDgDgCgEQgBgFgBgFIACgIQACgEADgEIAHgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQABAFAAAEIAAABIgiAAIABAGQABADADACIAEADQADACADAAQAEAAADgCIAGgEIAEAFQgEADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgDAFIAAAFIAcAAIgBgFIgCgFIgGgDQgCgCgEAAQgCAAgDACg");
	this.shape_50.setTransform(51.4,-63.775);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AgCAfIAAg9IAFAAIAAA9g");
	this.shape_51.setTransform(47.75,-64.625);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#333333").s().p("AgGAdQgEgCgDgDIAAAGIgHAAIAAg8IAHAAIAAAXQADgDAEgCQAEgCADAAIAIABQAEACACADIAEAHQACAEAAAFQAAAFgCAFQgBAEgDADQgCADgEACIgIABQgEAAgDgCgAgHgGQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgDIABgHIgBgHQgBgCgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_52.setTransform(44.175,-64.575);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_53.setTransform(40.375,-64.55);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("AANAWIgNgSIgNASIgIAAIARgWIgQgVIAIAAIAMARIAMgRIAIAAIgQAVIARAWg");
	this.shape_54.setTransform(37.1,-63.775);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgDgDgBgEQgCgFAAgFIACgIQABgEADgEIAIgFQAEgBAEAAQAFAAAEABQADACADAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAEAAAEgCIAHgEIADAFQgDADgFACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgCAAgDACg");
	this.shape_55.setTransform(32.25,-63.775);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_56.setTransform(28.6,-64.625);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#333333").s().p("AgTAfIAAg9IAnAAIAAAHIgfAAIAAAUIAfAAIAAAGIgfAAIAAAcg");
	this.shape_57.setTransform(25.225,-64.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_58.setTransform(71.225,-110.225);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#333333").s().p("AALAfIAAgeIAAgDIgCgEIgDgBIgFgBIgCABIgEABIgDADIgCACIAAAgIgIAAIAAg9IAIAAIAAAYIACgDIAEgDIAEgBIAFgBQAGAAAEAEQADADAAAHIAAAfg");
	this.shape_59.setTransform(66.65,-111.075);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_60.setTransform(62.775,-110.775);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#333333").s().p("AALAXIAAgcQABgGgDgDQgDgCgFAAIgCABIgEABIgDADIgCACIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_61.setTransform(58.9,-110.275);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#333333").s().p("AgIAWQgFgCgCgEIgFgHQgBgEAAgFIABgIIAFgIIAHgFQAEgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQACACACACQADABADAAQADAAADgBIAFgEIACgGIABgGIgBgGIgCgFIgFgEQgDgBgDAAQgDAAgDABg");
	this.shape_62.setTransform(53.75,-110.225);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#333333").s().p("AAXAXIAAgeQAAgEgCgCQgBgDgFAAQgDAAgEACIgFAFIAAAgIgGAAIAAgeQAAgEgBgCQgCgDgFAAQgDAAgDACQgEACgBADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIADgCIAEgCIAFgBQAFAAADACQACADABADIACgDIAEgCIAEgCIAFgBQAGAAADADQADAEAAAHIAAAfg");
	this.shape_63.setTransform(47.325,-110.275);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#333333").s().p("AgJAdQgEgCgDgFQgDgEgBgGIgCgMQAAgFACgGQABgGADgEIAIgHQAFgDAFAAQAGAAAFACQAEACACAEIgDAFIgGgEQgDgCgFAAQgDAAgDACQgEACgCAEIgDAHIgBAJIAAAAIAAACIADgDIAEgDIAFgCIAFgBIAHABQAEACADACQADACABADQACAEAAAFQAAAEgCADQgBAEgDADQgDADgEABQgEACgFAAQgFAAgFgDgAgHABQgEADgDAEIACAGIACAFIAFAEQADACADAAQADAAADgBIAEgDIADgEIABgFIgBgGIgDgEIgFgCIgFAAQgEAAgEABg");
	this.shape_64.setTransform(38.575,-111.075);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#333333").s().p("AgKAXIAAgsIAHAAIAAAHQADgDADgCQADgDAFAAIAAAHIgDAAIgDABIgEABIgCADIgCACIAAAfg");
	this.shape_65.setTransform(32.175,-110.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#333333").s().p("AgJAWQgDgCgDgEIgFgHQgBgEAAgFIABgIIAFgIIAGgFQAFgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQABACAEACQADABACAAQADAAADgBIAFgEIADgGIAAgGIAAgGIgDgFIgFgEQgDgBgDAAQgCAAgDABg");
	this.shape_66.setTransform(27.8,-110.225);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#333333").s().p("AgGAfIAAglIgIAAIAAgGIAIAAIAAgEQAAgHADgDQADgEAFAAIAFABQADAAACACIgDAFIgCgCIgDAAQgEAAgCACQgBACAAAEIAAAEIAJAAIAAAGIgJAAIAAAlg");
	this.shape_67.setTransform(24.125,-111.125);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_68.setTransform(69.325,-120.225);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#333333").s().p("AgDAfIAAg9IAHAAIAAA9g");
	this.shape_69.setTransform(65.8,-120.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#333333").s().p("AgHAWQgEgCgEgDQgDgDgBgEQgBgFAAgFIABgIQABgEADgEIAHgFQAEgBAEAAQAFAAAEABQAEACADAEQADADABAEQABAFAAAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAFAAADgCIAHgEIACAFQgDADgEACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgDAFIgCAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_70.setTransform(62.15,-119.425);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#333333").s().p("AALAfIAAgeIAAgDIgCgEIgEgBIgEgBIgCABIgEABIgDADIgCACIAAAgIgHAAIAAg9IAHAAIAAAYIACgDIAEgDIAEgBIAEgBQAIAAADAEQADADABAHIAAAfg");
	this.shape_71.setTransform(57,-120.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQABABAAAAQAAABAAAAQABABAAAAIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_72.setTransform(49.825,-119.425);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFABgFIABgIQACgEACgEIAHgFQAFgBADAAQAGAAADABQAFACACAEQADADABAEQACAFAAAEIAAABIgjAAIABAGQABADACACIAFADQADACACAAQAEAAAEgCIAHgEIACAFQgDADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_73.setTransform(45.15,-119.425);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_74.setTransform(41.275,-119.975);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#333333").s().p("AgIAWQgEgCgEgEIgDgHQgCgEAAgFIACgIIADgIIAIgFQAEgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQABACADACQADABADAAQAEAAACgBIAFgEIACgGIACgGIgCgGIgCgFIgFgEQgCgBgEAAQgDAAgDABg");
	this.shape_75.setTransform(37.3,-119.425);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#333333").s().p("AgOATQgDgDgBgHIAAgfIAIAAIAAAdIAAAEIACAEIAEABIAEABQACAAAEgCQAEgCABgDIAAggIAHAAIAAAsIgHAAIAAgHIgGAGQgEACgEAAQgIAAgDgEg");
	this.shape_76.setTransform(32.1,-119.375);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#333333").s().p("AARAaIgIAEIgJABQgGAAgFgDQgGgCgEgEQgEgEgCgGQgCgGgBgGQABgHACgGQACgFAEgFQAEgEAFgCQAGgDAGAAQAHAAAGADQAGACAEAEQADAFADAFQACAGAAAHQAAAGgCAGQgDAGgDAEIAFAGIgFAFgAgIgXQgEACgDADIgFAIQgCAFABAFQgBAEACAFIAFAIQADADAEACQAEACAEAAQAGAAAGgDIgJgKIAFgEIAJAJQADgDACgEQABgFAAgEQAAgFgCgFQgCgFgDgDQgCgDgFgCQgEgCgFAAQgEAAgEACg");
	this.shape_77.setTransform(26,-120.175);

	this.instance = new lib._5Multiple();
	this.instance.parent = this;
	this.instance.setTransform(4.55,-86.5,0.4749,0.4749,0,0,0,0.1,-0.4);

	this.instance_1 = new lib._1flexibleShipping();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.35,-60.1,0.4749,0.4749,0,0,0,0.2,-0.4);

	this.instance_2 = new lib._4Quotes();
	this.instance_2.parent = this;
	this.instance_2.setTransform(5,-114.45,0.4749,0.4749,0,0,0,0.1,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_2
	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("Ao3HYIAAuwIRvAAIAAOwg");
	this.shape_78.setTransform(42.125,-87.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_78).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-14.7,-135.1,113.7,94.5), null);


// stage content:
(lib._728x90_Government = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_751 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(751).call(this.frame_751).wait(353));

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape.setTransform(364.225,45.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_1.setTransform(364.225,45.9);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_2.setTransform(364.225,45.9);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_3.setTransform(364.225,45.9);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_4.setTransform(364.225,45.9);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_5.setTransform(364.225,45.9);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_6.setTransform(364.225,45.9);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_7.setTransform(364.225,45.9);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_8.setTransform(364.225,45.9);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_9.setTransform(364.225,45.9);
	this.shape_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(224));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(226));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(227));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(228));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(229));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(230));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(231));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(232));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(233));

	// t11
	this.instance = new lib.t11();
	this.instance.parent = this;
	this.instance.setTransform(154.5,118.35,1,1,0,0,0,105.6,41);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},105).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).to({_off:true},114).wait(224));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);

	this.instance_2 = new lib.t22();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[]},114).wait(224));

	// Лого
	this.instance_3 = new lib.biglogo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(551.55,15.95,0.5748,0.5748,0,0,0,43.9,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(660).to({_off:true},220).wait(224));

	// Слой_5
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.3,-51.8,-51.6,-21.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_10.setTransform(551.525,73.35);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-98,-49.2,-45.3,-18.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_11.setTransform(551.525,73.35);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91.8,-46.6,-39.1,-16.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_12.setTransform(551.525,73.35);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.5,-43.9,-32.8,-13.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_13.setTransform(551.525,73.35);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-79.2,-41.3,-26.5,-10.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_14.setTransform(551.525,73.35);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-73,-38.6,-20.3,-8.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_15.setTransform(551.525,73.35);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-66.7,-36,-14,-5.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_16.setTransform(551.525,73.35);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-60.5,-33.4,-7.8,-2.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_17.setTransform(551.525,73.35);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-54.2,-30.7,-1.5,-0.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_18.setTransform(551.525,73.35);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-48,-28.1,4.7,2.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_19.setTransform(551.525,73.35);
	this.shape_19._off = true;

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-41.7,-25.5,11,5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_20.setTransform(551.525,73.35);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-35.5,-22.8,17.2,7.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_21.setTransform(551.525,73.35);
	this.shape_21._off = true;

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-29.2,-20.2,23.5,10.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_22.setTransform(551.525,73.35);
	this.shape_22._off = true;

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-23,-17.6,29.7,12.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_23.setTransform(551.525,73.35);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,-14.9,36,15.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_24.setTransform(551.525,73.35);
	this.shape_24._off = true;

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-10.5,-12.3,42.2,18.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_25.setTransform(551.525,73.35);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-4.2,-9.7,48.5,20.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_26.setTransform(551.525,73.35);
	this.shape_26._off = true;

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],2,-7,54.7,23.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_27.setTransform(551.525,73.35);
	this.shape_27._off = true;

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,-4.4,61,26.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_28.setTransform(551.525,73.35);
	this.shape_28._off = true;

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],14.5,-1.8,67.2,28.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_29.setTransform(551.525,73.35);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],20.8,0.9,73.5,31.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_30.setTransform(551.525,73.35);
	this.shape_30._off = true;

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],27.1,3.5,79.8,34).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_31.setTransform(551.525,73.35);
	this.shape_31._off = true;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],33.3,6.2,86,36.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_32.setTransform(551.525,73.35);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.6,8.8,92.3,39.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_33.setTransform(551.525,73.35);
	this.shape_33._off = true;

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.8,11.4,98.5,41.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_34.setTransform(551.525,73.35);
	this.shape_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(38).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(293));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(39).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(292));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(40).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(291));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(41).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(290));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(42).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(289));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(43).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(288));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(44).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(287));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(45).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(286));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(46).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(285));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(47).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(284));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(48).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(283));
	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(49).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(282));
	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(50).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(281));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(51).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(280));
	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(52).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(279));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(53).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(278));
	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(54).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(277));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(55).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(276));
	this.timeline.addTween(cjs.Tween.get(this.shape_28).wait(56).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(275));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(57).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(274));
	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(58).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(273));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(59).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(272));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(60).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(271));
	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(61).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(270));
	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(62).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(269));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(570.65,65.75,0.801,0.801,0,0,0,-8.5,35.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(765).to({_off:true},115).wait(224));

	// Слой_2
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("A7zHIIAAuPMA3nAAAIAAOPg");
	this.shape_35.setTransform(550.45,45.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(765).to({_off:true},115).wait(224));

	// Слой_4
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABADADIgEAJIgGgEQgEgBgEAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABIAGABIAIADQADABADACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_36.setTransform(342.35,82.575);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQAAgGAEgFQADgGAFgDQAGgDAFAAQAIAAAEADQAGADACAGQADAGABAGIAAADIghAAQAAAEADADQADADAFAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgDAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_37.setTransform(337.45,82.575);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_38.setTransform(333.575,81.625);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgGIAAgXIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_39.setTransform(330.775,82);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_40.setTransform(327.925,81.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_41.setTransform(325.45,81.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_42.setTransform(323.075,81.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgDgGgBgHQABgGADgFQADgGAFgDQAGgDAGAAQAFAAAEABIAFADIAFAEIgIAIIgEgEIgGgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAADgCIAEgDIAIAHIgFAEIgFADIgJABQgGAAgGgDg");
	this.shape_43.setTransform(319.5,82.575);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEgBgFQABgFACgEQADgCADgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAFgCAEAAQAGAAAEACQAFABADAEQACAEAAAGIAAAdIgLAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgDACg");
	this.shape_44.setTransform(314.3,82.575);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgVAgIAAg/IAsAAIAAAMIgfAAIAAAOIAeAAIAAALIgeAAIAAAag");
	this.shape_45.setTransform(309.3,81.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_46.setTransform(351.45,72.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAGAAAEACQAFABACAEQADAEABAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_47.setTransform(347.55,72.975);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_48.setTransform(342.325,72.925);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFAAgHQAAgGADgFQADgFAFgEQAGgDAGAAQAHAAAGADQAFAEAEAFQACAFAAAGQAAAHgCAFQgEAGgFADQgGADgHAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAEgFQACgDAAgEQAAgDgCgDQgBgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_49.setTransform(336.85,72.975);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_50.setTransform(332.875,72.025);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_51.setTransform(330.075,72.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAFAAAFACQAFABACAEQAEAEAAAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgCACg");
	this.shape_52.setTransform(325.7,72.975);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQADgGAGgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAFAAIAEAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_53.setTransform(320.6,72.975);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIAMAAIAAAGQACgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_54.setTransform(316.45,72.925);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgDgGgBgHQABgGADgFQADgGAFgDQAGgDAGAAQAFAAAEABIAFADIAFAEIgIAIIgFgEIgFgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAACgCIAFgDIAIAHIgFAEIgFADIgJABQgGAAgGgDg");
	this.shape_55.setTransform(312.2,72.975);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQADgGAGgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAFAAIAEAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_56.setTransform(307.1,72.975);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAKAgIgLgWIgKAAIAAAWIgOAAIAAg/IAdAAQAHAAAEADQAFACADAFQACAFAAAFQAAAHgCADIgFAFQgDADgEAAIAPAZgAgLgCIANAAQAEAAADgCQACgCAAgFQAAgDgCgCQgDgDgEAAIgNAAg");
	this.shape_57.setTransform(301.525,72.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDACgEQADgDADgCQAFgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgEgBgEAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABIAGABIAHADQAFABACACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_58.setTransform(151,82.575);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgIAVQgGgDgDgFQgEgGAAgHQAAgGAEgFQADgGAGgDQAFgDAGAAQAFAAADABIAHADIADAEIgIAIIgDgEIgHgBQgEAAgEADQgDAEAAAFQAAAGADAEQAEADAEABQAEAAADgCIADgDIAIAHIgDAEIgHADIgIABQgGAAgFgDg");
	this.shape_59.setTransform(146.45,82.575);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_60.setTransform(142.775,81.625);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_61.setTransform(138.775,82.525);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_62.setTransform(134.825,81.625);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_63.setTransform(132.35,81.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgIQgEgHAAgKQAAgJAEgHQAFgIAHgEQAIgEAJAAQAHAAAFADQAFACADADIAGAIIgMAFQgCgDgEgDQgDgDgFAAQgFAAgFADQgEADgDAEQgCAFgBAFQABAGACAFQADAEAEADQAFADAFAAQAFAAADgDQAEgCACgEIAMAFIgGAIQgDAEgFACQgFACgHAAQgJAAgIgEg");
	this.shape_64.setTransform(127.975,81.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AAKAgIAAgcQAAgEgDgCQgCgCgEAAQgDABgCABIgEADIAAAfIgNAAIAAg/IANAAIAAAYIADgEIAFgCQADgCAEABQAHAAAEADQAEAFAAAGIAAAgg");
	this.shape_65.setTransform(176.325,72.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_66.setTransform(171.975,72.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_67.setTransform(169.1,72.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_68.setTransform(165.15,72.975);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_69.setTransform(160.05,72.975);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAPAgIAAgbIgdAAIAAAbIgOAAIAAg/IAOAAIAAAaIAdAAIAAgaIAOAAIAAA/g");
	this.shape_70.setTransform(153.9,72.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_71.setTransform(144.925,72.125);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgKAWQgGgBgDgEIAFgJIAEAEIAGACIAFABQAEAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDACgEQACgDAEgCQAFgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgEgBgEAAIgEABQgBAAAAAAQAAABAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABABAAIAFABIAIADQAFABACACQADADAAAGQAAAEgCADQgDAEgEABQgEACgHAAQgFAAgFgCg");
	this.shape_72.setTransform(136.95,72.975);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_73.setTransform(133.5,72.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAFgBQAEgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_74.setTransform(129.55,72.975);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_75.setTransform(125.525,72.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_76.setTransform(122.675,72.025);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgXAgIAAg+IANAAIAAAGIAGgGQAEgBADAAQAGAAAFACQAEADACAFQAEAGAAAIQAAAHgEAFQgCAFgEADQgFADgGAAIgHgCIgGgFIAAAXgAgGgTIgEAEIAAAPIAEAEIAGABQAFAAADgDQADgDAAgGQAAgGgDgEQgDgDgFgBIgGACg");
	this.shape_77.setTransform(118.85,73.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQAEAAABgCQABAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQABgDAFgCQAEgCAFAAQAGAAAFACQAEABAEADIgFAJIgGgEQgDgBgFAAIgEABQAAAAgBAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAGABIAJADQADABAEACQACADABAGQgBAEgCADQgCAEgFABQgEACgHAAQgFAAgGgCg");
	this.shape_78.setTransform(113.6,72.975);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgEgGQgDgFAAgHQAAgGADgFQAEgFAFgEQAGgDAGAAQAHAAAGADQAFAEADAFQADAFAAAGQAAAHgDAFQgDAGgFADQgGADgHAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgDACg");
	this.shape_79.setTransform(108.65,72.975);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAPAgIAAgbIgdAAIAAAbIgOAAIAAg/IAOAAIAAAaIAdAAIAAgaIANAAIAAA/g");
	this.shape_80.setTransform(102.4,72.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_81.setTransform(257.825,82.525);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAFgDAHAAQAHAAAGADQAGAEADAFQACAFAAAGQAAAHgCAFQgDAGgGADQgGADgHAAQgHAAgFgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_82.setTransform(252.35,82.575);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_83.setTransform(248.375,81.625);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgGIAAgXIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_84.setTransform(245.575,82);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_85.setTransform(241.2,82.575);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgEgGABgHQgBgGAEgFQADgGAFgDQAGgDAGAAQAFAAADABIAGADIAFAEIgIAIIgFgEIgFgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAACgCIAFgDIAIAHIgFAEIgGADIgIABQgGAAgGgDg");
	this.shape_86.setTransform(236.4,82.575);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgRATQgEgDAAgHIAAggIAMAAIAAAbQAAAFADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAtIgNAAIAAgFQgCACgEACQgDACgGAAQgHAAgEgEg");
	this.shape_87.setTransform(231.225,82.65);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgMAeQgFgDgCgGQgDgFgBgHQABgIADgFQACgFAFgDQAEgDAGAAQADAAAEACQADACADADIAAgYIANAAIAAA/IgNAAIAAgFIgGAFQgDABgEAAQgGAAgEgCgAgHAAQgDACAAAHQAAAFADAEQADAEAFAAIAGgCIAEgDIAAgRIgEgDIgGgBQgFAAgDAEg");
	this.shape_88.setTransform(225.5,81.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgVAgIAAg/IAsAAIAAAMIgfAAIAAAOIAeAAIAAALIgeAAIAAAOIAfAAIAAAMg");
	this.shape_89.setTransform(220.2,81.7);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQAAgBgBAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABg");
	this.shape_90.setTransform(211.825,81.725);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABAEADIgFAJIgGgEQgDgBgFAAIgEABQgBAAAAAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAHABIAIADQADABADACQADADABAGQgBAEgCADQgCAEgFABQgFACgGAAQgFAAgGgCg");
	this.shape_91.setTransform(249.3,72.975);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_92.setTransform(245.85,72.1);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFAAgHQAAgGADgFQADgFAFgEQAGgDAGAAQAHAAAGADQAFAEAEAFQACAFAAAGQAAAHgCAFQgEAGgFADQgGADgHAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgCACg");
	this.shape_93.setTransform(241.9,72.975);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFgBgHQABgGADgFQADgFAFgEQAGgDAGAAQAHAAAGADQAGAEADAFQADAFAAAGQAAAHgDAFQgDAGgGADQgGADgHAAQgGAAgGgDgAgGgKQgCABgCADQgBADAAADQAAAEABADIAEAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_94.setTransform(236.4,72.975);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AAKAgIAAgcQAAgEgDgCQgCgCgEAAQgDABgCABIgEADIAAAfIgNAAIAAg/IANAAIAAAYIADgEIAFgCQADgCAEABQAHAAAEADQAEAFAAAGIAAAgg");
	this.shape_95.setTransform(230.925,72.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgDgGgBgHQABgGADgFQADgGAFgDQAGgDAGAAQAFAAAEABIAFADIAFAEIgIAIIgFgEIgFgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAACgCIAFgDIAIAHIgFAEIgFADIgJABQgGAAgGgDg");
	this.shape_96.setTransform(225.8,72.975);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_97.setTransform(220.425,72.125);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABAEADIgFAJIgGgEQgEgBgEAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAAAABIAHABIAIADQADABADACQADADABAGQgBAEgCADQgCAEgFABQgFACgGAAQgFAAgGgCg");
	this.shape_98.setTransform(72.9,82.575);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQABgGADgFQADgGAFgDQAGgDAFAAQAIAAAEADQAGADACAGQAEAGAAAGIAAADIghAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgFABgFAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQAAgCgDgCQgDgBgEAAQgCAAgDABIgEAEIgBAFIAWAAIAAAAg");
	this.shape_99.setTransform(68,82.575);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgDgGgBgHQABgGADgFQADgGAFgDQAGgDAGAAQAFAAAEABIAFADIAFAEIgJAIIgDgEIgGgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAADgCIADgDIAJAHIgFAEIgFADIgJABQgGAAgGgDg");
	this.shape_100.setTransform(63,82.575);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQAEAEAAAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgCACg");
	this.shape_101.setTransform(57.85,82.575);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgWAhIAAg/IAMAAIAAAFIAGgEQAEgCADAAQAGAAAFADQAEACACAGQAEAFAAAIQAAAHgEAFQgCAGgEACQgFADgGAAIgHgBIgGgGIAAAYgAgGgTIgEADIAAAQIAEAEIAGACQAFgBACgEQAEgCAAgGQAAgGgEgEQgCgEgFABIgGABg");
	this.shape_102.setTransform(52.8,83.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAABQABAAAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_103.setTransform(46.925,81.725);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgEgGABgHQgBgGAEgFQADgGAFgDQAGgDAGAAQAFAAADABIAGADIAFAEIgIAIIgFgEIgFgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAACgCIAFgDIAIAHIgFAEIgGADIgIABQgGAAgGgDg");
	this.shape_104.setTransform(39.3,82.575);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_105.setTransform(35.625,81.625);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_106.setTransform(33.2,81.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgEAfIgGgFIAAAFIgNAAIAAg/IANAAIAAAYQADgDADgCQAEgCADAAQAGAAAFADQAEADACAFQAEAFAAAIQAAAHgEAFQgCAGgEADQgFACgGAAQgDAAgEgBgAgGgDIgEAEIAAAQIAEADIAGACQAFAAADgEQADgEAAgFQAAgHgDgCQgDgEgFAAIgGABg");
	this.shape_107.setTransform(29.3,81.75);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgRATQgEgDAAgHIAAggIAMAAIAAAbQAAAFADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAtIgNAAIAAgFQgCACgEACQgDACgGAAQgHAAgEgEg");
	this.shape_108.setTransform(23.625,82.65);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgYAgIAAg/IAcAAQAHAAAFADQAEADADAFQACAEAAAGQAAAFgCAFQgDAEgEACQgFADgHAAIgPAAIAAAXgAgLgCIANAAQAFAAACgCQACgCABgEQgBgFgCgCQgCgCgFAAIgNAAg");
	this.shape_109.setTransform(18.1,81.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_110.setTransform(61.725,72.125);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQAEAAABgCQABAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQABgDAFgCQAEgCAFAAQAGAAAFACQAEABAEADIgFAJIgGgEQgDgBgFAAIgEABQAAAAgBAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAHABIAIADQADABAEACQACADAAAGQAAAEgCADQgCAEgFABQgEACgHAAQgFAAgGgCg");
	this.shape_111.setTransform(53.75,72.975);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFABgIQAAgGACgFQADgGAGgDQAGgDAFAAQAHAAAGADQAFADADAGQADAGAAAGIAAADIgiAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgCAAgCABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_112.setTransform(48.85,72.975);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgIAVQgGgDgDgFQgEgGAAgHQAAgGAEgFQADgGAGgDQAFgDAGAAQAFAAADABIAHADIADAEIgIAIIgDgEIgHgBQgEAAgEADQgDAEAAAFQAAAGADAEQAEADAEABQAEAAADgCIADgDIAIAHIgDAEIgHADIgIABQgGAAgFgDg");
	this.shape_113.setTransform(43.85,72.975);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_114.setTransform(40.225,72.025);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgJAgIAAgiIgIAAIAAgLIAIAAIAAgCQAAgIAEgEQAEgEAHAAIAGABIAGADIgFAHIgCgBIgDgBQgBAAAAAAQgBABgBAAQAAAAAAAAQgBABAAAAQgCACAAADIAAACIAKAAIAAALIgKAAIAAAig");
	this.shape_115.setTransform(37.725,72.075);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgJAgIAAgiIgIAAIAAgLIAIAAIAAgCQAAgIAEgEQAEgEAHAAIAGABIAGADIgFAHIgCgBIgDgBQgBAAAAAAQgBABgBAAQAAAAAAAAQgBABAAAAQgCACAAADIAAACIAKAAIAAALIgKAAIAAAig");
	this.shape_116.setTransform(34.575,72.075);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgQAdQgIgEgEgIQgEgHAAgKQAAgJAEgHQAEgHAIgFQAHgEAJAAQAKAAAHAEQAIAFAEAHQAEAHAAAJQAAAKgEAHQgEAIgIAEQgHAEgKAAQgJAAgHgEgAgJgRQgFACgCAFQgCAFgBAFQABAGACAFQACAEAFAEQAEACAFAAQAGAAAEgCQAEgEADgEQACgFAAgGQAAgFgCgFQgDgFgEgCQgEgCgGgBQgFABgEACg");
	this.shape_117.setTransform(29.075,72.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).to({state:[{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).to({state:[{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).to({state:[{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).wait(224));

	// pc11
	this.instance_5 = new lib.pc11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.45,-10.1,0.9813,0.9813);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105).to({_off:false},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(105).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(105).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(105).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(224));

	// Слой_3
	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_118.setTransform(364,45);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("rgba(255,255,255,0.898)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_119.setTransform(364,45);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("rgba(255,255,255,0.8)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_120.setTransform(364,45);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("rgba(255,255,255,0.698)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_121.setTransform(364,45);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_122.setTransform(364,45);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("rgba(255,255,255,0.502)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_123.setTransform(364,45);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("rgba(255,255,255,0.4)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_124.setTransform(364,45);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("rgba(255,255,255,0.302)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_125.setTransform(364,45);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_126.setTransform(364,45);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_127.setTransform(364,45);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_128.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_118}]}).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[]},1).to({state:[{t:this.shape_118}]},209).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[]},1).to({state:[{t:this.shape_118}]},209).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[]},1).to({state:[{t:this.shape_118}]},209).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[]},1).to({state:[]},209).wait(224));

	// Слой_6
	this.instance_6 = new lib.icons();
	this.instance_6.parent = this;
	this.instance_6.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).to({alpha:1},6).to({_off:true},95).wait(119).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(119).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(119).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(339));

	// screen21.jpg - копия
	this.instance_7 = new lib.pc21("synched",15);
	this.instance_7.parent = this;
	this.instance_7.setTransform(306.45,85.45,0.71,0.71,0,0,0,296,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({y:58.45,startPosition:119},104).to({_off:true},1).wait(115).to({_off:false,y:85.45,startPosition:15},0).to({y:58.45,startPosition:119},104).to({_off:true},1).wait(115).to({_off:false,y:85.45,startPosition:15},0).to({y:58.45,startPosition:119},104).to({_off:true},1).wait(115).to({_off:false,y:85.45,startPosition:15},0).to({y:58.45,startPosition:119},104).to({_off:true},1).wait(339));

	// Слой_1
	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_129.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_129).wait(660).to({_off:true},220).wait(224));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728.5,184.9);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_Government_atlas_P_.png", id:"728x90_Government_atlas_P_"},
		{src:"images/728x90_Government_atlas_NP_.jpg", id:"728x90_Government_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;