(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_Government_atlas_P_", frames: [[0,0,98,28]]},
		{name:"300x250_Government_atlas_NP_", frames: [[0,731,49,43],[58,686,54,44],[0,492,336,192],[0,686,56,43],[0,0,336,296],[0,298,336,192]]}
];


// symbols:



(lib.Растровоеизображение10 = function() {
	this.initialize(ss["300x250_Government_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение11 = function() {
	this.initialize(ss["300x250_Government_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["300x250_Government_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["300x250_Government_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["300x250_Government_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["300x250_Government_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["300x250_Government_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(212.125,73.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAGgHQADADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgFAHQgDADgFABQgFABgHABQgHgBgHgCg");
	this.shape_1.setTransform(207.15,70.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_2.setTransform(199.775,69.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgEAvIAAhdIAJAAIAABdg");
	this.shape_3.setTransform(194.375,69.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_4.setTransform(191.225,69.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgWAdQgFgFAAgLIAAgvIALAAIAAAsIAAAIQABADACABQADACACABIAHABQAFAAAFgEQAGgDADgEIAAgxIAKAAIAABDIgKAAIAAgJQgEAEgGADQgHAEgHAAQgKAAgGgGg");
	this.shape_5.setTransform(185.8,71.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgKAsQgGgDgEgFIAAAKIgLAAIAAhdIALAAIAAAkQAEgFAGgDQAGgDAGAAQAGgBAGADQAFADAEAFQAEAEACAGQADAGAAAJQAAAHgDAHQgCAGgEAGQgEAEgFACQgGACgGABQgHAAgFgEgAgMgKQgFAEgDAEIAAAeQADAEAFADQAGAEAGAAQAEAAAEgCQAEgDADgDQADgEABgEQACgFAAgFQAAgGgCgFQgBgEgDgDQgDgEgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_6.setTransform(178.125,69.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgLAhQgGgCgFgFQgEgFgDgHQgDgGAAgIQAAgGADgHQACgGAFgFQAEgFAGgDQAGgCAGAAQAIAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQAAAGACADQACAFADADQADAEAEABQAFACAFAAQAGAAAFgCQAGgDAEgDIAEAHQgEAFgIACQgGACgJABQgGgBgGgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_7.setTransform(166.3,70.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgFAiIgchDIAMAAIAVA3IAWg3IAMAAIgcBDg");
	this.shape_8.setTransform(158.925,70.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_9.setTransform(153.925,69.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_10.setTransform(150.325,70.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_11.setTransform(146.675,69.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAFgHQAEADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgGABQgIgBgHgCg");
	this.shape_12.setTransform(141.75,70.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgHAAIgEABIgGACIgFADIgEAEIAAAxIgKAAIAAhDIAKAAIAAAKIAFgEIAFgEIAHgDIAHgBQAVAAAAAWIAAAvg");
	this.shape_13.setTransform(134.7,70.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQABAGABADQACAFADADQAEAEAEABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgGAFgHACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_14.setTransform(126.9,70.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAFgHQAEADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgHABQgHgBgHgCg");
	this.shape_15.setTransform(119.6,70.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_16.setTransform(110.775,70.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAGAAQAIAAAGACQAGADAEAFQAEAFADAHQACAGAAAHIAAACIg2AAQAAAGACADQACAFADADQADAEAFABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgFAFgIACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_17.setTransform(104.75,70.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgPAuQgGgCgGgFIAFgIQAFAEAFACQAFADAHAAIAHgBQAEgCADgCQADgCACgEQACgEAAgGIAAgJQgEAFgFADQgGAEgHAAQgGAAgGgDQgFgCgEgEQgEgFgCgHQgDgFAAgIQAAgIADgHQACgGAEgFQAEgEAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgKIALAAIAABBQAAAJgDAFQgDAGgEADQgFAEgGABQgFACgGAAQgIAAgHgDgAgHgkQgEACgDAEQgDACgBAGQgCAEAAAGQAAAGACAEQABAEADADQADAEAEABQAEADAEAAIAGgBIAGgDIAFgDIADgFIAAgcIgDgEIgFgEIgGgCIgGgBQgEAAgEACg");
	this.shape_18.setTransform(96.575,72.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_19.setTransform(88.525,69.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgWAdQgFgFAAgLIAAgvIALAAIAAAsIAAAIQABADACABQACACAEABIAGABQAFAAAFgEQAGgDADgEIAAgxIAKAAIAABDIgKAAIAAgJQgFAEgFADQgHAEgHAAQgKAAgGgGg");
	this.shape_20.setTransform(80.85,71.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgKAsQgGgDgEgFIAAAKIgLAAIAAhdIALAAIAAAkQAEgFAGgDQAGgDAGAAQAGgBAGADQAFADAEAFQAEAEACAGQADAGAAAJQAAAHgDAHQgCAGgEAGQgEAEgFACQgGACgGABQgHAAgFgEgAgMgKQgFAEgDAEIAAAeQADAEAFADQAGAEAGAAQAEAAAEgCQAEgDADgDQADgEABgEQACgFAAgFQAAgGgCgFQgBgEgDgDQgDgEgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_21.setTransform(73.175,69.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_22.setTransform(63.4,70.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgDgHABgHQgBgGADgHQACgGAFgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAFAFACAGQADAHgBAGQABAHgDAHQgCAGgFAGQgEAEgGADQgGACgIABQgHgBgGgCgAgJgXQgEADgCADQgEAEgBAFQgBAEAAAEQAAAGABAEQABAFAEAEQACADAEACQAFACAEABQAFgBAFgCQADgCADgDQAEgEABgFQABgEABgGQgBgEgBgEQgBgFgEgEIgGgGQgFgCgFAAQgEAAgFACg");
	this.shape_23.setTransform(56.7,70.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgKAvIAAg5IgMAAIAAgJIAMAAIAAgGQAAgKAFgGQAFgFAIAAQAEAAAEABQADABAEADIgFAHIgEgCIgEgBQgFAAgDADQgCAEAAAFIAAAGIANAAIAAAJIgNAAIAAA5g");
	this.shape_24.setTransform(51.175,69.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAFgHQAEADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEABgEIAGgFIAIgFQAEgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgBAHIgGAHQgDADgFABQgFABgGABQgIgBgHgCg");
	this.shape_25.setTransform(41.7,70.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_26.setTransform(36.525,70.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgIAhQgGgDgFgEQgEgGgDgGQgCgHAAgHQAAgHACgGQADgHAEgEQAFgFAGgDQAGgCAHAAQAJAAAGADQAFAEAEAEIgHAHQgDgFgEgCQgFgCgFAAQgFAAgEACQgEACgDAEQgDADgCAFQgBAFAAAEQAAAGABAEQACAFADAEQADADAEADQAEACAFAAQALgBAGgIIAHAGQgEAFgFADQgGAEgJAAQgHgBgGgCg");
	this.shape_27.setTransform(31.075,70.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgVAdQgGgFAAgLIAAgvIAKAAIAAAsIABAIQACADACABQABACADABIAGABQAGAAAFgEQAFgDADgEIAAgxIALAAIAABDIgLAAIAAgJQgDAEgHADQgGAEgGAAQgLAAgFgGg");
	this.shape_28.setTransform(23.65,71.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_29.setTransform(15.575,69.75);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgDgHABgHQgBgGADgHQACgGAFgFQAEgFAGgDQAHgCAGAAQAIAAAGACQAGADAEAFQAFAFACAGQACAHAAAGQAAAHgCAHQgCAGgFAGQgEAEgGADQgGACgIABQgGgBgHgCgAgIgXQgFADgCADQgDAEgCAFQgBAEgBAEQABAGABAEQACAFADAEQACADAFACQAEACAEABQAGgBAEgCQADgCADgDQAEgEABgFQACgEgBgGQABgEgCgEQgBgFgEgEIgGgGQgEgCgGAAQgEAAgEACg");
	this.shape_30.setTransform(7.75,70.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_31.setTransform(1.85,70.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_32.setTransform(-4.625,72.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AAkAjIAAgtQAAgHgEgDQgDgEgGAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAgtQABgHgDgDQgDgEgGAAQgGAAgFADQgEADgDAEIAAAxIgLAAIAAhDIALAAIAAAKIACgEIAGgDIAGgDQADgCAEAAQAIAAAFAEQADAEABAFIAFgEIAEgFIAHgCIAHgCQAKAAAEAGQAFAFAAAKIAAAwg");
	this.shape_33.setTransform(-18.15,70.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgVAdQgGgFAAgLIAAgvIAKAAIAAAsIABAIQACADACABQABACADABIAGABQAGAAAFgEQAFgDADgEIAAgxIALAAIAABDIgLAAIAAgJQgDAEgHADQgGAEgGAAQgLAAgFgGg");
	this.shape_34.setTransform(-27.65,71.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_35.setTransform(-33.075,69.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AAkAjIAAgtQAAgHgEgDQgDgEgGAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAgtQABgHgDgDQgDgEgGAAQgGAAgFADQgEADgDAEIAAAxIgLAAIAAhDIALAAIAAAKIACgEIAGgDIAGgDQADgCAEAAQAIAAAFAEQADAEABAFIAFgEIAEgFIAHgCIAHgCQAKAAAEAGQAFAFAAAKIAAAwg");
	this.shape_36.setTransform(-40.3,70.875);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgLAhQgHgCgEgFQgEgFgDgHQgDgGAAgIQAAgGADgHQACgGAEgFQAFgFAGgDQAGgCAGAAQAIAAAGACQAGADAFAFQADAFACAHQADAGAAAHIAAACIg2AAQABAGACADQABAFADADQADAEAEABQAFACAEAAQAHAAAFgCQAGgDAEgDIAEAHQgFAFgGACQgHACgJABQgGgBgGgCgAgJgYQgDACgDAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_37.setTransform(-49.9,70.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_38.setTransform(-55.75,70.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AggAvIAAhdIAkAAQAHAAAGADQAFACAEAEQAEAEABAFQACAFAAAGQAAAFgCAFQgBAFgEADQgEAEgFACQgGADgHAAIgZAAIAAAlgAgVAAIAYAAQAIAAAFgFQAFgFAAgHQAAgIgFgFQgFgFgIAAIgYAAg");
	this.shape_39.setTransform(-62.225,69.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t122, new cjs.Rectangle(-68.7,61.3,284.6,18), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(229.575,73.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgXAvIgEAAIACgKIADABIADAAQADAAADgCQACgBACgEIAEgKIgchEIAMAAIAVA3IAWg3IAMAAIgiBQQgCAIgFADQgFAEgHAAIgEgBg");
	this.shape_1.setTransform(224.525,72.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAGgHQADADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEABgEIAGgFIAIgFQAEgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgBAHIgGAHQgDADgFABQgFABgGABQgIgBgHgCg");
	this.shape_2.setTransform(217.75,70.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgMAjQgEgCgEgDQgDgDgCgEQgDgEAAgGQAAgFADgFQACgDADgDQAEgDAEgBQAEgBAEAAQAHAAAFACQAFADAFAEIAAgMQAAgHgFgEQgFgDgHAAQgLAAgJAJIgFgHQALgLAPAAQAGgBAEACQAFABAEADQADACACAFQACAEABAGIAAAuIgLAAIAAgHQgJAIgNABIgIgBgAgMACQgFAFABAGQgBAHAFAEQAEAEAIAAQAFAAAFgCQAFgCADgEIAAgNQgDgEgFgCQgFgBgFAAQgIAAgEACg");
	this.shape_3.setTransform(210.7,70.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgMAhQgGgCgEgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAEgFQAFgFAGgDQAGgCAHAAQAHAAAGACQAGADAFAFQADAFACAHQADAGAAAHIAAACIg2AAQABAGACADQABAFADADQAEAEADABQAFACAEAAQAGAAAGgCQAFgDAEgDIAFAHQgEAFgHACQgHACgJABQgGgBgHgCgAgIgYQgFACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgCgEgFgCQgEgBgGAAQgEAAgEABg");
	this.shape_4.setTransform(203.25,70.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQABAGABADQACAFADADQAEAEAEABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgGAFgHACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_5.setTransform(191.7,70.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_6.setTransform(183.525,69.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgCgEAAgGQAAgFACgFQACgDAEgDQADgDAEgBQAEgBAEAAQAHAAAFACQAGADAEAEIAAgMQAAgHgFgEQgFgDgHAAQgLAAgJAJIgFgHQALgLAPAAQAFgBAFACQAFABADADQAEACACAFQACAEAAAGIAAAuIgKAAIAAgHQgJAIgNABIgIgBgAgMACQgEAFAAAGQAAAHAEAEQAFAEAHAAQAFAAAFgCQAEgCAEgEIAAgNQgEgEgEgCQgFgBgFAAQgHAAgFACg");
	this.shape_7.setTransform(175.8,70.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAjAjIAAgtQAAgHgCgDQgDgEgHAAQgFAAgFADQgFADgDAEIAAAxIgJAAIAAgtQAAgHgDgDQgDgEgHAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAhDIAKAAIAAAKIAEgEIAFgDIAGgDQAEgCAEAAQAHAAAEAEQAEAEACAFIADgEIAGgFIAGgCIAHgCQAJAAAGAGQAEAFAAAKIAAAwg");
	this.shape_8.setTransform(166.65,70.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgHALIAGgGQABgDABgCIgBAAQgBAAgBgBQAAAAgBAAQAAAAgBgBQAAAAgBgBQgCgBAAgDQAAgDACgDQACgCADAAQADAAADADQACADAAAEQAAAGgDAGQgDAGgEADg");
	this.shape_9.setTransform(155.775,74.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgPAuQgGgCgGgFIAFgIQAFAEAFACQAFADAHAAIAHgBQAEgCADgCQADgCACgEQACgEAAgGIAAgJQgEAFgFADQgGAEgHAAQgGAAgGgDQgFgCgEgEQgEgFgCgHQgDgFAAgIQAAgIADgHQACgGAEgFQAEgEAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgKIALAAIAABBQAAAJgDAFQgDAGgEADQgFAEgGABQgFACgGAAQgIAAgHgDgAgHgkQgEACgDAEQgDACgBAGQgCAEAAAGQAAAGACAEQABAEADADQADAEAEABQAEADAEAAIAGgBIAGgDIAFgDIADgFIAAgcIgDgEIgFgEIgGgCIgGgBQgEAAgEACg");
	this.shape_10.setTransform(149.925,72.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgGAAIgGABIgFACIgFADIgDAEIAAAxIgLAAIAAhDIALAAIAAAKIAEgEIAGgEIAGgDIAGgBQAWAAAAAWIAAAvg");
	this.shape_11.setTransform(142.2,70.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_12.setTransform(136.775,69.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAFgHQAEADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgGABQgIgBgHgCg");
	this.shape_13.setTransform(131.85,70.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgCgEgBgGQABgFACgFQACgDAEgDQADgDAEgBQAEgBAFAAQAFAAAGACQAFADAFAEIAAgMQAAgHgFgEQgFgDgIAAQgKAAgJAJIgFgHQALgLAPAAQAGgBAEACQAFABADADQAEACACAFQACAEAAAGIAAAuIgKAAIAAgHQgJAIgMABIgJgBgAgMACQgEAFgBAGQABAHAEAEQAFAEAHAAQAFAAAEgCQAFgCAEgEIAAgNQgEgEgFgCQgEgBgFAAQgHAAgFACg");
	this.shape_14.setTransform(124.8,70.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AASAvIAAgtQAAgDgCgDQgBgDgCgCIgFgDIgGAAIgFABIgFACIgFADIgEAEIAAAxIgKAAIAAhdIAKAAIAAAkIAFgEIAFgEIAHgDIAHgBQAKAAAGAGQAFAFAAALIAAAvg");
	this.shape_15.setTransform(117.425,69.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgIAhQgGgDgFgEQgEgGgDgGQgCgHAAgHQAAgHACgGQADgHAEgEQAFgFAGgDQAGgCAHAAQAJAAAGADQAFAEAEAEIgHAHQgDgFgEgCQgFgCgFAAQgFAAgEACQgEACgDAEQgDADgCAFQgBAFAAAEQAAAGABAEQACAFADAEQADADAEADQAEACAFAAQALgBAGgIIAHAGQgEAFgFADQgGAEgJAAQgHgBgGgCg");
	this.shape_16.setTransform(110.175,70.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_17.setTransform(104.7,70.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgVAdQgGgFAAgLIAAgvIAKAAIAAAsIABAIQABADADABQACACACABIAHABQAFAAAFgEQAGgDADgEIAAgxIAKAAIAABDIgKAAIAAgJQgFAEgFADQgHAEgHAAQgKAAgFgGg");
	this.shape_18.setTransform(98.15,71.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_19.setTransform(90.525,72.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_20.setTransform(78.425,69.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgHAAIgEABIgGACIgFADIgEAEIAAAxIgKAAIAAhDIAKAAIAAAKIAFgEIAFgEIAHgDIAHgBQAVAAAAAWIAAAvg");
	this.shape_21.setTransform(70.7,70.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgDgEABgGQgBgFADgFQACgDAEgDQADgDAEgBQAEgBAEAAQAHAAAFACQAGADAEAEIAAgMQAAgHgFgEQgFgDgIAAQgKAAgJAJIgFgHQALgLAPAAQAFgBAFACQAFABADADQAEACACAFQADAEgBAGIAAAuIgKAAIAAgHQgJAIgNABIgIgBgAgMACQgEAFAAAGQAAAHAEAEQAFAEAHAAQAFAAAFgCQAEgCAEgEIAAgNQgEgEgEgCQgFgBgFAAQgHAAgFACg");
	this.shape_22.setTransform(62.95,70.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAGgHQADADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgHABQgHgBgHgCg");
	this.shape_23.setTransform(52.45,70.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAvIAAhdIAJAAIAABdg");
	this.shape_24.setTransform(47.725,69.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgDgEABgGQgBgFADgFQACgDAEgDQADgDAEgBQAEgBAEAAQAHAAAFACQAGADAEAEIAAgMQAAgHgFgEQgFgDgIAAQgKAAgJAJIgFgHQALgLAPAAQAFgBAFACQAFABADADQAEACACAFQADAEgBAGIAAAuIgKAAIAAgHQgJAIgNABIgIgBgAgMACQgEAFgBAGQABAHAEAEQAEAEAIAAQAFAAAFgCQAEgCAEgEIAAgNQgEgEgEgCQgFgBgFAAQgIAAgEACg");
	this.shape_25.setTransform(42.25,70.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAFgHQAEADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEABgEIAGgFIAIgFQAEgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgBAHIgGAHQgDADgFABQgFABgGABQgIgBgHgCg");
	this.shape_26.setTransform(35.4,70.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgCgHAAgHQAAgGACgHQACgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAHACQAGADAEAFQAFAFACAGQADAHgBAGQABAHgDAHQgCAGgFAGQgEAEgGADQgHACgHABQgHgBgGgCgAgJgXQgEADgCADQgEAEgBAFQgCAEABAEQgBAGACAEQABAFAEAEQACADAEACQAEACAFABQAFgBAEgCQAFgCACgDQADgEACgFQABgEABgGQgBgEgBgEQgCgFgDgEIgHgGQgEgCgFAAQgFAAgEACg");
	this.shape_27.setTransform(28.25,70.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_28.setTransform(20.475,72.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgDgHABgHQgBgGADgHQACgGAFgFQAEgFAGgDQAHgCAGAAQAIAAAGACQAGADAEAFQAFAFACAGQACAHAAAGQAAAHgCAHQgCAGgFAGQgEAEgGADQgGACgIABQgGgBgHgCgAgIgXQgFADgCADQgDAEgCAFQgBAEgBAEQABAGABAEQACAFADAEQACADAFACQAEACAEABQAGgBAEgCQADgCADgDQAEgEABgFQACgEgBgGQABgEgCgEQgBgFgEgEIgGgGQgEgCgGAAQgEAAgEACg");
	this.shape_29.setTransform(12.25,70.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_30.setTransform(6.35,70.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_31.setTransform(-0.125,72.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_32.setTransform(-10.025,70.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AASAjIAAgrQAAgKgFgDQgDgDgIAAIgFABIgFACIgFADIgDAEIAAAxIgLAAIAAhDIALAAIAAAKIAEgEIAGgEIAGgDIAGgBQAWAAAAAWIAAAvg");
	this.shape_33.setTransform(-16,70.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgLAhQgHgCgEgFQgEgFgDgHQgDgGAAgIQAAgGADgHQACgGAEgFQAFgFAGgDQAGgCAGAAQAIAAAGACQAGADAFAFQADAFACAHQADAGAAAHIAAACIg2AAQABAGACADQABAFADADQADAEAEABQAFACAEAAQAHAAAFgCQAGgDAEgDIAEAHQgFAFgGACQgHACgJABQgGgBgGgCgAgJgYQgDACgDAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_34.setTransform(-23.8,70.95);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAjAjIAAgtQAAgHgDgDQgCgEgHAAQgFAAgFADQgFADgDAEIAAAxIgJAAIAAgtQgBgHgCgDQgDgEgHAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAhDIAKAAIAAAKIAEgEIAFgDIAGgDQAEgCAEAAQAHAAAEAEQAEAEACAFIADgEIAGgFIAGgCIAHgCQAKAAAEAGQAFAFAAAKIAAAwg");
	this.shape_35.setTransform(-33.4,70.875);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgGAAIgFABIgGACIgFADIgEAEIAAAxIgKAAIAAhDIAKAAIAAAKIAFgEIAFgEIAHgDIAGgBQAWAAAAAWIAAAvg");
	this.shape_36.setTransform(-42.95,70.875);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgPAiIAAhCIAKAAIAAALQAEgFAFgEQAGgEAGAAIAAAMIgDgBIgGABIgFACIgEADIgDAFIAAAug");
	this.shape_37.setTransform(-48.7,70.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQABAGABADQACAFADADQAEAEAEABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgGAFgHACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_38.setTransform(-55.35,70.95);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgFAiIgchDIAMAAIAVA3IAWg3IAMAAIgcBDg");
	this.shape_39.setTransform(-62.725,70.975);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgNAhQgGgDgFgEQgEgGgCgGQgDgHAAgHQAAgGADgHQACgGAEgFQAFgFAGgDQAGgCAHAAQAIAAAGACQAGADAFAFQAEAFACAGQACAHABAGQgBAHgCAHQgCAGgEAGQgFAEgGADQgGACgIABQgHgBgGgCgAgJgXQgEADgDADQgDAEgBAFQgBAEAAAEQAAAGABAEQABAFADAEQADADAEACQAEACAFABQAGgBADgCQAEgCAEgDQADgEABgFQACgEAAgGQAAgEgCgEQgBgFgDgEIgIgGQgDgCgGAAQgFAAgEACg");
	this.shape_40.setTransform(-70.15,70.95);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgMAtQgJgDgHgHQgGgGgEgKQgDgIAAgLQAAgKADgJQAEgJAGgGQAHgGAJgEQAIgDAJAAQANAAAJAEQAJAFAGAIIgKAGQgEgGgHgEQgHgDgJAAQgGAAgGADQgIADgEAFQgFAFgDAGQgDAIAAAHQAAAIADAHQADAHAFAFQAEAFAIADQAGADAGAAIAIgBIAIgCIAFgEIAFgDIAAgTIggAAIAAgJIArAAIAAAgQgGAIgKAEQgJAFgMgBQgJABgIgEg");
	this.shape_41.setTransform(-79.2,69.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-86.2,61.3,319.5,18), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape.setTransform(245.625,130.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_1.setTransform(235.325,130.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_2.setTransform(225.2,130.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAiA0IAAhKIgdBKIgJAAIgehKIAABKIgWAAIAAhnIAfAAIAZBAIAZhAIAgAAIAABng");
	this.shape_3.setTransform(213.775,130.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_4.setTransform(201.325,130.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHAAAKQAAAJgDAHQgDAFgFAEQgGAEgFABIAXAogAgUgEIAXAAQAHAAAEgDQAEgEABgHQgBgGgEgEQgEgEgHAAIgXAAg");
	this.shape_5.setTransform(190.8,130.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_6.setTransform(181.1,130.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgNA0IgohnIAZAAIAcBPIAdhPIAZAAIgoBng");
	this.shape_7.setTransform(170.975,130.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_8.setTransform(159.625,130.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVAvQgNgGgHgMQgIgMAAgRQAAgQAIgMQAHgMANgGQAMgHAPAAQAKAAAJADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAFgCQAHgDADgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgMgHg");
	this.shape_9.setTransform(147.85,130.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAYA0IAAgsIgwAAIAAAsIgWAAIAAhnIAWAAIAAApIAwAAIAAgpIAXAAIAABng");
	this.shape_10.setTransform(132.5,130.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_11.setTransform(122.175,130.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_12.setTransform(115.45,130.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIAUBKIAShKIAZAAIgeBng");
	this.shape_13.setTransform(106.1,130.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape_14.setTransform(90.075,130.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AARA0IgegqIgJAKIAAAgIgWAAIAAhnIAWAAIAAAuIAkguIAcAAIgqAxIAtA2g");
	this.shape_15.setTransform(80.975,130.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHAAAKQAAAJgDAHQgDAFgFAEQgGAEgFABIAXAogAgUgEIAXAAQAHAAAEgDQAEgEABgHQgBgGgEgEQgEgEgHAAIgXAAg");
	this.shape_16.setTransform(70.65,130.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_17.setTransform(59.375,130.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_18.setTransform(46.15,130.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgQAdQgHgEgFgIQgEgIAAgJQAAgJAEgHQAFgIAHgDQAIgFAIgBQAJABAIAFQAHADAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAEQgIAEgJABQgIgBgIgEgAgNgYQgHAFgDAGQgEAGAAAHQAAAIAEAGQADAHAHAEQAGADAHAAQAIAAAGgDQAHgEADgHQAEgGAAgIQAAgHgEgGQgDgGgHgFQgGgDgIAAQgHAAgGADgAAJATIgJgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAADADQAEADAAAFQAAAFgCACIgEADIgDABIAKAPgAgGAAIAJAAIAFgBQACgCAAgEQAAgCgCgCQgDgCgCAAIgJAAg");
	this.shape_19.setTransform(31.025,128.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_20.setTransform(22.75,130.925);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgWAvQgMgGgHgMQgIgMAAgRQAAgQAIgMQAHgMAMgGQANgHAPAAQALAAAIADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAGgCQAFgDAEgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgNgHg");
	this.shape_21.setTransform(12.25,130.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_22.setTransform(1.325,130.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AATA0IgThHIgRBHIgYAAIgehnIAZAAIASBKIAVhKIAQAAIAUBKIAShKIAZAAIgeBng");
	this.shape_23.setTransform(-11.25,130.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_24.setTransform(-22.85,130.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_25.setTransform(-33.325,130.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-41.1,121.8,293.40000000000003,19.700000000000003), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,296), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._5Multiple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение11();
	this.instance.parent = this;
	this.instance.setTransform(-28,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._5Multiple, new cjs.Rectangle(-28,-23,54,44), null);


(lib._4Quotes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение10();
	this.instance.parent = this;
	this.instance.setTransform(-25,-22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._4Quotes, new cjs.Rectangle(-25,-22,49,43), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgHAWQgEgCgDgDQgEgDgBgEQgBgFAAgFIABgIQABgEAEgEIAGgFQAFgBADAAQAGAAADABQAEACADAEQADADABAEQABAFABAEIAAABIgjAAIABAGQABADACACIAFADQADACADAAQAEAAADgCIAGgEIADAFQgDADgEACQgFABgFAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgCgFIgGgDQgCgCgEAAQgDAAgCACg");
	this.shape.setTransform(168.2,25.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_1.setTransform(164.6,24.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgGAdQgEgCgDgDIAAAGIgHAAIAAg8IAHAAIAAAXQADgDAEgCQAEgCADAAIAIABQAEACACADIAEAHQACAEAAAFQAAAFgCAFQgBAEgDADQgCADgEACIgIABQgEAAgDgCgAgHgGQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgDIABgHIgBgHQgBgCgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_2.setTransform(160.975,24.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgCgDAAgDQAAgEACgDQABgCACgBIAGgDIAFgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgDgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAGADQACACABADIACAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQADACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgDACg");
	this.shape_3.setTransform(155.7,25.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_4.setTransform(152.35,24.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_5.setTransform(150.275,24.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgCgDAAgDQAAgEACgDQABgCACgBIAGgDIAFgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgDgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAGADQACACABADIACAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQADACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgDACg");
	this.shape_6.setTransform(146.7,25.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgDAWIgSgrIAHAAIAOAjIAPgjIAHAAIgSArg");
	this.shape_7.setTransform(142.125,25.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgBgDAAgDQAAgEABgDQABgCACgBIAGgDIAFgBQADAAAEABQAEACADACIAAgHQAAgFgDgCQgEgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAFADQADACACADIABAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQACACAFAAIAGgBQAEgBACgDIAAgJIgGgEIgGAAQgFAAgCACg");
	this.shape_8.setTransform(137.35,25.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_9.setTransform(130.425,25.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAMAXIAAgcQAAgGgDgDQgDgCgFAAIgCABIgEABIgEADIgBACIAAAgIgIAAIAAgsIAIAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_10.setTransform(125.8,25.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgJAWQgEgCgDgEIgDgHQgCgEAAgFIACgIIADgIIAHgFQAFgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQABACADACQAEABACAAQAEAAACgBIAFgEIADgGIABgGIgBgGIgDgFIgFgEQgCgBgEAAQgCAAgEABg");
	this.shape_11.setTransform(120.65,25.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_12.setTransform(116.975,24.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_13.setTransform(114.625,25.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_14.setTransform(110.775,26.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgIAWQgFgCgCgEIgFgHQgBgEAAgFIABgIIAFgIIAHgFQAEgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQACACADACQADABACAAQADAAADgBIAFgEIACgGIABgGIgBgGIgCgFIgFgEQgDgBgDAAQgCAAgDABg");
	this.shape_15.setTransform(105.4,25.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_16.setTransform(170.825,15.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AALAXIAAgcQABgGgDgDQgDgCgFAAIgCABIgEABIgDADIgCACIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_17.setTransform(166.9,16.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFAAgFIACgIQACgEACgEIAIgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape_18.setTransform(161.75,16.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAXAXIAAgeQAAgEgCgCQgBgDgFAAQgDAAgEACIgFAFIAAAgIgGAAIAAgeQAAgEgBgCQgCgDgFAAQgDAAgDACQgEACgBADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIADgCIAEgCIAFgBQAFAAADACQACADABADIACgDIAEgCIAEgCIAFgBQAGAAADADQADAEAAAHIAAAfg");
	this.shape_19.setTransform(155.375,16.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgPAfIgCAAIABgHIACABIACAAIADgBQACgBABgDIADgGIgSgsIAHAAIAOAjIAPgjIAHAAIgWA0QgBAFgEACQgDACgEAAIgDAAg");
	this.shape_20.setTransform(149.425,17.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgIAWQgCAAgCgCQgDgCgBgDQgBgDgBgDQABgEABgDQABgCADgBIAEgDIAGgBQADAAAFABQADACADACIAAgHQAAgFgEgCQgCgCgGAAQgGAAgGAGIgEgFQAIgHAJAAIAHAAIAGADQACACABADIABAHIAAAdIgGAAIAAgFQgGAGgIAAIgGgBgAgIACQgCACAAAFQAAAEACADQADACAFAAIAHgBQADgBACgDIAAgJIgFgEIgHAAQgFAAgDACg");
	this.shape_21.setTransform(144.6,16.475);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_22.setTransform(139.825,17.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFAAgFIACgIQACgEACgEIAIgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape_23.setTransform(132.05,16.475);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_24.setTransform(128.4,15.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_25.setTransform(124.875,17.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_26.setTransform(121.075,15.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_27.setTransform(118.725,15.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_28.setTransform(116.35,15.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOATQgDgDgBgHIAAgfIAHAAIAAAdIABAEIACAEIAEABIADABQADAAAEgCQADgCADgDIAAggIAGAAIAAAsIgGAAIAAgHIgHAGQgFACgDAAQgIAAgDgEg");
	this.shape_29.setTransform(112.75,16.525);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAXAfIAAgyIgVAyIgDAAIgUgyIAAAyIgIAAIAAg9IALAAIASAuIATguIALAAIAAA9g");
	this.shape_30.setTransform(106.475,15.625);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgPAfIgCAAIABgHIACABIACAAIADgBQACgBABgDIADgGIgSgsIAHAAIAOAjIAPgjIAHAAIgWA0QgBAFgEACQgDACgEAAIgDAAg");
	this.shape_31.setTransform(259.125,26.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgKAXIAAgsIAHAAIAAAHQADgDADgCQADgDAFAAIAAAHIgDAAIgDABIgEABIgCADIgCACIAAAfg");
	this.shape_32.setTransform(255.575,25.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgHAWQgEgCgDgDQgDgDgCgEQgBgFgBgFIACgIQACgEADgEIAHgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQABAFABAEIAAABIgjAAIABAGQABADADACIAEADQADACADAAQAEAAADgCIAGgEIAEAFQgEADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgDAFIAAAFIAcAAIgBgFIgCgFIgGgDQgCgCgEAAQgCAAgDACg");
	this.shape_33.setTransform(251.2,25.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAWIgSgrIAHAAIAOAjIAPgjIAHAAIgSArg");
	this.shape_34.setTransform(246.375,25.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_35.setTransform(243.025,24.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_36.setTransform(241,24.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFABgFIABgIQACgEACgEIAHgFQAFgBADAAQAGAAADABQAFACACAEQADADABAEQACAFAAAEIAAABIgjAAIABAGQABADACACIAFADQADACACAAQAEAAAEgCIAHgEIACAFQgDADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_37.setTransform(237.3,25.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_38.setTransform(231.925,24.875);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_39.setTransform(224.225,24.875);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AALAXIAAgcQAAgGgCgDQgDgCgFAAIgCABIgEABIgDADIgCACIAAAgIgIAAIAAgsIAIAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_40.setTransform(219.2,25.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgIAWQgDAAgBgCQgDgCgBgDQgCgDAAgDQAAgEACgDQABgCADgBIAEgDIAGgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgCgCgGAAQgGAAgGAGIgDgFQAGgHALAAIAGAAIAGADQACACABADIABAHIAAAdIgGAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQAEACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgEACg");
	this.shape_41.setTransform(214.1,25.675);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgJAeQgEgBgEgEIADgFQADADADACQAEABAEAAIAFgBIAEgCIAEgEIABgGIAAgHIgGAGQgEACgEAAIgIgBQgEgCgCgDQgDgDgBgEQgCgDAAgGQAAgFACgEQABgFADgDQACgDAEgBQADgCAFAAQADAAAEACQAEACADAEIAAgHIAHAAIAAAqQAAAGgCAEQgCADgDADIgHADIgHABQgFAAgEgCgAgEgXQgDABgCACIgDAFIgBAHIABAHIADAEQACADADABQACABADAAIAEAAIADgCIAEgCIACgDIAAgTIgCgCIgEgDIgDgBIgEgBQgDAAgCACg");
	this.shape_42.setTransform(277.325,17.325);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AAMAXIAAgcQgBgGgCgDQgDgCgEAAIgEABIgDABIgEADIgCACIAAAgIgHAAIAAgsIAHAAIAAAHIADgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_43.setTransform(272.25,16.425);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_44.setTransform(268.675,15.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_45.setTransform(265.175,17.275);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_46.setTransform(259.925,17.275);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_47.setTransform(256.075,15.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("AAMAfIAAgeIgBgDIgCgEIgEgBIgDgBIgEABIgDABIgDADIgDACIAAAgIgGAAIAAg9IAGAAIAAAYIADgDIAEgDIAEgBIAEgBQAIAAADAEQAEADAAAHIAAAfg");
	this.shape_48.setTransform(252.55,15.625);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_49.setTransform(247.775,16.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgDgDgBgEQgBgFAAgFIABgIQABgEADgEIAHgFQAFgBAEAAQAEAAAEABQAEACADAEQADADABAEQABAFAAAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAEAAAEgCIAHgEIADAFQgDADgFACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_50.setTransform(240.7,16.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AgDAfIAAg9IAHAAIAAA9g");
	this.shape_51.setTransform(237.05,15.625);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#333333").s().p("AgGAdQgEgCgDgDIAAAGIgHAAIAAg8IAHAAIAAAXQADgDAEgCQAEgCADAAIAIABQAEACACADIAEAHQACAEAAAFQAAAFgCAFQgBAEgDADQgCADgEACIgIABQgEAAgDgCgAgHgGQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgDIABgHIgBgHQgBgCgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_52.setTransform(233.475,15.675);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_53.setTransform(229.675,15.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("AAOAWIgOgSIgMASIgIAAIARgWIgQgVIAIAAIALARIAMgRIAIAAIgQAVIARAWg");
	this.shape_54.setTransform(226.4,16.475);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFABgFIABgIQACgEACgEIAHgFQAFgBADAAQAGAAADABQAFACACAEQADADABAEQACAFAAAEIAAABIgjAAIABAGQABADACACIAFADQADACACAAQAEAAAEgCIAHgEIACAFQgDADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_55.setTransform(221.55,16.475);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#333333").s().p("AgDAfIAAg9IAGAAIAAA9g");
	this.shape_56.setTransform(217.9,15.625);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#333333").s().p("AgTAfIAAg9IAnAAIAAAHIgfAAIAAAUIAfAAIAAAGIgfAAIAAAcg");
	this.shape_57.setTransform(214.525,15.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_58.setTransform(64.175,25.675);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#333333").s().p("AALAfIAAgeIAAgDIgCgEIgEgBIgDgBIgEABIgDABIgDADIgDACIAAAgIgGAAIAAg9IAGAAIAAAYIADgDIAEgDIAEgBIAEgBQAIAAADAEQADADABAHIAAAfg");
	this.shape_59.setTransform(59.6,24.825);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_60.setTransform(55.725,25.125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#333333").s().p("AAMAXIAAgcQgBgGgCgDQgDgCgEAAIgEABIgDABIgDADIgDACIAAAgIgGAAIAAgsIAGAAIAAAHIADgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_61.setTransform(51.85,25.625);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#333333").s().p("AgJAWQgDgCgDgEIgFgHQgBgEAAgFIABgIIAFgIIAGgFQAFgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQABACAEACQADABACAAQADAAADgBIAFgEIADgGIAAgGIAAgGIgDgFIgFgEQgDgBgDAAQgCAAgDABg");
	this.shape_62.setTransform(46.7,25.675);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#333333").s().p("AAXAXIAAgeQAAgEgCgCQgBgDgFAAQgDAAgEACIgFAFIAAAgIgGAAIAAgeQAAgEgBgCQgCgDgFAAQgDAAgDACQgEACgBADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIADgCIAEgCIAFgBQAFAAADACQACADABADIACgDIAEgCIAEgCIAFgBQAGAAADADQADAEAAAHIAAAfg");
	this.shape_63.setTransform(40.275,25.625);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#333333").s().p("AgJAdQgEgCgDgFQgDgEgBgGIgCgMQAAgFACgGQABgGADgEIAIgHQAFgDAFAAQAGAAAFACQAEACACAEIgDAFIgGgEQgDgCgFAAQgDAAgDACQgEACgCAEIgDAHIgBAJIAAAAIAAACIADgDIAEgDIAFgCIAFgBIAHABQAEACADACQADACABADQACAEAAAFQAAAEgCADQgBAEgDADQgDADgEABQgEACgFAAQgFAAgFgDgAgHABQgEADgDAEIACAGIACAFIAFAEQADACADAAQADAAADgBIAEgDIADgEIABgFIgBgGIgDgEIgFgCIgFAAQgEAAgEABg");
	this.shape_64.setTransform(31.525,24.825);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#333333").s().p("AgKAXIAAgsIAHAAIAAAHQADgDADgCQADgDAFAAIAAAHIgDAAIgDABIgEABIgCADIgCACIAAAfg");
	this.shape_65.setTransform(25.125,25.625);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#333333").s().p("AgJAWQgEgCgDgEIgDgHQgCgEAAgFIACgIIADgIIAHgFQAFgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQABACADACQAEABACAAQAEAAACgBIAFgEIADgGIABgGIgBgGIgDgFIgFgEQgCgBgEAAQgCAAgEABg");
	this.shape_66.setTransform(20.75,25.675);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#333333").s().p("AgGAfIAAglIgIAAIAAgGIAIAAIAAgEQAAgHADgDQADgEAFAAIAFABQADAAACACIgDAFIgCgCIgDAAQgEAAgCACQgBACAAAEIAAAEIAJAAIAAAGIgJAAIAAAlg");
	this.shape_67.setTransform(17.075,24.775);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_68.setTransform(62.275,15.675);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_69.setTransform(58.75,15.625);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFAAgFIACgIQACgEACgEIAIgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape_70.setTransform(55.1,16.475);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#333333").s().p("AAMAfIAAgeIgBgDIgCgEIgEgBIgDgBIgEABIgDABIgDADIgDACIAAAgIgHAAIAAg9IAHAAIAAAYIADgDIAEgDIAEgBIAEgBQAHAAAEAEQAEADAAAHIAAAfg");
	this.shape_71.setTransform(49.95,15.625);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_72.setTransform(42.775,16.475);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgDgDgBgEQgCgFAAgFIACgIQABgEADgEIAIgFQAEgBAEAAQAFAAAEABQADACADAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAEAAAEgCIAHgEIADAFQgDADgFACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgCAAgDACg");
	this.shape_73.setTransform(38.1,16.475);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_74.setTransform(34.225,15.925);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#333333").s().p("AgIAWQgFgCgCgEIgFgHQgBgEAAgFIABgIIAFgIIAHgFQAEgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQACACADACQADABACAAQAEAAACgBIAFgEIACgGIABgGIgBgGIgCgFIgFgEQgCgBgEAAQgCAAgDABg");
	this.shape_75.setTransform(30.25,16.475);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#333333").s().p("AgOATQgEgDABgHIAAgfIAHAAIAAAdIAAAEIACAEIADABIAFABQADAAADgCQADgCACgDIAAggIAIAAIAAAsIgIAAIAAgHIgGAGQgEACgFAAQgGAAgEgEg");
	this.shape_76.setTransform(25.05,16.525);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#333333").s().p("AARAaIgIAEIgJABQgFAAgGgDQgGgCgEgEQgEgEgCgGQgCgGAAgGQAAgHACgGQACgFAEgFQAEgEAGgCQAFgDAGAAQAHAAAFADQAGACAFAEQADAFACAFQACAGAAAHQAAAGgCAGQgCAGgDAEIAFAGIgFAFgAgIgXQgFACgDADIgEAIQgBAFAAAFQAAAEABAFIAEAIQADADAFACQAEACAEAAQAGAAAGgDIgJgKIAFgEIAJAJQADgDABgEQACgFAAgEQAAgFgCgFQgBgFgDgDQgEgDgEgCQgDgCgGAAQgEAAgEACg");
	this.shape_77.setTransform(18.95,15.725);

	this.instance = new lib._5Multiple();
	this.instance.parent = this;
	this.instance.setTransform(88.6,20.95,0.4749,0.4749,0,0,0,0.1,-0.4);

	this.instance_1 = new lib._1flexibleShipping();
	this.instance_1.parent = this;
	this.instance_1.setTransform(195.4,20.2,0.4749,0.4749,0,0,0,0.2,-0.4);

	this.instance_2 = new lib._4Quotes();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2.3,21.2,0.4749,0.4749,0,0,0,0.1,0.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_78.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_78},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-9.6,9.6,291.70000000000005,29.699999999999996), null);


// stage content:
(lib._300x250_Government = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_766 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(766).call(this.frame_766).wait(122));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_1.setTransform(150,125);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_2.setTransform(150,125);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_3.setTransform(150,125);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_4.setTransform(150,125);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_5.setTransform(150,125);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_6.setTransform(150,125);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_7.setTransform(150,125);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_8.setTransform(150,125);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(8));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(150,16,0.7142,0.7142);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(888));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-123,-26.3,-64.2,7.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_9.setTransform(149.85,223.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-115.3,-23.6,-56.5,10.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_10.setTransform(149.85,223.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-107.6,-20.9,-48.8,13.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_11.setTransform(149.85,223.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-99.8,-18.2,-41,15.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_12.setTransform(149.85,223.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-92.1,-15.5,-33.3,18.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_13.setTransform(149.85,223.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-84.4,-12.8,-25.6,21.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_14.setTransform(149.85,223.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-76.7,-10.1,-17.9,23.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_15.setTransform(149.85,223.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.9,-7.5,-10.1,26.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_16.setTransform(149.85,223.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-61.2,-4.8,-2.4,29.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_17.setTransform(149.85,223.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-53.5,-2.1,5.3,31.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_18.setTransform(149.85,223.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-45.8,0.6,13,34.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_19.setTransform(149.85,223.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-38,3.3,20.8,37.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_20.setTransform(149.85,223.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-30.3,6,28.5,40).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_21.setTransform(149.85,223.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-22.6,8.7,36.2,42.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_22.setTransform(149.85,223.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-14.8,11.4,44,45.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_23.setTransform(149.85,223.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-7.1,14.1,51.7,48.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_24.setTransform(149.85,223.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,16.8,59.4,50.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_25.setTransform(149.85,223.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,19.5,67.1,53.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_26.setTransform(149.85,223.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],16.1,22.2,74.9,56.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_27.setTransform(149.85,223.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],23.8,24.9,82.6,58.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_28.setTransform(149.85,223.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],31.5,27.6,90.3,61.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_29.setTransform(149.85,223.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.2,30.3,98,64.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_30.setTransform(149.85,223.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],47,33,105.8,66.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_31.setTransform(149.85,223.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],54.7,35.7,113.5,69.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_32.setTransform(149.85,223.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],62.4,38.4,121.2,72.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_33.setTransform(149.85,223.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).wait(234));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.instance_2 = new lib.t122();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},123).to({state:[{t:this.instance_1}]},173).to({state:[{t:this.instance_2}]},123).to({state:[{t:this.instance_1}]},173).to({state:[{t:this.instance_2}]},123).wait(173));

	// t11
	this.instance_3 = new lib.t11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,104.7,0.8928,0.8928,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(888));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,190.55,0.8928,0.8928,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(123).to({y:192.55},0).wait(173).to({y:190.55},0).wait(123).to({y:192.55},0).wait(173).to({y:190.55},0).wait(123).to({y:192.55},0).wait(173));

	// Слой_5
	this.instance_5 = new lib.icons();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(26).to({_off:false},0).to({alpha:1},6).to({_off:true},91).wait(199).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(199).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(173));

	// Слой_14
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("A3bI6IAAxzMAu3AAAIAARzg");
	this.shape_34.setTransform(150,225.175);

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(20).to({y:221.175},0).wait(1).to({y:217.175},0).wait(1).to({y:213.175},0).wait(1).to({y:209.175},0).wait(1).to({y:205.175},0).wait(1).to({y:201.175},0).wait(1).to({y:197.175},0).wait(1).to({y:193.175},0).wait(96).to({y:225.175},0).wait(193).to({y:221.175},0).wait(1).to({y:217.175},0).wait(1).to({y:213.175},0).wait(1).to({y:209.175},0).wait(1).to({y:205.175},0).wait(1).to({y:201.175},0).wait(1).to({y:197.175},0).wait(1).to({y:193.175},0).wait(96).to({y:225.175},0).wait(193).to({y:221.175},0).wait(1).to({y:217.175},0).wait(1).to({y:213.175},0).wait(1).to({y:209.175},0).wait(1).to({y:205.175},0).wait(1).to({y:201.175},0).wait(1).to({y:197.175},0).wait(1).to({y:193.175},0).wait(96).to({y:225.175},0).wait(173));

	// Слой_2
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEACQgDABgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_35.setTransform(279.725,156.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgPAaQgHgEgFgHQgDgHAAgIQAAgIADgHQAFgHAHgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgEACgBAEQgCAEAAAEQAAAEACAEQABAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_36.setTransform(272.7,156.325);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_37.setTransform(267.625,155.075);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_38.setTransform(264.025,155.575);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_39.setTransform(258.475,156.3208);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_40.setTransform(252.375,156.325);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_41.setTransform(245.775,156.375);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_42.setTransform(238.475,155.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgcAoIAAhQIA5AAIAAAPIgnAAIAAARIAmAAIAAAPIgmAAIAAATIAnAAIAAAOg");
	this.shape_43.setTransform(231.675,155.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgXAnQgGgCgEgGQgDgEAAgIQAAgGACgFQADgFADgCIAJgFIgEgJIgBgJQAAgFADgFQADgDAFgDQAFgDAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAGgDAEIgHAHIgJAGIADADIADAFIAHAIIAFgIIADgHIAMAEIgFALIgGAJIAHAIIAIAIIgTAAIgDgCIgDgDQgFADgGACQgEACgHAAQgHAAgGgDgAgSAKQgCADAAAEQAAAEACADIAEAEQADACAEgBIAGgBIAEgCIgEgGIgEgEIgEgGIgEgGIgFAGgAgGgbQgDACAAAEIABAFIADAGIAHgGQAEgDAAgEQAAgDgCgCQgCgBgCAAQgEAAgCACg");
	this.shape_44.setTransform(221.025,155.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgKgDQgGgBgDgDQgDgEgBgGQAAgFADgFQACgEAGgCQAFgDAIAAQAGAAAGACQAHADAEADIgGALQgDgDgFgCQgEgCgFAAQgEAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgGADgHAAQgIAAgHgDg");
	this.shape_45.setTransform(210.9,156.325);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_46.setTransform(206.475,155.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAHAEAEAHQADAHAAAIQAAAIgDAHQgEAHgHAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_47.setTransform(201.45,156.325);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgFgHQgDgHAAgIQAAgIADgHQAFgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgEACgBAEQgCAEAAAEQAAAEACAEQABAEAEADQADACAEAAQAFAAADgCQADgDADgEQABgEAAgEQAAgEgBgEQgDgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_48.setTransform(194.45,156.325);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAMAoIAAgkQAAgEgDgCQgDgDgFAAQgDAAgEACQgDACgCACIAAAnIgQAAIAAhQIAQAAIAAAeIAFgEIAGgDIAJgBQAJgBAFAFQAFAFAAAJIAAAog");
	this.shape_49.setTransform(187.425,155.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_50.setTransform(180.925,156.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgSAmQgJgDgGgGIAKgNQAEAEAHAEQAGADAIAAQAHgBADgCQAEgDAAgDQAAgEgEgCIgJgDIgKgCIgLgFQgFgCgDgEQgEgEAAgIQAAgHAEgFQAEgGAGgDQAIgEAIAAQAJAAAJADQAHADAGAGIgJAMQgFgEgGgDQgHgCgEABQgGgBgDACQgDADAAAEQAAACAEACIAIAEIAKACQAGABAFAEQAGACADADQAEAGAAAHQAAAHgEAGQgDAGgIADQgHAEgLAAQgLAAgIgEg");
	this.shape_51.setTransform(174.1,155.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgLgDQgFgBgDgDQgDgEgBgGQAAgFADgFQACgEAGgCQAFgDAIAAQAGAAAGACQAHADAEADIgGALIgHgFQgFgCgFAAQgEAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgGADgHAAQgHAAgIgDg");
	this.shape_52.setTransform(138.35,156.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAHgEAHAAQAJAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAFgBIAGgCIAEgDIAHALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgCgCgGAAQgDAAgDACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_53.setTransform(132.2,156.325);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_54.setTransform(125.825,156.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_55.setTransform(119.225,156.3208);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgdApIAAhQIAQAAIAAAHQADgEAFgCQAFgCAEAAQAHAAAGADQAGAEADAHQADAGABAKQgBAKgDAGQgDAHgGADQgGAEgHAAQgFAAgEgCQgEgCgEgFIAAAegAgIgZQgDACgCADIAAAUQACADADABQAEACAEAAQAFAAAEgEQAFgEAAgIQAAgHgFgFQgEgFgFAAQgEAAgEACg");
	this.shape_56.setTransform(112.75,157.375);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgTAmQgIgDgFgGIAJgNQAEAEAHAEQAHADAHAAQAHgBAEgCQADgDAAgDQAAgEgDgCIgJgDIgKgCIgMgFQgFgCgEgEQgDgEAAgIQAAgHAEgFQADgGAIgDQAGgEAJAAQAKAAAHADQAJADAFAGIgJAMQgFgEgGgDQgGgCgGABQgFgBgDACQgDADAAAEQAAACADACIAJAEIAKACQAGABAGAEQAEACAEADQAEAGgBAHQABAHgEAGQgDAGgIADQgHAEgLAAQgLAAgJgEg");
	this.shape_57.setTransform(105.3,155.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_58.setTransform(95.575,156.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_59.setTransform(90.875,155.075);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_60.setTransform(87.825,155.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgFAnQgFgCgEgFIAAAIIgPAAIAAhQIAPAAIAAAdQAEgEAFgCQAFgCAEAAQAIAAAFADQAGAEAEAHQACAGABAJQgBAKgCAHQgEAHgGAEQgFADgIAAQgEAAgFgCgAgHgEIgHAEIAAAVIAHAFQADABAEAAQAGAAAEgEQAEgFAAgIQAAgHgEgEQgEgFgGAAQgEAAgDACg");
	this.shape_61.setTransform(82.9,155.275);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_62.setTransform(75.625,156.375);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AggAoIAAhQIAlAAQAJAAAGAEQAGAEADAGQAEAFAAAHQAAAHgEAHQgDAEgGAEQgGAEgJgBIgTAAIAAAdgAgOgCIARAAQAFgBADgDQAEgCAAgGQAAgEgEgEQgDgDgFAAIgRAAg");
	this.shape_63.setTransform(68.575,155.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgXAnQgGgCgEgGQgDgEAAgIQAAgGACgFQADgFADgCIAJgFIgEgJIgBgJQAAgFADgFQADgDAFgDQAFgDAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAGgDAEIgHAHIgJAGIADADIADAFIAHAIIAFgIIADgHIAMAEIgFALIgGAJIAHAIIAIAIIgTAAIgDgCIgDgDQgFADgGACQgEACgHAAQgHAAgGgDgAgSAKQgCADAAAEQAAAEACADIAEAEQADACAEgBIAGgBIAEgCIgEgGIgEgEIgEgGIgEgGIgFAGgAgGgbQgDACAAAEIABAFIADAGIAHgGQAEgDAAgEQAAgDgCgCQgCgBgCAAQgEAAgCACg");
	this.shape_64.setTransform(57.525,155.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAGADIAHABQAFAAACgBQADgCAAgDQAAgCgEgCIgHgCIgKgDQgFgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAIAAAGACQAFADAFADIgHALQgCgDgFgCQgEgCgGAAQgDAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgGAAgHgDg");
	this.shape_65.setTransform(47.4,156.325);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAHgEAHAAQAJAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAFgBIAGgCIAEgDIAHALQgEAEgGACQgHACgHAAQgHAAgIgEgAAPgFIgCgGIgFgEQgCgCgGAAQgDAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_66.setTransform(41.2,156.325);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_67.setTransform(34.825,156.325);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_68.setTransform(30.125,155.075);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgMApIAAgsIgKAAIAAgOIAKAAIAAgCQAAgKAGgGQAFgFAIAAQAEAAAEABQAFABADADIgHAKIgCgCIgEAAQgDAAgDACQgBACAAAEIAAACIALAAIAAAOIgLAAIAAAsg");
	this.shape_69.setTransform(27,155.125);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgMApIAAgsIgJAAIAAgOIAJAAIAAgCQABgKAEgGQAGgFAIAAQAEAAAFABQADABAEADIgGAKIgDgCIgEAAQgEAAgBACQgDACAAAEIAAACIANAAIAAAOIgNAAIAAAsg");
	this.shape_70.setTransform(23,155.125);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgVAkQgJgFgGgKQgFgIgBgNQABgLAFgKQAGgJAJgFQAJgGAMAAQAMAAAKAGQAJAFAGAJQAGAKgBALQABANgGAIQgGAKgJAFQgKAGgMAAQgMAAgJgGgAgMgWQgFADgEAGQgCAHAAAGQAAAIACAFQAEAHAFADQAGADAGABQAHgBAGgDQAFgDADgHQADgFAAgIQAAgGgDgHQgDgGgFgDQgGgDgHAAQgGAAgGADg");
	this.shape_71.setTransform(15.95,155.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgKgDQgGgBgDgDQgDgEgBgGQAAgFADgFQACgEAGgCQAFgDAIAAQAGAAAGACQAHADAEADIgGALQgDgDgEgCQgFgCgFAAQgEAAgDACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgGADgHAAQgIAAgHgDg");
	this.shape_72.setTransform(248.25,158.525);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAHAAQAJAAAHAEQAHAEADAHQAEAIAAAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAEgDIAIALQgFAEgGACQgGACgIAAQgIAAgHgEgAAPgFIgCgGIgEgEQgEgCgFAAQgDAAgEACQgDABgBADIgCAGIAcAAIAAAAg");
	this.shape_73.setTransform(242.05,158.525);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgHApIAAhQIAPAAIAABQg");
	this.shape_74.setTransform(226.775,157.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgcApIAAhQIA5AAIAAAPIgnAAIAAAQIAmAAIAAAPIgmAAIAAAig");
	this.shape_75.setTransform(206.175,157.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AAMAeIAAgiQAAgGgDgDQgDgCgFAAQgDAAgEACQgDABgCADIAAAnIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_76.setTransform(248.325,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_77.setTransform(241.3,146.325);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_78.setTransform(236.225,145.075);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_79.setTransform(232.625,145.575);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_80.setTransform(227.075,146.3208);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_81.setTransform(220.6,146.325);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_82.setTransform(215.325,146.25);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_83.setTransform(203.4,146.325);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AANAoIgPgdIgNAAIAAAdIgRAAIAAhQIAlAAQAJAAAFAEQAHADADAGQAEAGAAAHQAAAHgDAGQgDADgEADQgEAEgEABIASAegAgPgDIARAAQAGAAADgDQAEgCAAgGQAAgEgEgEQgDgDgGAAIgRAAg");
	this.shape_84.setTransform(196.25,145.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAHADIAGABQAFAAACgBQADgCAAgDQAAgCgEgCIgIgCIgKgDQgEgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAHAAAHACQAFADAFADIgHALQgCgDgFgCQgEgCgGAAQgDAAgCACQgBAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgGAAgHgDg");
	this.shape_85.setTransform(91.6,158.525);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_86.setTransform(81.125,157.275);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgGgDgCQgDgCgFgBQgDAAgEACQgDADgCADIAAAmIgQAAIAAg6IAQAAIAAAIIAFgFIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_87.setTransform(76.075,158.45);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_88.setTransform(70.975,157.275);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgHApIAAhQIAPAAIAABQg");
	this.shape_89.setTransform(67.875,157.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgJgBgNQABgMAFgJQAGgJAKgGQAJgFAMAAQAJAAAGADQAHADAEAEQAFAFADAFIgPAHQgDgFgFgDQgFgEgGAAQgHAAgGAEQgFAEgDAFQgEAGAAAHQAAAHAEAHQADAFAFAEQAGAEAHgBQAGABAFgEQAFgDADgFIAPAHIgIAKQgEAEgHADQgGADgJAAQgMAAgJgGg");
	this.shape_90.setTransform(62.275,157.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AAMAoIAAgkQAAgEgDgDQgDgCgFAAQgDAAgEACQgDACgCACIAAAnIgQAAIAAhQIAQAAIAAAeIAFgEIAGgDIAJgBQAJgBAFAFQAFAFAAAJIAAAog");
	this.shape_91.setTransform(123.925,145.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_92.setTransform(118.325,145.575);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_93.setTransform(109.675,146.3208);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAHAAQAJAAAHAEQAGAEAEAHQAEAIAAAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAEgDIAHALQgEAEgGACQgHACgHAAQgHAAgIgEgAAPgFIgCgGIgFgEQgCgCgGAAQgDAAgEACQgDABgBADIgCAGIAcAAIAAAAg");
	this.shape_94.setTransform(103.2,146.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AATAoIAAghIglAAIAAAhIgRAAIAAhQIARAAIAAAgIAlAAIAAggIASAAIAABQg");
	this.shape_95.setTransform(95.35,145.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgXAnQgGgCgEgGQgDgFAAgHQAAgGACgFQADgEADgDIAJgFIgEgJIgBgJQAAgFADgFQADgDAFgEQAFgCAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAGgDAEIgHAHIgJAGIADADIADAFIAHAHIAFgHIADgHIAMAEIgFAKIgGAKIAHAIIAIAIIgTAAIgDgCIgDgDQgFADgGACQgEACgHAAQgHAAgGgDgAgSAKQgCADAAAEQAAAEACADIAEAEQADACAEgBIAGAAIAEgDIgEgGIgEgEIgEgGIgEgGIgFAGgAgGgbQgDACAAAEIABAFIADAGIAHgFQAEgDAAgFQAAgDgCgCQgCgCgCAAQgEABgCACg");
	this.shape_96.setTransform(83.925,145.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAFAEIAIADIAGABQAFAAACgBQADgCAAgDQAAgCgEgCIgIgCIgKgDQgEgBgEgDQgDgEgBgGQAAgFADgFQACgEAGgCQAFgDAIAAQAHAAAGACQAFADAFADIgHALQgCgDgEgCQgGgCgEAAQgEAAgCACQgBAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgGADgHAAQgIAAgGgDg");
	this.shape_97.setTransform(73.8,146.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_98.setTransform(69.375,145.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_99.setTransform(64.375,146.3208);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_100.setTransform(59.175,145.575);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_101.setTransform(55.525,145.075);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgKgDQgGgBgDgDQgDgEgBgGQAAgFADgFQACgEAGgCQAFgDAIAAQAGAAAGACQAHADAEADIgGALQgDgDgFgCQgEgCgFAAQgEAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgGADgHAAQgHAAgIgDg");
	this.shape_102.setTransform(43.95,146.325);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgFgHQgDgHAAgIQAAgIADgHQAFgHAGgEQAIgEAIAAQAJAAAHAEQAIAEADAHQAEAHAAAIQAAAIgEAHQgDAHgIAEQgHAFgJAAQgIAAgIgFgAgHgOQgDACgCAEQgCAEAAAEQAAAEACAEQACAEADADQADACAEAAQAFAAADgCQAEgDACgEQABgEAAgEQAAgEgBgEQgCgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_103.setTransform(37.6,146.325);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AATAoIAAghIglAAIAAAhIgRAAIAAhQIARAAIAAAgIAlAAIAAggIARAAIAABQg");
	this.shape_104.setTransform(29.65,145.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{x:30.125,y:155.075}},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60,p:{x:87.825,y:155.2}},{t:this.shape_59,p:{x:90.875,y:155.075}},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56,p:{x:112.75,y:157.375}},{t:this.shape_55,p:{x:119.225,y:156.3208}},{t:this.shape_54,p:{x:125.825,y:156.325}},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:180.925,y:156.325}},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:206.475,y:155.2}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40,p:{x:252.375,y:156.325}},{t:this.shape_39,p:{x:258.475,y:156.3208}},{t:this.shape_38,p:{x:264.025,y:155.575}},{t:this.shape_37,p:{x:267.625,y:155.075}},{t:this.shape_36},{t:this.shape_35}]},123).to({state:[{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_56,p:{x:50.65,y:147.375}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_60,p:{x:114.675,y:145.2}},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_54,p:{x:85.775,y:158.525}},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_50,p:{x:209.875,y:146.325}},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_55,p:{x:254.975,y:146.3208}},{t:this.shape_46,p:{x:259.975,y:145.2}},{t:this.shape_75},{t:this.shape_39,p:{x:212.625,y:158.5208}},{t:this.shape_40,p:{x:219.225,y:158.525}},{t:this.shape_68,p:{x:223.725,y:157.275}},{t:this.shape_74},{t:this.shape_59,p:{x:229.875,y:157.275}},{t:this.shape_38,p:{x:233.525,y:157.775}},{t:this.shape_37,p:{x:237.075,y:157.275}},{t:this.shape_73},{t:this.shape_72}]},86).to({state:[]},87).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{x:30.125,y:155.075}},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60,p:{x:87.825,y:155.2}},{t:this.shape_59,p:{x:90.875,y:155.075}},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56,p:{x:112.75,y:157.375}},{t:this.shape_55,p:{x:119.225,y:156.3208}},{t:this.shape_54,p:{x:125.825,y:156.325}},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:180.925,y:156.325}},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:206.475,y:155.2}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40,p:{x:252.375,y:156.325}},{t:this.shape_39,p:{x:258.475,y:156.3208}},{t:this.shape_38,p:{x:264.025,y:155.575}},{t:this.shape_37,p:{x:267.625,y:155.075}},{t:this.shape_36},{t:this.shape_35}]},123).to({state:[{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_56,p:{x:50.65,y:147.375}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_60,p:{x:114.675,y:145.2}},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_54,p:{x:85.775,y:158.525}},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_50,p:{x:209.875,y:146.325}},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_55,p:{x:254.975,y:146.3208}},{t:this.shape_46,p:{x:259.975,y:145.2}},{t:this.shape_75},{t:this.shape_39,p:{x:212.625,y:158.5208}},{t:this.shape_40,p:{x:219.225,y:158.525}},{t:this.shape_68,p:{x:223.725,y:157.275}},{t:this.shape_74},{t:this.shape_59,p:{x:229.875,y:157.275}},{t:this.shape_38,p:{x:233.525,y:157.775}},{t:this.shape_37,p:{x:237.075,y:157.275}},{t:this.shape_73},{t:this.shape_72}]},86).to({state:[]},87).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{x:30.125,y:155.075}},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60,p:{x:87.825,y:155.2}},{t:this.shape_59,p:{x:90.875,y:155.075}},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56,p:{x:112.75,y:157.375}},{t:this.shape_55,p:{x:119.225,y:156.3208}},{t:this.shape_54,p:{x:125.825,y:156.325}},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:180.925,y:156.325}},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:206.475,y:155.2}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40,p:{x:252.375,y:156.325}},{t:this.shape_39,p:{x:258.475,y:156.3208}},{t:this.shape_38,p:{x:264.025,y:155.575}},{t:this.shape_37,p:{x:267.625,y:155.075}},{t:this.shape_36},{t:this.shape_35}]},123).to({state:[{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_56,p:{x:50.65,y:147.375}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_60,p:{x:114.675,y:145.2}},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_54,p:{x:85.775,y:158.525}},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_50,p:{x:209.875,y:146.325}},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_55,p:{x:254.975,y:146.3208}},{t:this.shape_46,p:{x:259.975,y:145.2}},{t:this.shape_75},{t:this.shape_39,p:{x:212.625,y:158.5208}},{t:this.shape_40,p:{x:219.225,y:158.525}},{t:this.shape_68,p:{x:223.725,y:157.275}},{t:this.shape_74},{t:this.shape_59,p:{x:229.875,y:157.275}},{t:this.shape_38,p:{x:233.525,y:157.775}},{t:this.shape_37,p:{x:237.075,y:157.275}},{t:this.shape_73},{t:this.shape_72}]},86).wait(87));

	// Слой_9
	this.instance_6 = new lib.pc31("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(208.55,125,0.8929,0.8929,0,0,0,233.6,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).wait(87));

	// Слой_7
	this.instance_7 = new lib.pc21("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(208.7,125.7,0.8958,0.8958,0,0,0,233.4,140.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(123).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(86));

	// pc11
	this.instance_8 = new lib.pc11();
	this.instance_8.parent = this;
	this.instance_8.setTransform(150.05,73.95,0.8928,0.8928,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({regY:148,x:150,y:81},0).wait(1).to({y:80.85},0).wait(1).to({y:80.7},0).wait(1).to({y:80.55},0).wait(1).to({y:80.45},0).wait(1).to({y:80.3},0).wait(1).to({y:80.15},0).wait(1).to({y:80},0).wait(1).to({y:79.85},0).wait(1).to({y:79.7},0).wait(1).to({y:79.6},0).wait(1).to({y:79.45},0).wait(1).to({y:79.3},0).wait(1).to({y:79.15},0).wait(1).to({y:79},0).wait(1).to({y:78.85},0).wait(1).to({y:78.7},0).wait(1).to({y:78.55},0).wait(1).to({y:78.4},0).wait(1).to({y:78.25},0).wait(1).to({y:78.1},0).wait(1).to({y:77.95},0).wait(1).to({y:77.8},0).wait(1).to({y:77.65},0).wait(1).to({y:77.5},0).wait(1).to({y:77.35},0).wait(1).to({y:77.2},0).wait(1).to({y:77.05},0).wait(1).to({y:76.9},0).wait(1).to({y:76.75},0).wait(1).to({y:76.6},0).wait(1).to({y:76.4},0).wait(1).to({y:76.25},0).wait(1).to({y:76.1},0).wait(1).to({y:75.95},0).wait(1).to({y:75.8},0).wait(1).to({y:75.65},0).wait(1).to({y:75.5},0).wait(1).to({y:75.3},0).wait(1).to({y:75.15},0).wait(1).to({y:75},0).wait(1).to({y:74.85},0).wait(1).to({y:74.65},0).wait(1).to({y:74.5},0).wait(1).to({y:74.35},0).wait(1).to({y:74.2},0).wait(1).to({y:74},0).wait(1).to({y:73.85},0).wait(1).to({y:73.7},0).wait(1).to({y:73.5},0).wait(1).to({y:73.35},0).wait(1).to({y:73.2},0).wait(1).to({y:73},0).wait(1).to({y:72.85},0).wait(1).to({y:72.7},0).wait(1).to({y:72.5},0).wait(1).to({y:72.35},0).wait(1).to({y:72.15},0).wait(1).to({y:72},0).wait(1).to({y:71.8},0).wait(1).to({y:71.65},0).wait(1).to({y:71.5},0).wait(1).to({y:71.3},0).wait(1).to({y:71.15},0).wait(1).to({y:70.95},0).wait(1).to({y:70.8},0).wait(1).to({y:70.6},0).wait(1).to({y:70.45},0).wait(1).to({y:70.25},0).wait(1).to({y:70.05},0).wait(1).to({y:69.9},0).wait(1).to({y:69.7},0).wait(1).to({y:69.55},0).wait(1).to({y:69.35},0).wait(1).to({y:69.15},0).wait(1).to({y:69},0).wait(1).to({y:68.8},0).wait(1).to({y:68.65},0).wait(1).to({y:68.45},0).wait(1).to({y:68.25},0).wait(1).to({y:68.1},0).wait(1).to({y:67.9},0).wait(1).to({y:67.7},0).wait(1).to({y:67.5},0).wait(1).to({y:67.35},0).wait(1).to({y:67.15},0).wait(1).to({y:66.95},0).wait(1).to({y:66.75},0).wait(1).to({y:66.6},0).wait(1).to({y:66.4},0).wait(1).to({y:66.2},0).wait(1).to({y:66},0).wait(1).to({y:65.8},0).wait(1).to({y:65.65},0).wait(1).to({y:65.45},0).wait(1).to({y:65.25},0).wait(1).to({y:65.05},0).wait(1).to({y:64.85},0).wait(1).to({y:64.65},0).wait(1).to({y:64.45},0).wait(1).to({y:64.25},0).wait(1).to({y:64.05},0).wait(1).to({y:63.9},0).wait(1).to({y:63.7},0).wait(1).to({y:63.5},0).wait(1).to({y:63.3},0).wait(1).to({y:63.1},0).wait(1).to({y:62.9},0).wait(1).to({y:62.7},0).wait(1).to({y:62.5},0).wait(1).to({y:62.3},0).wait(1).to({y:62.1},0).wait(1).to({y:61.9},0).wait(1).to({y:61.65},0).wait(1).to({y:61.45},0).wait(1).to({y:61.25},0).wait(1).to({y:61.05},0).wait(1).to({y:60.85},0).wait(1).to({y:60.65},0).wait(1).to({y:60.45},0).wait(1).to({y:60.25},0).wait(1).to({regY:140,y:52.85},0).to({_off:true},1).wait(173).to({_off:false,x:150.05,y:73.95},0).wait(1).to({regY:148,x:150,y:81},0).wait(1).to({y:80.85},0).wait(1).to({y:80.7},0).wait(1).to({y:80.55},0).wait(1).to({y:80.45},0).wait(1).to({y:80.3},0).wait(1).to({y:80.15},0).wait(1).to({y:80},0).wait(1).to({y:79.85},0).wait(1).to({y:79.7},0).wait(1).to({y:79.6},0).wait(1).to({y:79.45},0).wait(1).to({y:79.3},0).wait(1).to({y:79.15},0).wait(1).to({y:79},0).wait(1).to({y:78.85},0).wait(1).to({y:78.7},0).wait(1).to({y:78.55},0).wait(1).to({y:78.4},0).wait(1).to({y:78.25},0).wait(1).to({y:78.1},0).wait(1).to({y:77.95},0).wait(1).to({y:77.8},0).wait(1).to({y:77.65},0).wait(1).to({y:77.5},0).wait(1).to({y:77.35},0).wait(1).to({y:77.2},0).wait(1).to({y:77.05},0).wait(1).to({y:76.9},0).wait(1).to({y:76.75},0).wait(1).to({y:76.6},0).wait(1).to({y:76.4},0).wait(1).to({y:76.25},0).wait(1).to({y:76.1},0).wait(1).to({y:75.95},0).wait(1).to({y:75.8},0).wait(1).to({y:75.65},0).wait(1).to({y:75.5},0).wait(1).to({y:75.3},0).wait(1).to({y:75.15},0).wait(1).to({y:75},0).wait(1).to({y:74.85},0).wait(1).to({y:74.65},0).wait(1).to({y:74.5},0).wait(1).to({y:74.35},0).wait(1).to({y:74.2},0).wait(1).to({y:74},0).wait(1).to({y:73.85},0).wait(1).to({y:73.7},0).wait(1).to({y:73.5},0).wait(1).to({y:73.35},0).wait(1).to({y:73.2},0).wait(1).to({y:73},0).wait(1).to({y:72.85},0).wait(1).to({y:72.7},0).wait(1).to({y:72.5},0).wait(1).to({y:72.35},0).wait(1).to({y:72.15},0).wait(1).to({y:72},0).wait(1).to({y:71.8},0).wait(1).to({y:71.65},0).wait(1).to({y:71.5},0).wait(1).to({y:71.3},0).wait(1).to({y:71.15},0).wait(1).to({y:70.95},0).wait(1).to({y:70.8},0).wait(1).to({y:70.6},0).wait(1).to({y:70.45},0).wait(1).to({y:70.25},0).wait(1).to({y:70.05},0).wait(1).to({y:69.9},0).wait(1).to({y:69.7},0).wait(1).to({y:69.55},0).wait(1).to({y:69.35},0).wait(1).to({y:69.15},0).wait(1).to({y:69},0).wait(1).to({y:68.8},0).wait(1).to({y:68.65},0).wait(1).to({y:68.45},0).wait(1).to({y:68.25},0).wait(1).to({y:68.1},0).wait(1).to({y:67.9},0).wait(1).to({y:67.7},0).wait(1).to({y:67.5},0).wait(1).to({y:67.35},0).wait(1).to({y:67.15},0).wait(1).to({y:66.95},0).wait(1).to({y:66.75},0).wait(1).to({y:66.6},0).wait(1).to({y:66.4},0).wait(1).to({y:66.2},0).wait(1).to({y:66},0).wait(1).to({y:65.8},0).wait(1).to({y:65.65},0).wait(1).to({y:65.45},0).wait(1).to({y:65.25},0).wait(1).to({y:65.05},0).wait(1).to({y:64.85},0).wait(1).to({y:64.65},0).wait(1).to({y:64.45},0).wait(1).to({y:64.25},0).wait(1).to({y:64.05},0).wait(1).to({y:63.9},0).wait(1).to({y:63.7},0).wait(1).to({y:63.5},0).wait(1).to({y:63.3},0).wait(1).to({y:63.1},0).wait(1).to({y:62.9},0).wait(1).to({y:62.7},0).wait(1).to({y:62.5},0).wait(1).to({y:62.3},0).wait(1).to({y:62.1},0).wait(1).to({y:61.9},0).wait(1).to({y:61.65},0).wait(1).to({y:61.45},0).wait(1).to({y:61.25},0).wait(1).to({y:61.05},0).wait(1).to({y:60.85},0).wait(1).to({y:60.65},0).wait(1).to({y:60.45},0).wait(1).to({y:60.25},0).wait(1).to({regY:140,y:52.85},0).to({_off:true},1).wait(173).to({_off:false,x:150.05,y:73.95},0).wait(1).to({regY:148,x:150,y:81},0).wait(1).to({y:80.85},0).wait(1).to({y:80.7},0).wait(1).to({y:80.55},0).wait(1).to({y:80.45},0).wait(1).to({y:80.3},0).wait(1).to({y:80.15},0).wait(1).to({y:80},0).wait(1).to({y:79.85},0).wait(1).to({y:79.7},0).wait(1).to({y:79.6},0).wait(1).to({y:79.45},0).wait(1).to({y:79.3},0).wait(1).to({y:79.15},0).wait(1).to({y:79},0).wait(1).to({y:78.85},0).wait(1).to({y:78.7},0).wait(1).to({y:78.55},0).wait(1).to({y:78.4},0).wait(1).to({y:78.25},0).wait(1).to({y:78.1},0).wait(1).to({y:77.95},0).wait(1).to({y:77.8},0).wait(1).to({y:77.65},0).wait(1).to({y:77.5},0).wait(1).to({y:77.35},0).wait(1).to({y:77.2},0).wait(1).to({y:77.05},0).wait(1).to({y:76.9},0).wait(1).to({y:76.75},0).wait(1).to({y:76.6},0).wait(1).to({y:76.4},0).wait(1).to({y:76.25},0).wait(1).to({y:76.1},0).wait(1).to({y:75.95},0).wait(1).to({y:75.8},0).wait(1).to({y:75.65},0).wait(1).to({y:75.5},0).wait(1).to({y:75.3},0).wait(1).to({y:75.15},0).wait(1).to({y:75},0).wait(1).to({y:74.85},0).wait(1).to({y:74.65},0).wait(1).to({y:74.5},0).wait(1).to({y:74.35},0).wait(1).to({y:74.2},0).wait(1).to({y:74},0).wait(1).to({y:73.85},0).wait(1).to({y:73.7},0).wait(1).to({y:73.5},0).wait(1).to({y:73.35},0).wait(1).to({y:73.2},0).wait(1).to({y:73},0).wait(1).to({y:72.85},0).wait(1).to({y:72.7},0).wait(1).to({y:72.5},0).wait(1).to({y:72.35},0).wait(1).to({y:72.15},0).wait(1).to({y:72},0).wait(1).to({y:71.8},0).wait(1).to({y:71.65},0).wait(1).to({y:71.5},0).wait(1).to({y:71.3},0).wait(1).to({y:71.15},0).wait(1).to({y:70.95},0).wait(1).to({y:70.8},0).wait(1).to({y:70.6},0).wait(1).to({y:70.45},0).wait(1).to({y:70.25},0).wait(1).to({y:70.05},0).wait(1).to({y:69.9},0).wait(1).to({y:69.7},0).wait(1).to({y:69.55},0).wait(1).to({y:69.35},0).wait(1).to({y:69.15},0).wait(1).to({y:69},0).wait(1).to({y:68.8},0).wait(1).to({y:68.65},0).wait(1).to({y:68.45},0).wait(1).to({y:68.25},0).wait(1).to({y:68.1},0).wait(1).to({y:67.9},0).wait(1).to({y:67.7},0).wait(1).to({y:67.5},0).wait(1).to({y:67.35},0).wait(1).to({y:67.15},0).wait(1).to({y:66.95},0).wait(1).to({y:66.75},0).wait(1).to({y:66.6},0).wait(1).to({y:66.4},0).wait(1).to({y:66.2},0).wait(1).to({y:66},0).wait(1).to({y:65.8},0).wait(1).to({y:65.65},0).wait(1).to({y:65.45},0).wait(1).to({y:65.25},0).wait(1).to({y:65.05},0).wait(1).to({y:64.85},0).wait(1).to({y:64.65},0).wait(1).to({y:64.45},0).wait(1).to({y:64.25},0).wait(1).to({y:64.05},0).wait(1).to({y:63.9},0).wait(1).to({y:63.7},0).wait(1).to({y:63.5},0).wait(1).to({y:63.3},0).wait(1).to({y:63.1},0).wait(1).to({y:62.9},0).wait(1).to({y:62.7},0).wait(1).to({y:62.5},0).wait(1).to({y:62.3},0).wait(1).to({y:62.1},0).wait(1).to({y:61.9},0).wait(1).to({y:61.65},0).wait(1).to({y:61.45},0).wait(1).to({y:61.25},0).wait(1).to({y:61.05},0).wait(1).to({y:60.85},0).wait(1).to({y:60.65},0).wait(1).to({y:60.45},0).wait(1).to({y:60.25},0).wait(1).to({regY:140,y:52.85},0).to({_off:true},1).wait(173));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(147.5,52.9,220.60000000000002,229.29999999999998);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_Government_atlas_P_.png", id:"300x250_Government_atlas_P_"},
		{src:"images/300x250_Government_atlas_NP_.jpg", id:"300x250_Government_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;