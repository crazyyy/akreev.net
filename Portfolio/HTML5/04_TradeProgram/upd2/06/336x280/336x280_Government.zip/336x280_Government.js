(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_Government_atlas_P_", frames: [[0,0,98,28]]},
		{name:"336x280_Government_atlas_NP_", frames: [[0,731,49,43],[58,686,54,44],[0,492,336,192],[0,686,56,43],[0,0,336,296],[0,298,336,192]]}
];


// symbols:



(lib.Растровоеизображение10 = function() {
	this.initialize(ss["336x280_Government_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение11 = function() {
	this.initialize(ss["336x280_Government_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["336x280_Government_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["336x280_Government_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_Government_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["336x280_Government_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["336x280_Government_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(212.125,73.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAGgHQADADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgFAHQgDADgFABQgFABgHABQgHgBgHgCg");
	this.shape_1.setTransform(207.15,70.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_2.setTransform(199.775,69.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgEAvIAAhdIAJAAIAABdg");
	this.shape_3.setTransform(194.375,69.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_4.setTransform(191.225,69.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgWAdQgFgFAAgLIAAgvIALAAIAAAsIAAAIQABADACABQADACACABIAHABQAFAAAFgEQAGgDADgEIAAgxIAKAAIAABDIgKAAIAAgJQgEAEgGADQgHAEgHAAQgKAAgGgGg");
	this.shape_5.setTransform(185.8,71.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgKAsQgGgDgEgFIAAAKIgLAAIAAhdIALAAIAAAkQAEgFAGgDQAGgDAGAAQAGgBAGADQAFADAEAFQAEAEACAGQADAGAAAJQAAAHgDAHQgCAGgEAGQgEAEgFACQgGACgGABQgHAAgFgEgAgMgKQgFAEgDAEIAAAeQADAEAFADQAGAEAGAAQAEAAAEgCQAEgDADgDQADgEABgEQACgFAAgFQAAgGgCgFQgBgEgDgDQgDgEgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_6.setTransform(178.125,69.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgLAhQgGgCgFgFQgEgFgDgHQgDgGAAgIQAAgGADgHQACgGAFgFQAEgFAGgDQAGgCAGAAQAIAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQAAAGACADQACAFADADQADAEAEABQAFACAFAAQAGAAAFgCQAGgDAEgDIAEAHQgEAFgIACQgGACgJABQgGgBgGgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_7.setTransform(166.3,70.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgFAiIgchDIAMAAIAVA3IAWg3IAMAAIgcBDg");
	this.shape_8.setTransform(158.925,70.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_9.setTransform(153.925,69.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_10.setTransform(150.325,70.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_11.setTransform(146.675,69.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAFgHQAEADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgGABQgIgBgHgCg");
	this.shape_12.setTransform(141.75,70.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgHAAIgEABIgGACIgFADIgEAEIAAAxIgKAAIAAhDIAKAAIAAAKIAFgEIAFgEIAHgDIAHgBQAVAAAAAWIAAAvg");
	this.shape_13.setTransform(134.7,70.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQABAGABADQACAFADADQAEAEAEABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgGAFgHACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_14.setTransform(126.9,70.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAFgHQAEADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgHABQgHgBgHgCg");
	this.shape_15.setTransform(119.6,70.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_16.setTransform(110.775,70.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAGAAQAIAAAGACQAGADAEAFQAEAFADAHQACAGAAAHIAAACIg2AAQAAAGACADQACAFADADQADAEAFABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgFAFgIACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_17.setTransform(104.75,70.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgPAuQgGgCgGgFIAFgIQAFAEAFACQAFADAHAAIAHgBQAEgCADgCQADgCACgEQACgEAAgGIAAgJQgEAFgFADQgGAEgHAAQgGAAgGgDQgFgCgEgEQgEgFgCgHQgDgFAAgIQAAgIADgHQACgGAEgFQAEgEAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgKIALAAIAABBQAAAJgDAFQgDAGgEADQgFAEgGABQgFACgGAAQgIAAgHgDgAgHgkQgEACgDAEQgDACgBAGQgCAEAAAGQAAAGACAEQABAEADADQADAEAEABQAEADAEAAIAGgBIAGgDIAFgDIADgFIAAgcIgDgEIgFgEIgGgCIgGgBQgEAAgEACg");
	this.shape_18.setTransform(96.575,72.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_19.setTransform(88.525,69.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgWAdQgFgFAAgLIAAgvIALAAIAAAsIAAAIQABADACABQACACAEABIAGABQAFAAAFgEQAGgDADgEIAAgxIAKAAIAABDIgKAAIAAgJQgFAEgFADQgHAEgHAAQgKAAgGgGg");
	this.shape_20.setTransform(80.85,71.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgKAsQgGgDgEgFIAAAKIgLAAIAAhdIALAAIAAAkQAEgFAGgDQAGgDAGAAQAGgBAGADQAFADAEAFQAEAEACAGQADAGAAAJQAAAHgDAHQgCAGgEAGQgEAEgFACQgGACgGABQgHAAgFgEgAgMgKQgFAEgDAEIAAAeQADAEAFADQAGAEAGAAQAEAAAEgCQAEgDADgDQADgEABgEQACgFAAgFQAAgGgCgFQgBgEgDgDQgDgEgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_21.setTransform(73.175,69.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_22.setTransform(63.4,70.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgDgHABgHQgBgGADgHQACgGAFgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAFAFACAGQADAHgBAGQABAHgDAHQgCAGgFAGQgEAEgGADQgGACgIABQgHgBgGgCgAgJgXQgEADgCADQgEAEgBAFQgBAEAAAEQAAAGABAEQABAFAEAEQACADAEACQAFACAEABQAFgBAFgCQADgCADgDQAEgEABgFQABgEABgGQgBgEgBgEQgBgFgEgEIgGgGQgFgCgFAAQgEAAgFACg");
	this.shape_23.setTransform(56.7,70.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgKAvIAAg5IgMAAIAAgJIAMAAIAAgGQAAgKAFgGQAFgFAIAAQAEAAAEABQADABAEADIgFAHIgEgCIgEgBQgFAAgDADQgCAEAAAFIAAAGIANAAIAAAJIgNAAIAAA5g");
	this.shape_24.setTransform(51.175,69.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAFgHQAEADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEABgEIAGgFIAIgFQAEgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgBAHIgGAHQgDADgFABQgFABgGABQgIgBgHgCg");
	this.shape_25.setTransform(41.7,70.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_26.setTransform(36.525,70.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgIAhQgGgDgFgEQgEgGgDgGQgCgHAAgHQAAgHACgGQADgHAEgEQAFgFAGgDQAGgCAHAAQAJAAAGADQAFAEAEAEIgHAHQgDgFgEgCQgFgCgFAAQgFAAgEACQgEACgDAEQgDADgCAFQgBAFAAAEQAAAGABAEQACAFADAEQADADAEADQAEACAFAAQALgBAGgIIAHAGQgEAFgFADQgGAEgJAAQgHgBgGgCg");
	this.shape_27.setTransform(31.075,70.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgVAdQgGgFAAgLIAAgvIAKAAIAAAsIABAIQACADACABQABACADABIAGABQAGAAAFgEQAFgDADgEIAAgxIALAAIAABDIgLAAIAAgJQgDAEgHADQgGAEgGAAQgLAAgFgGg");
	this.shape_28.setTransform(23.65,71.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_29.setTransform(15.575,69.75);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgDgHABgHQgBgGADgHQACgGAFgFQAEgFAGgDQAHgCAGAAQAIAAAGACQAGADAEAFQAFAFACAGQACAHAAAGQAAAHgCAHQgCAGgFAGQgEAEgGADQgGACgIABQgGgBgHgCgAgIgXQgFADgCADQgDAEgCAFQgBAEgBAEQABAGABAEQACAFADAEQACADAFACQAEACAEABQAGgBAEgCQADgCADgDQAEgEABgFQACgEgBgGQABgEgCgEQgBgFgEgEIgGgGQgEgCgGAAQgEAAgEACg");
	this.shape_30.setTransform(7.75,70.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_31.setTransform(1.85,70.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_32.setTransform(-4.625,72.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AAkAjIAAgtQAAgHgEgDQgDgEgGAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAgtQABgHgDgDQgDgEgGAAQgGAAgFADQgEADgDAEIAAAxIgLAAIAAhDIALAAIAAAKIACgEIAGgDIAGgDQADgCAEAAQAIAAAFAEQADAEABAFIAFgEIAEgFIAHgCIAHgCQAKAAAEAGQAFAFAAAKIAAAwg");
	this.shape_33.setTransform(-18.15,70.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgVAdQgGgFAAgLIAAgvIAKAAIAAAsIABAIQACADACABQABACADABIAGABQAGAAAFgEQAFgDADgEIAAgxIALAAIAABDIgLAAIAAgJQgDAEgHADQgGAEgGAAQgLAAgFgGg");
	this.shape_34.setTransform(-27.65,71.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_35.setTransform(-33.075,69.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AAkAjIAAgtQAAgHgEgDQgDgEgGAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAgtQABgHgDgDQgDgEgGAAQgGAAgFADQgEADgDAEIAAAxIgLAAIAAhDIALAAIAAAKIACgEIAGgDIAGgDQADgCAEAAQAIAAAFAEQADAEABAFIAFgEIAEgFIAHgCIAHgCQAKAAAEAGQAFAFAAAKIAAAwg");
	this.shape_36.setTransform(-40.3,70.875);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgLAhQgHgCgEgFQgEgFgDgHQgDgGAAgIQAAgGADgHQACgGAEgFQAFgFAGgDQAGgCAGAAQAIAAAGACQAGADAFAFQADAFACAHQADAGAAAHIAAACIg2AAQABAGACADQABAFADADQADAEAEABQAFACAEAAQAHAAAFgCQAGgDAEgDIAEAHQgFAFgGACQgHACgJABQgGgBgGgCgAgJgYQgDACgDAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_37.setTransform(-49.9,70.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_38.setTransform(-55.75,70.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AggAvIAAhdIAkAAQAHAAAGADQAFACAEAEQAEAEABAFQACAFAAAGQAAAFgCAFQgBAFgEADQgEAEgFACQgGADgHAAIgZAAIAAAlgAgVAAIAYAAQAIAAAFgFQAFgFAAgHQAAgIgFgFQgFgFgIAAIgYAAg");
	this.shape_39.setTransform(-62.225,69.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t122, new cjs.Rectangle(-68.7,61.3,284.6,18), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(229.575,73.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgXAvIgEAAIACgKIADABIADAAQADAAADgCQACgBACgEIAEgKIgchEIAMAAIAVA3IAWg3IAMAAIgiBQQgCAIgFADQgFAEgHAAIgEgBg");
	this.shape_1.setTransform(224.525,72.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAGgHQADADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEABgEIAGgFIAIgFQAEgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgBAHIgGAHQgDADgFABQgFABgGABQgIgBgHgCg");
	this.shape_2.setTransform(217.75,70.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgMAjQgEgCgEgDQgDgDgCgEQgDgEAAgGQAAgFADgFQACgDADgDQAEgDAEgBQAEgBAEAAQAHAAAFACQAFADAFAEIAAgMQAAgHgFgEQgFgDgHAAQgLAAgJAJIgFgHQALgLAPAAQAGgBAEACQAFABAEADQADACACAFQACAEABAGIAAAuIgLAAIAAgHQgJAIgNABIgIgBgAgMACQgFAFABAGQgBAHAFAEQAEAEAIAAQAFAAAFgCQAFgCADgEIAAgNQgDgEgFgCQgFgBgFAAQgIAAgEACg");
	this.shape_3.setTransform(210.7,70.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgMAhQgGgCgEgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAEgFQAFgFAGgDQAGgCAHAAQAHAAAGACQAGADAFAFQADAFACAHQADAGAAAHIAAACIg2AAQABAGACADQABAFADADQAEAEADABQAFACAEAAQAGAAAGgCQAFgDAEgDIAFAHQgEAFgHACQgHACgJABQgGgBgHgCgAgIgYQgFACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgCgEgFgCQgEgBgGAAQgEAAgEABg");
	this.shape_4.setTransform(203.25,70.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQABAGABADQACAFADADQAEAEAEABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgGAFgHACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_5.setTransform(191.7,70.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_6.setTransform(183.525,69.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgCgEAAgGQAAgFACgFQACgDAEgDQADgDAEgBQAEgBAEAAQAHAAAFACQAGADAEAEIAAgMQAAgHgFgEQgFgDgHAAQgLAAgJAJIgFgHQALgLAPAAQAFgBAFACQAFABADADQAEACACAFQACAEAAAGIAAAuIgKAAIAAgHQgJAIgNABIgIgBgAgMACQgEAFAAAGQAAAHAEAEQAFAEAHAAQAFAAAFgCQAEgCAEgEIAAgNQgEgEgEgCQgFgBgFAAQgHAAgFACg");
	this.shape_7.setTransform(175.8,70.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAjAjIAAgtQAAgHgCgDQgDgEgHAAQgFAAgFADQgFADgDAEIAAAxIgJAAIAAgtQAAgHgDgDQgDgEgHAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAhDIAKAAIAAAKIAEgEIAFgDIAGgDQAEgCAEAAQAHAAAEAEQAEAEACAFIADgEIAGgFIAGgCIAHgCQAJAAAGAGQAEAFAAAKIAAAwg");
	this.shape_8.setTransform(166.65,70.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgHALIAGgGQABgDABgCIgBAAQgBAAgBgBQAAAAgBAAQAAAAgBgBQAAAAgBgBQgCgBAAgDQAAgDACgDQACgCADAAQADAAADADQACADAAAEQAAAGgDAGQgDAGgEADg");
	this.shape_9.setTransform(155.775,74.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgPAuQgGgCgGgFIAFgIQAFAEAFACQAFADAHAAIAHgBQAEgCADgCQADgCACgEQACgEAAgGIAAgJQgEAFgFADQgGAEgHAAQgGAAgGgDQgFgCgEgEQgEgFgCgHQgDgFAAgIQAAgIADgHQACgGAEgFQAEgEAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgKIALAAIAABBQAAAJgDAFQgDAGgEADQgFAEgGABQgFACgGAAQgIAAgHgDgAgHgkQgEACgDAEQgDACgBAGQgCAEAAAGQAAAGACAEQABAEADADQADAEAEABQAEADAEAAIAGgBIAGgDIAFgDIADgFIAAgcIgDgEIgFgEIgGgCIgGgBQgEAAgEACg");
	this.shape_10.setTransform(149.925,72.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgGAAIgGABIgFACIgFADIgDAEIAAAxIgLAAIAAhDIALAAIAAAKIAEgEIAGgEIAGgDIAGgBQAWAAAAAWIAAAvg");
	this.shape_11.setTransform(142.2,70.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgEAuIAAhDIAJAAIAABDgAgEghQgCgCAAgCQAAgDACgDQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACADAAADQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_12.setTransform(136.775,69.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgOAhQgHgCgFgGIAFgHQAEADAGAEQAGACAGAAQAIAAAEgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgGABQgIgBgHgCg");
	this.shape_13.setTransform(131.85,70.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgCgEgBgGQABgFACgFQACgDAEgDQADgDAEgBQAEgBAFAAQAFAAAGACQAFADAFAEIAAgMQAAgHgFgEQgFgDgIAAQgKAAgJAJIgFgHQALgLAPAAQAGgBAEACQAFABADADQAEACACAFQACAEAAAGIAAAuIgKAAIAAgHQgJAIgMABIgJgBgAgMACQgEAFgBAGQABAHAEAEQAFAEAHAAQAFAAAEgCQAFgCAEgEIAAgNQgEgEgFgCQgEgBgFAAQgHAAgFACg");
	this.shape_14.setTransform(124.8,70.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AASAvIAAgtQAAgDgCgDQgBgDgCgCIgFgDIgGAAIgFABIgFACIgFADIgEAEIAAAxIgKAAIAAhdIAKAAIAAAkIAFgEIAFgEIAHgDIAHgBQAKAAAGAGQAFAFAAALIAAAvg");
	this.shape_15.setTransform(117.425,69.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgIAhQgGgDgFgEQgEgGgDgGQgCgHAAgHQAAgHACgGQADgHAEgEQAFgFAGgDQAGgCAHAAQAJAAAGADQAFAEAEAEIgHAHQgDgFgEgCQgFgCgFAAQgFAAgEACQgEACgDAEQgDADgCAFQgBAFAAAEQAAAGABAEQACAFADAEQADADAEADQAEACAFAAQALgBAGgIIAHAGQgEAFgFADQgGAEgJAAQgHgBgGgCg");
	this.shape_16.setTransform(110.175,70.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_17.setTransform(104.7,70.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgVAdQgGgFAAgLIAAgvIAKAAIAAAsIABAIQABADADABQACACACABIAHABQAFAAAFgEQAGgDADgEIAAgxIAKAAIAABDIgKAAIAAgJQgFAEgFADQgHAEgHAAQgKAAgFgGg");
	this.shape_18.setTransform(98.15,71.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_19.setTransform(90.525,72.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAtQgFgCgEgEQgEgGgCgGQgDgHAAgHQAAgJADgGQACgGAEgEQAEgFAFgDQAGgDAGABQAGAAAGADQAGADAEAFIAAgkIALAAIAABdIgLAAIAAgKQgEAFgFADQgGAEgHAAQgGgBgGgCgAgHgLQgEACgDAEQgDADgBAEQgCAFAAAGQAAAFACAFQABAEADAEQADADAEADQAEACAEAAQAGAAAGgEQAFgDADgEIAAgeQgDgEgFgEQgGgDgGAAQgEAAgEACg");
	this.shape_20.setTransform(78.425,69.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgHAAIgEABIgGACIgFADIgEAEIAAAxIgKAAIAAhDIAKAAIAAAKIAFgEIAFgEIAHgDIAHgBQAVAAAAAWIAAAvg");
	this.shape_21.setTransform(70.7,70.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgDgEABgGQgBgFADgFQACgDAEgDQADgDAEgBQAEgBAEAAQAHAAAFACQAGADAEAEIAAgMQAAgHgFgEQgFgDgIAAQgKAAgJAJIgFgHQALgLAPAAQAFgBAFACQAFABADADQAEACACAFQADAEgBAGIAAAuIgKAAIAAgHQgJAIgNABIgIgBgAgMACQgEAFAAAGQAAAHAEAEQAFAEAHAAQAFAAAFgCQAEgCAEgEIAAgNQgEgEgEgCQgFgBgFAAQgHAAgFACg");
	this.shape_22.setTransform(62.95,70.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAGgHQADADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEACgEIAEgFIAIgFQAFgBAFAAQAJAAAGACQAGADAEAFIgEAHQgEgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJACIAKAEQAFABADAEQADADAAAIIgCAHIgEAHQgEADgFABQgFABgHABQgHgBgHgCg");
	this.shape_23.setTransform(52.45,70.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAvIAAhdIAJAAIAABdg");
	this.shape_24.setTransform(47.725,69.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgMAjQgEgCgDgDQgEgDgCgEQgDgEABgGQgBgFADgFQACgDAEgDQADgDAEgBQAEgBAEAAQAHAAAFACQAGADAEAEIAAgMQAAgHgFgEQgFgDgIAAQgKAAgJAJIgFgHQALgLAPAAQAFgBAFACQAFABADADQAEACACAFQADAEgBAGIAAAuIgKAAIAAgHQgJAIgNABIgIgBgAgMACQgEAFgBAGQABAHAEAEQAEAEAIAAQAFAAAFgCQAEgCAEgEIAAgNQgEgEgEgCQgFgBgFAAQgIAAgEACg");
	this.shape_25.setTransform(42.25,70.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgOAhQgGgCgGgGIAFgHQAEADAGAEQAGACAGAAQAHAAAFgDQAEgDAAgFQAAgFgDgBIgIgFIgJgCIgKgDQgFgCgDgDQgDgEAAgGQAAgEABgEIAGgFIAIgFQAEgBAFAAQAJAAAGACQAGADAEAFIgFAHQgDgEgFgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEAEACIAHADIAJACIAKAEQAFABADAEQADADAAAIIgBAHIgGAHQgDADgFABQgFABgGABQgIgBgHgCg");
	this.shape_26.setTransform(35.4,70.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgCgHAAgHQAAgGACgHQACgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAHACQAGADAEAFQAFAFACAGQADAHgBAGQABAHgDAHQgCAGgFAGQgEAEgGADQgHACgHABQgHgBgGgCgAgJgXQgEADgCADQgEAEgBAFQgCAEABAEQgBAGACAEQABAFAEAEQACADAEACQAEACAFABQAFgBAEgCQAFgCACgDQADgEACgFQABgEABgGQgBgEgBgEQgCgFgDgEIgHgGQgEgCgFAAQgFAAgEACg");
	this.shape_27.setTransform(28.25,70.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_28.setTransform(20.475,72.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAhQgGgDgEgEQgFgGgCgGQgDgHABgHQgBgGADgHQACgGAFgFQAEgFAGgDQAHgCAGAAQAIAAAGACQAGADAEAFQAFAFACAGQACAHAAAGQAAAHgCAHQgCAGgFAGQgEAEgGADQgGACgIABQgGgBgHgCgAgIgXQgFADgCADQgDAEgCAFQgBAEgBAEQABAGABAEQACAFADAEQACADAFACQAEACAEABQAGgBAEgCQADgCADgDQAEgEABgFQACgEgBgGQABgEgCgEQgBgFgEgEIgGgGQgEgCgGAAQgEAAgEACg");
	this.shape_29.setTransform(12.25,70.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgQAiIAAhCIALAAIAAALQAEgFAFgEQAFgEAIAAIAAAMIgFgBIgFABIgFACIgEADIgDAFIAAAug");
	this.shape_30.setTransform(6.35,70.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgfAwIAAhdIALAAIAAAKQADgFAGgDQAGgEAHAAQAGAAAGADQAFACAEAFQAEAEADAHQACAHAAAIQAAAIgCAGQgDAGgEAFQgEAFgFACQgGACgGAAQgGAAgGgDQgGgDgEgFIAAAkgAgMgiQgFADgDAFIAAAdQADAFAFADQAGADAGAAQAEAAAEgCQAEgCADgDQADgEABgEQACgEAAgGQAAgGgCgEQgBgFgDgEQgDgDgEgCQgEgCgEAAQgGAAgGADg");
	this.shape_31.setTransform(-0.125,72.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgDAoQgEgEAAgIIAAgrIgLAAIAAgJIALAAIAAgTIAJAAIAAATIAOAAIAAAJIgOAAIAAApQAAAEACACQACADADAAIAEgBIADgCIADAIIgFADIgHABQgHAAgDgEg");
	this.shape_32.setTransform(-10.025,70.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AASAjIAAgrQAAgKgFgDQgDgDgIAAIgFABIgFACIgFADIgDAEIAAAxIgLAAIAAhDIALAAIAAAKIAEgEIAGgEIAGgDIAGgBQAWAAAAAWIAAAvg");
	this.shape_33.setTransform(-16,70.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgLAhQgHgCgEgFQgEgFgDgHQgDgGAAgIQAAgGADgHQACgGAEgFQAFgFAGgDQAGgCAGAAQAIAAAGACQAGADAFAFQADAFACAHQADAGAAAHIAAACIg2AAQABAGACADQABAFADADQADAEAEABQAFACAEAAQAHAAAFgCQAGgDAEgDIAEAHQgFAFgGACQgHACgJABQgGgBgGgCgAgJgYQgDACgDAEQgDADgBAEIgCAIIAsAAIgCgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_34.setTransform(-23.8,70.95);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAjAjIAAgtQAAgHgDgDQgCgEgHAAQgFAAgFADQgFADgDAEIAAAxIgJAAIAAgtQgBgHgCgDQgDgEgHAAQgFAAgFADQgFADgDAEIAAAxIgKAAIAAhDIAKAAIAAAKIAEgEIAFgDIAGgDQAEgCAEAAQAHAAAEAEQAEAEACAFIADgEIAGgFIAGgCIAHgCQAKAAAEAGQAFAFAAAKIAAAwg");
	this.shape_35.setTransform(-33.4,70.875);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AARAjIAAgrQAAgKgDgDQgFgDgGAAIgFABIgGACIgFADIgEAEIAAAxIgKAAIAAhDIAKAAIAAAKIAFgEIAFgEIAHgDIAGgBQAWAAAAAWIAAAvg");
	this.shape_36.setTransform(-42.95,70.875);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgPAiIAAhCIAKAAIAAALQAEgFAFgEQAGgEAGAAIAAAMIgDgBIgGABIgFACIgEADIgDAFIAAAug");
	this.shape_37.setTransform(-48.7,70.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgMAhQgFgCgFgFQgFgFgDgHQgCgGAAgIQAAgGACgHQADgGAFgFQAEgFAGgDQAGgCAHAAQAHAAAGACQAGADAEAFQAFAFACAHQACAGAAAHIAAACIg2AAQABAGABADQACAFADADQAEAEAEABQAEACAFAAQAFAAAGgCQAGgDADgDIAGAHQgGAFgHACQgGACgIABQgHgBgHgCgAgJgYQgEACgCAEQgDADgBAEIgCAIIArAAIgBgIQgBgEgDgDQgDgEgEgCQgEgBgGAAQgEAAgFABg");
	this.shape_38.setTransform(-55.35,70.95);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgFAiIgchDIAMAAIAVA3IAWg3IAMAAIgcBDg");
	this.shape_39.setTransform(-62.725,70.975);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgNAhQgGgDgFgEQgEgGgCgGQgDgHAAgHQAAgGADgHQACgGAEgFQAFgFAGgDQAGgCAHAAQAIAAAGACQAGADAFAFQAEAFACAGQACAHABAGQgBAHgCAHQgCAGgEAGQgFAEgGADQgGACgIABQgHgBgGgCgAgJgXQgEADgDADQgDAEgBAFQgBAEAAAEQAAAGABAEQABAFADAEQADADAEACQAEACAFABQAGgBADgCQAEgCAEgDQADgEABgFQACgEAAgGQAAgEgCgEQgBgFgDgEIgIgGQgDgCgGAAQgFAAgEACg");
	this.shape_40.setTransform(-70.15,70.95);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgMAtQgJgDgHgHQgGgGgEgKQgDgIAAgLQAAgKADgJQAEgJAGgGQAHgGAJgEQAIgDAJAAQANAAAJAEQAJAFAGAIIgKAGQgEgGgHgEQgHgDgJAAQgGAAgGADQgIADgEAFQgFAFgDAGQgDAIAAAHQAAAIADAHQADAHAFAFQAEAFAIADQAGADAGAAIAIgBIAIgCIAFgEIAFgDIAAgTIggAAIAAgJIArAAIAAAgQgGAIgKAEQgJAFgMgBQgJABgIgEg");
	this.shape_41.setTransform(-79.2,69.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-86.2,61.3,319.5,18), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape.setTransform(245.625,130.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_1.setTransform(235.325,130.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_2.setTransform(225.2,130.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAiA0IAAhKIgdBKIgJAAIgehKIAABKIgWAAIAAhnIAfAAIAZBAIAZhAIAgAAIAABng");
	this.shape_3.setTransform(213.775,130.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_4.setTransform(201.325,130.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHAAAKQAAAJgDAHQgDAFgFAEQgGAEgFABIAXAogAgUgEIAXAAQAHAAAEgDQAEgEABgHQgBgGgEgEQgEgEgHAAIgXAAg");
	this.shape_5.setTransform(190.8,130.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_6.setTransform(181.1,130.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgNA0IgohnIAZAAIAcBPIAdhPIAZAAIgoBng");
	this.shape_7.setTransform(170.975,130.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_8.setTransform(159.625,130.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVAvQgNgGgHgMQgIgMAAgRQAAgQAIgMQAHgMANgGQAMgHAPAAQAKAAAJADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAFgCQAHgDADgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgMgHg");
	this.shape_9.setTransform(147.85,130.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAYA0IAAgsIgwAAIAAAsIgWAAIAAhnIAWAAIAAApIAwAAIAAgpIAXAAIAABng");
	this.shape_10.setTransform(132.5,130.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_11.setTransform(122.175,130.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_12.setTransform(115.45,130.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIAUBKIAShKIAZAAIgeBng");
	this.shape_13.setTransform(106.1,130.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape_14.setTransform(90.075,130.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AARA0IgegqIgJAKIAAAgIgWAAIAAhnIAWAAIAAAuIAkguIAcAAIgqAxIAtA2g");
	this.shape_15.setTransform(80.975,130.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHAAAKQAAAJgDAHQgDAFgFAEQgGAEgFABIAXAogAgUgEIAXAAQAHAAAEgDQAEgEABgHQgBgGgEgEQgEgEgHAAIgXAAg");
	this.shape_16.setTransform(70.65,130.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_17.setTransform(59.375,130.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_18.setTransform(46.15,130.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgQAdQgHgEgFgIQgEgIAAgJQAAgJAEgHQAFgIAHgDQAIgFAIgBQAJABAIAFQAHADAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAEQgIAEgJABQgIgBgIgEgAgNgYQgHAFgDAGQgEAGAAAHQAAAIAEAGQADAHAHAEQAGADAHAAQAIAAAGgDQAHgEADgHQAEgGAAgIQAAgHgEgGQgDgGgHgFQgGgDgIAAQgHAAgGADgAAJATIgJgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAADADQAEADAAAFQAAAFgCACIgEADIgDABIAKAPgAgGAAIAJAAIAFgBQACgCAAgEQAAgCgCgCQgDgCgCAAIgJAAg");
	this.shape_19.setTransform(31.025,128.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_20.setTransform(22.75,130.925);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgWAvQgMgGgHgMQgIgMAAgRQAAgQAIgMQAHgMAMgGQANgHAPAAQALAAAIADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAGgCQAFgDAEgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgNgHg");
	this.shape_21.setTransform(12.25,130.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_22.setTransform(1.325,130.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AATA0IgThHIgRBHIgYAAIgehnIAZAAIASBKIAVhKIAQAAIAUBKIAShKIAZAAIgeBng");
	this.shape_23.setTransform(-11.25,130.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_24.setTransform(-22.85,130.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_25.setTransform(-33.325,130.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-41.1,121.8,293.40000000000003,19.700000000000003), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,296), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._5Multiple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение11();
	this.instance.parent = this;
	this.instance.setTransform(-28,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._5Multiple, new cjs.Rectangle(-28,-23,54,44), null);


(lib._4Quotes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение10();
	this.instance.parent = this;
	this.instance.setTransform(-25,-22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._4Quotes, new cjs.Rectangle(-25,-22,49,43), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgHAWQgEgCgDgDQgEgDgBgEQgBgFAAgFIABgIQABgEAEgEIAGgFQAFgBADAAQAGAAADABQAEACADAEQADADABAEQABAFABAEIAAABIgjAAIABAGQABADACACIAFADQADACADAAQAEAAADgCIAGgEIADAFQgDADgEACQgFABgFAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgCgFIgGgDQgCgCgEAAQgDAAgCACg");
	this.shape.setTransform(168.2,25.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_1.setTransform(164.6,24.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgGAdQgEgCgDgDIAAAGIgHAAIAAg8IAHAAIAAAXQADgDAEgCQAEgCADAAIAIABQAEACACADIAEAHQACAEAAAFQAAAFgCAFQgBAEgDADQgCADgEACIgIABQgEAAgDgCgAgHgGQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgDIABgHIgBgHQgBgCgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_2.setTransform(160.975,24.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgCgDAAgDQAAgEACgDQABgCACgBIAGgDIAFgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgDgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAGADQACACABADIACAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQADACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgDACg");
	this.shape_3.setTransform(155.7,25.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_4.setTransform(152.35,24.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_5.setTransform(150.275,24.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgCgDAAgDQAAgEACgDQABgCACgBIAGgDIAFgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgDgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAGADQACACABADIACAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQADACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgDACg");
	this.shape_6.setTransform(146.7,25.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgDAWIgSgrIAHAAIAOAjIAPgjIAHAAIgSArg");
	this.shape_7.setTransform(142.125,25.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgHAWQgEAAgCgCQgCgCgBgDQgBgDAAgDQAAgEABgDQABgCACgBIAGgDIAFgBQADAAAEABQAEACADACIAAgHQAAgFgDgCQgEgCgEAAQgIAAgFAGIgDgFQAGgHALAAIAGAAIAFADQADACACADIABAHIAAAdIgHAAIAAgFQgGAGgIAAIgFgBgAgHACQgEACAAAFQAAAEAEADQACACAFAAIAGgBQAEgBACgDIAAgJIgGgEIgGAAQgFAAgCACg");
	this.shape_8.setTransform(137.35,25.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_9.setTransform(130.425,25.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAMAXIAAgcQAAgGgDgDQgDgCgFAAIgCABIgEABIgEADIgBACIAAAgIgIAAIAAgsIAIAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_10.setTransform(125.8,25.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgJAWQgEgCgDgEIgDgHQgCgEAAgFIACgIIADgIIAHgFQAFgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQABACADACQAEABACAAQAEAAACgBIAFgEIADgGIABgGIgBgGIgDgFIgFgEQgCgBgEAAQgCAAgEABg");
	this.shape_11.setTransform(120.65,25.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_12.setTransform(116.975,24.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_13.setTransform(114.625,25.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_14.setTransform(110.775,26.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgIAWQgFgCgCgEIgFgHQgBgEAAgFIABgIIAFgIIAHgFQAEgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQACACADACQADABACAAQADAAADgBIAFgEIACgGIABgGIgBgGIgCgFIgFgEQgDgBgDAAQgCAAgDABg");
	this.shape_15.setTransform(105.4,25.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_16.setTransform(170.825,15.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AALAXIAAgcQABgGgDgDQgDgCgFAAIgCABIgEABIgDADIgCACIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_17.setTransform(166.9,16.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFAAgFIACgIQACgEACgEIAIgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape_18.setTransform(161.75,16.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAXAXIAAgeQAAgEgCgCQgBgDgFAAQgDAAgEACIgFAFIAAAgIgGAAIAAgeQAAgEgBgCQgCgDgFAAQgDAAgDACQgEACgBADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIADgCIAEgCIAFgBQAFAAADACQACADABADIACgDIAEgCIAEgCIAFgBQAGAAADADQADAEAAAHIAAAfg");
	this.shape_19.setTransform(155.375,16.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgPAfIgCAAIABgHIACABIACAAIADgBQACgBABgDIADgGIgSgsIAHAAIAOAjIAPgjIAHAAIgWA0QgBAFgEACQgDACgEAAIgDAAg");
	this.shape_20.setTransform(149.425,17.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgIAWQgCAAgCgCQgDgCgBgDQgBgDgBgDQABgEABgDQABgCADgBIAEgDIAGgBQADAAAFABQADACADACIAAgHQAAgFgEgCQgCgCgGAAQgGAAgGAGIgEgFQAIgHAJAAIAHAAIAGADQACACABADIABAHIAAAdIgGAAIAAgFQgGAGgIAAIgGgBgAgIACQgCACAAAFQAAAEACADQADACAFAAIAHgBQADgBACgDIAAgJIgFgEIgHAAQgFAAgDACg");
	this.shape_21.setTransform(144.6,16.475);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_22.setTransform(139.825,17.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFAAgFIACgIQACgEACgEIAIgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape_23.setTransform(132.05,16.475);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_24.setTransform(128.4,15.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_25.setTransform(124.875,17.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_26.setTransform(121.075,15.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_27.setTransform(118.725,15.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_28.setTransform(116.35,15.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOATQgDgDgBgHIAAgfIAHAAIAAAdIABAEIACAEIAEABIADABQADAAAEgCQADgCADgDIAAggIAGAAIAAAsIgGAAIAAgHIgHAGQgFACgDAAQgIAAgDgEg");
	this.shape_29.setTransform(112.75,16.525);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAXAfIAAgyIgVAyIgDAAIgUgyIAAAyIgIAAIAAg9IALAAIASAuIATguIALAAIAAA9g");
	this.shape_30.setTransform(106.475,15.625);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgPAfIgCAAIABgHIACABIACAAIADgBQACgBABgDIADgGIgSgsIAHAAIAOAjIAPgjIAHAAIgWA0QgBAFgEACQgDACgEAAIgDAAg");
	this.shape_31.setTransform(259.125,26.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgKAXIAAgsIAHAAIAAAHQADgDADgCQADgDAFAAIAAAHIgDAAIgDABIgEABIgCADIgCACIAAAfg");
	this.shape_32.setTransform(255.575,25.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgHAWQgEgCgDgDQgDgDgCgEQgBgFgBgFIACgIQACgEADgEIAHgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQABAFABAEIAAABIgjAAIABAGQABADADACIAEADQADACADAAQAEAAADgCIAGgEIAEAFQgEADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgDAFIAAAFIAcAAIgBgFIgCgFIgGgDQgCgCgEAAQgCAAgDACg");
	this.shape_33.setTransform(251.2,25.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAWIgSgrIAHAAIAOAjIAPgjIAHAAIgSArg");
	this.shape_34.setTransform(246.375,25.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgCAeIAAgrIAGAAIAAArgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_35.setTransform(243.025,24.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_36.setTransform(241,24.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFABgFIABgIQACgEACgEIAHgFQAFgBADAAQAGAAADABQAFACACAEQADADABAEQACAFAAAEIAAABIgjAAIABAGQABADACACIAFADQADACACAAQAEAAAEgCIAHgEIACAFQgDADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_37.setTransform(237.3,25.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_38.setTransform(231.925,24.875);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_39.setTransform(224.225,24.875);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AALAXIAAgcQAAgGgCgDQgDgCgFAAIgCABIgEABIgDADIgCACIAAAgIgIAAIAAgsIAIAAIAAAHIACgDIAEgDIAEgBIAEgBQAOAAAAAPIAAAeg");
	this.shape_40.setTransform(219.2,25.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgIAWQgDAAgBgCQgDgCgBgDQgCgDAAgDQAAgEACgDQABgCADgBIAEgDIAGgBQAEAAADABQAEACADACIAAgHQAAgFgEgCQgCgCgGAAQgGAAgGAGIgDgFQAGgHALAAIAGAAIAGADQACACABADIABAHIAAAdIgGAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQAEACAEAAIAGgBQADgBADgDIAAgJIgGgEIgGAAQgEAAgEACg");
	this.shape_41.setTransform(214.1,25.675);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgJAeQgEgBgEgEIADgFQADADADACQAEABAEAAIAFgBIAEgCIAEgEIABgGIAAgHIgGAGQgEACgEAAIgIgBQgEgCgCgDQgDgDgBgEQgCgDAAgGQAAgFACgEQABgFADgDQACgDAEgBQADgCAFAAQADAAAEACQAEACADAEIAAgHIAHAAIAAAqQAAAGgCAEQgCADgDADIgHADIgHABQgFAAgEgCgAgEgXQgDABgCACIgDAFIgBAHIABAHIADAEQACADADABQACABADAAIAEAAIADgCIAEgCIACgDIAAgTIgCgCIgEgDIgDgBIgEgBQgDAAgCACg");
	this.shape_42.setTransform(277.325,17.325);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AAMAXIAAgcQgBgGgCgDQgDgCgEAAIgEABIgDABIgEADIgCACIAAAgIgHAAIAAgsIAHAAIAAAHIADgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_43.setTransform(272.25,16.425);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_44.setTransform(268.675,15.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_45.setTransform(265.175,17.275);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AgUAfIAAg8IAHAAIAAAGQADgDADgCQAEgCAEAAQAFAAADABQAEACACADQADADACAEIABAKIgBAJQgCAEgDADQgCADgEACQgDABgFAAQgDAAgEgCQgEgCgDgDIAAAXgAgHgWQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgCIABgHIgBgHQgBgDgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_46.setTransform(259.925,17.275);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_47.setTransform(256.075,15.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("AAMAfIAAgeIgBgDIgCgEIgEgBIgDgBIgEABIgDABIgDADIgDACIAAAgIgGAAIAAg9IAGAAIAAAYIADgDIAEgDIAEgBIAEgBQAIAAADAEQAEADAAAHIAAAfg");
	this.shape_48.setTransform(252.55,15.625);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_49.setTransform(247.775,16.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgDgDgBgEQgBgFAAgFIABgIQABgEADgEIAHgFQAFgBAEAAQAEAAAEABQAEACADAEQADADABAEQABAFAAAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAEAAAEgCIAHgEIADAFQgDADgFACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_50.setTransform(240.7,16.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AgDAfIAAg9IAHAAIAAA9g");
	this.shape_51.setTransform(237.05,15.625);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#333333").s().p("AgGAdQgEgCgDgDIAAAGIgHAAIAAg8IAHAAIAAAXQADgDAEgCQAEgCADAAIAIABQAEACACADIAEAHQACAEAAAFQAAAFgCAFQgBAEgDADQgCADgEACIgIABQgEAAgDgCgAgHgGQgEACgCADIAAATQACADAEACQADACAEAAQADAAACgBQADgBACgDQACgCABgDIABgHIgBgHQgBgCgCgCQgCgDgDgBQgCgBgDAAQgEAAgDACg");
	this.shape_52.setTransform(233.475,15.675);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#333333").s().p("AgCAeIAAgsIAGAAIAAAsgAgCgVQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIACgBIADABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDABIgCgBg");
	this.shape_53.setTransform(229.675,15.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("AAOAWIgOgSIgMASIgIAAIARgWIgQgVIAIAAIALARIAMgRIAIAAIgQAVIARAWg");
	this.shape_54.setTransform(226.4,16.475);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFABgFIABgIQACgEACgEIAHgFQAFgBADAAQAGAAADABQAFACACAEQADADABAEQACAFAAAEIAAABIgjAAIABAGQABADACACIAFADQADACACAAQAEAAAEgCIAHgEIACAFQgDADgEACQgEABgGAAQgEAAgEgBgAgFgPIgFADIgCAFIgBAFIAcAAIgBgFIgDgFIgEgDQgDgCgEAAQgDAAgCACg");
	this.shape_55.setTransform(221.55,16.475);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#333333").s().p("AgDAfIAAg9IAGAAIAAA9g");
	this.shape_56.setTransform(217.9,15.625);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#333333").s().p("AgTAfIAAg9IAnAAIAAAHIgfAAIAAAUIAfAAIAAAGIgfAAIAAAcg");
	this.shape_57.setTransform(214.525,15.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_58.setTransform(64.175,25.675);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#333333").s().p("AALAfIAAgeIAAgDIgCgEIgEgBIgDgBIgEABIgDABIgDADIgDACIAAAgIgGAAIAAg9IAGAAIAAAYIADgDIAEgDIAEgBIAEgBQAIAAADAEQADADABAHIAAAfg");
	this.shape_59.setTransform(59.6,24.825);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_60.setTransform(55.725,25.125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#333333").s().p("AAMAXIAAgcQgBgGgCgDQgDgCgEAAIgEABIgDABIgDADIgDACIAAAgIgGAAIAAgsIAGAAIAAAHIADgDIAEgDIAEgBIAEgBQAPAAAAAPIAAAeg");
	this.shape_61.setTransform(51.85,25.625);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#333333").s().p("AgJAWQgDgCgDgEIgFgHQgBgEAAgFIABgIIAFgIIAGgFQAFgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQABACAEACQADABACAAQADAAADgBIAFgEIADgGIAAgGIAAgGIgDgFIgFgEQgDgBgDAAQgCAAgDABg");
	this.shape_62.setTransform(46.7,25.675);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#333333").s().p("AAXAXIAAgeQAAgEgCgCQgBgDgFAAQgDAAgEACIgFAFIAAAgIgGAAIAAgeQAAgEgBgCQgCgDgFAAQgDAAgDACQgEACgBADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIADgCIAEgCIAFgBQAFAAADACQACADABADIACgDIAEgCIAEgCIAFgBQAGAAADADQADAEAAAHIAAAfg");
	this.shape_63.setTransform(40.275,25.625);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#333333").s().p("AgJAdQgEgCgDgFQgDgEgBgGIgCgMQAAgFACgGQABgGADgEIAIgHQAFgDAFAAQAGAAAFACQAEACACAEIgDAFIgGgEQgDgCgFAAQgDAAgDACQgEACgCAEIgDAHIgBAJIAAAAIAAACIADgDIAEgDIAFgCIAFgBIAHABQAEACADACQADACABADQACAEAAAFQAAAEgCADQgBAEgDADQgDADgEABQgEACgFAAQgFAAgFgDgAgHABQgEADgDAEIACAGIACAFIAFAEQADACADAAQADAAADgBIAEgDIADgEIABgFIgBgGIgDgEIgFgCIgFAAQgEAAgEABg");
	this.shape_64.setTransform(31.525,24.825);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#333333").s().p("AgKAXIAAgsIAHAAIAAAHQADgDADgCQADgDAFAAIAAAHIgDAAIgDABIgEABIgCADIgCACIAAAfg");
	this.shape_65.setTransform(25.125,25.625);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#333333").s().p("AgJAWQgEgCgDgEIgDgHQgCgEAAgFIACgIIADgIIAHgFQAFgBAEAAQAFAAAEABIAHAFQADAEABAEIACAIQAAAFgCAEQgBAEgDADQgDAEgEACQgEABgFAAQgEAAgFgBgAgGgPIgEAEIgDAFIgBAGIABAGQABAEACACQABACADACQAEABACAAQAEAAACgBIAFgEIADgGIABgGIgBgGIgDgFIgFgEQgCgBgEAAQgCAAgEABg");
	this.shape_66.setTransform(20.75,25.675);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#333333").s().p("AgGAfIAAglIgIAAIAAgGIAIAAIAAgEQAAgHADgDQADgEAFAAIAFABQADAAACACIgDAFIgCgCIgDAAQgEAAgCACQgBACAAAEIAAAEIAJAAIAAAGIgJAAIAAAlg");
	this.shape_67.setTransform(17.075,24.775);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#333333").s().p("AgIAeQgEgCgCgDQgDgDgBgEQgCgFAAgFQAAgFACgEQABgEADgDQACgDAEgCQADgBAFAAQADAAAEACQAEACADADIAAgXIAHAAIAAA8IgHAAIAAgGQgDADgDACQgEACgEAAIgIgBgAgEgHQgDABgCADQgCACgBACIgBAHIABAHQABADACACQACADADABQACABADAAQAEAAADgCQAEgCACgDIAAgTQgCgDgEgCQgDgCgEAAQgDAAgCABg");
	this.shape_68.setTransform(62.275,15.675);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#333333").s().p("AgCAfIAAg9IAGAAIAAA9g");
	this.shape_69.setTransform(58.75,15.625);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgCgDgCgEQgCgFAAgFIACgIQACgEACgEIAIgFQADgBAFAAQAEAAAFABQAEACACAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACADAAQADAAAEgCIAGgEIAEAFQgDADgFACQgEABgGAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgFgDQgCgCgEAAQgCAAgDACg");
	this.shape_70.setTransform(55.1,16.475);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#333333").s().p("AAMAfIAAgeIgBgDIgCgEIgEgBIgDgBIgEABIgDABIgDADIgDACIAAAgIgHAAIAAg9IAHAAIAAAYIADgDIAEgDIAEgBIAEgBQAHAAAEAEQAEADAAAHIAAAfg");
	this.shape_71.setTransform(49.95,15.625);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#333333").s().p("AgJAWQgEgCgEgEIAEgFIAGAFQAEACAEAAQAFAAACgCQADgDAAgDQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgCIgGgCIgGgCIgFgDQgDgCAAgFIACgFIADgEIAFgCIAGgBQAGAAAEABIAHAFIgEAFQgCgDgDgBQgEgCgEAAQgDAAgDACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAIAFACIAGACIAHACIAFADQACADAAAEIgBAFQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_72.setTransform(42.775,16.475);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#333333").s().p("AgHAWQgFgCgDgDQgDgDgBgEQgCgFAAgFIACgIQABgEADgEIAIgFQAEgBAEAAQAFAAAEABQADACADAEQADADABAEQACAFgBAEIAAABIgjAAIACAGQABADADACIAEADQADACACAAQAEAAAEgCIAHgEIADAFQgDADgFACQgFABgFAAQgEAAgEgBgAgFgPIgEADIgEAFIgBAFIAdAAIgBgFIgDgFIgEgDQgDgCgEAAQgCAAgDACg");
	this.shape_73.setTransform(38.1,16.475);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#333333").s().p("AgCAaQgCgDAAgFIAAgcIgIAAIAAgGIAIAAIAAgMIAFAAIAAAMIAKAAIAAAGIgKAAIAAAbQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAIADgBIACgBIACAFIgEACIgFABQgEAAgCgDg");
	this.shape_74.setTransform(34.225,15.925);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#333333").s().p("AgIAWQgFgCgCgEIgFgHQgBgEAAgFIABgIIAFgIIAHgFQAEgBAEAAQAFAAAEABIAHAFQADAEACAEIABAIQAAAFgBAEQgCAEgDADQgDAEgEACQgEABgFAAQgEAAgEgBgAgFgPIgFAEIgDAFIgBAGIABAGQABAEACACQACACADACQADABACAAQAEAAACgBIAFgEIACgGIABgGIgBgGIgCgFIgFgEQgCgBgEAAQgCAAgDABg");
	this.shape_75.setTransform(30.25,16.475);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#333333").s().p("AgOATQgEgDABgHIAAgfIAHAAIAAAdIAAAEIACAEIADABIAFABQADAAADgCQADgCACgDIAAggIAIAAIAAAsIgIAAIAAgHIgGAGQgEACgFAAQgGAAgEgEg");
	this.shape_76.setTransform(25.05,16.525);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#333333").s().p("AARAaIgIAEIgJABQgFAAgGgDQgGgCgEgEQgEgEgCgGQgCgGAAgGQAAgHACgGQACgFAEgFQAEgEAGgCQAFgDAGAAQAHAAAFADQAGACAFAEQADAFACAFQACAGAAAHQAAAGgCAGQgCAGgDAEIAFAGIgFAFgAgIgXQgFACgDADIgEAIQgBAFAAAFQAAAEABAFIAEAIQADADAFACQAEACAEAAQAGAAAGgDIgJgKIAFgEIAJAJQADgDABgEQACgFAAgEQAAgFgCgFQgBgFgDgDQgEgDgEgCQgDgCgGAAQgEAAgEACg");
	this.shape_77.setTransform(18.95,15.725);

	this.instance = new lib._5Multiple();
	this.instance.parent = this;
	this.instance.setTransform(88.6,20.95,0.4749,0.4749,0,0,0,0.1,-0.4);

	this.instance_1 = new lib._1flexibleShipping();
	this.instance_1.parent = this;
	this.instance_1.setTransform(195.4,20.2,0.4749,0.4749,0,0,0,0.2,-0.4);

	this.instance_2 = new lib._4Quotes();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2.3,21.2,0.4749,0.4749,0,0,0,0.1,0.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_78.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_78},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-9.6,9.6,291.70000000000005,29.699999999999996), null);


// stage content:
(lib._336x280_Government = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_766 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(766).call(this.frame_766).wait(122));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape.setTransform(168,140);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_1.setTransform(168,140);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_2.setTransform(168,140);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_3.setTransform(168,140);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_4.setTransform(168,140);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_5.setTransform(168,140);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_6.setTransform(168,140);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_7.setTransform(168,140);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_8.setTransform(168,140);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(8));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(167.95,17.9,0.7999,0.7999);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(888));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-137.8,-29.5,-71.9,8.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_9.setTransform(167.825,250.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-129.1,-26.5,-63.3,11.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_10.setTransform(167.825,250.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-120.5,-23.4,-54.6,14.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_11.setTransform(167.825,250.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-111.8,-20.4,-46,17.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_12.setTransform(167.825,250.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-103.2,-17.4,-37.3,20.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_13.setTransform(167.825,250.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-94.5,-14.4,-28.7,23.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_14.setTransform(167.825,250.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.8,-11.4,-20,26.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_15.setTransform(167.825,250.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-77.2,-8.4,-11.3,29.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_16.setTransform(167.825,250.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.5,-5.4,-2.7,32.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_17.setTransform(167.825,250.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-59.9,-2.4,6,35.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_18.setTransform(167.825,250.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.2,0.7,14.6,38.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_19.setTransform(167.825,250.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-42.6,3.7,23.3,41.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_20.setTransform(167.825,250.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-33.9,6.7,31.9,44.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_21.setTransform(167.825,250.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.3,9.7,40.5,47.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_22.setTransform(167.825,250.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,12.7,49.2,50.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_23.setTransform(167.825,250.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-8,15.8,57.8,53.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_24.setTransform(167.825,250.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,18.8,66.5,56.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_25.setTransform(167.825,250.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],9.3,21.8,75.1,59.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_26.setTransform(167.825,250.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],18,24.8,83.8,62.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_27.setTransform(167.825,250.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.6,27.8,92.5,65.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_28.setTransform(167.825,250.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],35.3,30.8,101.1,68.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_29.setTransform(167.825,250.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],43.9,33.9,109.8,71.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_30.setTransform(167.825,250.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],52.6,36.9,118.4,74.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_31.setTransform(167.825,250.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],61.2,39.9,127.1,77.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_32.setTransform(167.825,250.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],69.9,42.9,135.7,80.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_33.setTransform(167.825,250.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).wait(234));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.instance_2 = new lib.t122();
	this.instance_2.parent = this;
	this.instance_2.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},123).to({state:[{t:this.instance_1}]},173).to({state:[{t:this.instance_2}]},123).to({state:[{t:this.instance_1}]},173).to({state:[{t:this.instance_2}]},123).wait(173));

	// t11
	this.instance_3 = new lib.t11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(168,117.25,1,1,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(888));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(168,213.4,1,1,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(123).to({y:215.6},0).wait(173).to({y:213.4},0).wait(123).to({y:215.6},0).wait(173).to({y:213.4},0).wait(123).to({y:215.6},0).wait(173));

	// Слой_5
	this.instance_5 = new lib.icons();
	this.instance_5.parent = this;
	this.instance_5.setTransform(168.8,170.55,1.12,1.12,0,0,0,136.4,18.6);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(26).to({_off:false},0).to({alpha:1},6).to({_off:true},91).wait(199).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(199).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(173));

	// Слой_14
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("A6PJ/IAAz8MA0fAAAIAAT8g");
	this.shape_34.setTransform(168,252.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("A6PJ+IAAz8MA0fAAAIAAT8g");
	this.shape_35.setTransform(168,243.25);
	this.shape_35._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(20).to({y:247.7},0).to({_off:true},1).wait(2).to({_off:false,y:234.3},0).wait(1).to({y:229.8},0).wait(1).to({y:225.3},0).to({_off:true},1).wait(97).to({_off:false,y:252.2},0).wait(193).to({y:247.7},0).to({_off:true},1).wait(2).to({_off:false,y:234.3},0).wait(1).to({y:229.8},0).wait(1).to({y:225.3},0).to({_off:true},1).wait(97).to({_off:false,y:252.2},0).wait(193).to({y:247.7},0).to({_off:true},1).wait(2).to({_off:false,y:234.3},0).wait(1).to({y:229.8},0).wait(1).to({y:225.3},0).to({_off:true},1).wait(97).to({_off:false,y:252.2},0).wait(173));
	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(21).to({_off:false},0).wait(1).to({y:238.75},0).to({_off:true},1).wait(3).to({_off:false,y:220.85},0).wait(1).to({y:216.35},0).to({_off:true},96).wait(194).to({_off:false,y:243.25},0).wait(1).to({y:238.75},0).to({_off:true},1).wait(3).to({_off:false,y:220.85},0).wait(1).to({y:216.35},0).to({_off:true},96).wait(194).to({_off:false,y:243.25},0).wait(1).to({y:238.75},0).to({_off:true},1).wait(3).to({_off:false,y:220.85},0).wait(1).to({y:216.35},0).to({_off:true},96).wait(173));

	// Слой_2
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAOAiIAAgnQAAgHgEgDQgDgCgGAAQgDAAgFACQgDACgCADIAAAsIgSAAIAAhBIASAAIAAAIIAFgEIAHgEQAEgCAFAAQAMAAAFAGQAFAGAAAJIAAAug");
	this.shape_36.setTransform(313.25,174.975);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_37.setTransform(305.375,175.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_38.setTransform(299.725,173.675);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQABADABACQAAABABAAQAAAAABABQAAAAABAAQABAAABAAIADAAIADgCIADAOIgGADIgJABQgHAAgFgFg");
	this.shape_39.setTransform(295.65,174.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgRAgQgGgCgDgFQgDgFgBgHQABgIADgEQADgFAGgBQAFgCAGAAQAGAAAEACQAGACADADIAAgIQAAgFgEgCQgDgEgHAAQgEAAgGADQgEABgEAEIgHgMQAGgFAHgDQAIgCAHAAQAHAAAHACQAGACAFAGQADAFABAJIAAAqIgSAAIAAgHQgEAEgFACQgEACgGAAQgGAAgFgCgAgIAFQgEADAAAFQAAAFAEADQADACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgCQgEgBgDAAQgFAAgDACg");
	this.shape_40.setTransform(289.45,175.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgNAeQgIgEgEgIQgFgIABgKQgBgJAFgIQAEgIAIgEQAIgFAKABQAGAAAFACQAFABAEACIAFAHIgLAKQgDgEgDgBQgEgCgEAAQgHAAgFAFQgFAFAAAIQAAAJAFAFQAFAFAHAAQAEAAAEgCQADgBADgEIALALIgFAGIgJAEQgFABgGAAQgKABgIgFg");
	this.shape_41.setTransform(282.65,175.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgZAcQgFgFAAgKIAAguIASAAIAAAnQAAAHACADQAEADAFgBQAEAAAEgCIAHgFIAAgsIARAAIAABBIgRAAIAAgIQgEAEgFADQgGADgIAAQgLAAgFgGg");
	this.shape_42.setTransform(275.2,175.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgSAqQgHgEgEgIQgEgHAAgLQAAgLAEgHQAEgHAHgFQAGgEAIAAQAGAAAEADQAGACAEAFIAAghIARAAIAABaIgRAAIAAgJQgEAFgFADQgFACgGAAQgIAAgGgEgAgKgBQgFAEAAAJQAAAIAFAGQAEAFAHAAQAEAAAFgCQAEgCACgEIAAgXQgCgCgEgCQgFgCgEAAQgHAAgEAFg");
	this.shape_43.setTransform(267.05,173.875);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgfAuIAAhaIA/AAIAAAQIgsAAIAAAUIArAAIAAAPIgrAAIAAAWIAsAAIAAARg");
	this.shape_44.setTransform(259.425,173.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgFQgEgHAAgIQAAgHADgFQACgFAFgDIAKgGIgFgJIgBgKQAAgGADgFQADgFAGgDQAGgCAIgBQAFAAAFADQAGACADAEQADAEAAAHQAAAGgDAFQgDAEgFAEIgKAFIADAFIAEAEIAIAJIAFgJIADgHIAOAFIgGALIgHALIAJAJIAJAKIgWAAIgEgEIgDgDQgFADgHADQgFACgHAAQgIAAgHgDgAgUALQgDAEAAAEQAAAFACADQACADADABQAEACADAAIAHgBIAGgDIgFgHIgFgEIgEgGIgFgHQgDADgCADgAgHgfQgDADAAAFIABAGIADAFQAGgCACgDQAEgEAAgEQAAgFgCgBQgCgCgDAAQgEAAgCACg");
	this.shape_45.setTransform(247.525,173.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAHgMIAHAEIAIAEIAHABQAGAAACgCQADgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgDgDQgEgEgBgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAJAAAGACQAGADAFAEIgGAMQgEgDgEgDQgGgBgGgBIgGACQgDACAAADQAAACAEABIAJADIALADQAGACAEAEQAEAEAAAHQAAAGgEAFQgDAFgGADQgHACgJAAQgHAAgIgCg");
	this.shape_46.setTransform(236.15,175.05);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgIAuIAAhaIARAAIAABag");
	this.shape_47.setTransform(231.225,173.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_48.setTransform(225.575,175.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_49.setTransform(217.725,175.05);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AANAuIAAgpQAAgFgCgDQgEgDgFABQgEgBgEADQgEACgDACIAAAtIgRAAIAAhaIARAAIAAAhIAGgEIAHgFQAEgBAGAAQALAAAFAGQAFAFAAAKIAAAug");
	this.shape_50.setTransform(209.9,173.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgNAeQgHgEgFgIQgEgIgBgKQABgJAEgIQAFgIAHgEQAIgFAJABQAHAAAFACQAFABADACIAGAHIgLAKQgCgEgEgBQgEgCgEAAQgHAAgFAFQgEAFgBAIQABAJAEAFQAFAFAHAAQAEAAAEgCQAEgBACgEIALALIgGAGIgIAEQgFABgHAAQgJABgIgFg");
	this.shape_51.setTransform(202.6,175.05);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgHIALgOQAFAEAHAFQAIADAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgDgGAAIgLgEIgNgEQgGgDgEgFQgDgEgBgJQABgIAEgGQAEgGAIgEQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgDgGAAQgGAAgDADQgEACAAAEQABAEADACQAEACAGABIALAEQAHABAGADQAGADAEAEQADAFABAJQAAAIgEAHQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_52.setTransform(194.975,173.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIAEIAIABQAGAAACgCQADgCAAgDQAAgDgEgBIgIgDIgMgDQgGgCgDgDQgFgEAAgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAIAAAHACQAHADAEAEIgHAMQgCgDgGgDQgFgBgGgBIgHACQgCACAAADQAAACAEABIAJADIALADQAGACAEAEQAEAEAAAHQAAAGgDAFQgDAFgHADQgGACgKAAQgHAAgIgCg");
	this.shape_53.setTransform(154.95,175.05);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAHgEAKAAQAKgBAHAFQAHAEAEAJQAFAIAAAKIAAADIgxAAQABAHAFAEQAFAEAHABIAGgBIAHgDIAFgDIAHALQgFAFgGACQgIACgIAAQgJAAgIgDgAARgFIgCgHQgCgDgEgCQgDgCgFgBQgFABgEACQgDACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_54.setTransform(148,175.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgNAeQgIgEgEgIQgFgIABgKQgBgJAFgIQAEgIAIgEQAIgFAKABQAGAAAFACQAFABAEACIAFAHIgLAKQgDgEgDgBQgEgCgEAAQgHAAgFAFQgFAFAAAIQAAAJAFAFQAFAFAHAAQAEAAAEgCQADgBADgEIALALIgFAGIgJAEQgFABgGAAQgKABgIgFg");
	this.shape_55.setTransform(140.9,175.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgRAgQgFgCgEgFQgEgFAAgHQAAgIAEgEQAEgFAFgBQAFgCAFAAQAHAAAEACQAGACADADIAAgIQAAgFgEgCQgEgEgFAAQgGAAgEADQgFABgEAEIgHgMQAGgFAHgDQAIgCAGAAQAJAAAGACQAGACAFAGQADAFAAAJIAAAqIgRAAIAAgHQgDAEgGACQgEACgHAAQgFAAgFgCgAgIAFQgEADAAAFQAAAFAEADQADACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgCQgDgBgEAAQgFAAgDACg");
	this.shape_56.setTransform(133.5,175.05);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AggAuIAAhaIARAAIAAAJQAEgFAFgDQAFgCAFAAQAJAAAGAEQAHAEAEAIQADAHAAALQAAALgDAHQgEAIgHAEQgGAEgJAAQgFAAgFgDQgFgCgEgFIAAAhgAgJgcQgEACgCAEIAAAWQACADAEACQAFACAEAAQAGAAAFgFQAEgEABgJQgBgIgEgFQgFgGgGAAQgEAAgFACg");
	this.shape_57.setTransform(126.25,176.225);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgHIALgOQAFAEAHAFQAIADAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgDgGAAIgLgEIgNgEQgGgDgEgFQgDgEgBgJQABgIAEgGQAEgGAIgEQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgDgGAAQgGAAgDADQgEACAAAEQABAEADACQAEACAGABIALAEQAHABAGADQAGADAEAEQADAFABAJQAAAIgEAHQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_58.setTransform(117.875,173.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgNAeQgIgEgEgIQgFgIABgKQgBgJAFgIQAEgIAIgEQAIgFAJABQAHAAAFACQAFABAEACIAFAHIgLAKQgDgEgDgBQgDgCgFAAQgHAAgFAFQgFAFAAAIQAAAJAFAFQAFAFAHAAQAFAAADgCQADgBADgEIALALIgFAGIgJAEQgFABgHAAQgJABgIgFg");
	this.shape_59.setTransform(107.05,175.05);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_60.setTransform(101.775,173.675);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgIAuIAAhaIARAAIAABag");
	this.shape_61.setTransform(98.325,173.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgGAsQgFgDgEgFIAAAJIgRAAIAAhaIARAAIAAAhQAEgFAFgCQAGgDAEAAQAIAAAIAEQAGAFAEAHQADAHAAALQAAALgDAHQgEAIgHAEQgHAEgIAAQgFAAgFgCgAgIgEQgEACgDACIAAAYQADADAEACQAEACAEAAQAHAAAEgFQAFgGgBgIQABgJgFgEQgEgFgHAAQgEAAgEACg");
	this.shape_62.setTransform(92.8,173.875);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgYAcQgGgFAAgKIAAguIARAAIAAAnQAAAHADADQAEADAFgBQAFAAADgCIAGgFIAAgsIASAAIAABBIgSAAIAAgIQgDAEgGADQgEADgIAAQgMAAgEgGg");
	this.shape_63.setTransform(84.7,175.125);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgkAuIAAhaIAqAAQAKAAAHADQAHAEADAHQAEAHgBAIQABAIgEAGQgEAGgGAEQgHAEgKAAIgWAAIAAAhgAgQgDIAUAAQAFAAAEgDQADgDABgGQgBgGgDgDQgEgEgFAAIgUAAg");
	this.shape_64.setTransform(76.75,173.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgFQgEgHAAgIQAAgHADgFQACgFAFgDIAKgGIgFgJIgBgKQAAgGADgFQADgFAGgDQAGgCAIgBQAFAAAFADQAGACADAEQADAEAAAHQAAAGgDAFQgDAEgFAEIgKAFIADAFIAEAEIAIAJIAFgJIADgHIAOAFIgGALIgHALIAJAJIAJAKIgWAAIgEgEIgDgDQgFADgHADQgFACgHAAQgIAAgHgDgAgUALQgDAEAAAEQAAAFACADQACADADABQAEACADAAIAHgBIAGgDIgFgHIgFgEIgEgGIgFgHQgDADgCADgAgHgfQgDADAAAFIABAGIADAFQAGgCACgDQAEgEAAgEQAAgFgCgBQgCgCgDAAQgEAAgCACg");
	this.shape_65.setTransform(64.425,173.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIAEIAIABQAGAAADgCQACgCAAgDQAAgDgEgBIgIgDIgMgDQgGgCgEgDQgEgEAAgIQAAgFADgFQAEgFAFgDQAHgCAHAAQAJAAAGACQAHADAFAEIgIAMQgCgDgGgDQgEgBgHgBIgHACQgCACAAADQAAACAEABIAIADIAMADQAGACAEAEQAEAEAAAHQAAAGgDAFQgDAFgHADQgGACgKAAQgIAAgHgCg");
	this.shape_66.setTransform(53.05,175.05);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAIgEAJAAQAKgBAHAFQAHAEAEAJQAEAIAAAKIAAADIgwAAQACAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgFAFgHACQgIACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgBAEgBADIAgAAIAAAAg");
	this.shape_67.setTransform(46.1,175.05);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgNAeQgHgEgFgIQgFgIAAgKQAAgJAFgIQAFgIAHgEQAIgFAJABQAHAAAFACQAFABAEACIAFAHIgLAKQgDgEgDgBQgDgCgFAAQgHAAgFAFQgEAFgBAIQABAJAEAFQAFAFAHAAQAFAAADgCQADgBADgEIALALIgFAGIgJAEQgFABgHAAQgJABgIgFg");
	this.shape_68.setTransform(39,175.05);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_69.setTransform(33.725,173.675);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgNAuIAAgxIgLAAIAAgQIALAAIAAgCQAAgMAGgGQAGgGAJAAQAFAAAEABQAFACADADIgHALIgDgCIgEgBQgDAAgDACQgCADAAAFIAAACIANAAIAAAQIgNAAIAAAxg");
	this.shape_70.setTransform(30.225,173.725);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgNAuIAAgxIgLAAIAAgQIALAAIAAgCQAAgMAGgGQAGgGAJAAQAFAAAEABQAFACADADIgHALIgDgCIgEgBQgDAAgDACQgCADAAAFIAAACIANAAIAAAQIgNAAIAAAxg");
	this.shape_71.setTransform(25.725,173.725);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgYApQgKgGgGgLQgGgKAAgOQAAgMAGgLQAGgLAKgGQAMgGANAAQANAAALAGQAKAGAGALQAHALgBAMQABAOgHAKQgGALgKAGQgLAGgNAAQgNAAgMgGgAgOgZQgFAEgEAHQgEAGABAIQgBAJAEAGQAEAHAFAEQAHAEAIAAQAHAAAHgEQAGgEAEgHQACgGABgJQgBgIgCgGQgEgHgGgEQgHgEgHAAQgIAAgHAEg");
	this.shape_72.setTransform(17.85,173.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAGAFIAIADIAHABQAGAAACgCQADgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgDgDQgEgEgBgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAJgBAGADQAGADAFAEIgGAMQgEgDgEgCQgGgCgGgBIgGACQgDACAAACQAAADAEACIAJACIALADQAGACAEAEQAEAEAAAHQAAAHgEAEQgDAFgGADQgHADgJAAQgHAAgIgDg");
	this.shape_73.setTransform(278,177.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgFgHQgFgJAAgKQAAgIAFgIQAEgIAIgFQAHgEAJAAQAKAAAIAEQAHAFAEAIQAFAIAAAKIAAADIgxAAQACAHAEAEQAFAEAIABIAFgBIAHgCIAFgEIAHAMQgFAEgHACQgHACgIABQgIgBgJgEgAARgGIgCgGQgCgDgEgCQgDgCgGgBQgEABgEACQgDACgBADQgCAEgBACIAgAAIAAAAg");
	this.shape_74.setTransform(271.05,177.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgNAeQgHgFgFgHQgEgIAAgKQAAgJAEgIQAFgHAHgFQAIgEAKAAQAGAAAFABQAFACADADIAHAFIgMALQgDgDgDgCQgDgCgFAAQgHAAgFAFQgEAGgBAHQABAIAEAGQAFAFAHAAQAFAAADgBQADgCADgEIAMAKIgHAHIgIAEQgFACgGAAQgKAAgIgFg");
	this.shape_75.setTransform(245.5,177.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgSAgQgFgCgDgFQgDgFgBgHQABgIADgEQADgFAFgCQAGgBAGAAQAGAAAEABQAGACADAEIAAgIQAAgFgEgCQgDgDgHAAQgEAAgGACQgEABgEAEIgHgMQAGgGAHgCQAIgDAHABQAHgBAHADQAGACAEAGQAFAFAAAKIAAApIgSAAIAAgHQgDAEgGACQgEACgGABQgGAAgGgDgAgJAFQgDAEAAAEQAAAFADADQAEACAFAAQAEAAADgCQAEgBACgDIAAgIQgCgDgEgCQgDgBgEAAQgFAAgEACg");
	this.shape_76.setTransform(238.05,177.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgfAuIAAhaIA/AAIAAARIgsAAIAAATIArAAIAAAQIgrAAIAAAmg");
	this.shape_77.setTransform(230.925,176.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_78.setTransform(291.125,162.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgRAgQgGgCgDgFQgEgFAAgHQAAgIAEgFQADgEAGgCQAFgCAGAAQAGAAAEACQAGACADAEIAAgIQAAgFgEgDQgEgCgFAAQgGAAgFABQgEACgEAEIgHgMQAGgGAHgCQAIgCAHgBQAHABAHACQAGACAFAFQADAGAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEACgGAAQgGgBgFgCgAgIAGQgEADAAAEQAAAFAEACQADADAFAAQADAAAEgCQAEgBACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgDADg");
	this.shape_79.setTransform(285.5,163.85);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_80.setTransform(278.1,163.775);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgGAKAAQALAAAIAGQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLABQgKgBgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEADQAEACAEAAQAFAAAEgCQAEgDACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_81.setTransform(270.225,163.85);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_82.setTransform(264.525,162.475);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQAAADABACQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgCIADAOIgFADIgJABQgJAAgEgFg");
	this.shape_83.setTransform(260.5,163.025);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgEgFABgHQgBgIAEgFQAEgEAEgCQAGgCAFAAQAHAAAFACQAFACADAEIAAgIQAAgFgEgDQgEgCgFAAQgFAAgFABQgFACgEAEIgHgMQAGgGAIgCQAHgCAGgBQAJABAGACQAHACADAFQAEAGAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEACgHAAQgFgBgGgCgAgIAGQgEADAAAEQAAAFAEACQADADAFAAQAEAAADgCQAEgBACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_84.setTransform(254.3,163.85);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgPAeQgJgEgEgIQgFgHABgLQgBgIAFgJQAEgHAIgEQAIgGAJAAQAJABAIAEQAHAFAFAIQADAIAAAJIAAAFIgvAAQABAGAEAEQAFAFAIgBIAGgBIAFgCIAGgDIAIAMQgGAEgHADQgHACgHAAQgKAAgHgFgAARgGIgCgFQgCgEgDgCQgEgCgFAAQgFAAgDACQgEACgCADQgBADAAADIAfAAIAAAAg");
	this.shape_85.setTransform(247.05,163.85);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_86.setTransform(241.075,163.775);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgNAeQgHgEgFgIQgEgIgBgKQABgJAEgIQAFgHAHgFQAIgEAJgBQAHAAAFACQAFACADADIAHAGIgMAKQgCgEgEgCQgEgBgEAAQgHAAgFAFQgEAFgBAIQABAIAEAGQAFAFAHAAQAEAAAEgCQAEgCACgDIAMALIgHAFIgIAFQgFABgHABQgJgBgIgEg");
	this.shape_87.setTransform(235,163.85);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgFgIQgFgHAAgLQAAgIAFgJQAEgHAIgEQAHgGAJAAQALABAHAEQAHAFAEAIQAFAIAAAJIAAAFIgxAAQABAGAFAEQAFAFAHgBIAGgBIAHgCIAFgDIAHAMQgFAEgGADQgIACgIAAQgJAAgIgFgAARgGIgCgFQgCgEgEgCQgDgCgGAAQgEAAgEACQgDACgBADQgDADAAADIAgAAIAAAAg");
	this.shape_88.setTransform(227.75,163.85);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AAOAtIgRggIgNAAIAAAgIgUAAIAAhaIApAAQAKAAAHAFQAHADADAHQAEAGAAAJQAAAIgDAGQgDAEgEAEIgKAEIAVAigAgQgDIATAAQAGAAADgDQAEgDABgHQgBgFgEgDQgDgDgGgBIgTAAg");
	this.shape_89.setTransform(219.8,162.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAHgMIAHAFIAIADIAHABQAGAAADgCQACgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgEgDQgDgEgBgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAJgBAGADQAGADAFAEIgGAMQgEgDgEgCQgGgCgGgBIgGACQgDACAAACQAAADAEACIAJACIALADQAGACAEAEQAEAEAAAHQAAAHgEAEQgDAFgGADQgHADgIAAQgIAAgIgDg");
	this.shape_90.setTransform(102.6,177.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgNAeQgHgFgFgHQgFgIAAgKQAAgJAFgIQAFgHAHgFQAIgEAJAAQAHAAAFABQAFACADADIAGAFIgLALQgDgDgDgCQgEgCgEAAQgHAAgFAFQgEAGgBAHQABAIAEAGQAFAFAHAAQAEAAAEgBQADgCADgEIALAKIgGAHIgIAEQgFACgHAAQgJAAgIgFg");
	this.shape_91.setTransform(96.05,177.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_92.setTransform(90.825,176.125);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_93.setTransform(85.15,177.425);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_94.setTransform(79.475,176.125);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgSApQgLgGgHgKQgGgLAAgOQAAgNAGgLQAHgKALgGQALgGAMAAQAKAAAIADQAHAEAFAFQAFAFADAFIgQAIQgDgFgGgEQgFgDgIAAQgHAAgGADQgHAEgDAGQgEAIAAAHQAAAIAEAIQADAGAHAEQAGAEAHAAQAIAAAFgEQAGgEADgFIAQAIQgDAFgFAGQgFAEgHAEQgIADgKAAQgMAAgLgGg");
	this.shape_95.setTransform(69.725,176.25);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AAOAtIAAgnQAAgHgEgCQgDgDgGAAQgDAAgFADQgDACgCACIAAAsIgSAAIAAhaIASAAIAAAiIAFgFIAHgDQAEgCAFAAQALAAAGAFQAFAGAAAKIAAAtg");
	this.shape_96.setTransform(138.75,162.6);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQgBADACACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgJABQgIAAgEgFg");
	this.shape_97.setTransform(132.45,163.025);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_98.setTransform(128.425,162.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgRAgQgFgCgEgFQgDgFAAgHQAAgIADgFQAEgEAFgCQAFgCAFAAQAHAAAEACQAGACADAEIAAgIQAAgFgEgDQgEgCgFAAQgGAAgEABQgFACgEAEIgHgMQAGgGAHgCQAIgCAGgBQAJABAGACQAHACAEAFQADAGAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEACgHAAQgFgBgFgCgAgIAGQgEADAAAEQAAAFAEACQADADAFAAQAEAAADgCQAEgBACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_99.setTransform(122.8,163.85);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgPAeQgJgEgEgIQgFgHABgLQgBgIAFgJQAEgHAIgEQAIgGAIAAQAKABAIAEQAHAFAFAIQADAIAAAJIAAAFIgvAAQAAAGAFAEQAFAFAIgBIAFgBIAGgCIAGgDIAIAMQgGAEgHADQgGACgIAAQgKAAgHgFgAARgGIgCgFQgCgEgEgCQgDgCgGAAQgEAAgEACQgDACgBADQgCADAAADIAfAAIAAAAg");
	this.shape_100.setTransform(115.55,163.85);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AAWAtIAAgmIgrAAIAAAmIgTAAIAAhaIATAAIAAAkIArAAIAAgkIATAAIAABag");
	this.shape_101.setTransform(106.75,162.6);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgGQgEgFAAgJQAAgHADgFQACgFAFgEIAKgEIgFgLIgBgJQAAgGADgFQADgFAGgDQAGgDAIAAQAFAAAFACQAGACADAFQADAFAAAFQAAAIgDAEQgDAEgFADIgKAHIADADIAEAFIAIAJIAFgJIADgHIAOAGIgGAKIgHALIAJAJIAJAJIgWAAIgEgCIgDgFQgFAEgHADQgFACgHAAQgIAAgHgDgAgUALQgDADAAAFQAAAEACAEQACADADACQAEACADAAIAHgCIAGgDIgFgGIgFgGIgEgGIgFgGQgDACgCAEgAgHgeQgDACAAAEIABAGIADAHQAGgDACgEQAEgCAAgGQAAgDgCgCQgCgDgDAAQgEABgCADg");
	this.shape_102.setTransform(93.975,162.6);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgEIAIgNIAGAFIAHACIAIACQAGAAACgCQADgCAAgDQAAgDgEgCIgJgCIgLgDQgGgCgDgDQgFgEAAgHQAAgHAEgEQACgEAHgDQAFgEAIAAQAIABAHACQAHACAEAEIgHANQgDgDgEgDQgGgCgGAAIgHACQgCACAAACQAAAEAEABIAJACIALADQAGACAEADQAEAFAAAIQAAAFgEAGQgDAEgGADQgHACgJABQgHgBgIgCg");
	this.shape_103.setTransform(82.6,163.85);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_104.setTransform(77.675,162.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgEgFABgHQgBgIAEgFQAEgEAEgCQAGgCAFAAQAHAAAFACQAFACADAEIAAgIQAAgFgEgDQgEgCgFAAQgFAAgFABQgFACgEAEIgHgMQAGgGAIgCQAHgCAGgBQAJABAGACQAHACADAFQAEAGAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEACgHAAQgFgBgGgCgAgJAGQgDADAAAEQAAAFADACQAEADAFAAQAEAAADgCQAEgBACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_105.setTransform(72.05,163.85);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQAAADACACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIADgCIADAOIgGADIgJABQgHAAgFgFg");
	this.shape_106.setTransform(66.25,163.025);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_107.setTransform(62.175,162.475);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AghAuIAAhaIASAAIAAAJQADgFAGgDQAFgCAFAAQAJAAAGAEQAHAEADAIQAFAHAAALQAAALgFAHQgDAIgHAEQgGAEgJAAQgEAAgGgDQgFgCgEgFIAAAhgAgJgcQgDACgDAEIAAAWQACADAEACQAEACAFAAQAGAAAFgFQAEgEABgJQgBgIgEgFQgFgGgGAAQgFAAgEACg");
	this.shape_108.setTransform(56.75,165.025);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgEIAIgNIAFAFIAIACIAIACQAGAAACgCQADgCAAgDQAAgDgEgCIgJgCIgLgDQgGgCgDgDQgFgEAAgHQAAgHAEgEQACgEAHgDQAFgEAIAAQAIABAHACQAHACAEAEIgHANQgCgDgGgDQgFgCgGAAIgHACQgCACAAACQAAAEAEABIAJACIALADQAGACAEADQAEAFAAAIQAAAFgEAGQgCAEgHADQgGACgKABQgHgBgIgCg");
	this.shape_109.setTransform(49.2,163.85);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgGAKAAQALAAAIAGQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLABQgKgBgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEADQAEACAEAAQAFAAAEgCQAEgDACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_110.setTransform(42.075,163.85);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AAVAtIAAgmIgqAAIAAAmIgTAAIAAhaIATAAIAAAkIAqAAIAAgkIAUAAIAABag");
	this.shape_111.setTransform(33.15,162.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69,p:{x:33.725,y:173.675}},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61,p:{x:98.325,y:173.8}},{t:this.shape_60,p:{x:101.775,y:173.675}},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:231.225,y:173.8}},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:295.65,y:174.225}},{t:this.shape_38,p:{x:299.725,y:173.675}},{t:this.shape_37},{t:this.shape_36}]},123).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_61,p:{x:76.025,y:176.25}},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_69,p:{x:250.525,y:176.125}},{t:this.shape_47,p:{x:253.975,y:176.25}},{t:this.shape_60,p:{x:257.425,y:176.125}},{t:this.shape_39,p:{x:261.45,y:176.675}},{t:this.shape_38,p:{x:265.525,y:176.125}},{t:this.shape_74},{t:this.shape_73}]},86).to({state:[]},87).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69,p:{x:33.725,y:173.675}},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61,p:{x:98.325,y:173.8}},{t:this.shape_60,p:{x:101.775,y:173.675}},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:231.225,y:173.8}},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:295.65,y:174.225}},{t:this.shape_38,p:{x:299.725,y:173.675}},{t:this.shape_37},{t:this.shape_36}]},123).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_61,p:{x:76.025,y:176.25}},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_69,p:{x:250.525,y:176.125}},{t:this.shape_47,p:{x:253.975,y:176.25}},{t:this.shape_60,p:{x:257.425,y:176.125}},{t:this.shape_39,p:{x:261.45,y:176.675}},{t:this.shape_38,p:{x:265.525,y:176.125}},{t:this.shape_74},{t:this.shape_73}]},86).to({state:[]},87).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69,p:{x:33.725,y:173.675}},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61,p:{x:98.325,y:173.8}},{t:this.shape_60,p:{x:101.775,y:173.675}},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:231.225,y:173.8}},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:295.65,y:174.225}},{t:this.shape_38,p:{x:299.725,y:173.675}},{t:this.shape_37},{t:this.shape_36}]},123).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_61,p:{x:76.025,y:176.25}},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_69,p:{x:250.525,y:176.125}},{t:this.shape_47,p:{x:253.975,y:176.25}},{t:this.shape_60,p:{x:257.425,y:176.125}},{t:this.shape_39,p:{x:261.45,y:176.675}},{t:this.shape_38,p:{x:265.525,y:176.125}},{t:this.shape_74},{t:this.shape_73}]},86).wait(87));

	// Слой_9
	this.instance_6 = new lib.pc31("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(233.6,140,1,1,0,0,0,233.6,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).wait(87));

	// Слой_7
	this.instance_7 = new lib.pc21("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(233.75,140.85,1.0033,1.0033,0,0,0,233.4,140.3);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(123).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(86));

	// pc11
	this.instance_8 = new lib.pc11();
	this.instance_8.parent = this;
	this.instance_8.setTransform(168.05,82.75,1,1,0,0,0,168,139.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({regY:148,x:168,y:90.7},0).wait(1).to({y:90.55},0).wait(1).to({y:90.4},0).wait(1).to({y:90.25},0).wait(1).to({y:90.1},0).wait(1).to({y:89.95},0).wait(1).to({y:89.8},0).wait(1).to({y:89.6},0).wait(1).to({y:89.45},0).wait(1).to({y:89.3},0).wait(1).to({y:89.15},0).wait(1).to({y:89},0).wait(1).to({y:88.8},0).wait(1).to({y:88.65},0).wait(1).to({y:88.5},0).wait(1).to({y:88.35},0).wait(1).to({y:88.15},0).wait(1).to({y:88},0).wait(1).to({y:87.85},0).wait(1).to({y:87.65},0).wait(1).to({y:87.5},0).wait(1).to({y:87.35},0).wait(1).to({y:87.15},0).wait(1).to({y:87},0).wait(1).to({y:86.8},0).wait(1).to({y:86.65},0).wait(1).to({y:86.5},0).wait(1).to({y:86.3},0).wait(1).to({y:86.15},0).wait(1).to({y:85.95},0).wait(1).to({y:85.8},0).wait(1).to({y:85.6},0).wait(1).to({y:85.45},0).wait(1).to({y:85.25},0).wait(1).to({y:85.1},0).wait(1).to({y:84.9},0).wait(1).to({y:84.75},0).wait(1).to({y:84.55},0).wait(1).to({y:84.4},0).wait(1).to({y:84.2},0).wait(1).to({y:84},0).wait(1).to({y:83.85},0).wait(1).to({y:83.65},0).wait(1).to({y:83.45},0).wait(1).to({y:83.3},0).wait(1).to({y:83.1},0).wait(1).to({y:82.9},0).wait(1).to({y:82.75},0).wait(1).to({y:82.55},0).wait(1).to({y:82.35},0).wait(1).to({y:82.2},0).wait(1).to({y:82},0).wait(1).to({y:81.8},0).wait(1).to({y:81.6},0).wait(1).to({y:81.45},0).wait(1).to({y:81.25},0).wait(1).to({y:81.05},0).wait(1).to({y:80.85},0).wait(1).to({y:80.65},0).wait(1).to({y:80.45},0).wait(1).to({y:80.3},0).wait(1).to({y:80.1},0).wait(1).to({y:79.9},0).wait(1).to({y:79.7},0).wait(1).to({y:79.5},0).wait(1).to({y:79.3},0).wait(1).to({y:79.1},0).wait(1).to({y:78.9},0).wait(1).to({y:78.7},0).wait(1).to({y:78.5},0).wait(1).to({y:78.3},0).wait(1).to({y:78.1},0).wait(1).to({y:77.9},0).wait(1).to({y:77.7},0).wait(1).to({y:77.5},0).wait(1).to({y:77.3},0).wait(1).to({y:77.1},0).wait(1).to({y:76.9},0).wait(1).to({y:76.7},0).wait(1).to({y:76.5},0).wait(1).to({y:76.3},0).wait(1).to({y:76.05},0).wait(1).to({y:75.85},0).wait(1).to({y:75.65},0).wait(1).to({y:75.45},0).wait(1).to({y:75.25},0).wait(1).to({y:75.05},0).wait(1).to({y:74.8},0).wait(1).to({y:74.6},0).wait(1).to({y:74.4},0).wait(1).to({y:74.2},0).wait(1).to({y:73.95},0).wait(1).to({y:73.75},0).wait(1).to({y:73.55},0).wait(1).to({y:73.35},0).wait(1).to({y:73.1},0).wait(1).to({y:72.9},0).wait(1).to({y:72.7},0).wait(1).to({y:72.45},0).wait(1).to({y:72.25},0).wait(1).to({y:72},0).wait(1).to({y:71.8},0).wait(1).to({y:71.6},0).wait(1).to({y:71.35},0).wait(1).to({y:71.15},0).wait(1).to({y:70.9},0).wait(1).to({y:70.7},0).wait(1).to({y:70.45},0).wait(1).to({y:70.25},0).wait(1).to({y:70},0).wait(1).to({y:69.8},0).wait(1).to({y:69.55},0).wait(1).to({y:69.35},0).wait(1).to({y:69.1},0).wait(1).to({y:68.9},0).wait(1).to({y:68.65},0).wait(1).to({y:68.45},0).wait(1).to({y:68.2},0).wait(1).to({y:67.95},0).wait(1).to({y:67.75},0).wait(1).to({y:67.5},0).wait(1).to({regY:140,y:59.2},0).to({_off:true},1).wait(173).to({_off:false,regY:139.9,x:168.05,y:82.75},0).wait(1).to({regY:148,x:168,y:90.7},0).wait(1).to({y:90.55},0).wait(1).to({y:90.4},0).wait(1).to({y:90.25},0).wait(1).to({y:90.1},0).wait(1).to({y:89.95},0).wait(1).to({y:89.8},0).wait(1).to({y:89.6},0).wait(1).to({y:89.45},0).wait(1).to({y:89.3},0).wait(1).to({y:89.15},0).wait(1).to({y:89},0).wait(1).to({y:88.8},0).wait(1).to({y:88.65},0).wait(1).to({y:88.5},0).wait(1).to({y:88.35},0).wait(1).to({y:88.15},0).wait(1).to({y:88},0).wait(1).to({y:87.85},0).wait(1).to({y:87.65},0).wait(1).to({y:87.5},0).wait(1).to({y:87.35},0).wait(1).to({y:87.15},0).wait(1).to({y:87},0).wait(1).to({y:86.8},0).wait(1).to({y:86.65},0).wait(1).to({y:86.5},0).wait(1).to({y:86.3},0).wait(1).to({y:86.15},0).wait(1).to({y:85.95},0).wait(1).to({y:85.8},0).wait(1).to({y:85.6},0).wait(1).to({y:85.45},0).wait(1).to({y:85.25},0).wait(1).to({y:85.1},0).wait(1).to({y:84.9},0).wait(1).to({y:84.75},0).wait(1).to({y:84.55},0).wait(1).to({y:84.4},0).wait(1).to({y:84.2},0).wait(1).to({y:84},0).wait(1).to({y:83.85},0).wait(1).to({y:83.65},0).wait(1).to({y:83.45},0).wait(1).to({y:83.3},0).wait(1).to({y:83.1},0).wait(1).to({y:82.9},0).wait(1).to({y:82.75},0).wait(1).to({y:82.55},0).wait(1).to({y:82.35},0).wait(1).to({y:82.2},0).wait(1).to({y:82},0).wait(1).to({y:81.8},0).wait(1).to({y:81.6},0).wait(1).to({y:81.45},0).wait(1).to({y:81.25},0).wait(1).to({y:81.05},0).wait(1).to({y:80.85},0).wait(1).to({y:80.65},0).wait(1).to({y:80.45},0).wait(1).to({y:80.3},0).wait(1).to({y:80.1},0).wait(1).to({y:79.9},0).wait(1).to({y:79.7},0).wait(1).to({y:79.5},0).wait(1).to({y:79.3},0).wait(1).to({y:79.1},0).wait(1).to({y:78.9},0).wait(1).to({y:78.7},0).wait(1).to({y:78.5},0).wait(1).to({y:78.3},0).wait(1).to({y:78.1},0).wait(1).to({y:77.9},0).wait(1).to({y:77.7},0).wait(1).to({y:77.5},0).wait(1).to({y:77.3},0).wait(1).to({y:77.1},0).wait(1).to({y:76.9},0).wait(1).to({y:76.7},0).wait(1).to({y:76.5},0).wait(1).to({y:76.3},0).wait(1).to({y:76.05},0).wait(1).to({y:75.85},0).wait(1).to({y:75.65},0).wait(1).to({y:75.45},0).wait(1).to({y:75.25},0).wait(1).to({y:75.05},0).wait(1).to({y:74.8},0).wait(1).to({y:74.6},0).wait(1).to({y:74.4},0).wait(1).to({y:74.2},0).wait(1).to({y:73.95},0).wait(1).to({y:73.75},0).wait(1).to({y:73.55},0).wait(1).to({y:73.35},0).wait(1).to({y:73.1},0).wait(1).to({y:72.9},0).wait(1).to({y:72.7},0).wait(1).to({y:72.45},0).wait(1).to({y:72.25},0).wait(1).to({y:72},0).wait(1).to({y:71.8},0).wait(1).to({y:71.6},0).wait(1).to({y:71.35},0).wait(1).to({y:71.15},0).wait(1).to({y:70.9},0).wait(1).to({y:70.7},0).wait(1).to({y:70.45},0).wait(1).to({y:70.25},0).wait(1).to({y:70},0).wait(1).to({y:69.8},0).wait(1).to({y:69.55},0).wait(1).to({y:69.35},0).wait(1).to({y:69.1},0).wait(1).to({y:68.9},0).wait(1).to({y:68.65},0).wait(1).to({y:68.45},0).wait(1).to({y:68.2},0).wait(1).to({y:67.95},0).wait(1).to({y:67.75},0).wait(1).to({y:67.5},0).wait(1).to({regY:140,y:59.2},0).to({_off:true},1).wait(173).to({_off:false,regY:139.9,x:168.05,y:82.75},0).wait(1).to({regY:148,x:168,y:90.7},0).wait(1).to({y:90.55},0).wait(1).to({y:90.4},0).wait(1).to({y:90.25},0).wait(1).to({y:90.1},0).wait(1).to({y:89.95},0).wait(1).to({y:89.8},0).wait(1).to({y:89.6},0).wait(1).to({y:89.45},0).wait(1).to({y:89.3},0).wait(1).to({y:89.15},0).wait(1).to({y:89},0).wait(1).to({y:88.8},0).wait(1).to({y:88.65},0).wait(1).to({y:88.5},0).wait(1).to({y:88.35},0).wait(1).to({y:88.15},0).wait(1).to({y:88},0).wait(1).to({y:87.85},0).wait(1).to({y:87.65},0).wait(1).to({y:87.5},0).wait(1).to({y:87.35},0).wait(1).to({y:87.15},0).wait(1).to({y:87},0).wait(1).to({y:86.8},0).wait(1).to({y:86.65},0).wait(1).to({y:86.5},0).wait(1).to({y:86.3},0).wait(1).to({y:86.15},0).wait(1).to({y:85.95},0).wait(1).to({y:85.8},0).wait(1).to({y:85.6},0).wait(1).to({y:85.45},0).wait(1).to({y:85.25},0).wait(1).to({y:85.1},0).wait(1).to({y:84.9},0).wait(1).to({y:84.75},0).wait(1).to({y:84.55},0).wait(1).to({y:84.4},0).wait(1).to({y:84.2},0).wait(1).to({y:84},0).wait(1).to({y:83.85},0).wait(1).to({y:83.65},0).wait(1).to({y:83.45},0).wait(1).to({y:83.3},0).wait(1).to({y:83.1},0).wait(1).to({y:82.9},0).wait(1).to({y:82.75},0).wait(1).to({y:82.55},0).wait(1).to({y:82.35},0).wait(1).to({y:82.2},0).wait(1).to({y:82},0).wait(1).to({y:81.8},0).wait(1).to({y:81.6},0).wait(1).to({y:81.45},0).wait(1).to({y:81.25},0).wait(1).to({y:81.05},0).wait(1).to({y:80.85},0).wait(1).to({y:80.65},0).wait(1).to({y:80.45},0).wait(1).to({y:80.3},0).wait(1).to({y:80.1},0).wait(1).to({y:79.9},0).wait(1).to({y:79.7},0).wait(1).to({y:79.5},0).wait(1).to({y:79.3},0).wait(1).to({y:79.1},0).wait(1).to({y:78.9},0).wait(1).to({y:78.7},0).wait(1).to({y:78.5},0).wait(1).to({y:78.3},0).wait(1).to({y:78.1},0).wait(1).to({y:77.9},0).wait(1).to({y:77.7},0).wait(1).to({y:77.5},0).wait(1).to({y:77.3},0).wait(1).to({y:77.1},0).wait(1).to({y:76.9},0).wait(1).to({y:76.7},0).wait(1).to({y:76.5},0).wait(1).to({y:76.3},0).wait(1).to({y:76.05},0).wait(1).to({y:75.85},0).wait(1).to({y:75.65},0).wait(1).to({y:75.45},0).wait(1).to({y:75.25},0).wait(1).to({y:75.05},0).wait(1).to({y:74.8},0).wait(1).to({y:74.6},0).wait(1).to({y:74.4},0).wait(1).to({y:74.2},0).wait(1).to({y:73.95},0).wait(1).to({y:73.75},0).wait(1).to({y:73.55},0).wait(1).to({y:73.35},0).wait(1).to({y:73.1},0).wait(1).to({y:72.9},0).wait(1).to({y:72.7},0).wait(1).to({y:72.45},0).wait(1).to({y:72.25},0).wait(1).to({y:72},0).wait(1).to({y:71.8},0).wait(1).to({y:71.6},0).wait(1).to({y:71.35},0).wait(1).to({y:71.15},0).wait(1).to({y:70.9},0).wait(1).to({y:70.7},0).wait(1).to({y:70.45},0).wait(1).to({y:70.25},0).wait(1).to({y:70},0).wait(1).to({y:69.8},0).wait(1).to({y:69.55},0).wait(1).to({y:69.35},0).wait(1).to({y:69.1},0).wait(1).to({y:68.9},0).wait(1).to({y:68.65},0).wait(1).to({y:68.45},0).wait(1).to({y:68.2},0).wait(1).to({y:67.95},0).wait(1).to({y:67.75},0).wait(1).to({y:67.5},0).wait(1).to({regY:140,y:59.2},0).to({_off:true},1).wait(173));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(165.2,59.2,247.10000000000002,256.90000000000003);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_Government_atlas_P_.png", id:"336x280_Government_atlas_P_"},
		{src:"images/336x280_Government_atlas_NP_.jpg", id:"336x280_Government_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;