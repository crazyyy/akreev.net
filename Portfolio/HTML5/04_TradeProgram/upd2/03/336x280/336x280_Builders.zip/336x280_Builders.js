(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_Builders_atlas_P_", frames: [[0,0,98,28]]},
		{name:"336x280_Builders_atlas_NP_", frames: [[338,0,336,269],[676,194,336,192],[58,298,56,43],[116,298,48,45],[0,298,56,47],[0,0,336,296],[676,0,336,192],[338,271,336,192]]}
];


// symbols:



(lib.Растровоеизображение151111 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение151 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_Builders_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen1111 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.screen2111 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.screen211 = function() {
	this.initialize(ss["336x280_Builders_atlas_NP_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape.setTransform(214.1,71.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_1.setTransform(206,71.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_2.setTransform(200.375,69.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_3.setTransform(194.725,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgFAjIgdhFIAMAAIAWA5IAXg5IAMAAIgdBFg");
	this.shape_4.setTransform(187.55,71.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_5.setTransform(178.25,71.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAGAAQAJAAAGADQAGADAEAFQAFAFABAHQADAHAAAHIAAADIg4AAQABAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgIgZQgFACgDAEQgDADgBAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgFAAgDACg");
	this.shape_6.setTransform(171.4,71.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_7.setTransform(163.75,71.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_8.setTransform(158.575,70.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_9.setTransform(155.325,69.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgCADgCAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgEAAgFACg");
	this.shape_10.setTransform(149.65,71.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_11.setTransform(141.175,70.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgDgIAAgHQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgDAEgBAEQgBAFAAAFQAAAFABAFQABAFADAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_12.setTransform(129.3,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_13.setTransform(123.05,70.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_14.setTransform(112.775,70.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAFADQAHADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape_15.setTransform(104.75,71.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_16.setTransform(96.65,71.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_17.setTransform(88.275,72.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_18.setTransform(82.675,70.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_19.setTransform(77.575,71.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgCgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_20.setTransform(70.25,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_21.setTransform(61.775,70.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_22.setTransform(50.575,71.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgCgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_23.setTransform(43.25,71.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_24.setTransform(35.675,71.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_25.setTransform(30.325,70.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_26.setTransform(25.15,71.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_27.setTransform(19.6,71.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(12.75,71.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_29.setTransform(5.175,71.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgXAwQgFgCgEgDQgEgDgDgFQgCgGAAgGQAAgGACgFQACgDADgEIAHgFIAIgFIgGgLQgCgFAAgFQAAgGACgDQACgFADgDQAEgDAEgCQAEgBAFAAIAIABIAHAEQADACACAEQACADAAAFQgBAFgCAEQgCAFgEACIgHAGIgJAFIAGAGIAFAHIAFAHIAHAGIAGgMIAEgKIAJAEIgGAMQgDAHgEAGIAJAIIAKAKIgPAAIgFgEIgGgGQgFAFgHAEQgGADgIAAQgHAAgGgCgAgZAKQgEAFAAAHQAAAEACAEQABAEADACQADACADABQAEACAEAAQAGAAAEgDQAFgDAEgEIgIgIIgFgGIgGgHIgGgJQgGAEgEAFgAgHgoIgFAEQgCABgBADIgBAGIACAIIAFAIIAGgEIAFgEIAFgGQABgCABgEQgBgFgDgDQgDgCgEgBIgFABg");
	this.shape_30.setTransform(-6.45,69.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_31.setTransform(-18.375,71.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAKAAIAAATIANAAIAAAJIgNAAIAAArQgBAEACACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_32.setTransform(-23.75,70.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_33.setTransform(-29.375,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_34.setTransform(-37.1,71.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_35.setTransform(-45.475,70.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFAAAFQAAAFACAFQACAFACAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_36.setTransform(-53.6,71.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgFAAIgFABIgFACIgEAEIgDAEIAAAxg");
	this.shape_37.setTransform(-59.75,71.175);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgiAwIAAhfIAmAAQAIAAAFACQAGACADAEQAEAEADAFQABAGAAAGQAAAGgBAFQgDAFgEADQgDAEgGACQgFADgIAAIgZAAIAAAmgAgVAAIAYAAQAJAAAEgFQAGgFAAgIQAAgJgGgFQgEgFgJAAIgYAAg");
	this.shape_38.setTransform(-66.45,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t122, new cjs.Rectangle(-73.1,61.3,293.4,18.5), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgDgBAAgEQAAgDADgCQACgCACAAQADAAADACQACACAAADQAAAEgCABQgDADgDAAQgCAAgCgDg");
	this.shape.setTransform(155.5,74.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAGAAQAJAAAGADQAGADAEAFQAFAFABAHQADAHAAAHIAAADIg4AAQABAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgIgZQgFACgDAEQgDADgBAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgFAAgDACg");
	this.shape_1.setTransform(149.8,71.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgEAEIAAAxg");
	this.shape_2.setTransform(143.7,71.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFAAAFQAAAFACAFQACAFACAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_3.setTransform(136.75,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AAlAkIAAguQAAgHgDgEQgDgEgHAAQgGAAgFADQgFADgDAEIAAAzIgKAAIAAguQAAgHgDgEQgDgEgHAAQgFAAgFADQgFAEgDAEIAAAyIgLAAIAAhFIALAAIAAAKIADgDIAGgEIAGgEQAEgBAEAAQAIAAAEAEQAEAEABAFIAEgEIAGgEIAHgEIAHgBQAKAAAEAGQAGAFAAAKIAAAyg");
	this.shape_4.setTransform(126.775,71.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_5.setTransform(113.675,71.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_6.setTransform(106.35,71.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgEACgDAEQgEAEgBAEQgCAFABAFQgBAFACAFQABAFAEAEQADADAEADQAFACAEAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_7.setTransform(98.1,71.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_8.setTransform(89.575,70.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAKAAIAAATIANAAIAAAJIgNAAIAAArQgBAEACACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_9.setTransform(79.75,70.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_10.setTransform(73.575,71.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AASAwIAAguQAAgEgBgDIgDgFIgFgCIgGgBIgFABIgHACIgEAEIgEAEIAAAyIgLAAIAAhfIALAAIAAAkIAFgEIAFgEIAHgDIAHgBQALAAAGAGQAFAFAAAMIAAAwg");
	this.shape_11.setTransform(65.95,69.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAKAAIAAATIANAAIAAAJIgNAAIAAArQgBAEACACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_12.setTransform(59.85,70.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_13.setTransform(51.95,71.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgCAEQgDADgCAFIgCAIIAtAAIgBgIQgCgFgCgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_14.setTransform(45.1,71.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_15.setTransform(39.375,70.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_16.setTransform(36.125,69.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AggAxIAAhfIALAAIAAAKQAEgFAGgEQAGgDAHAAQAHAAAFADQAGACAEAFQAEAEADAHQACAHAAAJQAAAIgCAGQgDAHgEAFQgEAEgGADQgFADgHAAQgHAAgGgEQgGgDgEgGIAAAlgAgMgjQgGADgDAFIAAAeQADAFAGADQAFAEAHAAQAEAAAEgCQAFgCACgEQADgEACgEQABgEAAgGQAAgGgBgFQgCgFgDgEQgCgDgFgCQgEgCgEAAQgHAAgFADg");
	this.shape_17.setTransform(30.575,72.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AggAxIAAhfIALAAIAAAKQAEgFAGgEQAGgDAHAAQAHAAAFADQAGACAEAFQAEAEADAHQACAHAAAJQAAAIgCAGQgDAHgEAFQgEAEgGADQgFADgHAAQgHAAgGgEQgGgDgEgGIAAAlgAgMgjQgGADgDAFIAAAeQADAFAGADQAFAEAHAAQAEAAAEgCQAFgCACgEQADgEACgEQABgEAAgGQAAgGgBgFQgCgFgDgEQgCgDgFgCQgEgCgEAAQgHAAgFADg");
	this.shape_18.setTransform(22.275,72.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAHABQAFAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgGAEQgHADgHAAQgLAAgGgFg");
	this.shape_19.setTransform(13.9,71.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_20.setTransform(6.425,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AAhAwIgJgVIgvAAIgJAVIgNAAIAmhfIAOAAIAnBfgAgUAQIAoAAIgUgzg");
	this.shape_21.setTransform(-5.375,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-12.2,61.3,171.5,18.5), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgTApQgKgEgGgGIALgOQAEAEAHAEQAHADAIAAQAIAAADgDQAEgCAAgEQAAgEgEgCIgJgDIgLgDQgGgCgGgDQgFgCgEgEQgEgFAAgIQAAgIAEgGQAEgGAIgDQAHgEAJAAQAKAAAJADQAIADAHAGIgKAOQgGgFgGgCQgHgCgGAAQgFAAgEACQgDACAAAEQAAAEAEABIAJAEIALADIAMAEQAGADADAEQAEAFAAAIQAAAIgEAGQgEAGgHAEQgIAEgMAAQgLAAgJgEg");
	this.shape.setTransform(207.475,129.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_1.setTransform(199.675,129.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_2.setTransform(191.625,129.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgnArIAAhVIAiAAQANAAAKAFQAKAFAGAKQAGAKAAAMQAAANgGAKQgGAJgKAGQgKAFgNAAgAgVAbIAQAAQAIAAAGgEQAGgDADgHQADgGAAgHQAAgHgDgGQgDgGgGgEQgGgDgIAAIgQAAg");
	this.shape_3.setTransform(183.225,129.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgbArIAAhVIATAAIAABFIAjAAIAAAQg");
	this.shape_4.setTransform(175.2,129.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_5.setTransform(169.875,129.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgVAoQgJgFgEgJQgEgHAAgLIAAgzIATAAIAAAzQAAAJAFAFQAFAGAJgBQAKABAFgGQAFgFAAgJIAAgzIATAAIAAAzQAAALgEAHQgEAJgJAFQgJAEgNAAQgMAAgJgEg");
	this.shape_6.setTransform(163.325,129.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgjArIAAhVIAsAAQAJAAAFADQAGADADAFQACAFAAAGQAAAFgCAEQgCAEgDADQgDADgFABQAFAAAEACQAEADACAFQACAEAAAGQAAAGgDAGQgDAFgFADQgGADgIAAgAgRAbIAXAAQAFAAADgDQADgCAAgFQAAgEgDgDQgCgDgGAAIgXAAgAgRgIIAWAAQAFAAADgCQACgDABgEQgBgEgCgDQgDgCgFAAIgWAAg");
	this.shape_7.setTransform(154.425,129.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAVArIAAgkIgpAAIAAAkIgSAAIAAhVIASAAIAAAiIApAAIAAgiIASAAIAABVg");
	this.shape_8.setTransform(141.85,129.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgIArIAAhFIgaAAIAAgQIBFAAIAAAQIgaAAIAABFg");
	this.shape_9.setTransform(133.325,129.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_10.setTransform(127.775,129.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAQArIgQg6IgOA6IgUAAIgZhVIAWAAIAOA9IARg9IAOAAIAQA9IAPg9IAUAAIgYBVg");
	this.shape_11.setTransform(120,129.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgTApQgKgEgGgGIALgOQAEAEAHAEQAHADAIAAQAIAAADgDQAEgCAAgEQAAgEgEgCIgJgDIgLgDQgGgCgGgDQgFgCgEgEQgEgFAAgIQAAgIAEgGQAEgGAIgDQAHgEAJAAQAKAAAJADQAIADAHAGIgKAOQgGgFgGgCQgHgCgGAAQgFAAgEACQgDACAAAEQAAAEAEABIAJAEIALADIAMAEQAGADADAEQAEAFAAAIQAAAIgEAGQgEAGgHAEQgIAEgMAAQgLAAgJgEg");
	this.shape_12.setTransform(106.725,129.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAOArIgZgjIgHAJIAAAaIgSAAIAAhVIASAAIAAAmIAegmIAXAAIgjAoIAlAtg");
	this.shape_13.setTransform(99.225,129.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_14.setTransform(90.675,129.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgWAnQgLgGgFgKQgGgKAAgNQAAgMAGgKQAFgKALgGQAKgGAMAAQANAAAKAGQALAGAFAKQAGAKAAAMQAAANgGAKQgFAKgLAGQgKAGgNAAQgMAAgKgGgAgNgYQgGAEgDAGQgDAHAAAHQAAAIADAGQADAHAGAEQAGADAHAAQAIAAAGgDQAGgEADgHQADgGAAgIQAAgHgDgHQgDgGgGgEQgGgDgIAAQgHAAgGADg");
	this.shape_15.setTransform(81.325,129.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAQArIgQg6IgOA6IgUAAIgYhVIAVAAIAPA9IAQg9IANAAIARA9IAPg9IAVAAIgZBVg");
	this.shape_16.setTransform(70.35,129.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgNAYQgGgEgDgGQgFgGAAgIQAAgGAFgHQADgGAGgDQAHgFAGAAQAIAAAGAFQAHADADAGQAEAHgBAGQABAIgEAGQgDAGgHAEQgGAEgIgBQgGABgHgEgAgLgTQgFADgDAFQgDAGAAAFQAAAHADAFQADAFAFADQAFAEAGAAQAHAAAFgEQAFgDAEgFQADgFAAgHQAAgFgDgGQgEgFgFgDQgFgDgHAAQgGAAgFADgAAHAQIgHgMIgFAAIAAAMIgFAAIAAgfIANAAQADAAADADQAEADAAAEIgCAFIgEACIgCACIAIAMgAgFAAIAIAAIADgBQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAIgDgCIgIAAg");
	this.shape_17.setTransform(57.85,127.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_18.setTransform(50.975,129.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgSAnQgKgFgGgKQgGgKAAgOQAAgNAGgKQAGgKAKgFQALgGAMAAQAIAAAIADQAGADAFAEIAIAKIgPAIQgDgFgFgDQgGgDgGAAQgIAAgGADQgGAEgDAGQgDAHgBAHQABAIADAHQADAGAGAEQAGADAIAAQAFAAAFgCQAFgCADgCIAAgLIgXAAIAAgPIApAAIAAAhQgGAHgKAEQgIAFgMAAQgMAAgLgGg");
	this.shape_19.setTransform(42.3,129.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAYArIgGgOIgjAAIgGAOIgVAAIAihVIAVAAIAiBVgAANAMIgNgkIgNAkIAaAAg");
	this.shape_20.setTransform(33.25,129.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAQArIgQg6IgOA6IgTAAIgahVIAWAAIAOA9IARg9IAOAAIAQA9IAPg9IAUAAIgYBVg");
	this.shape_21.setTransform(22.8,129.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_22.setTransform(13.175,129.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAVArIgog3IAAA3IgTAAIAAhVIATAAIAnA1IAAg1IATAAIAABVg");
	this.shape_23.setTransform(4.475,129.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-2.3,121.8,215.9,17.000000000000014), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение151111();
	this.instance.parent = this;
	this.instance.setTransform(-5,-4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc31, new cjs.Rectangle(-5,-4,336,269), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],14.7,-19,14.7,27).s().p("A7vEsIAApXMA3fAAAIAAJXg");
	this.shape.setTransform(166,162.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_1
	this.instance = new lib.screen2111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc21, new cjs.Rectangle(-11.6,0,355.3,192), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen1111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,296), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.pc31копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},13).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},19).to({state:[]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},22).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},28).to({state:[]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},32).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},38).to({state:[]},1).wait(113));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},42).to({state:[]},1).wait(113));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},48).to({state:[]},1).wait(113));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},52).to({state:[]},1).wait(113));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},58).to({state:[]},1).wait(113));

	// Слой_1
	this.instance = new lib.Растровоеизображение151();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(66).to({_off:true},1).wait(113));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},7).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},13).to({state:[]},1).wait(119));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},16).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},22).to({state:[]},1).wait(119));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},26).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},32).to({state:[]},1).wait(119));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},36).to({state:[]},1).wait(119));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},42).to({state:[]},1).wait(119));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},46).to({state:[]},1).wait(119));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},52).to({state:[]},1).wait(119));

	// Слой_1
	this.instance = new lib.screen211();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:true},1).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape.setTransform(237.675,27);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_1.setTransform(233.525,25.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEgBgGQABgEACgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAFACADADQACAEACAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgEAAQgCAAgEABg");
	this.shape_2.setTransform(229.55,26.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AATAhIAAgeIgmAAIAAAeIgIAAIAAhBIAIAAIAAAcIAmAAIAAgcIAJAAIAABBg");
	this.shape_3.setTransform(223.225,25.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_4.setTransform(270.4,16.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_5.setTransform(264.625,17.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_6.setTransform(260.775,15.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_7.setTransform(257.275,16.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgDgFIgGgEQgCgBgFAAQgCAAgEABg");
	this.shape_8.setTransform(252.15,16.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGAAAGQAAAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_9.setTransform(246,15.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgFAEIgCAFIgCAGIAgAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgDABg");
	this.shape_10.setTransform(236.9,16.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgDgEAAgGQAAgEADgFIAEgIQADgDAFgCQAFgCAEAAQAFAAAEACQAEACAEADQADAEABAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgDgBgEAAQgEAAgDABg");
	this.shape_11.setTransform(231.25,16.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_12.setTransform(227.075,16.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_13.setTransform(222.625,15.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_14.setTransform(158.325,27.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(152.85,26.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(148.975,25.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAFgCQAEgCAFAAQAGAAAEACIAHAGIgFAFQgCgEgDgBQgDgCgEAAQgEAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACAEAAQAIAAAEgHIAFAFIgHAGQgEACgGAAQgFAAgEgBg");
	this.shape_17.setTransform(145.45,26.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(141.775,25.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(139.275,26.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(134.725,25.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgJAgIgHgFIgEgIQgCgEAAgGQAAgGACgEQACgFACgDQADgDAEgCQAEgCAFAAQAEAAAEACQAEADADAEIAAgaIAIAAIAABCIgIAAIAAgHQgCADgFADQgEACgEAAQgFAAgEgCgAgFgIIgFAEIgDAFIgBAIIABAHIADAGIAFAEQADABADAAQAEAAAEgCQAEgCACgDIAAgVQgCgDgEgDQgEgCgEAAQgDAAgDABg");
	this.shape_21.setTransform(156.825,15.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEgBgGQABgEACgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAFACADADQACAEACAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgEAAQgCAAgEABg");
	this.shape_22.setTransform(151.25,16.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_23.setTransform(147.075,16.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgDgDgDgFQgBgEgBgGQABgEABgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACAEADQACAEACAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_24.setTransform(142.3,16.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_25.setTransform(138.375,15.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAhIAAg6IgWAAIAAgHIAzAAIAAAHIgWAAIAAA6g");
	this.shape_26.setTransform(134.4,15.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_27.setTransform(71.025,27.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_28.setTransform(65.55,26.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_29.setTransform(61.675,25.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_30.setTransform(57.875,27);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_31.setTransform(52.175,27);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_32.setTransform(48.025,25.275);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AAMAhIAAggIAAgEIgDgDQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgDABIgFACIgDACIgCADIAAAiIgIAAIAAhBIAIAAIAAAZIADgDIADgDIAFgCIAFAAQAIAAAEADQADAEAAAIIAAAhg");
	this.shape_33.setTransform(44.15,25.225);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAFgGIADADIAFADIAGACIAFABQAFAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBIABgDQAAgEgBgCIgFgDIgGgDIgGgCIgIgCIgGgCIgEgFQgCgDAAgFQAAgEACgDIAEgGIAHgEIAJgBQAHAAAHACQAGACAEAFIgGAGQgDgEgGgCQgFgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAEADIAHADIAHACIAHACIAGADIAFAFQABADAAAFIgBAHQgBAEgEACQgDADgEACQgFABgHAAQgHAAgGgDg");
	this.shape_34.setTransform(38.5,25.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape_35.setTransform(58.825,15.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAFgCQAEgCAFAAQAGAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgDAAQgEAAgCACQgEABgBADIgEAGIgBAGIABAIIAEAFQABADAEABQACACAEAAQAHAAAFgHIAFAFIgHAGQgEACgGAAQgFAAgEgBg");
	this.shape_36.setTransform(53.55,16.125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_37.setTransform(49.875,15.275);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIABAGIADADIADACIAEAAQAEAAADgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_38.setTransform(46,16.175);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AASAdIgIADIgKABQgGABgHgDQgGgDgEgEQgEgFgDgGQgCgHAAgGQAAgHACgGQADgHAEgEQAEgFAGgCQAHgDAGAAQAHAAAGADQAHACAEAFQAEAEADAHQACAGAAAHQAAAGgCAHQgDAGgEAFIAGAHIgGAEgAgJgZQgFACgDAEQgDAEgCAEQgCAFAAAGQAAAFACAFQACAFADAEQADADAFACQAEACAFAAQAHAAAGgDIgKgKIAGgGIAJALQADgDACgFQABgFAAgFQAAgGgBgFQgCgEgDgEQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_39.setTransform(39.425,15.3);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(202.85,21.45,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(112.5,21.85,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(15.15,21.85,0.515,0.515,0,0,0,0.1,0.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_40.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-8.1,8.7,288.6,30.599999999999998), null);


// stage content:
(lib._336x280_Builders = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_770 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(770).call(this.frame_770).wait(131));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape.setTransform(167.9993,139.9994,1.12,1.12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_1.setTransform(168,140);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_2.setTransform(168,140);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_3.setTransform(168,140);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_4.setTransform(168,140);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_5.setTransform(168,140);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_6.setTransform(168,140);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_7.setTransform(168,140);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_8.setTransform(167.9993,139.9994,1.12,1.12);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(59).to({_off:false},0).wait(1).to({_off:true},1).wait(65).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(59).to({_off:false},0).wait(1).to({_off:true},1).wait(65).to({_off:false},0).to({_off:true},1).wait(53));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(54));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(55));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(56));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(57));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(58));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(59));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(60));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(43).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(43).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(61));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(167.95,17.9,0.7999,0.7999);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(633).to({_off:true},215).wait(53));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-137.8,-29.5,-71.9,8.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_9.setTransform(167.825,250.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-129.1,-26.5,-63.3,11.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_10.setTransform(167.825,250.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-120.5,-23.4,-54.6,14.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_11.setTransform(167.825,250.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-111.8,-20.4,-46,17.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_12.setTransform(167.825,250.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-103.2,-17.4,-37.3,20.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_13.setTransform(167.825,250.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-94.5,-14.4,-28.7,23.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_14.setTransform(167.825,250.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.8,-11.4,-20,26.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_15.setTransform(167.825,250.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-77.2,-8.4,-11.3,29.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_16.setTransform(167.825,250.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.5,-5.4,-2.7,32.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_17.setTransform(167.825,250.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-59.9,-2.4,6,35.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_18.setTransform(167.825,250.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.2,0.7,14.6,38.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_19.setTransform(167.825,250.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-42.6,3.7,23.3,41.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_20.setTransform(167.825,250.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-33.9,6.7,31.9,44.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_21.setTransform(167.825,250.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.3,9.7,40.5,47.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_22.setTransform(167.825,250.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,12.7,49.2,50.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_23.setTransform(167.825,250.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-8,15.8,57.8,53.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_24.setTransform(167.825,250.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,18.8,66.5,56.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_25.setTransform(167.825,250.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],9.3,21.8,75.1,59.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_26.setTransform(167.825,250.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],18,24.8,83.8,62.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_27.setTransform(167.825,250.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.6,27.8,92.5,65.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_28.setTransform(167.825,250.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],35.3,30.8,101.1,68.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_29.setTransform(167.825,250.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],43.9,33.9,109.8,71.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_30.setTransform(167.825,250.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],52.6,36.9,118.4,74.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_31.setTransform(167.825,250.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],61.2,39.9,127.1,77.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_32.setTransform(167.825,250.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],69.9,42.9,135.7,80.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_33.setTransform(167.825,250.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},399).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[]},362).wait(53));

	// Слой_8
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgTApQgLgEgGgFIAKgRQACAEAGACIAKAEQAGACAEAAQAHAAADgDQAEgCAAgEQAAgEgFgCIgLgDIgQgEQgHgDgFgEQgFgFgBgKQAAgHAEgGQAFgGAIgDQAHgEALgBQAKAAAJAEQAIADAHAFIgJAQQgEgEgHgDQgHgDgHAAQgFAAgEADQgEACAAADQABAEAEACIAMACIAPAFQAHACAFAFQAGAGgBAJQAAAIgDAHQgFAFgJAEQgHAEgMgBQgLABgJgEg");
	this.shape_34.setTransform(235.65,172.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AASArIAAgyQAAgJgFgDQgEgEgHABQgGAAgFADIgHAGIAAA4IgXAAIAAhTIAXAAIAAALIAGgHIAKgEQAFgCAHgBQAPAAAGAIQAHAHAAAMIAAA7g");
	this.shape_35.setTransform(226.45,172.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgFgKAAgMQAAgMAFgJQAGgKAKgHQAKgFANgBQAOABAKAFQAKAHAFAKQAGAJAAAMQAAAMgGAKQgFAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgDAGAAAGQAAAGADAHQACAFAFAEQAFACAGAAQAHAAAFgCQAFgEACgFQADgHAAgGQAAgGgDgGQgCgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_36.setTransform(216.3,172.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgKA8IAAhUIAVAAIAABUgAgIglQgEgDAAgGQAAgGAEgEQADgDAFAAQAGAAADADQAEAEAAAGQAAAGgEADQgDAEgGAAQgFAAgDgEg");
	this.shape_37.setTransform(209.025,170.925);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_38.setTransform(203.825,171.65);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AggAlQgHgIAAgMIAAg7IAXAAIAAAyQAAAJAEAEQAEADAHgBQAGAAAFgCQAFgDADgEIAAg4IAWAAIAABTIgWAAIAAgKQgFAFgHAEQgHADgKAAQgOAAgHgGg");
	this.shape_39.setTransform(195.775,172.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgKA7IAAh1IAVAAIAAB1g");
	this.shape_40.setTransform(188.475,171.075);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgFgKQgFgKgBgMQABgMAFgJQAFgKAKgHQAKgFANgBQAOABAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgEADgDAFQgDAGABAGQgBAGADAHQADAFAEAEQAFACAGAAQAHAAAFgCQAEgEADgFQADgHAAgGQAAgGgDgGQgDgFgEgDQgFgEgHABQgGgBgFAEg");
	this.shape_41.setTransform(181.15,172.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgbA4QgMgGgIgIIANgUQAHAHAJAEQAJAFAMABQAKgBAFgEQAFgDAAgGQgBgEgEgDIgMgFIgQgEQgJgCgHgEQgIgDgEgGQgFgHgBgLQAAgKAGgHQAFgJAKgFQAKgEANAAQAOAAALADQAMAFAIAIIgNATQgIgHgJgDQgJgEgHAAQgJAAgDAEQgFADAAAFQAAAFAFACQAFADAHACIAQADIAQAHQAIAEAEAFQAFAHABALQAAALgGAIQgFAIgLAGQgKAEgQAAQgPAAgNgEg");
	this.shape_42.setTransform(170.8,171.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgeA7IgGgBIADgUIAEACIADAAQAFAAADgCQACgBACgDIADgIIgihVIAYAAIAVA7IAWg7IAYAAIgoBiQgDAIgEAFQgFAEgGACQgGACgHAAIgFgBg");
	this.shape_43.setTransform(156.625,174.425);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgKQgGgLAAgNQAAgLAGgKQAFgKAKgHQAKgFAMgBQANABAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAGgKACQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_44.setTransform(147.225,172.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAOA7IgWghIgKALIAAAWIgXAAIAAh1IAXAAIAABGIAfglIAcAAIgiAlIAjAvg");
	this.shape_45.setTransform(138.2,171.075);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AARArIAAgyQAAgJgEgDQgEgEgHABQgGAAgFADIgIAGIAAA4IgWAAIAAhTIAWAAIAAALIAIgHIAJgEQAFgCAHgBQAPAAAGAIQAHAHAAAMIAAA7g");
	this.shape_46.setTransform(127.85,172.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_47.setTransform(119.975,172.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AggAlQgHgIAAgMIAAg7IAXAAIAAAyQAAAJAEAEQAEADAHgBQAGAAAFgCQAFgDADgEIAAg4IAWAAIAABTIgWAAIAAgKQgFAFgHAEQgHADgKAAQgOAAgHgGg");
	this.shape_48.setTransform(111.325,172.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgMA7IAAhfIgiAAIAAgWIBdAAIAAAWIgiAAIAABfg");
	this.shape_49.setTransform(101.125,171.075);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgXAqQgGgEgFgGQgEgGAAgJQAAgKAEgHQAFgEAGgEQAHgCAHAAQAJAAAGACQAHAEAEAEIAAgKQAAgHgFgDQgFgFgIAAQgHABgGACQgGACgFAFIgJgPQAIgHAJgEQAKgDAJAAQAKAAAIADQAJAEAFAHQAFAGAAANIAAA2IgWAAIAAgJQgFAFgHADQgGACgIAAQgHAAgHgCgAgLAIQgFADAAAGQAAAGAFADQAEAEAHgBQAEAAAFgCQAFgBADgEIAAgLQgDgDgFgCQgFgCgEAAQgHAAgEAEg");
	this.shape_50.setTransform(231.925,173.75);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgUAnQgKgGgGgJQgGgKAAgOQAAgMAGgJQAFgLAKgFQAKgHAMAAQANAAAJAHQAKAFAFALQAFAKAAANIAAAGIg+AAQABAHAHAFQAGAGAKAAIAIAAIAIgDIAGgFIAKAPQgGAFgKAEQgJACgKAAQgMAAgKgFgAAWgHQAAgEgDgFQgCgDgEgEQgFgCgHAAQgGAAgFACQgEAEgCADQgCAFgBAEIApAAIAAAAg");
	this.shape_51.setTransform(222.525,173.75);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgqA8IAAh1IAXAAIAAALQAFgGAGgDQAHgEAHAAQAKAAAJAGQAJAFAEAKQAFAKAAAOQAAAOgFAJQgEAKgJAFQgJAFgKAAQgHAAgHgDQgHgDgEgHIAAAsgAgLgkQgGACgCAFIAAAdQACAEAGADQAFACAGAAQAJAAAFgGQAGgGAAgLQAAgLgGgHQgFgHgJAAQgGAAgFADg");
	this.shape_52.setTransform(212.8,175.275);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgqA8IAAh1IAXAAIAAALQAEgGAHgDQAHgEAHAAQAKAAAJAGQAJAFAEAKQAFAKAAAOQAAAOgFAJQgEAKgJAFQgJAFgKAAQgHAAgHgDQgGgDgFgHIAAAsgAgLgkQgGACgCAFIAAAdQACAEAGADQAFACAGAAQAJAAAFgGQAGgGAAgLQAAgLgGgHQgFgHgJAAQgGAAgFADg");
	this.shape_53.setTransform(202.55,175.275);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAgA7IgHgUIgxAAIgIAUIgcAAIAth1IAfAAIAtB1gAASARIgSgyIgRAyIAjAAg");
	this.shape_54.setTransform(191.175,172.125);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AApAsIAAg1QAAgGgDgEQgCgEgIAAQgFAAgFAEQgEADgDADIAAA5IgVAAIAAg1QgBgGgDgEQgCgEgHAAQgGAAgFAEQgEADgDADIAAA5IgWAAIAAhVIAWAAIAAAMIAHgGQADgDAGgCQAFgCAHgBQAJAAAGAFQAFAEADAHQACgEAFgEQAEgDAGgCQAFgCAHgBQAMABAGAGQAHAGAAANIAAA9g");
	this.shape_55.setTransform(173.1,173.65);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgGgLQgFgKAAgMQAAgLAFgKQAGgLAKgFQAKgHANAAQAOAAAKAHQAKAFAFALQAGAKAAALQAAAMgGAKQgFALgKAFQgKAHgOgBQgNABgKgHgAgLgUQgFADgCAGQgDAFAAAGQAAAGADAGQACAGAFADQAFAEAGAAQAHAAAFgEQAFgDACgGQADgGAAgGQAAgGgDgFQgCgGgFgDQgFgEgHAAQgGAAgFAEg");
	this.shape_56.setTransform(160.5,173.75);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgFgLQgGgKAAgMQAAgLAGgKQAFgLAKgFQAKgHANAAQAOAAAKAHQAKAFAFALQAGAKAAALQAAAMgGAKQgFALgKAFQgKAHgOgBQgNABgKgHgAgLgUQgEADgDAGQgCAFAAAGQAAAGACAGQADAGAEADQAFAEAGAAQAHAAAFgEQAEgDADgGQADgGAAgGQAAgGgDgFQgDgGgEgDQgFgEgHAAQgGAAgFAEg");
	this.shape_57.setTransform(150.35,173.75);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgYAsIAAhVIAXAAIAAAMQADgFAHgEQAIgFAIAAIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA3g");
	this.shape_58.setTransform(142.575,173.65);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AASArIgSg6IgRA6IgYAAIgahVIAXAAIAQA5IATg5IATAAIASA5IAQg5IAYAAIgaBVg");
	this.shape_59.setTransform(132.225,173.75);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgGgLQgFgKAAgMQAAgLAFgKQAGgLAKgFQAKgHANAAQAOAAAKAHQAKAFAFALQAGAKAAALQAAAMgGAKQgFALgKAFQgKAHgOgBQgNABgKgHgAgLgUQgEADgDAGQgDAFAAAGQAAAGADAGQADAGAEADQAFAEAGAAQAHAAAFgEQAFgDADgGQACgGAAgGQAAgGgCgFQgDgGgFgDQgFgEgHAAQgGAAgFAEg");
	this.shape_60.setTransform(120.35,173.75);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AASA7IAAg0QAAgIgFgDQgEgEgHABQgGAAgEADQgFADgEACIAAA6IgWAAIAAh1IAWAAIAAAsIAIgGIAJgFQAFgCAHAAQAPAAAGAHQAHAHAAAMIAAA8g");
	this.shape_61.setTransform(110.2,172.125);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgbA3QgMgEgJgJIAPgTQAFAGAKAFQAJAEAMABQAKgBAFgEQAFgEAAgFQgBgFgEgDIgNgEIgPgEQgJgCgHgDQgIgEgFgGQgEgHgBgLQAAgKAGgHQAFgJAKgFQAKgEANAAQAOAAALAEQAMAEAIAIIgNASQgIgGgJgEQgJgCgIAAQgHAAgEADQgFADAAAFQAAAFAFACQAFADAHACIAPAEIARAGQAIADAEAHQAFAGABALQgBALgFAIQgFAJgLAEQgKAGgPgBQgRABgMgGg");
	this.shape_62.setTransform(99.8,172.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40,p:{x:188.475,y:171.075}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34}]},123).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_40,p:{x:239.225,y:172.125}}]},86).to({state:[]},87).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40,p:{x:188.475,y:171.075}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34}]},251).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_40,p:{x:239.225,y:172.125}}]},86).to({state:[]},87).to({state:[]},128).wait(53));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.instance_2 = new lib.t122();
	this.instance_2.parent = this;
	this.instance_2.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},296).to({state:[{t:this.instance_1}]},128).to({state:[{t:this.instance_2}]},296).to({state:[]},128).wait(53));

	// t11
	this.instance_3 = new lib.t11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(168,117.25,1,1,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(424).to({_off:true},424).wait(53));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(168,213.4,1,1,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(123).to({y:215.6},0).wait(301).to({y:213.4},0).wait(123).to({y:215.6},0).to({_off:true},301).wait(53));

	// Слой_5
	this.instance_5 = new lib.icons();
	this.instance_5.parent = this;
	this.instance_5.setTransform(168.8,170.55,1.12,1.12,0,0,0,136.4,18.6);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({alpha:1},6).to({_off:true},117).wait(301).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},117).wait(354));

	// Слой_14
	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("A6PJ+IAAz8MA0fAAAIAAT8g");
	this.shape_63.setTransform(168,216.35);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("A6PJ/IAAz8MA0fAAAIAAT8g");
	this.shape_64.setTransform(168,252.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_63}]}).to({state:[{t:this.shape_64}]},123).to({state:[{t:this.shape_63}]},301).to({state:[{t:this.shape_64}]},123).to({state:[]},301).wait(53));

	// Слой_4
	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_65.setTransform(275.425,175.8063);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgGAAQgEAAgEACQgDACgDADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAFAAQALAAAGAGQAFAGAAAJIAAAug");
	this.shape_66.setTransform(267.7,174.475);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_67.setTransform(262.025,173.175);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_68.setTransform(258.125,174.475);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgJAAgJQAAgIAEgIQAEgIAIgEQAIgGAKAAQALAAAIAGQAHAEAFAIQAEAIAAAIQAAAJgEAJQgFAHgHAFQgIAEgLABQgKgBgIgEgAgIgQQgEADgCAFQgCAEAAAEQAAAFACAEQACAFAEADQAEACAEAAQAFAAAEgCQAEgDACgFQACgEAAgFQAAgEgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_69.setTransform(251.475,174.55);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgJAAgJQAAgIAEgIQAEgIAIgEQAIgGAKAAQALAAAIAGQAHAEAFAIQAEAIAAAIQAAAJgEAJQgFAHgHAFQgIAEgLABQgKgBgIgEgAgIgQQgEADgCAFQgCAEAAAEQAAAFACAEQACAFAEADQAEACAEAAQAFAAAEgCQAEgDACgFQACgEAAgFQAAgEgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_70.setTransform(243.625,174.55);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_71.setTransform(237.975,173.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgfAtIAAhaIA/AAIAAASIgsAAIAAASIArAAIAAARIgrAAIAAAlg");
	this.shape_72.setTransform(232.575,173.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgEgHgBgLQABgIAEgJQAEgHAIgFQAHgEAJgBQALAAAHAFQAHAFAEAIQAEAIABAJIAAAFIgxAAQABAGAFAEQAFAFAHAAIAGgCIAHgCIAFgDIAHALQgFAFgGADQgHABgJAAQgJAAgIgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_73.setTransform(308.2,160.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgTAqQgGgEgEgIQgDgHAAgLQAAgLADgHQAEgHAGgFQAHgEAIAAQAGAAAEADQAGACAEAFIAAghIARAAIAABaIgRAAIAAgJQgEAFgFADQgGACgFAAQgIAAgHgEgAgKgBQgEAEgBAJQABAIAEAGQAFAFAGAAQAFAAAEgCQAEgCACgEIAAgXQgCgCgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_74.setTransform(300.25,159.725);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgEgFABgHQgBgIAEgFQAEgDAEgCQAGgDAFAAQAHAAAFADQAFACADADIAAgIQAAgFgEgDQgEgDgFAAQgFAAgFACQgFACgEAEIgHgMQAGgGAIgCQAHgDAGAAQAJAAAGADQAHACADAGQAEAFAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEABgHAAQgFABgGgDgAgIAGQgEADAAAEQAAAFAEADQADACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_75.setTransform(292.55,160.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_76.setTransform(286.875,160.825);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgTApQgKgGgHgKQgGgKgBgPQABgNAGgLQAHgKAKgGQALgGANAAQAJAAAHADQAIACAFAFQAFAFADAFIgQAJQgDgFgFgDQgGgDgHgBQgHABgHADQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAHAGAEQAHAEAHAAQAGAAAFgDIAIgEIAAgLIgYAAIAAgQIAsAAIAAAiQgHAIgKAEQgKAFgMAAQgNAAgLgGg");
	this.shape_77.setTransform(279.075,159.65);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgPAHIAAgOIAfAAIAAAOg");
	this.shape_78.setTransform(272.25,160.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_79.setTransform(268.425,159.65);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgSAgQgFgCgDgFQgDgFgBgHQABgIADgFQADgDAFgCQAGgDAGAAQAGAAAEADQAGACADADIAAgIQAAgFgEgDQgDgDgHAAQgEAAgGACQgEACgEAEIgHgMQAGgGAHgCQAIgDAHAAQAHAAAHADQAGACAEAGQAFAFAAAJIAAAqIgSAAIAAgHQgDAEgGADQgEABgGAAQgGABgGgDgAgJAGQgDADAAAEQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_80.setTransform(262.8,160.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_81.setTransform(257.575,159.525);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgNAeQgHgFgFgHQgEgIgBgKQABgJAEgIQAFgHAHgFQAIgFAJAAQAHABAFACQAFABADACIAHAHIgMAKQgCgEgEgCQgEgBgEAAQgHAAgFAFQgEAGgBAHQABAIAEAGQAFAFAHAAQAEAAAEgCQAEgCACgDIAMALIgHAFIgIAFQgFACgHgBQgJAAgIgEg");
	this.shape_82.setTransform(252.55,160.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_83.setTransform(246.875,160.825);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgFgHAAgLQAAgIAFgJQAEgHAIgFQAHgEAJgBQALAAAHAFQAHAFAEAIQAFAIAAAJIAAAFIgxAAQABAGAFAEQAFAFAHAAIAGgCIAHgCIAFgDIAHALQgFAFgGADQgIABgIAAQgJAAgIgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgEACQgDACgBADQgDAEAAADIAgAAIAAAAg");
	this.shape_84.setTransform(240.35,160.9);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AAhAiIAAgpQgBgFgCgCQgCgDgFAAQgFAAgEACQgEACgBADIAAAsIgRAAIAAgpQAAgFgCgCQgCgDgGAAQgEAAgEACQgDACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAEgEQAEgCAEgCQAFgCAEAAQAIAAAEADQAEAEABAFIAGgGIAIgEQAFgCAFAAQAIAAAFAFQAGAFAAAKIAAAvg");
	this.shape_85.setTransform(230.75,160.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AAhAiIAAgpQAAgFgDgCQgCgDgGAAQgEAAgEACQgDACgCADIAAAsIgRAAIAAgpQAAgFgCgCQgCgDgFAAQgFAAgEACQgDACgCADIAAAsIgSAAIAAhBIASAAIAAAIIAFgEQADgCAEgCQAFgCAFAAQAGAAAEADQAFAEACAFIAFgGIAIgEQAEgCAFAAQAKAAAFAFQAEAFAAAKIAAAvg");
	this.shape_86.setTransform(219.1,160.825);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgFQAIgEAKgBQALABAIAEQAHAFAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_87.setTransform(209.375,160.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgSApQgLgGgHgLQgGgKAAgOQAAgNAGgKQAHgLALgGQALgGAMAAQAKAAAIAEQAHADAFAEQAFAFADAHIgQAIQgDgGgGgEQgFgDgIgBQgHABgGADQgHAEgDAHQgEAGAAAIQAAAJAEAGQADAHAHAEQAGAEAHAAQAIAAAFgEQAGgDADgHIAQAIQgDAHgFAEQgFAGgHADQgIADgKAAQgMAAgLgGg");
	this.shape_88.setTransform(200.875,159.65);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgFgHAAgLQAAgIAFgJQAEgHAIgEQAHgFAJgBQALAAAHAFQAHAFAEAIQAFAIAAAJIAAAFIgxAAQABAGAFAEQAFAFAHAAIAGgCIAHgCIAFgDIAHALQgFAFgGADQgIABgIAAQgJAAgIgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgEACQgDACgBADQgDAEAAADIAgAAIAAAAg");
	this.shape_89.setTransform(112.1,175.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_90.setTransform(104.075,177.0063);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgRAgQgGgCgDgFQgDgFgBgHQABgIADgFQADgDAGgCQAFgDAGAAQAGAAAEADQAGACADADIAAgIQAAgFgEgDQgDgDgHAAQgEAAgGACQgEACgEAEIgHgMQAGgGAHgCQAIgDAHAAQAHAAAHADQAGACAFAGQADAFAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEABgGAAQgGABgFgDgAgIAGQgEADAAAEQAAAFAEADQADACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgDADg");
	this.shape_91.setTransform(96.4,175.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_92.setTransform(90.775,175.675);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgFAKgBQALABAIAFQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_93.setTransform(84.075,175.75);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQAAADABACQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgCIADAOIgFADIgJABQgJAAgEgFg");
	this.shape_94.setTransform(77.8,174.925);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgGIALgQQAFAGAHADQAIAEAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgCgGgBIgLgEIgNgEQgGgDgEgEQgDgGgBgIQABgHAEgHQAEgHAIgDQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgCgGgBQgGABgDACQgEACAAAEQABAEADACQAEACAGABIALADQAHACAGADQAGADAEAFQADAEABAJQAAAJgEAGQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_95.setTransform(71.375,174.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgGQgEgFAAgJQAAgHADgFQACgFAFgEIAKgEIgFgKIgBgKQAAgGADgFQADgFAGgDQAGgCAIgBQAFAAAFACQAGADADAEQADAFAAAFQAAAIgDAEQgDAEgFADIgKAGIADAFIAEAEIAIAJIAFgJIADgHIAOAGIgGAKIgHALIAJAJIAJAJIgWAAIgEgDIgDgDQgFAEgHACQgFACgHAAQgIAAgHgDgAgUALQgDADAAAFQAAAEACAEQACADADACQAEABADAAIAHgBIAGgDIgFgGIgFgGIgEgFIgFgHQgDADgCADgAgHgeQgDACAAAFIABAFIADAGQAGgCACgEQAEgCAAgGQAAgEgCgBQgCgCgDAAQgEAAgCADg");
	this.shape_96.setTransform(59.525,174.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgFgHQgEgJgBgKQABgJAEgHQAEgIAIgFQAHgEAJAAQALgBAHAFQAHAFAEAIQAFAIAAAKIAAADIgxAAQABAHAFAEQAFAEAHABIAGgBIAHgCIAFgEIAHALQgFAFgGACQgHACgJAAQgJAAgIgEgAARgFIgCgHQgCgDgEgCQgDgCgGgBQgEABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_97.setTransform(137.65,162.1);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_98.setTransform(131.725,162.025);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgYAcQgGgFAAgKIAAguIASAAIAAAnQAAAHACADQAEADAFgBQAFAAADgCIAHgFIAAgsIARAAIAABBIgRAAIAAgIQgEAEgFADQgGADgIAAQgKAAgFgGg");
	this.shape_99.setTransform(125,162.175);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQAAADABACQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAIAEAAIACgCIAEAOIgFADIgJABQgJAAgEgFg");
	this.shape_100.setTransform(118.75,161.275);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_101.setTransform(114.725,160.725);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AAOAiIAAgnQAAgHgEgDQgDgCgGAAQgDAAgFACQgDACgCADIAAAsIgSAAIAAhBIASAAIAAAIIAFgEIAHgEQAEgCAFAAQAMAAAEAGQAGAGAAAJIAAAug");
	this.shape_102.setTransform(109.05,162.025);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_103.setTransform(102.925,162.025);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgZAcQgFgFAAgKIAAguIARAAIAAAnQABAHADADQADADAGgBQADAAAFgCIAFgFIAAgsIASAAIAABBIgSAAIAAgIQgDAEgGADQgFADgHAAQgMAAgFgGg");
	this.shape_104.setTransform(96.25,162.175);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgfAuIAAhaIA/AAIAAARIgsAAIAAATIArAAIAAAQIgrAAIAAAmg");
	this.shape_105.setTransform(88.625,160.85);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_106.setTransform(78.825,162.025);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgIAAgKQAAgJAEgHQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAHAAAJQAAAKgEAIQgFAHgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAFQgCAEAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_107.setTransform(72.125,162.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgIAAgKQAAgJAEgHQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAHAAAJQAAAKgEAIQgFAHgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAFQgCAEAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_108.setTransform(64.275,162.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgSAqQgHgEgDgIQgFgHAAgLQAAgLAFgHQADgHAHgFQAGgEAIAAQAFAAAGADQAFACAEAFIAAghIASAAIAABaIgSAAIAAgJQgEAFgFADQgFACgGAAQgIAAgGgEgAgKgBQgEAEgBAJQABAIAEAGQAFAFAGAAQAFAAADgCQAEgCADgEIAAgXQgDgCgEgCQgDgCgFAAQgGAAgFAFg");
	this.shape_109.setTransform(56.2,160.925);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQAAADACACQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAIAEAAIADgCIADAOIgGADIgJABQgHAAgFgFg");
	this.shape_110.setTransform(50.05,161.275);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgZAcQgFgFAAgKIAAguIASAAIAAAnQAAAHADADQADADAFgBQAEAAAEgCIAHgFIAAgsIARAAIAABBIgRAAIAAgIQgEAEgFADQgGADgIAAQgKAAgGgGg");
	this.shape_111.setTransform(43.8,162.175);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgXApQgLgGgGgLQgGgKgBgOQABgMAGgMQAGgKALgGQALgGANAAQANAAAKAGQAMAGAFAKQAHAMAAAMQAAAOgHAKQgFALgMAGQgKAGgNAAQgNAAgLgGgAgNgZQgGAEgEAHQgEAHAAAHQAAAJAEAGQAEAHAGAEQAFAEAJAAQAHAAAHgEQAGgEADgHQADgGABgJQgBgHgDgHQgDgHgGgEQgHgEgHAAQgJAAgFAEg");
	this.shape_112.setTransform(34.65,160.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65}]},357).to({state:[]},67).to({state:[{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65}]},357).to({state:[]},67).wait(53));

	// Слой_13
	this.instance_6 = new lib.pc31копия("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(233.6,140,1,1,0,0,0,233.6,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(357).to({_off:false},0).to({_off:true},67).wait(357).to({_off:false},0).to({_off:true},67).wait(53));

	// Слой_15
	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAHgMIAHAEIAIAEIAHABQAGAAADgCQACgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgEgDQgDgEgBgIQAAgFADgFQAEgFAFgDQAGgCAIAAQAIAAAHACQAGADAGAEIgHAMQgDgDgFgDQgFgBgHgBIgGACQgDACAAADQAAACAEABIAJADIALADQAGACAEAEQAEAEAAAHQAAAGgEAFQgDAFgGADQgHACgIAAQgIAAgIgCg");
	this.shape_113.setTransform(312.4,175.05);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgFgIABgLQgBgJAFgHQAEgIAIgFQAIgEAIAAQAKgBAIAFQAHAEAFAJQADAIAAAKIAAADIgvAAQAAAHAFAEQAFAEAIABIAFgBIAGgDIAGgDIAIALQgGAFgHACQgGACgIAAQgKAAgHgDgAARgFIgCgHQgCgDgEgCQgDgCgGgBQgEABgEACQgDACgBADQgCAEAAADIAfAAIAAAAg");
	this.shape_114.setTransform(305.45,175.05);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgNAeQgIgEgEgIQgEgIgBgKQABgJAEgIQAEgIAIgEQAIgFAJABQAHAAAFACQAFABADACIAHAHIgMAKQgCgEgEgBQgEgCgEAAQgHAAgFAFQgEAFgBAIQABAJAEAFQAFAFAHAAQAEAAAEgCQAEgBACgEIAMALIgHAGIgIAEQgFABgHAAQgJABgIgFg");
	this.shape_115.setTransform(298.35,175.05);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AANAiIAAgnQABgHgEgDQgDgCgFAAQgEAAgEACQgEACgDADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAGAGQAFAGAAAJIAAAug");
	this.shape_116.setTransform(290.9,174.975);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgSAgQgFgCgDgFQgDgFgBgHQABgIADgEQADgFAFgBQAGgCAGAAQAGAAAEACQAGACADADIAAgIQAAgFgEgCQgDgEgHAAQgEAAgGADQgEABgEAEIgHgMQAGgFAHgDQAIgCAHAAQAHAAAHACQAGACAEAGQAFAFAAAJIAAAqIgSAAIAAgHQgDAEgGACQgEACgGAAQgGAAgGgCgAgJAFQgDADAAAFQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgCQgDgBgEAAQgFAAgEACg");
	this.shape_117.setTransform(283.05,175.05);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_118.setTransform(277.775,173.675);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgIAuIAAhaIARAAIAABag");
	this.shape_119.setTransform(274.325,173.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AggAuIAAhaIARAAIAAAJQAEgFAFgDQAFgCAFAAQAJAAAGAEQAHAEAEAIQADAHABALQgBALgDAHQgEAIgHAEQgGAEgJAAQgFAAgFgDQgFgCgEgFIAAAhgAgJgcQgEACgCAEIAAAWQACADAEACQAFACAEAAQAGAAAFgFQAEgEAAgJQAAgIgEgFQgFgGgGAAQgEAAgFACg");
	this.shape_120.setTransform(268.9,176.225);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AghAuIAAhaIASAAIAAAJQADgFAGgDQAFgCAFAAQAJAAAGAEQAHAEADAIQAFAHAAALQAAALgFAHQgDAIgHAEQgGAEgJAAQgFAAgFgDQgFgCgEgFIAAAhgAgIgcQgEACgDAEIAAAWQACADAFACQADACAFAAQAGAAAFgFQAFgEAAgJQAAgIgFgFQgFgGgGAAQgFAAgDACg");
	this.shape_121.setTransform(260.95,176.225);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AAZAuIgGgQIgmAAIgFAQIgWAAIAjhaIAXAAIAjBagAAOANIgOgmIgNAmIAbAAg");
	this.shape_122.setTransform(252.075,173.8);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_123.setTransform(241.725,174.975);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_124.setTransform(235.025,175.05);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_125.setTransform(227.175,175.05);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgSAqQgHgEgDgIQgFgHAAgLQAAgLAFgHQADgHAHgFQAGgEAIAAQAFAAAGADQAFACAEAFIAAghIASAAIAABaIgSAAIAAgJQgEAFgFADQgFACgGAAQgIAAgGgEgAgKgBQgEAEgBAJQABAIAEAGQAFAFAGAAQAFAAAEgCQADgCADgEIAAgXQgDgCgDgCQgEgCgFAAQgGAAgFAFg");
	this.shape_126.setTransform(219.1,173.875);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQAAADACACQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAIAEAAIADgCIADAOIgGADIgJABQgHAAgFgFg");
	this.shape_127.setTransform(212.95,174.225);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgZAcQgFgFAAgKIAAguIASAAIAAAnQAAAHACADQAEADAGgBQADAAAEgCIAHgFIAAgsIARAAIAABBIgRAAIAAgIQgEAEgFADQgFADgJAAQgKAAgGgGg");
	this.shape_128.setTransform(206.7,175.125);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgXApQgLgGgGgLQgGgKgBgOQABgMAGgLQAGgLALgGQALgGANAAQANAAAKAGQAMAGAFALQAHALAAAMQAAAOgHAKQgFALgMAGQgKAGgNAAQgNAAgLgGgAgNgZQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAHAGAEQAFAEAJAAQAHAAAHgEQAGgEADgHQADgGABgJQgBgIgDgGQgDgHgGgEQgHgEgHAAQgJAAgFAEg");
	this.shape_129.setTransform(197.55,173.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgXAuIgFgBIADgPIADABIACAAIAGgBIADgEIADgFIgbhCIATAAIAQAtIARgtIATAAIgfBMQgCAGgEADQgDAEgFABQgFABgFAAIgEAAg");
	this.shape_130.setTransform(129.5,176.375);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_131.setTransform(123.825,174.975);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQAAADABACQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAIAEAAIACgCIAEAOIgFADIgJABQgJAAgEgFg");
	this.shape_132.setTransform(118.75,174.225);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAIgEAJAAQAKgBAHAFQAHAEAFAJQADAIAAAKIAAADIgvAAQABAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgFAFgHACQgIACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgCAEABADIAfAAIAAAAg");
	this.shape_133.setTransform(112.7,175.05);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_134.setTransform(104.95,174.975);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_135.setTransform(99.275,173.675);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgGAsQgFgDgEgFIAAAJIgSAAIAAhaIASAAIAAAhQAEgFAFgCQAFgDAFAAQAJAAAGAEQAHAFADAHQAFAHAAALQAAALgFAHQgEAIgGAEQgHAEgIAAQgFAAgFgCgAgJgEQgDACgDACIAAAYQADADADACQAEACAFAAQAHAAAEgFQAEgGABgIQgBgJgEgEQgEgFgHAAQgFAAgEACg");
	this.shape_136.setTransform(93.75,173.875);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgEgFABgHQgBgIAEgEQAEgFAEgBQAGgCAFAAQAHAAAFACQAFACADADIAAgIQAAgFgEgCQgEgEgGAAQgEAAgFADQgFABgEAEIgHgMQAGgFAIgDQAHgCAGAAQAJAAAGACQAHACADAGQAEAFABAJIAAAqIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAFQgDADAAAFQAAAFADADQAEACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgCQgEgBgDAAQgFAAgEACg");
	this.shape_137.setTransform(85.65,175.05);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgSApQgLgGgHgLQgGgKAAgOQAAgNAGgKQAHgLALgGQALgGAMAAQAKAAAIAEQAHACAFAGQAFAEADAHIgQAIQgDgGgGgEQgFgEgIAAQgHAAgGAEQgHAEgDAHQgEAGAAAIQAAAJAEAGQADAHAHAEQAGAEAHAAQAIAAAFgEQAGgDADgHIAQAIQgDAGgFAGQgFAFgHADQgIADgKAAQgMAAgLgGg");
	this.shape_138.setTransform(77.575,173.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgIAuIAAhaIARAAIAABag");
	this.shape_139.setTransform(67.575,173.8);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgFgIABgLQgBgJAFgHQAEgIAIgFQAIgEAJAAQAJgBAIAFQAHAEAFAJQADAIAAAKIAAADIgvAAQABAHAEAEQAFAEAIABIAGgBIAFgDIAGgDIAIALQgGAFgHACQgHACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgBAEAAADIAfAAIAAAAg");
	this.shape_140.setTransform(62.1,175.05);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIAAgLQAAgJAEgHQAEgIAIgFQAIgEAJAAQAJgBAIAFQAHAEAFAJQADAIAAAKIAAADIgvAAQABAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgGAFgHACQgHACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgBAEAAADIAfAAIAAAAg");
	this.shape_141.setTransform(54.55,175.05);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQABADABACQAAABABAAQAAAAABABQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgJABQgIAAgEgFg");
	this.shape_142.setTransform(48.4,174.225);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgHIALgOQAFAEAHAFQAIADAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgDgGAAIgLgEIgNgEQgGgDgEgFQgDgEgBgJQABgIAEgGQAEgGAIgEQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgDgGAAQgGAAgDADQgEACAAAEQABAEADACQAEACAGABIALAEQAHABAGADQAGADAEAEQADAFABAJQAAAIgEAHQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_143.setTransform(41.925,173.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113}]},296).to({state:[]},61).to({state:[{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113}]},363).to({state:[]},61).to({state:[]},67).wait(53));

	// Слой_16
	this.instance_7 = new lib.pc21копия("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(233.75,140.85,1.0033,1.0033,0,0,0,233.4,140.3);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(296).to({_off:false},0).to({_off:true},61).wait(363).to({_off:false},0).to({_off:true},61).wait(120));

	// Слой_2
	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],14,-21.3,14,30.2).s().p("A6dFQIAAqfMA07AAAIAAKfg");
	this.shape_144.setTransform(169.35,163.725);
	this.shape_144._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_144).wait(209).to({_off:false},0).wait(86).to({_off:true},1).wait(337).to({_off:false},0).wait(86).to({_off:true},1).wait(181));

	// Слой_9
	this.instance_8 = new lib.pc31();
	this.instance_8.parent = this;
	this.instance_8.setTransform(239.8,145.45,1.0097,1.0097,0,0,0,233.7,140.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(209).to({_off:false},0).to({y:63.55},86).to({_off:true},1).wait(337).to({_off:false,y:145.45},0).to({y:63.55},86).to({_off:true},1).wait(181));

	// Слой_7
	this.instance_9 = new lib.pc21();
	this.instance_9.parent = this;
	this.instance_9.setTransform(252.05,151.35,1.0803,1.0803,0,0,0,233.3,140.1);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(123).to({_off:false},0).to({x:225.1},86).to({_off:true},1).wait(337).to({_off:false,x:252.05},0).to({x:225.1},86).to({_off:true},1).wait(267));

	// pc11
	this.instance_10 = new lib.pc11();
	this.instance_10.parent = this;
	this.instance_10.setTransform(168,85.7,1,1,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({regY:139.9,y:54.8},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(301).to({_off:false,regY:140,y:85.7},0).to({regY:139.9,y:54.8},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(354));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,412.3,316.1);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_Builders_atlas_P_.png", id:"336x280_Builders_atlas_P_"},
		{src:"images/336x280_Builders_atlas_NP_.jpg", id:"336x280_Builders_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;