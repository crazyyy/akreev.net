(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_Trade Program_atlas_P_", frames: [[0,30,50,50],[0,0,98,28]]},
		{name:"336x280_Trade Program_atlas_NP_", frames: [[0,282,467,280],[338,613,56,43],[338,658,48,45],[338,564,56,47],[0,564,336,280],[0,0,467,280]]}
];


// symbols:



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.icons8circledplay50 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_Trade Program_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["336x280_Trade Program_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t1222 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgDgBAAgEQAAgDADgCQACgCACAAQADAAADACQACACAAADQAAAEgCABQgDADgDAAQgCAAgCgDg");
	this.shape.setTransform(203.4,74.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AggAxIAAhfIALAAIAAAKQAEgFAGgEQAGgDAHAAQAHAAAFADQAGACAEAFQAEAEADAHQACAHAAAJQAAAIgCAGQgDAHgEAFQgEAEgGADQgFADgHAAQgHAAgGgEQgGgDgEgGIAAAlgAgMgjQgGADgDAFIAAAeQADAFAGADQAFAEAHAAQAEAAAEgCQAFgCACgEQADgEACgEQABgEAAgGQAAgGgBgFQgCgFgDgEQgCgDgFgCQgEgCgEAAQgHAAgFADg");
	this.shape_1.setTransform(197.825,72.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_2.setTransform(191.825,69.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgEAAgEACg");
	this.shape_3.setTransform(186.15,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AATAwIAAguQgBgEgBgDIgDgFIgFgCIgHgBIgFABIgFACIgGAEIgDAEIAAAyIgLAAIAAhfIALAAIAAAkIAEgEIAGgEIAHgDIAHgBQALAAAFAGQAGAFAAAMIAAAwg");
	this.shape_4.setTransform(178.05,69.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_5.setTransform(168.675,69.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_6.setTransform(165.425,69.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgCATIgBgPIgBgFIgBgEIAAgFIAAgBQAAgBAAgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAABAAABIAAABIAAAFIgBAEIAAAFIgCAPg");
	this.shape_7.setTransform(162.35,66.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEAEADQADAEAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgCADgCAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgEAAgFACg");
	this.shape_8.setTransform(156.85,71.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AAVAwIgVhNIgVBNIgMAAIgchfIANAAIAWBPIAWhPIAJAAIAWBPIAVhPIAOAAIgcBfg");
	this.shape_9.setTransform(146.35,69.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgFAFQgCgBAAgEQAAgDACgCQADgCACAAQAEAAACACQACACAAADQAAAEgCABQgCADgEAAQgCAAgDgDg");
	this.shape_10.setTransform(134.5,74.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgDApQgFgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIALAAIAAATIANAAIAAAJIgNAAIAAArQAAAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_11.setTransform(130.75,70.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_12.setTransform(125.125,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgCgIgBgHQABgHACgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgEACgEAEQgDAEgBAEQgBAFAAAFQAAAFABAFQABAFADAEQAEADAEADQAEACAFAAQAGAAAEgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_13.setTransform(117.7,71.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgDAEgBAEQgCAFAAAFQAAAFACAFQABAFADAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_14.setTransform(109.4,71.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAuQgGgEgEgFIAAAKIgLAAIAAhfIALAAIAAAlQAEgGAGgDQAGgEAHAAQAHAAAFADQAGADAEAEQAEAFADAHQACAGAAAIQAAAJgCAHQgDAHgEAEQgEAFgGACQgFADgHAAQgHAAgGgDgAgMgLQgGAEgDAEIAAAfQADAFAGADQAFADAHAAQAEAAAFgCQAEgCADgDIAEgJQACgFAAgGQAAgGgCgEIgEgIQgDgEgEgCQgFgCgEAAQgHAAgFADg");
	this.shape_15.setTransform(101.275,70.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_16.setTransform(89.125,71.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_17.setTransform(78.275,71.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_18.setTransform(70.95,71.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_19.setTransform(65.225,69.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_20.setTransform(59.575,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_21.setTransform(52.475,71.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAFADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAEADADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgJgZQgEACgCAEQgEADgBAFIgCAIIAtAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgEAAgFACg");
	this.shape_22.setTransform(41.4,71.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_23.setTransform(33.3,71.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_24.setTransform(27.675,70.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_25.setTransform(24.425,69.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_26.setTransform(18.8,71.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgBgIgBgHQABgHABgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAFAFQAEAFACAHQADAGAAAHQAAAHgDAIQgCAGgEAFQgFAFgHADQgGADgIAAQgHAAgHgDgAgJgYQgEACgDAEQgDAEgCAEQgBAFgBAFQABAFABAFQACAFADAEQADADAEADQAFACAEAAQAGAAAEgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgEgCgGAAQgEAAgFACg");
	this.shape_27.setTransform(10.65,71.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_28.setTransform(0.75,71.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_29.setTransform(-6.05,71.35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgOAiQgGgDgEgFQgFgFgDgGQgBgIAAgHQAAgHABgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAGADQAHADAFAFQAEAFACAHQADAGAAAHQAAAHgDAIQgCAGgEAFQgFAFgHADQgGADgIAAQgHAAgHgDgAgJgYQgEACgDAEQgDAEgCAEQgBAFgBAFQABAFABAFQACAFADAEQADADAEADQAEACAFAAQAGAAAEgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_30.setTransform(-14.2,71.25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgYAxIgEgBIACgKIADABIADAAQAEAAACgBQACgCACgEIAFgLIgdhFIAMAAIAWA4IAXg4IAMAAIgjBTQgCAIgGADQgFADgGAAIgFAAg");
	this.shape_31.setTransform(-21.9,72.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_32.setTransform(-33.25,71.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_33.setTransform(-40.9,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_34.setTransform(-46.075,70.025);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAvQgJgEgGgHQgHgGgEgKQgEgJAAgLQAAgKAEgKQAEgJAHgGQAGgHAJgDQAKgEAJAAQANAAAJAFQAJAFAGAIIgJAGQgFgGgHgEQgHgDgJAAQgHAAgHADQgHACgFAGQgFAFgDAHQgCAHAAAIQAAAJACAHQADAHAFAFQAFAFAHADQAHADAHAAIAIgBIAHgCIAGgDIAFgEIAAgUIggAAIAAgKIAsAAIAAAiQgHAIgKAFQgJAEgMAAQgJAAgKgDg");
	this.shape_35.setTransform(-52.925,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1222, new cjs.Rectangle(-60.1,61.3,267.3,18.5), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape.setTransform(229.1,71.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDApQgFgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQAAAEACACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_1.setTransform(222.9,70.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_2.setTransform(219.125,70.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_3.setTransform(214.025,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgLAuQgGgEgEgFIAAAKIgLAAIAAhfIALAAIAAAlQAEgGAGgDQAGgEAHAAQAHAAAFADQAGADAEAEQAEAFADAHQACAGAAAIQAAAJgCAHQgDAHgEAEQgEAFgGACQgFADgHAAQgHAAgGgDgAgMgLQgGAEgDAEIAAAfQADAFAGADQAFADAHAAQAEAAAFgCQAEgCADgDIAEgJQACgFAAgGQAAgGgCgEIgEgIQgDgEgEgCQgFgCgEAAQgHAAgFADg");
	this.shape_4.setTransform(206.775,70.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape_5.setTransform(198.35,71.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AASAjIgSg3IgRA3IgLAAIgWhFIALAAIARA3IASg3IAJAAIASA3IARg3IALAAIgWBFg");
	this.shape_6.setTransform(188.925,71.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgFAAIgFABIgFACIgEAEIgDAEIAAAxg");
	this.shape_7.setTransform(177.85,71.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAHABQAFAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgGAEQgHADgHAAQgLAAgGgFg");
	this.shape_8.setTransform(171.05,71.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgEACgDAEQgEAEgBAEQgCAFABAFQgBAFACAFQABAFAEAEQADADAEADQAFACAEAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_9.setTransform(162.9,71.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgYAxIgDgBIABgKIADABIADAAQAEAAACgBQADgCACgEIAEgLIgdhFIALAAIAXA4IAXg4IAMAAIgjBTQgCAIgGADQgEADgHAAIgFAAg");
	this.shape_10.setTransform(155.2,72.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_11.setTransform(144.425,71.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgEAAgEACg");
	this.shape_12.setTransform(137.1,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEApQgEgFABgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_13.setTransform(130.9,70.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_14.setTransform(124.725,71.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_15.setTransform(117.55,71.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_16.setTransform(109.95,71.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_17.setTransform(104.225,69.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAFADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAEADADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgJgZQgEACgCAEQgEADgBAFIgCAIIAtAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgEAAgFACg");
	this.shape_18.setTransform(98.55,71.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_19.setTransform(88.6,70.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_20.setTransform(82.425,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AATAwIAAguQAAgEgCgDIgDgFIgFgCIgGgBIgGABIgFACIgGAEIgDAEIAAAyIgLAAIAAhfIALAAIAAAkIAEgEIAGgEIAHgDIAHgBQALAAAFAGQAGAFAAAMIAAAwg");
	this.shape_21.setTransform(74.8,69.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_22.setTransform(68.7,70.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEApQgEgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_23.setTransform(60.7,70.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgFACIgGAEIgDAEIAAAyIgLAAIAAhFIALAAIAAAKIAEgEIAGgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_24.setTransform(54.55,71.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_25.setTransform(46.5,71.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDApQgFgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIALAAIAAATIANAAIAAAJIgNAAIAAArQAAAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_26.setTransform(40.3,70.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgEgEgIAAIgEABIgGACIgGAEIgDAEIAAAyIgLAAIAAhFIALAAIAAAKIAEgEIAGgEIAHgDIAHgBQAWAAAAAXIAAAwg");
	this.shape_27.setTransform(34.15,71.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFABAFQgBAFACAFQACAFACAEQADADAFADQAEACAFAAQAGAAAEgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(26,71.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_29.setTransform(18.375,71.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_30.setTransform(6.875,71.25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_31.setTransform(1.625,70.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_32.setTransform(-4.375,70.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAEACADQAEAEAFACQAEACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgCAEQgDADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_33.setTransform(-12.4,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AAlAkIAAguQAAgHgDgEQgDgEgHAAQgGAAgFADQgFADgDAEIAAAzIgKAAIAAguQAAgHgDgEQgDgEgHAAQgFAAgFADQgFAEgDAEIAAAyIgLAAIAAhFIALAAIAAAKIADgDIAGgEIAGgEQAEgBAEAAQAIAAAEAEQAEAEABAFIAEgEIAGgEIAHgEIAHgBQAKAAAEAGQAGAFAAAKIAAAyg");
	this.shape_34.setTransform(-22.325,71.15);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_35.setTransform(-33.95,71.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_36.setTransform(-40.8,71.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgLAxIAAg8IgLAAIAAgJIALAAIAAgFQAAgMAGgFQAFgGAIAAIAIABQAEABADADIgEAIIgEgEIgFAAQgFAAgDAEQgCADAAAHIAAAFIANAAIAAAJIgNAAIAAA8g");
	this.shape_37.setTransform(-46.425,69.85);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgLAxIAAg8IgLAAIAAgJIALAAIAAgFQAAgMAGgFQAFgGAIAAIAIABQAEABADADIgEAIIgEgEIgFAAQgFAAgDAEQgCADAAAHIAAAFIANAAIAAAJIgNAAIAAA8g");
	this.shape_38.setTransform(-50.525,69.85);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFABAFQgBAFACAFQACAFACAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_39.setTransform(-57.25,71.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgCAEQgDADgCAFIgCAIIAtAAIgBgIQgCgFgCgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_40.setTransform(-69.2,71.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAVAwIgVhNIgUBNIgOAAIgbhfIAOAAIAVBPIAWhPIAJAAIAWBPIAVhPIAOAAIgbBfg");
	this.shape_41.setTransform(-79.7,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-88.1,61.3,323.4,18.5), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape.setTransform(261.825,130.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA0IgUglIgQAAIAAAlIgXAAIAAhnIAxAAQAKAAAIAEQAIAEAEAIQAEAHABAKQAAAJgEAHQgDAFgGAEQgFAEgFABIAYAogAgTgEIAWAAQAHAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgHAAIgWAAg");
	this.shape_1.setTransform(252.4,130.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_2.setTransform(242.7,130.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AggA0IAAhnIAWAAIAABUIArAAIAAATg");
	this.shape_3.setTransform(234.125,130.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_4.setTransform(227.7,130.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_5.setTransform(220.175,130.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_6.setTransform(210.225,130.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_7.setTransform(201.25,130.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHAAAKQAAAJgDAHQgDAFgFAEQgGAEgFABIAXAogAgUgEIAXAAQAHAAAEgDQAEgEABgHQgBgGgEgEQgEgEgHAAIgXAAg");
	this.shape_8.setTransform(191.7,130.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_9.setTransform(177.95,130.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_10.setTransform(167.475,130.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_11.setTransform(159.6,130.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AggA0IAAhnIAWAAIAABUIArAAIAAATg");
	this.shape_12.setTransform(153.625,130.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_13.setTransform(143.625,130.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_14.setTransform(131.925,130.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAYA0IAAgsIgwAAIAAAsIgWAAIAAhnIAWAAIAAApIAwAAIAAgpIAXAAIAABng");
	this.shape_15.setTransform(116.1,130.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_16.setTransform(105.775,130.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_17.setTransform(99.05,130.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_18.setTransform(89.7,130.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape_19.setTransform(73.675,130.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AARA0IgegqIgJAKIAAAgIgWAAIAAhnIAWAAIAAAuIAkguIAcAAIgqAxIAtA2g");
	this.shape_20.setTransform(64.575,130.925);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAQA0IgTglIgQAAIAAAlIgWAAIAAhnIAvAAQAMAAAHAEQAIAEAEAIQAFAHAAAKQgBAJgDAHQgDAFgFAEQgGAEgGABIAZAogAgTgEIAWAAQAHAAAFgDQADgEABgHQgBgGgDgEQgFgEgHAAIgWAAg");
	this.shape_21.setTransform(54.25,130.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_22.setTransform(42.975,130.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAThKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_23.setTransform(29.75,130.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgQAdQgHgEgFgIQgEgIAAgJQAAgJAEgHQAFgIAHgDQAIgFAIgBQAJABAIAFQAHADAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAEQgIAEgJABQgIgBgIgEgAgNgYQgHAFgDAGQgEAGAAAHQAAAIAEAGQADAHAHAEQAGADAHAAQAIAAAGgDQAHgEADgHQAEgGAAgIQAAgHgEgGQgDgGgHgFQgGgDgIAAQgHAAgGADgAAJATIgJgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAADADQAEADAAAFQAAAFgCACIgEADIgDABIAKAPgAgGAAIAJAAIAFgBQACgCAAgEQAAgCgCgCQgDgCgCAAIgJAAg");
	this.shape_24.setTransform(14.625,128.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_25.setTransform(6.35,130.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgVAvQgNgGgHgMQgIgMAAgRQAAgQAIgMQAHgMANgGQAMgHAPAAQAKAAAJADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAFgCQAHgDADgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgMgHg");
	this.shape_26.setTransform(-4.15,130.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_27.setTransform(-15.075,130.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_28.setTransform(-27.65,130.925);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_29.setTransform(-39.25,130.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_30.setTransform(-49.725,130.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-57.5,121.8,326.2,19.700000000000003), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],8.5,-35.7,8.5,40.1).s().p("EglWAFlIAArJMBKtAAAIAALJg");
	this.shape.setTransform(239.175,222.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc31, new cjs.Rectangle(0,0,478.3,280), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc21, new cjs.Rectangle(0,0,467,280), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,280), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape.setTransform(266.775,26.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIglAAIABAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAfAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgCABg");
	this.shape_1.setTransform(261.65,26.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_2.setTransform(256.45,26.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_3.setTransform(252.775,25.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgDAYIgUgvIAIAAIAPAnIAQgnIAIAAIgUAvg");
	this.shape_4.setTransform(249.2,26.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_5.setTransform(245.375,26.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgHAYQgFgCgEgEQgCgDgDgFQgCgEAAgGQAAgEACgFIAFgIQADgDAFgCQAFgCAEAAQAFAAAEACQAFACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_6.setTransform(240.6,26.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAEgGIAFADIAEADIAGACIAGABQAEAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBIABgDQAAgEgCgCIgDgDIgHgDIgHgCIgHgCIgGgCIgFgFQgBgDAAgFQAAgEABgDIAGgGIAGgEIAJgBQAIAAAFACQAGACAEAFIgEAGQgFgEgEgCQgGgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAFADIAGADIAGACIAIACIAGADIAEAFQACADAAAFIgCAHQAAAEgDACQgEADgEACQgFABgGAAQgJAAgFgDg");
	this.shape_7.setTransform(234.9,25.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgDgDQgCgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_8.setTransform(260.05,16.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_9.setTransform(254.275,17.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_10.setTransform(250.425,15.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_11.setTransform(246.925,16.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAfAAIAAgGIgDgFIgFgEQgDgBgFAAQgCAAgEABg");
	this.shape_12.setTransform(241.8,16.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGAAAGQAAAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_13.setTransform(235.65,15.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_14.setTransform(160.225,27.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgDgDQgCgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(154.75,26.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(150.875,25.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_17.setTransform(147.35,26.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(143.675,25.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(141.175,26.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(136.625,25.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_21.setTransform(170.475,15.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgEABIgEABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_22.setTransform(166.25,16.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIABAGIADADIADACIAEAAQAEAAADgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_23.setTransform(160.75,16.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAXQgFgCgDgDQgCgDgCgFQgCgFAAgFQAAgEACgFQACgEACgEQADgDAFgCQAEgCAFAAQAGAAAEACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgCAFgEADQgDADgEACQgEACgGAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_24.setTransform(155.15,16.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgEABgCADIgDAGIgBAGIABAIIADAFQACADAEABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_25.setTransform(149.9,16.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_26.setTransform(144.975,16.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_27.setTransform(141.575,15.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGAAAGQAAAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFABgFIgCgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_28.setTransform(137.1,15.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_29.setTransform(71.025,27.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_30.setTransform(65.55,26.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(61.675,25.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_32.setTransform(57.875,27);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_33.setTransform(52.175,27);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_34.setTransform(48.025,25.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAMAhIAAggIAAgEIgDgDQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgDABIgFACIgDACIgCADIAAAiIgIAAIAAhBIAIAAIAAAZIADgDIADgDIAFgCIAFAAQAIAAAEADQADAEAAAIIAAAhg");
	this.shape_35.setTransform(44.15,25.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAFgGIADADIAFADIAGACIAFABQAFAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBIABgDQAAgEgBgCIgFgDIgGgDIgGgCIgIgCIgGgCIgEgFQgCgDAAgFQAAgEACgDIAEgGIAHgEIAJgBQAHAAAHACQAGACAEAFIgGAGQgDgEgGgCQgFgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAEADIAHADIAHACIAHACIAGADIAFAFQABADAAAFIgBAHQgBAEgEACQgDADgEACQgFABgHAAQgHAAgGgDg");
	this.shape_36.setTransform(38.5,25.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAYQgFgCgEgEQgCgDgDgFQgCgEAAgGQAAgEACgFIAFgIQADgDAFgCQAFgCAEAAQAFAAAEACQAFACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_37.setTransform(66.9,16.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_38.setTransform(62.975,15.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgHAgQgFgDgCgDIAAAHIgIAAIAAhCIAIAAIAAAaQADgEAEgDQAEgCAEAAQAFAAAEACQAEACADADQACADACAFQACAEAAAGQAAAGgCAEIgEAIIgHAFQgEACgFAAQgEAAgEgCgAgIgHQgEADgCADIAAAVQACADAEACQAEACAEAAQADAAADgBIAFgEIADgGIABgHIgBgIIgDgFIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_39.setTransform(59.125,15.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_40.setTransform(54.975,15.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAPAYIgPgUIgNAUIgJAAIASgYIgRgXIAJAAIAMASIANgSIAJAAIgRAXIASAYg");
	this.shape_41.setTransform(51.425,16.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQADgDAFgCQAEgCAEAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgmAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgHAAQgEAAgFgBgAgFgRIgFAEIgDAFIgBAGIAeAAIAAgGIgDgFIgGgEQgCgBgFAAQgCAAgDABg");
	this.shape_42.setTransform(46.15,16.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_43.setTransform(42.225,15.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_44.setTransform(38.575,15.225);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(215.2,21.45,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(114.4,21.85,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(15.15,21.85,0.515,0.515,0,0,0,0.1,0.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_45.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-8.1,8.7,288.6,30.599999999999998), null);


// stage content:
(lib._336x280_TradeProgram = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_766 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(766).call(this.frame_766).wait(122));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape.setTransform(168,140);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_1.setTransform(168,140);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_2.setTransform(168,140);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_3.setTransform(168,140);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_4.setTransform(168,140);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_5.setTransform(168,140);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_6.setTransform(168,140);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_7.setTransform(168,140);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_8.setTransform(168,140);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(8));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(167.95,17.9,0.7999,0.7999);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(888));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-137.8,-29.5,-71.9,8.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_9.setTransform(167.825,250.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-129.1,-26.5,-63.3,11.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_10.setTransform(167.825,250.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-120.5,-23.4,-54.6,14.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_11.setTransform(167.825,250.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-111.8,-20.4,-46,17.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_12.setTransform(167.825,250.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-103.2,-17.4,-37.3,20.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_13.setTransform(167.825,250.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-94.5,-14.4,-28.7,23.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_14.setTransform(167.825,250.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.8,-11.4,-20,26.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_15.setTransform(167.825,250.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-77.2,-8.4,-11.3,29.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_16.setTransform(167.825,250.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.5,-5.4,-2.7,32.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_17.setTransform(167.825,250.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-59.9,-2.4,6,35.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_18.setTransform(167.825,250.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.2,0.7,14.6,38.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_19.setTransform(167.825,250.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-42.6,3.7,23.3,41.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_20.setTransform(167.825,250.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-33.9,6.7,31.9,44.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_21.setTransform(167.825,250.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.3,9.7,40.5,47.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_22.setTransform(167.825,250.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,12.7,49.2,50.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_23.setTransform(167.825,250.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-8,15.8,57.8,53.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_24.setTransform(167.825,250.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,18.8,66.5,56.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_25.setTransform(167.825,250.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],9.3,21.8,75.1,59.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_26.setTransform(167.825,250.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],18,24.8,83.8,62.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_27.setTransform(167.825,250.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.6,27.8,92.5,65.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_28.setTransform(167.825,250.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],35.3,30.8,101.1,68.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_29.setTransform(167.825,250.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],43.9,33.9,109.8,71.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_30.setTransform(167.825,250.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],52.6,36.9,118.4,74.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_31.setTransform(167.825,250.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],61.2,39.9,127.1,77.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_32.setTransform(167.825,250.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],69.9,42.9,135.7,80.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_33.setTransform(167.825,250.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).wait(234));

	// Слой_11
	this.instance_1 = new lib.icons8circledplay50();
	this.instance_1.parent = this;
	this.instance_1.setTransform(146,75,0.896,0.896);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(123).to({_off:false},0).to({_off:true},86).wait(210).to({_off:false},0).to({_off:true},86).wait(210).to({_off:false},0).to({_off:true},86).wait(87));

	// Слой_8
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_34.setTransform(253.475,171.65);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AARArIAAgyQAAgJgEgDQgEgEgHABQgGAAgFADIgIAGIAAA4IgWAAIAAhTIAWAAIAAALIAHgHIAKgEQAFgCAHgBQAPAAAGAIQAHAHAAAMIAAA7g");
	this.shape_35.setTransform(245.4,172.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgKQgGgLAAgNQAAgLAGgKQAFgKAKgHQAKgFAMgBQANABAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAGgKACQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_36.setTransform(235.425,172.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_37.setTransform(227.575,171.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AARArIAAgyQABgJgFgDQgEgEgHABQgGAAgFADIgIAGIAAA4IgWAAIAAhTIAWAAIAAALIAHgHIAKgEQAFgCAHgBQAOAAAHAIQAHAHAAAMIAAA7g");
	this.shape_38.setTransform(219.5,172.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgEgKgBgMQABgMAEgJQAGgKAKgHQAKgFANgBQAOABAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgCAGgBAGQABAGACAHQACAFAFAEQAFACAGAAQAHAAAFgCQAFgEADgFQACgHAAgGQAAgGgCgGQgDgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_39.setTransform(209.35,172.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgYA1QgOgIgIgOQgJgNAAgSQAAgRAJgOQAIgNAOgIQAOgHARAAQANAAAJADQAKAFAGAGQAHAGAEAIIgWAKQgEgHgHgEQgHgFgJgBQgKABgIAFQgJAEgEAJQgFAJAAAKQAAALAFAJQAEAJAJAEQAIAGAKAAQAJgBAHgFQAHgEAEgIIAWAKQgEAIgHAHQgGAGgKAFQgJADgNAAQgRABgOgIg");
	this.shape_40.setTransform(198.375,171.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgFgKAAgMQAAgMAFgJQAGgKAKgHQAKgFANgBQAOABAKAFQAKAHAFAKQAGAJAAAMQAAAMgGAKQgFAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgDAGAAAGQAAAGADAHQACAFAFAEQAFACAGAAQAHAAAFgCQAFgEACgFQADgHAAgGQAAgGgDgGQgCgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_41.setTransform(182.55,172.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgKQgGgLAAgNQAAgLAGgKQAFgKAKgHQAKgFAMgBQANABAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAGgKACQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_42.setTransform(172.625,172.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgYA3QgIgGgFgKQgFgKAAgOQAAgOAFgJQAFgJAIgGQAJgGALAAQAGABAHADQAHADAFAHIAAgsIAWAAIAAB0IgWAAIAAgKQgFAGgHADQgHAEgGgBQgLAAgJgEgAgNgCQgGAGAAALQAAALAGAHQAGAGAJAAQAFABAGgDQAFgDADgEIAAgeQgDgDgFgDQgGgCgFAAQgJgBgGAHg");
	this.shape_43.setTransform(162.325,171.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgKA8IAAhUIAVAAIAABUgAgIglQgEgDAAgGQAAgGAEgEQADgDAFAAQAGAAADADQAEAEAAAGQAAAGgEADQgDAEgGAAQgFAAgDgEg");
	this.shape_44.setTransform(155.275,170.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgPA7Igth1IAcAAIAgBaIAghaIAdAAIgtB1g");
	this.shape_45.setTransform(147.025,171.075);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgeA7IgGgBIADgUIAEACIADAAQAFAAADgCQACgBACgDIADgIIgihVIAYAAIAVA7IAWg7IAYAAIgoBiQgDAIgEAFQgFAEgGACQgGACgHAAIgFgBg");
	this.shape_46.setTransform(132.025,174.425);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_47.setTransform(124.525,171.65);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgKA8IAAhUIAVAAIAABUgAgIglQgEgDAAgGQAAgGAEgEQADgDAFAAQAGAAADADQAEAEAAAGQAAAGgEADQgDAEgGAAQgFAAgDgEg");
	this.shape_48.setTransform(119.375,170.925);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgKA7IAAh1IAVAAIAAB1g");
	this.shape_49.setTransform(114.925,171.075);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgXApQgGgCgFgHQgEgGAAgKQAAgKAEgGQAFgEAGgEQAHgCAHAAQAJAAAGACQAHAEAEAEIAAgLQAAgGgFgDQgFgEgIAAQgHAAgGACQgGADgFAFIgJgQQAIgHAJgDQAKgDAJgBQAKABAIADQAJACAFAIQAFAGAAAMIAAA2IgWAAIAAgJQgFAGgHACQgGADgIAAQgHAAgHgDgAgLAHQgFADAAAHQAAAGAFADQAEAEAHAAQAEAAAFgDQAFgBADgEIAAgKQgDgEgFgCQgFgCgEAAQgHAAgEADg");
	this.shape_50.setTransform(107.675,172.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AggAlQgHgIAAgMIAAg7IAXAAIAAAyQAAAJAEAEQAEADAHgBQAGAAAFgCQAFgDADgEIAAg4IAWAAIAABTIgWAAIAAgKQgFAFgHAEQgHADgKAAQgOAAgHgGg");
	this.shape_51.setTransform(98.025,172.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAcA0QgGADgHACQgHABgIAAQgRAAgOgIQgNgHgIgOQgIgOAAgRQAAgRAIgOQAIgNANgJQAOgHARAAQASAAAOAHQANAJAIANQAIAOAAARQAAAMgEALQgEAKgHAIIAJAKIgSAOgAgSgjQgIAFgEAJQgEAJgBAKQABAKAEAJQAEAJAIAFQAIAFAKAAIAGgBIAGgBIgMgPIARgOIANAPQADgFABgGQACgFAAgGQAAgKgFgJQgEgJgIgFQgIgFgLAAQgKAAgIAFg");
	this.shape_52.setTransform(86.225,171.35);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AARA7IAAg0QAAgIgEgDQgEgEgHABQgFAAgGADQgEADgDACIAAA6IgXAAIAAh1IAXAAIAAAsIAGgGIAKgFQAFgCAIAAQANAAAHAHQAHAHAAAMIAAA8g");
	this.shape_53.setTransform(256.95,171.075);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgqA8IAAh1IAXAAIAAALQAFgGAGgDQAHgEAHAAQAKAAAJAGQAJAFAEAKQAFAKAAAOQAAAOgFAJQgEAKgJAFQgJAFgKAAQgHAAgHgDQgHgDgEgHIAAAsgAgLgkQgGACgCAFIAAAdQACAEAGADQAFACAGAAQAJAAAFgGQAGgGAAgLQAAgLgGgHQgFgHgJAAQgGAAgFADg");
	this.shape_54.setTransform(247,174.225);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_55.setTransform(229.275,172.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgVA6QgJgDgIgHIAKgQQAFAFAHADQAGACAIAAQAFAAAFgBQAFgCAEgFQAEgFAAgIIAAgJQgFAHgHADQgHAEgHAAQgKAAgJgFQgIgFgFgKQgFgIAAgPQAAgNAFgKQAFgKAIgFQAJgFAKAAQAHAAAHADQAHAEAFAGIAAgLIAWAAIAABPQAAAMgEAHQgEAIgHAFQgHAEgIACQgIACgHAAQgLAAgIgDgAgNgiQgGAGAAALQAAAMAGAFQAGAGAJAAQAFAAAFgDQAGgDADgDIAAgbQgDgFgGgCQgFgDgFAAQgJAAgGAGg");
	this.shape_56.setTransform(220.225,174.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgFgKQgGgKAAgMQAAgMAGgJQAFgKAKgHQAKgFANgBQAOABAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgEADgDAFQgDAGABAGQgBAGADAHQADAFAEAEQAFACAGAAQAHAAAFgCQAEgEADgFQADgHAAgGQAAgGgDgGQgDgFgEgDQgFgEgHABQgGgBgFAEg");
	this.shape_57.setTransform(210.3,172.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgFgKQgFgKgBgMQABgMAFgJQAFgKAKgHQAKgFANgBQAOABAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgEADgDAFQgDAGABAGQgBAGADAHQADAFAEAEQAFACAGAAQAHAAAFgCQAEgEADgFQADgHAAgGQAAgGgDgGQgDgFgEgDQgFgEgHABQgGgBgFAEg");
	this.shape_58.setTransform(194.2,172.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AARA7IAAg0QAAgIgEgDQgEgEgHABQgFAAgGADQgEADgDACIAAA6IgXAAIAAh1IAXAAIAAAsIAGgGIAKgFQAFgCAIAAQANAAAHAHQAHAHAAAMIAAA8g");
	this.shape_59.setTransform(184.05,171.075);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AguA7IAAh1IA2AAQAMABAJAFQAJAFAFAIQAEAJAAAKQAAALgEAIQgFAIgJAFQgJAFgMAAIgdAAIAAAqgAgVgEIAZAAQAIAAAFgEQAEgEABgIQgBgHgEgEQgFgEgIgBIgZAAg");
	this.shape_60.setTransform(173.875,171.075);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgXApQgGgCgFgHQgEgGAAgKQAAgKAEgGQAFgEAGgEQAHgCAHAAQAJAAAGACQAHAEAEAEIAAgLQAAgGgFgDQgFgEgIAAQgHAAgGACQgGADgFAFIgJgQQAIgHAJgDQAKgDAJgBQAKABAIADQAJACAFAIQAFAGAAAMIAAA2IgWAAIAAgJQgFAGgHACQgGADgIAAQgHAAgHgDgAgLAHQgFADAAAHQAAAGAFADQAEAEAHAAQAEAAAFgDQAFgBADgEIAAgKQgDgEgFgCQgFgCgEAAQgHAAgEADg");
	this.shape_61.setTransform(153.975,172.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgEgKgBgMQABgMAEgJQAGgKAKgHQAKgFANgBQAOABAKAFQAKAHAFAKQAGAJAAAMQAAAMgGAKQgFAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgCAGgBAGQABAGACAHQACAFAFAEQAFACAGAAQAHAAAFgCQAFgEADgFQACgHAAgGQAAgGgCgGQgDgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_62.setTransform(134.2,172.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgUApQgJgEgIgFIAKgRQADAEAFACIALAEQAGACAEAAQAHAAAEgDQADgCAAgEQAAgEgFgCIgMgDIgPgEQgHgDgFgEQgFgFgBgKQABgHAEgGQAEgGAHgDQAIgEAKgBQALAAAJAEQAJADAFAFIgJAQQgDgEgHgDQgGgDgJAAQgEAAgEADQgEACAAADQAAAEAFACIAMACIAPAFQAIACAFAFQAEAGAAAJQAAAIgEAHQgEAFgIAEQgJAEgMgBQgJABgLgEg");
	this.shape_63.setTransform(120.4,172.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgTApQgLgEgGgFIAKgRQACAEAGACIAKAEQAFACAFAAQAHAAADgDQAEgCAAgEQAAgEgFgCIgLgDIgQgEQgHgDgFgEQgFgFgBgKQAAgHAFgGQAEgGAIgDQAHgEAKgBQALAAAJAEQAIADAHAFIgJAQQgEgEgHgDQgGgDgJAAQgEAAgEADQgEACAAADQABAEAEACIAMACIAPAFQAHACAGAFQAEAGAAAJQAAAIgDAHQgFAFgJAEQgHAEgNgBQgKABgJgEg");
	this.shape_64.setTransform(112,172.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgSA7IAAhAIgNAAIAAgTIANAAIAAgEQABgPAHgHQAIgJAMABQAHAAAFABQAGACAEAFIgIANIgEgDIgGAAQgEAAgDADQgDADAAAGIAAAEIARAAIAAATIgRAAIAABAg");
	this.shape_65.setTransform(95.85,171);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgEgKgBgMQABgMAEgJQAGgKAKgHQAKgFANgBQAOABAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgCAGgBAGQABAGACAHQACAFAFAEQAFACAGAAQAHAAAFgCQAEgEAEgFQACgHAAgGQAAgGgCgGQgEgFgEgDQgFgEgHABQgGgBgFAEg");
	this.shape_66.setTransform(87.3,172.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_67.setTransform(79.525,172.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AguA7IAAh1IA2AAQAMABAJAFQAJAFAFAIQAEAJAAAKQAAALgEAIQgFAIgJAFQgJAFgMAAIgdAAIAAAqgAgVgEIAZAAQAIAAAFgEQAEgEABgIQgBgHgEgEQgFgEgIgBIgZAAg");
	this.shape_68.setTransform(70.825,171.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:107.675}},{t:this.shape_49,p:{x:114.925}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:132.025}},{t:this.shape_45},{t:this.shape_44,p:{x:155.275}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38,p:{x:219.5}},{t:this.shape_37},{t:this.shape_36,p:{x:235.425}},{t:this.shape_35},{t:this.shape_34,p:{x:253.475}}]},123).to({state:[{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_36,p:{x:103.025}},{t:this.shape_64},{t:this.shape_63},{t:this.shape_44,p:{x:126.925}},{t:this.shape_62},{t:this.shape_38,p:{x:144.35}},{t:this.shape_61},{t:this.shape_49,p:{x:161.275}},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_34,p:{x:202.275}},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_50,p:{x:236.525}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_46,p:{x:266.525}}]},86).to({state:[]},87).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:107.675}},{t:this.shape_49,p:{x:114.925}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:132.025}},{t:this.shape_45},{t:this.shape_44,p:{x:155.275}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38,p:{x:219.5}},{t:this.shape_37},{t:this.shape_36,p:{x:235.425}},{t:this.shape_35},{t:this.shape_34,p:{x:253.475}}]},123).to({state:[{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_36,p:{x:103.025}},{t:this.shape_64},{t:this.shape_63},{t:this.shape_44,p:{x:126.925}},{t:this.shape_62},{t:this.shape_38,p:{x:144.35}},{t:this.shape_61},{t:this.shape_49,p:{x:161.275}},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_34,p:{x:202.275}},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_50,p:{x:236.525}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_46,p:{x:266.525}}]},86).to({state:[]},87).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:107.675}},{t:this.shape_49,p:{x:114.925}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:132.025}},{t:this.shape_45},{t:this.shape_44,p:{x:155.275}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38,p:{x:219.5}},{t:this.shape_37},{t:this.shape_36,p:{x:235.425}},{t:this.shape_35},{t:this.shape_34,p:{x:253.475}}]},123).to({state:[{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_36,p:{x:103.025}},{t:this.shape_64},{t:this.shape_63},{t:this.shape_44,p:{x:126.925}},{t:this.shape_62},{t:this.shape_38,p:{x:144.35}},{t:this.shape_61},{t:this.shape_49,p:{x:161.275}},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_34,p:{x:202.275}},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_50,p:{x:236.525}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_46,p:{x:266.525}}]},86).wait(87));

	// t12
	this.instance_2 = new lib.t1222();
	this.instance_2.parent = this;
	this.instance_2.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.instance_3 = new lib.t12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},123).to({state:[{t:this.instance_2}]},173).to({state:[{t:this.instance_3}]},123).to({state:[{t:this.instance_2}]},173).to({state:[{t:this.instance_3}]},123).wait(173));

	// t11
	this.instance_4 = new lib.t11();
	this.instance_4.parent = this;
	this.instance_4.setTransform(168,117.25,1,1,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(888));

	// btn
	this.instance_5 = new lib.btn();
	this.instance_5.parent = this;
	this.instance_5.setTransform(168,213.4,1,1,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(123).to({y:215.6},0).wait(173).to({y:213.4},0).wait(123).to({y:215.6},0).wait(173).to({y:213.4},0).wait(123).to({y:215.6},0).wait(173));

	// Слой_5
	this.instance_6 = new lib.icons();
	this.instance_6.parent = this;
	this.instance_6.setTransform(168.8,170.55,1.12,1.12,0,0,0,136.4,18.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},123).wait(173).to({_off:false},0).to({_off:true},123).wait(173).to({_off:false},0).to({_off:true},123).wait(173));

	// Слой_14
	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("A6PJ+IAAz8MA0fAAAIAAT8g");
	this.shape_69.setTransform(168,216.35);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("A6PJ/IAAz8MA0fAAAIAAT8g");
	this.shape_70.setTransform(168,252.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_69}]}).to({state:[{t:this.shape_70}]},123).to({state:[{t:this.shape_69}]},173).to({state:[{t:this.shape_70}]},123).to({state:[{t:this.shape_69}]},173).to({state:[{t:this.shape_70}]},123).wait(173));

	// Слой_9
	this.instance_7 = new lib.pc31();
	this.instance_7.parent = this;
	this.instance_7.setTransform(179.35,100.85,0.7682,0.7682,0,0,0,233.5,140);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(209).to({_off:false},0).to({x:156.65},86).to({_off:true},1).wait(209).to({_off:false,x:179.35},0).to({x:156.65},86).to({_off:true},1).wait(209).to({_off:false,x:179.35},0).to({x:156.65},86).wait(1));

	// Слой_7
	this.instance_8 = new lib.pc21();
	this.instance_8.parent = this;
	this.instance_8.setTransform(192.65,115.6,0.825,0.825,0,0,0,233.5,140.1);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(123).to({_off:false},0).to({regX:233.3,scaleX:0.7529,scaleY:0.7529,x:160.1,y:105.5},86).to({_off:true},1).wait(209).to({_off:false,regX:233.5,scaleX:0.825,scaleY:0.825,x:192.65,y:115.6},0).to({regX:233.3,scaleX:0.7529,scaleY:0.7529,x:160.1,y:105.5},86).to({_off:true},1).wait(209).to({_off:false,regX:233.5,scaleX:0.825,scaleY:0.825,x:192.65,y:115.6},0).to({regX:233.3,scaleX:0.7529,scaleY:0.7529,x:160.1,y:105.5},86).to({_off:true},1).wait(86));

	// pc11
	this.instance_9 = new lib.pc11();
	this.instance_9.parent = this;
	this.instance_9.setTransform(168,117.65,1,1,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({y:140},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(173).to({_off:false,y:117.65},0).to({y:140},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(173).to({_off:false,y:117.65},0).to({y:140},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(173));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(145.3,113.2,240,202.90000000000003);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_Trade Program_atlas_P_.png", id:"336x280_Trade Program_atlas_P_"},
		{src:"images/336x280_Trade Program_atlas_NP_.jpg", id:"336x280_Trade Program_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;