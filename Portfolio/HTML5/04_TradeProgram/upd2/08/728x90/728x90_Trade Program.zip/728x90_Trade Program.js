(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_Trade Program_atlas_P_", frames: [[145,0,50,50],[0,0,143,51]]},
		{name:"728x90_Trade Program_atlas_NP_", frames: [[652,0,56,43],[710,0,48,45],[594,0,56,47],[529,282,425,254],[0,0,592,280],[0,282,527,280]]}
];


// symbols:



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.icons8circledplay50 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.logoblack = function() {
	this.initialize(ss["728x90_Trade Program_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen31 = function() {
	this.initialize(ss["728x90_Trade Program_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape.setTransform(619.675,-104.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_1.setTransform(613.275,-105.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_2.setTransform(609.35,-106.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape_3.setTransform(604.05,-104.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_4.setTransform(596.525,-106.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_5.setTransform(587.775,-104.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_6.setTransform(578.075,-104.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_7.setTransform(566.575,-104.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQACACACAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgIADQgGAEgHAAQgMAAgFgGg");
	this.shape_8.setTransform(559.6,-104.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_9.setTransform(551.125,-104.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgYAyIgFAAIACgLIADABIADABQAEAAADgCQACgCACgEIAFgLIgehIIAMAAIAXA7IAYg7IAMAAIgkBWQgCAIgGADQgFADgHABIgEgBg");
	this.shape_10.setTransform(543.175,-103.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgKgDQgFgCgEgEQgDgDAAgHIACgIQACgEADgDQADgDAFgBQAGgCAFAAQAJAAAHADQAGADAFAEIgGAIQgDgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIAKADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgEADQgDADgFABQgFACgIAAQgIAAgHgDg");
	this.shape_11.setTransform(532,-104.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_12.setTransform(524.375,-104.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_13.setTransform(517.975,-105.65);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEAAgGQAAgGACgEQACgEAEgDQAEgDAEgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgFgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEAAAHQAAAHAEAFQAFAEAIAAQAFAAAFgCQAFgDAEgEIAAgOQgEgEgFgCQgFgCgFAAQgIAAgFAEg");
	this.shape_14.setTransform(511.6,-104.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgFAkIgehHIAMAAIAXA6IAYg6IAMAAIgeBHg");
	this.shape_15.setTransform(504.175,-104.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_16.setTransform(496.275,-104.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_17.setTransform(490.325,-106.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_18.setTransform(484.425,-104.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_19.setTransform(474.125,-105.65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQADAFgBAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_20.setTransform(467.75,-104.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgBgDgCgCQgDgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAEgFIAHgDIAHgDIAHgCQAMABAFAFQAGAGAAAMIAAAyg");
	this.shape_21.setTransform(459.85,-106.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_22.setTransform(453.525,-105.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_23.setTransform(445.225,-105.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_24.setTransform(438.85,-104.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_25.setTransform(430.475,-104.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_26.setTransform(424.075,-105.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_27.setTransform(417.7,-104.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(409.225,-104.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_29.setTransform(401.325,-104.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_30.setTransform(389.45,-104.775);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgDgCAAgDQAAgDADgDQACgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_31.setTransform(384,-106.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAFADAEAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_32.setTransform(377.75,-106.05);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_33.setTransform(369.425,-104.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAgwQAAgHgDgEQgDgEgHAAQgGAAgEADQgGAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIADgEIAGgEIAHgDIAHgBQAJAAAFAEQADAEACAFIAEgEIAGgFIAGgDIAIgBQAKAAAFAFQAGAGAAALIAAAzg");
	this.shape_34.setTransform(359.15,-104.875);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_35.setTransform(347.125,-104.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_36.setTransform(340.025,-104.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_37.setTransform(334.2,-106.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAGgGQAFgGAJAAIAIABIAHAFIgEAHIgFgDIgEgBQgGAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_38.setTransform(329.95,-106.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_39.setTransform(322.975,-104.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_40.setTransform(310.575,-104.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAWAyIgWhPIgVBPIgNAAIgdhjIAOAAIAWBTIAXhTIAJAAIAYBTIAVhTIAOAAIgdBjg");
	this.shape_41.setTransform(299.7,-106.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(291,-115,335,19), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAGQgCgDAAgDQAAgDACgCQADgCACAAQADAAADACQACACAAADQAAADgCADQgDACgDAAQgCAAgDgCg");
	this.shape.setTransform(605.175,-101.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AghAzIAAhjIALAAIAAALQAEgFAHgFQAGgDAHAAQAHAAAGADQAGADAEAEQAEAFADAHQACAIAAAIQAAAJgCAGQgDAHgEAFQgEAFgGACQgGADgHAAQgHABgGgEQgGgEgFgFIAAAmgAgNglQgGAEgDAFIAAAgQADAEAGAEQAGAEAHgBQAEABAFgDQAEgCADgEIAFgIQABgFAAgGQAAgGgBgFQgCgFgDgDQgDgEgEgDQgFgCgEAAQgHAAgGADg");
	this.shape_1.setTransform(599.375,-103.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_2.setTransform(593.125,-106.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_3.setTransform(587.225,-104.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgCgDQgBgDgBgCQgDgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAFgFIAGgDIAHgDIAHgCQAMABAFAFQAGAGAAAMIAAAyg");
	this.shape_4.setTransform(578.85,-106.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_5.setTransform(569.075,-106.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_6.setTransform(565.675,-106.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgCAUIgCgQIAAgFIgBgFIAAgEIgBgCQAAgDACgCQACgCACAAQADAAACACQACACAAADIgBACIAAAEIgBAFIAAAFIgCAQg");
	this.shape_7.setTransform(562.5,-109.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(556.775,-104.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AAWAyIgWhPIgVBPIgOAAIgchjIAOAAIAWBTIAXhTIAKAAIAWBTIAXhTIANAAIgcBjg");
	this.shape_9.setTransform(545.9,-106.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgFAGQgCgDAAgDQAAgDACgCQADgCACAAQADAAADACQACACAAADQAAADgCADQgDACgDAAQgCAAgDgCg");
	this.shape_10.setTransform(533.675,-101.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_11.setTransform(529.775,-105.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape_12.setTransform(523.95,-104.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_13.setTransform(516.225,-104.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFQAAAFACAGQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_14.setTransform(507.625,-104.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_15.setTransform(499.225,-106.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFgBAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_16.setTransform(486.65,-104.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgKgDQgFgCgEgEQgDgDAAgHIACgIQACgEADgDQADgDAFgBQAGgCAFAAQAJAAAHADQAGADAFAEIgGAIQgDgEgGgCQgFgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIAKADIALADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgEADQgDADgGABQgEACgIAAQgHAAgIgDg");
	this.shape_17.setTransform(475.4,-104.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_18.setTransform(467.775,-104.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_19.setTransform(461.825,-106.15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEABgGQgBgGADgEQACgEAEgDQADgDAFgBIAJgCQAHAAAFADQAGACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgGgIQAMgMAQAAQAGAAAFABQAFACAEADQAEADACAEQADAFAAAGIAAAxIgMAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEgBAHQABAHAEAFQAFAEAIAAQAFAAAFgCQAFgDAEgEIAAgOQgEgEgFgCQgFgCgFAAQgIAAgFAEg");
	this.shape_20.setTransform(456,-104.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgPAjQgHgCgGgGIAGgIQAEAEAGADQAGADAHAAQAIAAAFgEQAEgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgKgDQgFgCgEgEQgDgDAAgHIACgIQABgEAEgDQAEgDAEgBQAGgCAFAAQAJAAAHADQAHADAEAEIgFAIQgEgEgFgCQgGgDgHAAQgHAAgEADQgEAEAAAFQAAADADADIAIADIAKADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape_21.setTransform(448.65,-104.775);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_22.setTransform(437.125,-104.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_23.setTransform(428.75,-104.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgDACgDQACgCACAAQADAAACACQADADgBADQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_24.setTransform(422.9,-106.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_25.setTransform(419.475,-106.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_26.setTransform(413.65,-104.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_27.setTransform(405.175,-104.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_28.setTransform(394.925,-104.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_29.setTransform(387.95,-104.675);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_30.setTransform(379.475,-104.775);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgYAyIgFAAIACgLIADABIADABQAEAAADgCQACgCACgEIAFgLIgehIIAMAAIAXA7IAYg7IAMAAIgkBWQgCAIgGADQgFADgHABIgEgBg");
	this.shape_31.setTransform(371.525,-103.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_32.setTransform(359.725,-104.775);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgFAkIgehHIAMAAIAXA6IAYg6IAMAAIgeBHg");
	this.shape_33.setTransform(351.825,-104.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_34.setTransform(346.45,-106.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAwQgKgEgGgHQgHgGgFgKQgEgJAAgMQAAgLAEgJQAFgKAHgHQAGgHAKgDQAJgEAKAAQANAAAKAFQAJAFAHAJIgKAGQgFgGgHgEQgIgEgJAAQgHAAgIADQgHADgEAGQgGAFgCAHQgDAIgBAIQABAJADAHQACAIAGAFQAEAFAIAEQAHADAHAAIAJgBIAHgDIAGgDIAFgEIAAgVIghAAIAAgKIAtAAIAAAjQgGAIgLAFQgKAFgMAAQgKAAgJgEg");
	this.shape_35.setTransform(339.35,-106.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(332,-115,277,19), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYAyQgMgEgHgIIAMgSQAGAGAJAFQAIAEAKAAQAKAAAEgEQAFgDAAgFQAAgEgFgDQgEgCgHgCIgOgEIgPgFQgHgDgEgGQgEgGgBgKQABgJAEgHQAFgHAJgFQAJgEAMAAQANAAAKAEQALAEAIAHIgNARQgHgGgIgDQgIgDgHAAQgHAAgEADQgEADAAAFQAAAEAEACIAMAEIANAEQAIACAHADQAHAEAFAFQAEAGAAAKQAAAKgFAHQgEAIgKAFQgJAEgPAAQgOAAgLgFg");
	this.shape.setTransform(661.875,-41.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_1.setTransform(652.225,-41.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_2.setTransform(642.325,-41.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AghA1IAAhpIAXAAIAABVIAsAAIAAAUg");
	this.shape_3.setTransform(633.6,-41.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgLA1IAAhpIAXAAIAABpg");
	this.shape_4.setTransform(627.05,-41.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAeA1IgHgSIgtAAIgHASIgZAAIAphpIAbAAIApBpgAARAPIgRgtIgQAtIAhAAg");
	this.shape_5.setTransform(619.375,-41.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgKA1IAAhVIggAAIAAgUIBVAAIAAAUIggAAIAABVg");
	this.shape_6.setTransform(609.25,-41.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_7.setTransform(600.075,-41.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_8.setTransform(590.325,-41.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_9.setTransform(576.325,-41.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_10.setTransform(565.675,-41.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgLA1IAAhpIAXAAIAABpg");
	this.shape_11.setTransform(557.65,-41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AghA1IAAhpIAXAAIAABVIAsAAIAAAUg");
	this.shape_12.setTransform(551.55,-41.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_13.setTransform(541.375,-41.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_14.setTransform(529.425,-41.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAZA1IAAgtIgxAAIAAAtIgXAAIAAhpIAXAAIAAApIAxAAIAAgpIAXAAIAABpg");
	this.shape_15.setTransform(513.35,-41.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgLA1IAAhVIgeAAIAAgUIBTAAIAAAUIgfAAIAABVg");
	this.shape_16.setTransform(502.85,-41.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgLA1IAAhpIAXAAIAABpg");
	this.shape_17.setTransform(496,-41.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_18.setTransform(486.425,-41.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgYAyQgMgEgHgIIAMgSQAGAGAJAFQAIAEAKAAQAKAAAEgEQAFgDAAgFQAAgEgFgDQgEgCgHgCIgOgEIgPgFQgHgDgEgGQgEgGgBgKQABgJAEgHQAFgHAJgFQAJgEAMAAQANAAAKAEQALAEAIAHIgNARQgHgGgIgDQgIgDgHAAQgHAAgEADQgEADAAAFQAAAEAEACIAMAEIANAEQAIACAHADQAHAEAFAFQAEAGAAAKQAAAKgFAHQgEAIgKAFQgJAEgPAAQgOAAgLgFg");
	this.shape_19.setTransform(470.125,-41.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AASA1IgggrIgIAKIAAAhIgXAAIAAhpIAXAAIAAAvIAlgvIAcAAIgrAyIAuA3g");
	this.shape_20.setTransform(460.825,-41.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_21.setTransform(450.275,-41.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_22.setTransform(438.775,-41.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_23.setTransform(425.275,-41.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgQAdQgIgEgEgIQgFgHAAgKQAAgIAFgIQAEgIAIgEQAIgEAIgBQAKABAHAEQAIAEAEAIQAFAIAAAIQAAAKgFAHQgEAIgIAEQgHAFgKAAQgIAAgIgFgAgOgYQgGAEgEAGQgEAHAAAHQAAAIAEAGQAEAHAGAEQAHAEAHAAQAIAAAHgEQAGgEAEgHQADgGABgIQgBgHgDgHQgEgGgGgEQgHgEgIABQgHgBgHAEgAAKATIgKgPIgHAAIAAAPIgFAAIAAglIAPAAQAFAAADADQAFADAAAFQAAAFgDACIgDADIgEABIAKAPgAgHAAIAKAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAABAAQACgDAAgDQAAgCgCgDQgBAAgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIgKAAg");
	this.shape_24.setTransform(409.9,-43.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_25.setTransform(401.425,-41.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgWAwQgNgGgHgNQgIgMAAgRQAAgQAIgMQAHgNANgGQANgHAPAAQALAAAIADQAJADAGAGQAGAFAEAHIgTAKQgEgGgGgEQgHgEgIAAQgJAAgHAFQgIAEgEAIQgFAIAAAJQAAAKAFAIQAEAIAIAEQAHAFAJAAQAHAAAGgDQAGgCADgDIAAgNIgcAAIAAgTIAzAAIAAAoQgIAJgLAGQgMAFgOAAQgPAAgNgHg");
	this.shape_26.setTransform(390.75,-41.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAeA1IgHgSIgtAAIgHASIgZAAIAphpIAbAAIApBpgAARAPIgRgtIgQAtIAhAAg");
	this.shape_27.setTransform(379.625,-41.675);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_28.setTransform(366.775,-41.675);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_29.setTransform(354.925,-41.675);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_30.setTransform(344.275,-41.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(336.4,-51,332.5,20), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,592,280);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,425,254), null);


(lib.pc3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen31();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc3, new cjs.Rectangle(0,0,527,280), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape.setTransform(16.9,45.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAFgDQAGgEADgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(9.4,45.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_2.setTransform(-2.8,44.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_3.setTransform(-9.125,44.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(-13.05,44.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(-20.225,45.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_6.setTransform(-31.825,44.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(-37.675,45.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(-45.725,45.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(-54.1,45.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(-62.4,45.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(-70.875,45.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgMAwQgKgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAKgDQAJgEAKAAQAGAAAGACIAKAEQAFACADAEIAHAIIgKAGQgEgHgHgEQgIgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAIgEQAHgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgJgEg");
	this.shape_12.setTransform(-80.05,44.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApJCAQgqAAAAgqIAAirQAAgqAqAAISUAAQApAAAAAqIAACrQAAAqgpAAg");
	this.shape_13.setTransform(-32.4,44.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-95.2,32,125.6,25.700000000000003), null);


(lib.biglogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logoblack();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6129,0.6129);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.biglogo, new cjs.Rectangle(0,0,87.7,31.3), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape.setTransform(60.225,-55.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgCAGIAgAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgCABg");
	this.shape_1.setTransform(55.1,-55.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgDABgDADIgDAGIgBAGIABAIIADAFQADADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_2.setTransform(49.9,-55.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_3.setTransform(46.225,-56.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgDAYIgUgvIAIAAIAPAnIAQgnIAIAAIgUAvg");
	this.shape_4.setTransform(42.65,-55.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_5.setTransform(38.825,-55.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgHAYQgFgCgEgEQgCgDgDgFQgCgEAAgGQAAgEACgFIAFgIQADgDAFgCQAFgCAEAAQAFAAAEACQAFACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_6.setTransform(34.05,-55.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAEgGIAFADIAEADIAGACIAGABQAEAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBIABgDQAAgEgCgCIgDgDIgHgDIgHgCIgHgCIgGgCIgFgFQgBgDAAgFQAAgEABgDIAGgGIAGgEIAJgBQAIAAAFACQAGACAEAFIgEAGQgFgEgEgCQgGgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAFADIAGADIAGACIAIACIAGADIAEAFQACADAAAFIgCAHQgBAEgCACQgEADgEACQgFABgGAAQgJAAgFgDg");
	this.shape_7.setTransform(28.35,-56.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_8.setTransform(53.5,-65.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_9.setTransform(47.725,-64.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_10.setTransform(43.875,-66.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_11.setTransform(40.375,-65.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAfAAIAAgGIgDgFIgFgEQgDgBgFAAQgCAAgEABg");
	this.shape_12.setTransform(35.25,-65.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGABAGQgBAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_13.setTransform(29.1,-66.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADAEAEABQADACAFAAIAFgCQADAAACgCQADgBABgDQABgDAAgEIAAgHQgCADgFADQgEADgEgBQgFABgEgCIgHgFIgEgIQgCgDAAgHQAAgFACgFIAEgIIAHgFQAEgBAFAAQAEAAAEACQAEACADAEIAAgHIAIAAIAAAuQAAAFgCAEQgCAEgDADQgEACgEABIgIABQgGABgEgCgAgFgaIgFAFIgDAFIgBAHIABAIQABADACACIAFADQADACADAAIAEgBIAEgCIAEgCIACgDIAAgUIgCgDIgEgCIgEgCIgEgBQgDAAgDABg");
	this.shape_14.setTransform(52.225,-82);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(46.75,-82.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(42.875,-83.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAFgCQAEgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgEgBg");
	this.shape_17.setTransform(39.35,-82.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(35.675,-83.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(33.175,-82.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(28.625,-83.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_21.setTransform(62.475,-93.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgEABIgEABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_22.setTransform(58.25,-92.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIABAGIADADIADACIAEAAQAEAAADgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_23.setTransform(52.75,-92.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAXQgFgCgDgDQgCgDgCgFQgCgFAAgFQAAgEACgFQACgEACgEQADgDAFgCQAEgCAFAAQAFAAAFACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgCAFgEADQgDADgEACQgFACgFAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_24.setTransform(47.15,-92.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgEABgCADIgDAGIgBAGIABAIIADAFQACADAEABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_25.setTransform(41.9,-92.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDIAEgEQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_26.setTransform(36.975,-92.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_27.setTransform(33.575,-93.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGABAGQgBAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_28.setTransform(29.1,-93.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKAhQgFgBgEgFIAEgFQADADAEACQADABAFAAIAFgBQADAAACgCQADgCABgCQABgDAAgEIAAgHQgCAEgFACQgEACgEAAQgFAAgEgBIgHgFIgEgIQgCgDAAgHQAAgFACgFIAEgIIAHgFQAEgCAFAAQAEABAEACQAEACADAEIAAgHIAIAAIAAAuQAAAGgCAEQgCADgDADQgEACgEABIgIABQgGABgEgCgAgFgaIgFAFIgDAFIgBAHIABAIQABADACACIAFADQADACADAAIAEgBIAEgCIAEgCIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_29.setTransform(60.875,-109.55);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgDgDQgDgCgEAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_30.setTransform(55.4,-110.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(51.525,-111.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgEAFgDQAEgCAEAAQAFAAAEABIAHAGQADADABAFQACAEAAAHQAAAFgCAEQgBAFgDADIgHAFQgEACgFAAQgEgBgEgCQgEgCgDgEIAAAagAgIgYQgEACgCAEIAAAUQACADAEADQAEACAEAAQADAAADgBIAFgFIADgEIABgHIgBgIIgDgGIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_32.setTransform(47.725,-109.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgEAFgDQAEgCAEAAQAFAAAEABIAHAGQADADABAFQACAEAAAHQAAAFgCAEQgBAFgDADIgHAFQgEACgFAAQgEgBgEgCQgEgCgDgEIAAAagAgIgYQgEACgCAEIAAAUQACADAEADQAEACAEAAQADAAADgBIAFgFIADgEIABgHIgBgIIgDgGIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_33.setTransform(42.025,-109.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_34.setTransform(37.875,-111.325);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AANAhIAAggIgBgEIgDgDQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgEABIgDACIgEACIgCADIAAAiIgIAAIAAhBIAIAAIAAAZIACgDIAFgDIAEgCIAFAAQAIAAADADQAEAEAAAIIAAAhg");
	this.shape_35.setTransform(34,-111.375);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAEgGIAFADIAEADIAGACIAGABQAEAAADgBIAFgDQAAAAABgBQAAAAABgBQAAAAAAgBQAAAAAAgBIABgDQAAgEgCgCIgDgDIgHgDIgHgCIgHgCIgGgCIgFgFQgBgDAAgFQAAgEABgDIAGgGIAGgEIAJgBQAIAAAFACQAGACAEAFIgEAGQgFgEgEgCQgGgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAFADIAGADIAGACIAIACIAGADIAEAFQACADAAAFIgCAHQgBAEgCACQgEADgEACQgFABgGAAQgJAAgFgDg");
	this.shape_36.setTransform(28.35,-111.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEgBgGQABgEACgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAFACADADQACAEACAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgEAAQgCAAgEABg");
	this.shape_37.setTransform(56.75,-120.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_38.setTransform(52.825,-121.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgHAgQgFgDgCgDIAAAHIgIAAIAAhCIAIAAIAAAaQADgEAEgDQAEgCAEAAQAFAAAEACQAEACADADQACADACAFQACAEAAAGQAAAGgCAEIgEAIIgHAFQgEACgFAAQgEAAgEgCgAgIgHQgEADgCADIAAAVQACADAEACQAEACAEAAQADAAADgBIAFgEIADgGIABgHIgBgIIgDgFIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_39.setTransform(48.975,-121.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_40.setTransform(44.825,-121.325);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAPAYIgPgUIgNAUIgJAAIASgYIgRgXIAJAAIAMASIANgSIAJAAIgRAXIASAYg");
	this.shape_41.setTransform(41.275,-120.475);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACADADQAEAEABAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_42.setTransform(36,-120.475);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_43.setTransform(32.075,-121.375);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_44.setTransform(28.425,-121.375);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(6.25,-60.1,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.75,-87.1,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(7.4,-114.1,0.515,0.515,0,0,0,0.1,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_2
	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AmyHYIAAuwINlAAIAAOwg");
	this.shape_45.setTransform(28.8,-87.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_45).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-14.6,-135.1,86.89999999999999,94.5), null);


// stage content:
(lib._728x90_TradeProgram = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_751 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(751).call(this.frame_751).wait(353));

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape.setTransform(364.225,45.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_1.setTransform(364.225,45.9);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_2.setTransform(364.225,45.9);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_3.setTransform(364.225,45.9);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_4.setTransform(364.225,45.9);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_5.setTransform(364.225,45.9);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_6.setTransform(364.225,45.9);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_7.setTransform(364.225,45.9);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_8.setTransform(364.225,45.9);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_9.setTransform(364.225,45.9);
	this.shape_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(146).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(146).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(146).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(144).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(144).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(144).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(142).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(142).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(142).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(9));

	// t11
	this.instance = new lib.t11();
	this.instance.parent = this;
	this.instance.setTransform(154.5,118.35,1,1,0,0,0,105.6,41);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},105).wait(1).to({_off:false},0).wait(262).to({_off:true},105).wait(1).to({_off:false},0).wait(262).to({_off:true},105).wait(1).to({_off:false},0).wait(262));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(154.5,173.35,1,1,0,0,0,73.5,17);

	this.instance_2 = new lib.t22();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},262).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},262).to({state:[]},105).to({state:[{t:this.instance_2}]},1).wait(262));

	// Лого
	this.instance_3 = new lib.biglogo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(551.55,15.95,0.5748,0.5748,0,0,0,43.9,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1104));

	// Слой_5
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.3,-51.8,-51.6,-21.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_10.setTransform(551.525,73.35);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-98,-49.2,-45.3,-18.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_11.setTransform(551.525,73.35);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91.8,-46.6,-39.1,-16.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_12.setTransform(551.525,73.35);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.5,-43.9,-32.8,-13.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_13.setTransform(551.525,73.35);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-79.2,-41.3,-26.5,-10.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_14.setTransform(551.525,73.35);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-73,-38.6,-20.3,-8.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_15.setTransform(551.525,73.35);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-66.7,-36,-14,-5.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_16.setTransform(551.525,73.35);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-60.5,-33.4,-7.8,-2.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_17.setTransform(551.525,73.35);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-54.2,-30.7,-1.5,-0.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_18.setTransform(551.525,73.35);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-48,-28.1,4.7,2.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_19.setTransform(551.525,73.35);
	this.shape_19._off = true;

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-41.7,-25.5,11,5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_20.setTransform(551.525,73.35);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-35.5,-22.8,17.2,7.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_21.setTransform(551.525,73.35);
	this.shape_21._off = true;

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-29.2,-20.2,23.5,10.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_22.setTransform(551.525,73.35);
	this.shape_22._off = true;

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-23,-17.6,29.7,12.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_23.setTransform(551.525,73.35);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,-14.9,36,15.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_24.setTransform(551.525,73.35);
	this.shape_24._off = true;

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-10.5,-12.3,42.2,18.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_25.setTransform(551.525,73.35);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-4.2,-9.7,48.5,20.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_26.setTransform(551.525,73.35);
	this.shape_26._off = true;

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],2,-7,54.7,23.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_27.setTransform(551.525,73.35);
	this.shape_27._off = true;

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,-4.4,61,26.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_28.setTransform(551.525,73.35);
	this.shape_28._off = true;

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],14.5,-1.8,67.2,28.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_29.setTransform(551.525,73.35);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],20.8,0.9,73.5,31.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_30.setTransform(551.525,73.35);
	this.shape_30._off = true;

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],27.1,3.5,79.8,34).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_31.setTransform(551.525,73.35);
	this.shape_31._off = true;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],33.3,6.2,86,36.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_32.setTransform(551.525,73.35);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.6,8.8,92.3,39.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_33.setTransform(551.525,73.35);
	this.shape_33._off = true;

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.8,11.4,98.5,41.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_34.setTransform(551.525,73.35);
	this.shape_34._off = true;

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.9,11.4,98.6,41.9).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_35.setTransform(546.45,73.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.4,10.1,92.1,40.5).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_36.setTransform(546.45,73.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],32.9,8.7,85.6,39.1).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_37.setTransform(546.45,73.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.4,7.3,79.1,37.8).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_38.setTransform(546.45,73.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],19.8,6,72.5,36.4).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_39.setTransform(546.45,73.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],13.3,4.6,66,35.1).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_40.setTransform(546.45,73.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],6.8,3.2,59.5,33.6).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_41.setTransform(546.45,73.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.2,1.8,52.9,32.3).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_42.setTransform(546.45,73.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-6.3,0.5,46.4,30.9).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_43.setTransform(546.45,73.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-12.8,-0.9,39.9,29.5).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_44.setTransform(546.45,73.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-19.3,-2.3,33.4,28.2).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_45.setTransform(546.45,73.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.8,-3.6,26.9,26.8).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_46.setTransform(546.45,73.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-32.4,-5,20.3,25.5).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_47.setTransform(546.45,73.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-38.9,-6.4,13.8,24.1).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_48.setTransform(546.4,73.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-45.4,-7.7,7.3,22.7).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_49.setTransform(546.4,73.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.9,-9.1,0.8,21.4).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_50.setTransform(546.4,73.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-58.4,-10.5,-5.7,20).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_51.setTransform(546.4,73.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-64.9,-11.8,-12.2,18.6).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_52.setTransform(546.4,73.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-71.5,-13.2,-18.8,17.2).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_53.setTransform(546.4,73.35);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-78,-14.6,-25.3,15.8).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_54.setTransform(546.4,73.35);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-84.5,-16,-31.8,14.5).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_55.setTransform(546.4,73.35);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91,-17.3,-38.3,13.1).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_56.setTransform(546.4,73.35);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-97.6,-18.7,-44.9,11.8).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_57.setTransform(546.4,73.35);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.1,-20.1,-51.4,10.4).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_58.setTransform(546.4,73.35);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-110.6,-21.4,-57.9,9).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_59.setTransform(546.4,73.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10}]},38).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},87).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},114).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},92).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},87).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},114).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},92).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},87).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},114).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).wait(54));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(38).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(217));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(39).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(216));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(40).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(215));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(41).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(214));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(42).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(213));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(43).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(212));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(44).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(211));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(45).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(210));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(46).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(209));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(47).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(208));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(48).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(207));
	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(49).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(206));
	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(50).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(205));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(51).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(204));
	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(52).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(203));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(53).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(202));
	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(54).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(201));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(55).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(200));
	this.timeline.addTween(cjs.Tween.get(this.shape_28).wait(56).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(199));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(57).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(198));
	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(58).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(197));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(59).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(196));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(60).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(61).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(194));
	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(62).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(255).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(193));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(570.65,65.75,0.801,0.801,0,0,0,-8.5,35.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1104));

	// Слой_2
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("A7zHIIAAuPMA3nAAAIAAOPg");
	this.shape_60.setTransform(550.45,45.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_60).wait(1104));

	// Слой_7
	this.instance_5 = new lib.icons8circledplay50();
	this.instance_5.parent = this;
	this.instance_5.setTransform(167,25,0.6512,0.6512);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_61.setTransform(259.325,76.925);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAPAnIAAgtQABgIgEgDQgEgDgGAAQgGAAgDADQgFACgCAEIAAAyIgUAAIAAhLIAUAAIAAAKIAGgGIAIgEQAFgCAGAAQAMAAAHAHQAFAGABALIAAA1g");
	this.shape_62.setTransform(252.1,77.775);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_63.setTransform(243.225,77.875);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_64.setTransform(236.225,76.925);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AAQAnIAAgtQAAgIgEgDQgEgDgHAAQgEAAgFADQgEACgDAEIAAAyIgUAAIAAhLIAUAAIAAAKIAHgGIAIgEQAEgCAHAAQANAAAFAHQAHAGAAALIAAA1g");
	this.shape_65.setTransform(229,77.775);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgVAiQgIgFgFgJQgFgJAAgLQAAgKAFgJQAFgJAIgFQAJgGAMAAQANAAAIAGQAJAFAGAJQAEAJAAAKQAAALgEAJQgGAJgJAFQgIAFgNABQgMgBgJgFgAgJgSQgEADgDAFQgCAFAAAFQAAAGACAFQADAFAEADQAEADAFAAQAHAAADgDQAFgDADgFQABgFAAgGQAAgFgBgFQgDgFgFgDQgDgDgHAAQgFAAgEADg");
	this.shape_66.setTransform(219.9,77.875);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgHgMQgIgMAAgQQAAgPAIgMQAHgNAMgGQANgHAPAAQALAAAJAEQAIADAGAGIAKAMIgUAKQgDgHgGgEQgHgEgIAAQgJAAgHAEQgHAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAHAFQAHAEAJAAQAIAAAHgEQAGgEADgHIAUAJQgEAHgGAGQgGAGgIADQgJAEgLAAQgPAAgNgHg");
	this.shape_67.setTransform(210.125,76.425);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgUAiQgKgFgEgJQgFgJAAgLQAAgKAFgJQAEgJAKgFQAJgGALAAQANAAAJAGQAIAFAFAJQAFAJAAAKQAAALgFAJQgFAJgIAFQgJAFgNABQgLgBgJgFgAgKgSQgDADgDAFQgCAFAAAFQAAAGACAFQADAFADADQAFADAFAAQAGAAAEgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgFgFgDQgEgDgGAAQgFAAgFADg");
	this.shape_68.setTransform(196,77.875);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_69.setTransform(187.175,77.875);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgVAwQgHgEgFgJQgFgJAAgNQAAgMAFgIQAFgJAHgFQAHgEAKAAQAGAAAGACQAGADAFAGIAAgmIAUAAIAABnIgUAAIAAgJQgFAFgGADQgGADgGAAQgKAAgHgFgAgMgCQgFAFAAAKQAAAKAFAGQAGAGAIAAQAEAAAFgCQAFgCADgEIAAgbQgDgDgFgCQgFgDgEAAQgIAAgGAGg");
	this.shape_70.setTransform(177.95,76.525);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgJA2IAAhLIATAAIAABLgAgHghQgEgDAAgFQAAgFAEgEQADgDAEAAQAFAAADADQAEAEAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_71.setTransform(171.625,76.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgNA0IgohnIAZAAIAcBPIAdhPIAZAAIgoBng");
	this.shape_72.setTransform(164.275,76.425);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgbA1IgFgBIADgRIADAAIADABIAHgBQACgCACgDIADgGIgfhMIAVAAIATA0IAUg0IAVAAIgjBXQgDAHgDAEQgFAEgFACQgGABgGAAIgFAAg");
	this.shape_73.setTransform(150.875,79.375);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_74.setTransform(144.225,76.925);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgJA2IAAhLIATAAIAABLgAgHghQgEgDAAgFQAAgFAEgEQADgDAEAAQAFAAADADQAEAEAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_75.setTransform(139.575,76.275);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_76.setTransform(135.65,76.425);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_77.setTransform(129.125,77.875);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgcAgQgHgGABgLIAAg1IATAAIAAAtQABAIADADQAEADAHAAQAEAAAFgCQAEgDADgEIAAgyIAUAAIAABLIgUAAIAAgJQgFAEgGADQgGADgJABQgNAAgFgHg");
	this.shape_78.setTransform(120.55,77.95);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAZAuIgMAFQgGABgHAAQgPgBgMgGQgNgHgHgMQgHgMAAgPQAAgQAHgMQAHgNANgGQAMgIAPABQAQgBAMAIQAMAGAHANQAHAMABAQQgBAKgDAJQgEAJgGAHIAIAJIgQANgAgQgfQgHAEgEAIQgEAIAAAKQAAAIAEAJQAEAHAHAEQAHAFAJAAIAGAAIAFgBIgLgOIAPgNIALANIAEgJQACgFAAgEQAAgKgEgIQgEgIgHgEQgHgEgKgBQgJABgHAEg");
	this.shape_79.setTransform(110.025,76.65);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAQA0IAAguQgBgHgDgDQgEgDgGAAQgFAAgFADQgEADgDACIAAAzIgUAAIAAhnIAUAAIAAAmIAHgFIAIgFQAFgBAGAAQANAAAFAGQAHAGgBALIAAA1g");
	this.shape_80.setTransform(262.4,76.425);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgmA1IAAhoIAVAAIAAAKQADgGAHgCQAGgDAFAAQAKAAAIAEQAHAFAFAJQAEAJAAAMQAAANgEAIQgFAJgHAEQgIAFgKAAQgFAAgGgDQgGgDgEgFIAAAmgAgKggQgFACgCAEIAAAaQACADAEADQAGACAFAAQAHAAAFgGQAFgFABgKQgBgKgFgGQgFgGgHAAQgGAAgEADg");
	this.shape_81.setTransform(253.55,79.225);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgCgBIgEAAIgGABIgHADIgEAFIAAAxg");
	this.shape_82.setTransform(237.7,77.775);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgBA2QgKAAgIgDQgIgCgHgGIAJgPQAEAFAGADQAGACAIAAQADAAAFgCQAFgCADgEQAEgEgBgIIAAgHQgEAGgGADQgGADgGAAQgKAAgHgFQgHgEgFgJQgEgHAAgNQAAgMAEgJQAFgIAHgFQAHgEAKAAQAGAAAGACQAGADAEAGIAAgKIAUAAIAABGQAAALgEAHQgDAHgGAEQgGAEgHABQgGACgGAAIgBAAgAgLgeQgGAFAAAKQAAAKAGAFQAFAFAHAAQAGAAAEgCQAFgDACgDIAAgYQgCgEgFgCQgEgDgGAAQgHAAgFAGg");
	this.shape_83.setTransform(229.65,79.305);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAQA0IAAguQAAgHgEgDQgEgDgGAAQgFAAgFADQgEADgCACIAAAzIgVAAIAAhnIAVAAIAAAmIAGgFIAIgFQAFgBAGAAQAMAAAHAGQAFAGAAALIAAA1g");
	this.shape_84.setTransform(197.35,76.425);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQALAAAIAEQAIAFAEAHQAEAIAAAJQAAAKgEAHQgEAHgIAEQgIAFgLAAIgaAAIAAAlgAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgGAAIgXAAg");
	this.shape_85.setTransform(188.25,76.425);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_86.setTransform(170.475,77.875);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AAPAnIAAgtQAAgIgDgDQgEgDgGAAQgFAAgFADQgEACgCAEIAAAyIgVAAIAAhLIAVAAIAAAKIAFgGIAJgEQAFgCAGAAQAMAAAHAHQAFAGAAALIAAA1g");
	this.shape_87.setTransform(161.9,77.775);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgUAiQgKgFgEgJQgFgJAAgLQAAgKAFgJQAEgJAKgFQAJgGALAAQANAAAJAGQAIAFAFAJQAFAJAAAKQAAALgFAJQgFAJgIAFQgJAFgNABQgLgBgJgFgAgKgSQgDADgDAFQgCAFAAAFQAAAGACAFQADAFADADQAFADAFAAQAGAAAEgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgFgFgDQgEgDgGAAQgFAAgFADg");
	this.shape_88.setTransform(152.8,77.875);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_89.setTransform(140.525,77.875);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_90.setTransform(133.025,77.875);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgPA1IAAg5IgNAAIAAgSIANAAIAAgDQAAgNAHgHQAHgHAKAAQAGAAAFACQAFABAEAEIgIAMIgDgCIgFgBQgEAAgDADQgCADAAAFIAAADIAPAAIAAASIgPAAIAAA5g");
	this.shape_91.setTransform(118.575,76.325);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgUAiQgKgFgEgJQgFgJAAgLQAAgKAFgJQAEgJAKgFQAJgGALAAQANAAAJAGQAIAFAFAJQAFAJAAAKQAAALgFAJQgFAJgIAFQgJAFgNABQgLgBgJgFgAgKgSQgDADgDAFQgCAFAAAFQAAAGACAFQADAFADADQAFADAFAAQAGAAAEgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgFgFgDQgEgDgGAAQgFAAgFADg");
	this.shape_92.setTransform(110.95,77.875);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAGgDQAHgEAHAAIAAAUIgDgBIgCAAIgIABIgHADIgDAFIAAAxg");
	this.shape_93.setTransform(104,77.775);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQAMAAAHAEQAIAFAEAHQAEAIAAAJQAAAKgEAHQgEAHgIAEQgIAFgLAAIgaAAIAAAlgAgTgEIAWAAQAIAAAEgDQAEgEAAgHQAAgGgEgEQgEgEgIAAIgWAAg");
	this.shape_94.setTransform(96.25,76.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_79},{t:this.shape_78},{t:this.shape_77,p:{x:129.125}},{t:this.shape_76,p:{x:135.65}},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73,p:{x:150.875}},{t:this.shape_72},{t:this.shape_71,p:{x:171.625}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{x:196}},{t:this.shape_67},{t:this.shape_66,p:{x:219.9}},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63,p:{x:243.225}},{t:this.shape_62},{t:this.shape_61,p:{x:259.325}},{t:this.instance_5}]},105).to({state:[{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_63,p:{x:125.025}},{t:this.shape_90},{t:this.shape_89},{t:this.shape_71,p:{x:146.325}},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_76,p:{x:177}},{t:this.shape_85},{t:this.shape_84},{t:this.shape_66,p:{x:206.4}},{t:this.shape_61,p:{x:213.625}},{t:this.shape_68,p:{x:220.75}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_77,p:{x:244.175}},{t:this.shape_81},{t:this.shape_80},{t:this.shape_73,p:{x:270.975}}]},115).to({state:[]},148).to({state:[{t:this.shape_79},{t:this.shape_78},{t:this.shape_77,p:{x:129.125}},{t:this.shape_76,p:{x:135.65}},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73,p:{x:150.875}},{t:this.shape_72},{t:this.shape_71,p:{x:171.625}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{x:196}},{t:this.shape_67},{t:this.shape_66,p:{x:219.9}},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63,p:{x:243.225}},{t:this.shape_62},{t:this.shape_61,p:{x:259.325}},{t:this.instance_5}]},105).to({state:[{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_63,p:{x:125.025}},{t:this.shape_90},{t:this.shape_89},{t:this.shape_71,p:{x:146.325}},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_76,p:{x:177}},{t:this.shape_85},{t:this.shape_84},{t:this.shape_66,p:{x:206.4}},{t:this.shape_61,p:{x:213.625}},{t:this.shape_68,p:{x:220.75}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_77,p:{x:244.175}},{t:this.shape_81},{t:this.shape_80},{t:this.shape_73,p:{x:270.975}}]},115).to({state:[]},148).to({state:[{t:this.shape_79},{t:this.shape_78},{t:this.shape_77,p:{x:129.125}},{t:this.shape_76,p:{x:135.65}},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73,p:{x:150.875}},{t:this.shape_72},{t:this.shape_71,p:{x:171.625}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{x:196}},{t:this.shape_67},{t:this.shape_66,p:{x:219.9}},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63,p:{x:243.225}},{t:this.shape_62},{t:this.shape_61,p:{x:259.325}},{t:this.instance_5}]},105).to({state:[{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_63,p:{x:125.025}},{t:this.shape_90},{t:this.shape_89},{t:this.shape_71,p:{x:146.325}},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_76,p:{x:177}},{t:this.shape_85},{t:this.shape_84},{t:this.shape_66,p:{x:206.4}},{t:this.shape_61,p:{x:213.625}},{t:this.shape_68,p:{x:220.75}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_77,p:{x:244.175}},{t:this.shape_81},{t:this.shape_80},{t:this.shape_73,p:{x:270.975}}]},115).wait(148));

	// Слой_8
	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],8.5,-22.5,8.5,25.1).s().p("EglWADgIAAm/MBKtAAAIAAG/g");
	this.shape_95.setTransform(221.125,74.025);
	this.shape_95._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_95).wait(220).to({_off:false},0).to({_off:true},148).wait(220).to({_off:false},0).to({_off:true},148).wait(220).to({_off:false},0).wait(148));

	// Слой_21
	this.instance_6 = new lib.pc3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(249.4,101.15,0.73,0.73,0,0,0,342.7,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(220).to({_off:false},0).to({y:-8.05},147).to({_off:true},1).wait(220).to({_off:false,y:101.15},0).to({y:-8.05},147).to({_off:true},1).wait(220).to({_off:false,y:101.15},0).to({y:-8.05},147).wait(1));

	// pc11
	this.instance_7 = new lib.pc11();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-5.45,-7.05,0.8893,0.8893);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(105).to({_off:false},0).to({y:-77.05},115).to({_off:true},1).wait(252).to({_off:false,y:-7.05},0).to({y:-77.05},115).to({_off:true},1).wait(252).to({_off:false,y:-7.05},0).to({y:-77.05},115).to({_off:true},1).wait(147));

	// Слой_3
	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_96.setTransform(364,45);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.898)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_97.setTransform(364,45);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.8)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_98.setTransform(364,45);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.698)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_99.setTransform(364,45);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_100.setTransform(364,45);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.502)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_101.setTransform(364,45);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0.4)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_102.setTransform(364,45);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("rgba(255,255,255,0.302)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_103.setTransform(364,45);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_104.setTransform(364,45);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_105.setTransform(364,45);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_106.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_96}]}).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[]},1).to({state:[{t:this.shape_96}]},357).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[]},1).to({state:[{t:this.shape_96}]},357).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[]},1).wait(357));

	// Слой_6
	this.instance_8 = new lib.icons();
	this.instance_8.parent = this;
	this.instance_8.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(4).to({_off:false},0).to({alpha:1},6).to({_off:true},358).wait(4).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},358).wait(4).to({_off:false,alpha:0},0).to({alpha:1},6).wait(358));

	// screen21.jpg - копия
	this.instance_9 = new lib.pc21("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(168.5,96.7,0.6909,0.6909,0,0,0,296,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:167.5,y:66.7},104).to({_off:true},1).wait(263).to({_off:false,x:168.5,y:96.7},0).to({x:167.5,y:66.7},104).to({_off:true},1).wait(263).to({_off:false,x:168.5,y:96.7},0).to({x:167.5,y:66.7},104).to({_off:true},1).wait(263));

	// Слой_1
	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_107.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_107).wait(1104));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(327,-65.2,401.5,284);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_Trade Program_atlas_P_.png", id:"728x90_Trade Program_atlas_P_"},
		{src:"images/728x90_Trade Program_atlas_NP_.jpg", id:"728x90_Trade Program_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;