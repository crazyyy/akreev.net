(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_Trade Program_atlas_P_", frames: [[0,30,50,50],[0,0,98,28]]},
		{name:"300x250_Trade Program_atlas_NP_", frames: [[0,282,467,280],[338,613,56,43],[338,658,48,45],[338,564,56,47],[0,564,336,280],[0,0,467,280]]}
];


// symbols:



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.icons8circledplay50 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["300x250_Trade Program_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t1222 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgDgBAAgEQAAgDADgCQACgCACAAQADAAADACQACACAAADQAAAEgCABQgDADgDAAQgCAAgCgDg");
	this.shape.setTransform(203.4,74.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AggAxIAAhfIALAAIAAAKQAEgFAGgEQAGgDAHAAQAHAAAFADQAGACAEAFQAEAEADAHQACAHAAAJQAAAIgCAGQgDAHgEAFQgEAEgGADQgFADgHAAQgHAAgGgEQgGgDgEgGIAAAlgAgMgjQgGADgDAFIAAAeQADAFAGADQAFAEAHAAQAEAAAEgCQAFgCACgEQADgEACgEQABgEAAgGQAAgGgBgFQgCgFgDgEQgCgDgFgCQgEgCgEAAQgHAAgFADg");
	this.shape_1.setTransform(197.825,72.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_2.setTransform(191.825,69.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgEAAgEACg");
	this.shape_3.setTransform(186.15,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AATAwIAAguQgBgEgBgDIgDgFIgFgCIgHgBIgFABIgFACIgGAEIgDAEIAAAyIgLAAIAAhfIALAAIAAAkIAEgEIAGgEIAHgDIAHgBQALAAAFAGQAGAFAAAMIAAAwg");
	this.shape_4.setTransform(178.05,69.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_5.setTransform(168.675,69.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_6.setTransform(165.425,69.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgCATIgBgPIgBgFIgBgEIAAgFIAAgBQAAgBAAgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAABAAABIAAABIAAAFIgBAEIAAAFIgCAPg");
	this.shape_7.setTransform(162.35,66.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEAEADQADAEAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgCADgCAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgEAAgFACg");
	this.shape_8.setTransform(156.85,71.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AAVAwIgVhNIgVBNIgMAAIgchfIANAAIAWBPIAWhPIAJAAIAWBPIAVhPIAOAAIgcBfg");
	this.shape_9.setTransform(146.35,69.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgFAFQgCgBAAgEQAAgDACgCQADgCACAAQAEAAACACQACACAAADQAAAEgCABQgCADgEAAQgCAAgDgDg");
	this.shape_10.setTransform(134.5,74.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgDApQgFgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIALAAIAAATIANAAIAAAJIgNAAIAAArQAAAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_11.setTransform(130.75,70.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_12.setTransform(125.125,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgCgIgBgHQABgHACgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgEACgEAEQgDAEgBAEQgBAFAAAFQAAAFABAFQABAFADAEQAEADAEADQAEACAFAAQAGAAAEgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_13.setTransform(117.7,71.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgDAEgBAEQgCAFAAAFQAAAFACAFQABAFADAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_14.setTransform(109.4,71.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAuQgGgEgEgFIAAAKIgLAAIAAhfIALAAIAAAlQAEgGAGgDQAGgEAHAAQAHAAAFADQAGADAEAEQAEAFADAHQACAGAAAIQAAAJgCAHQgDAHgEAEQgEAFgGACQgFADgHAAQgHAAgGgDgAgMgLQgGAEgDAEIAAAfQADAFAGADQAFADAHAAQAEAAAFgCQAEgCADgDIAEgJQACgFAAgGQAAgGgCgEIgEgIQgDgEgEgCQgFgCgEAAQgHAAgFADg");
	this.shape_15.setTransform(101.275,70.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_16.setTransform(89.125,71.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_17.setTransform(78.275,71.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_18.setTransform(70.95,71.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_19.setTransform(65.225,69.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_20.setTransform(59.575,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_21.setTransform(52.475,71.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAFADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAEADADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgJgZQgEACgCAEQgEADgBAFIgCAIIAtAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgEAAgFACg");
	this.shape_22.setTransform(41.4,71.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_23.setTransform(33.3,71.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_24.setTransform(27.675,70.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_25.setTransform(24.425,69.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_26.setTransform(18.8,71.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgBgIgBgHQABgHABgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAFAFQAEAFACAHQADAGAAAHQAAAHgDAIQgCAGgEAFQgFAFgHADQgGADgIAAQgHAAgHgDgAgJgYQgEACgDAEQgDAEgCAEQgBAFgBAFQABAFABAFQACAFADAEQADADAEADQAFACAEAAQAGAAAEgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgEgCgGAAQgEAAgFACg");
	this.shape_27.setTransform(10.65,71.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_28.setTransform(0.75,71.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_29.setTransform(-6.05,71.35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgOAiQgGgDgEgFQgFgFgDgGQgBgIAAgHQAAgHABgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAGADQAHADAFAFQAEAFACAHQADAGAAAHQAAAHgDAIQgCAGgEAFQgFAFgHADQgGADgIAAQgHAAgHgDgAgJgYQgEACgDAEQgDAEgCAEQgBAFgBAFQABAFABAFQACAFADAEQADADAEADQAEACAFAAQAGAAAEgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_30.setTransform(-14.2,71.25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgYAxIgEgBIACgKIADABIADAAQAEAAACgBQACgCACgEIAFgLIgdhFIAMAAIAWA4IAXg4IAMAAIgjBTQgCAIgGADQgFADgGAAIgFAAg");
	this.shape_31.setTransform(-21.9,72.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_32.setTransform(-33.25,71.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_33.setTransform(-40.9,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_34.setTransform(-46.075,70.025);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAvQgJgEgGgHQgHgGgEgKQgEgJAAgLQAAgKAEgKQAEgJAHgGQAGgHAJgDQAKgEAJAAQANAAAJAFQAJAFAGAIIgJAGQgFgGgHgEQgHgDgJAAQgHAAgHADQgHACgFAGQgFAFgDAHQgCAHAAAIQAAAJACAHQADAHAFAFQAFAFAHADQAHADAHAAIAIgBIAHgCIAGgDIAFgEIAAgUIggAAIAAgKIAsAAIAAAiQgHAIgKAFQgJAEgMAAQgJAAgKgDg");
	this.shape_35.setTransform(-52.925,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1222, new cjs.Rectangle(-60.1,61.3,267.3,18.5), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape.setTransform(229.1,71.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDApQgFgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQAAAEACACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_1.setTransform(222.9,70.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_2.setTransform(219.125,70.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_3.setTransform(214.025,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgLAuQgGgEgEgFIAAAKIgLAAIAAhfIALAAIAAAlQAEgGAGgDQAGgEAHAAQAHAAAFADQAGADAEAEQAEAFADAHQACAGAAAIQAAAJgCAHQgDAHgEAEQgEAFgGACQgFADgHAAQgHAAgGgDgAgMgLQgGAEgDAEIAAAfQADAFAGADQAFADAHAAQAEAAAFgCQAEgCADgDIAEgJQACgFAAgGQAAgGgCgEIgEgIQgDgEgEgCQgFgCgEAAQgHAAgFADg");
	this.shape_4.setTransform(206.775,70.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape_5.setTransform(198.35,71.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AASAjIgSg3IgRA3IgLAAIgWhFIALAAIARA3IASg3IAJAAIASA3IARg3IALAAIgWBFg");
	this.shape_6.setTransform(188.925,71.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgFAAIgFABIgFACIgEAEIgDAEIAAAxg");
	this.shape_7.setTransform(177.85,71.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAHABQAFAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgGAEQgHADgHAAQgLAAgGgFg");
	this.shape_8.setTransform(171.05,71.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgEACgDAEQgEAEgBAEQgCAFABAFQgBAFACAFQABAFAEAEQADADAEADQAFACAEAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_9.setTransform(162.9,71.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgYAxIgDgBIABgKIADABIADAAQAEAAACgBQADgCACgEIAEgLIgdhFIALAAIAXA4IAXg4IAMAAIgjBTQgCAIgGADQgEADgHAAIgFAAg");
	this.shape_10.setTransform(155.2,72.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_11.setTransform(144.425,71.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgEAAgEACg");
	this.shape_12.setTransform(137.1,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEApQgEgFABgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_13.setTransform(130.9,70.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_14.setTransform(124.725,71.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_15.setTransform(117.55,71.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_16.setTransform(109.95,71.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_17.setTransform(104.225,69.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAFADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAEADADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgJgZQgEACgCAEQgEADgBAFIgCAIIAtAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgEAAgFACg");
	this.shape_18.setTransform(98.55,71.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_19.setTransform(88.6,70.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_20.setTransform(82.425,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AATAwIAAguQAAgEgCgDIgDgFIgFgCIgGgBIgGABIgFACIgGAEIgDAEIAAAyIgLAAIAAhfIALAAIAAAkIAEgEIAGgEIAHgDIAHgBQALAAAFAGQAGAFAAAMIAAAwg");
	this.shape_21.setTransform(74.8,69.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_22.setTransform(68.7,70.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEApQgEgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_23.setTransform(60.7,70.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgFACIgGAEIgDAEIAAAyIgLAAIAAhFIALAAIAAAKIAEgEIAGgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_24.setTransform(54.55,71.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_25.setTransform(46.5,71.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDApQgFgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIALAAIAAATIANAAIAAAJIgNAAIAAArQAAAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_26.setTransform(40.3,70.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgEgEgIAAIgEABIgGACIgGAEIgDAEIAAAyIgLAAIAAhFIALAAIAAAKIAEgEIAGgEIAHgDIAHgBQAWAAAAAXIAAAwg");
	this.shape_27.setTransform(34.15,71.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFABAFQgBAFACAFQACAFACAEQADADAFADQAEACAFAAQAGAAAEgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(26,71.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_29.setTransform(18.375,71.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_30.setTransform(6.875,71.25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_31.setTransform(1.625,70.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_32.setTransform(-4.375,70.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAEACADQAEAEAFACQAEACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgCAEQgDADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_33.setTransform(-12.4,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AAlAkIAAguQAAgHgDgEQgDgEgHAAQgGAAgFADQgFADgDAEIAAAzIgKAAIAAguQAAgHgDgEQgDgEgHAAQgFAAgFADQgFAEgDAEIAAAyIgLAAIAAhFIALAAIAAAKIADgDIAGgEIAGgEQAEgBAEAAQAIAAAEAEQAEAEABAFIAEgEIAGgEIAHgEIAHgBQAKAAAEAGQAGAFAAAKIAAAyg");
	this.shape_34.setTransform(-22.325,71.15);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_35.setTransform(-33.95,71.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_36.setTransform(-40.8,71.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgLAxIAAg8IgLAAIAAgJIALAAIAAgFQAAgMAGgFQAFgGAIAAIAIABQAEABADADIgEAIIgEgEIgFAAQgFAAgDAEQgCADAAAHIAAAFIANAAIAAAJIgNAAIAAA8g");
	this.shape_37.setTransform(-46.425,69.85);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgLAxIAAg8IgLAAIAAgJIALAAIAAgFQAAgMAGgFQAFgGAIAAIAIABQAEABADADIgEAIIgEgEIgFAAQgFAAgDAEQgCADAAAHIAAAFIANAAIAAAJIgNAAIAAA8g");
	this.shape_38.setTransform(-50.525,69.85);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFABAFQgBAFACAFQACAFACAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_39.setTransform(-57.25,71.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgCAEQgDADgCAFIgCAIIAtAAIgBgIQgCgFgCgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_40.setTransform(-69.2,71.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAVAwIgVhNIgUBNIgOAAIgbhfIAOAAIAVBPIAWhPIAJAAIAWBPIAVhPIAOAAIgbBfg");
	this.shape_41.setTransform(-79.7,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-88.1,61.3,323.4,18.5), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape.setTransform(261.825,130.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA0IgUglIgQAAIAAAlIgXAAIAAhnIAxAAQAKAAAIAEQAIAEAEAIQAEAHABAKQAAAJgEAHQgDAFgGAEQgFAEgFABIAYAogAgTgEIAWAAQAHAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgHAAIgWAAg");
	this.shape_1.setTransform(252.4,130.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_2.setTransform(242.7,130.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AggA0IAAhnIAWAAIAABUIArAAIAAATg");
	this.shape_3.setTransform(234.125,130.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_4.setTransform(227.7,130.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_5.setTransform(220.175,130.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_6.setTransform(210.225,130.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_7.setTransform(201.25,130.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHAAAKQAAAJgDAHQgDAFgFAEQgGAEgFABIAXAogAgUgEIAXAAQAHAAAEgDQAEgEABgHQgBgGgEgEQgEgEgHAAIgXAAg");
	this.shape_8.setTransform(191.7,130.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_9.setTransform(177.95,130.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_10.setTransform(167.475,130.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_11.setTransform(159.6,130.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AggA0IAAhnIAWAAIAABUIArAAIAAATg");
	this.shape_12.setTransform(153.625,130.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_13.setTransform(143.625,130.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_14.setTransform(131.925,130.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAYA0IAAgsIgwAAIAAAsIgWAAIAAhnIAWAAIAAApIAwAAIAAgpIAXAAIAABng");
	this.shape_15.setTransform(116.1,130.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_16.setTransform(105.775,130.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_17.setTransform(99.05,130.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_18.setTransform(89.7,130.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape_19.setTransform(73.675,130.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AARA0IgegqIgJAKIAAAgIgWAAIAAhnIAWAAIAAAuIAkguIAcAAIgqAxIAtA2g");
	this.shape_20.setTransform(64.575,130.925);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAQA0IgTglIgQAAIAAAlIgWAAIAAhnIAvAAQAMAAAHAEQAIAEAEAIQAFAHAAAKQgBAJgDAHQgDAFgFAEQgGAEgGABIAZAogAgTgEIAWAAQAHAAAFgDQADgEABgHQgBgGgDgEQgFgEgHAAIgWAAg");
	this.shape_21.setTransform(54.25,130.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_22.setTransform(42.975,130.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAThKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_23.setTransform(29.75,130.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgQAdQgHgEgFgIQgEgIAAgJQAAgJAEgHQAFgIAHgDQAIgFAIgBQAJABAIAFQAHADAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAEQgIAEgJABQgIgBgIgEgAgNgYQgHAFgDAGQgEAGAAAHQAAAIAEAGQADAHAHAEQAGADAHAAQAIAAAGgDQAHgEADgHQAEgGAAgIQAAgHgEgGQgDgGgHgFQgGgDgIAAQgHAAgGADgAAJATIgJgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAADADQAEADAAAFQAAAFgCACIgEADIgDABIAKAPgAgGAAIAJAAIAFgBQACgCAAgEQAAgCgCgCQgDgCgCAAIgJAAg");
	this.shape_24.setTransform(14.625,128.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_25.setTransform(6.35,130.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgVAvQgNgGgHgMQgIgMAAgRQAAgQAIgMQAHgMANgGQAMgHAPAAQAKAAAJADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAFgCQAHgDADgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgMgHg");
	this.shape_26.setTransform(-4.15,130.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_27.setTransform(-15.075,130.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_28.setTransform(-27.65,130.925);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_29.setTransform(-39.25,130.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_30.setTransform(-49.725,130.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-57.5,121.8,326.2,19.700000000000003), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],8.5,-35.7,8.5,40.1).s().p("EglWAFlIAArJMBKtAAAIAALJg");
	this.shape.setTransform(239.175,222.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc31, new cjs.Rectangle(0,0,478.3,280), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc21, new cjs.Rectangle(0,0,467,280), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,280), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape.setTransform(266.775,26.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIglAAIABAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAfAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgCABg");
	this.shape_1.setTransform(261.65,26.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_2.setTransform(256.45,26.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_3.setTransform(252.775,25.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgDAYIgUgvIAIAAIAPAnIAQgnIAIAAIgUAvg");
	this.shape_4.setTransform(249.2,26.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_5.setTransform(245.375,26.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgHAYQgFgCgEgEQgCgDgDgFQgCgEAAgGQAAgEACgFIAFgIQADgDAFgCQAFgCAEAAQAFAAAEACQAFACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_6.setTransform(240.6,26.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAEgGIAFADIAEADIAGACIAGABQAEAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBIABgDQAAgEgCgCIgDgDIgHgDIgHgCIgHgCIgGgCIgFgFQgBgDAAgFQAAgEABgDIAGgGIAGgEIAJgBQAIAAAFACQAGACAEAFIgEAGQgFgEgEgCQgGgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAFADIAGADIAGACIAIACIAGADIAEAFQACADAAAFIgCAHQAAAEgDACQgEADgEACQgFABgGAAQgJAAgFgDg");
	this.shape_7.setTransform(234.9,25.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgDgDQgCgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_8.setTransform(260.05,16.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_9.setTransform(254.275,17.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_10.setTransform(250.425,15.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_11.setTransform(246.925,16.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAfAAIAAgGIgDgFIgFgEQgDgBgFAAQgCAAgEABg");
	this.shape_12.setTransform(241.8,16.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGAAAGQAAAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_13.setTransform(235.65,15.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_14.setTransform(160.225,27.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgDgDQgCgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(154.75,26.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(150.875,25.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_17.setTransform(147.35,26.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(143.675,25.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(141.175,26.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(136.625,25.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_21.setTransform(170.475,15.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgEABIgEABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_22.setTransform(166.25,16.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIABAGIADADIADACIAEAAQAEAAADgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_23.setTransform(160.75,16.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAXQgFgCgDgDQgCgDgCgFQgCgFAAgFQAAgEACgFQACgEACgEQADgDAFgCQAEgCAFAAQAGAAAEACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgCAFgEADQgDADgEACQgEACgGAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_24.setTransform(155.15,16.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgEABgCADIgDAGIgBAGIABAIIADAFQACADAEABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_25.setTransform(149.9,16.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_26.setTransform(144.975,16.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_27.setTransform(141.575,15.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGAAAGQAAAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFABgFIgCgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_28.setTransform(137.1,15.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_29.setTransform(71.025,27.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_30.setTransform(65.55,26.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(61.675,25.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_32.setTransform(57.875,27);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_33.setTransform(52.175,27);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_34.setTransform(48.025,25.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAMAhIAAggIAAgEIgDgDQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgDABIgFACIgDACIgCADIAAAiIgIAAIAAhBIAIAAIAAAZIADgDIADgDIAFgCIAFAAQAIAAAEADQADAEAAAIIAAAhg");
	this.shape_35.setTransform(44.15,25.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAFgGIADADIAFADIAGACIAFABQAFAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBIABgDQAAgEgBgCIgFgDIgGgDIgGgCIgIgCIgGgCIgEgFQgCgDAAgFQAAgEACgDIAEgGIAHgEIAJgBQAHAAAHACQAGACAEAFIgGAGQgDgEgGgCQgFgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAEADIAHADIAHACIAHACIAGADIAFAFQABADAAAFIgBAHQgBAEgEACQgDADgEACQgFABgHAAQgHAAgGgDg");
	this.shape_36.setTransform(38.5,25.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAYQgFgCgEgEQgCgDgDgFQgCgEAAgGQAAgEACgFIAFgIQADgDAFgCQAFgCAEAAQAFAAAEACQAFACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_37.setTransform(66.9,16.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_38.setTransform(62.975,15.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgHAgQgFgDgCgDIAAAHIgIAAIAAhCIAIAAIAAAaQADgEAEgDQAEgCAEAAQAFAAAEACQAEACADADQACADACAFQACAEAAAGQAAAGgCAEIgEAIIgHAFQgEACgFAAQgEAAgEgCgAgIgHQgEADgCADIAAAVQACADAEACQAEACAEAAQADAAADgBIAFgEIADgGIABgHIgBgIIgDgFIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_39.setTransform(59.125,15.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_40.setTransform(54.975,15.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAPAYIgPgUIgNAUIgJAAIASgYIgRgXIAJAAIAMASIANgSIAJAAIgRAXIASAYg");
	this.shape_41.setTransform(51.425,16.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQADgDAFgCQAEgCAEAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgmAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgHAAQgEAAgFgBgAgFgRIgFAEIgDAFIgBAGIAeAAIAAgGIgDgFIgGgEQgCgBgFAAQgCAAgDABg");
	this.shape_42.setTransform(46.15,16.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_43.setTransform(42.225,15.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_44.setTransform(38.575,15.225);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(215.2,21.45,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(114.4,21.85,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(15.15,21.85,0.515,0.515,0,0,0,0.1,0.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_45.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-8.1,8.7,288.6,30.599999999999998), null);


// stage content:
(lib._300x250_TradeProgram = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_766 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(766).call(this.frame_766).wait(122));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_1.setTransform(150,125);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_2.setTransform(150,125);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_3.setTransform(150,125);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_4.setTransform(150,125);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_5.setTransform(150,125);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_6.setTransform(150,125);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_7.setTransform(150,125);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_8.setTransform(150,125);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(8));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(150,16,0.7142,0.7142);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(888));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-123,-26.3,-64.2,7.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_9.setTransform(149.85,223.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-115.3,-23.6,-56.5,10.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_10.setTransform(149.85,223.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-107.6,-20.9,-48.8,13.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_11.setTransform(149.85,223.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-99.8,-18.2,-41,15.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_12.setTransform(149.85,223.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-92.1,-15.5,-33.3,18.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_13.setTransform(149.85,223.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-84.4,-12.8,-25.6,21.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_14.setTransform(149.85,223.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-76.7,-10.1,-17.9,23.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_15.setTransform(149.85,223.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.9,-7.5,-10.1,26.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_16.setTransform(149.85,223.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-61.2,-4.8,-2.4,29.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_17.setTransform(149.85,223.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-53.5,-2.1,5.3,31.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_18.setTransform(149.85,223.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-45.8,0.6,13,34.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_19.setTransform(149.85,223.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-38,3.3,20.8,37.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_20.setTransform(149.85,223.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-30.3,6,28.5,40).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_21.setTransform(149.85,223.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-22.6,8.7,36.2,42.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_22.setTransform(149.85,223.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-14.8,11.4,44,45.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_23.setTransform(149.85,223.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-7.1,14.1,51.7,48.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_24.setTransform(149.85,223.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,16.8,59.4,50.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_25.setTransform(149.85,223.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,19.5,67.1,53.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_26.setTransform(149.85,223.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],16.1,22.2,74.9,56.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_27.setTransform(149.85,223.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],23.8,24.9,82.6,58.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_28.setTransform(149.85,223.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],31.5,27.6,90.3,61.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_29.setTransform(149.85,223.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.2,30.3,98,64.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_30.setTransform(149.85,223.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],47,33,105.8,66.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_31.setTransform(149.85,223.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],54.7,35.7,113.5,69.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_32.setTransform(149.85,223.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],62.4,38.4,121.2,72.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_33.setTransform(149.85,223.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).wait(234));

	// Слой_11
	this.instance_1 = new lib.icons8circledplay50();
	this.instance_1.parent = this;
	this.instance_1.setTransform(130,67,0.8,0.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(123).to({_off:false},0).to({_off:true},86).wait(210).to({_off:false},0).to({_off:true},86).wait(210).to({_off:false},0).to({_off:true},86).wait(87));

	// Слой_8
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_34.setTransform(226.325,153.325);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAQAnIAAgtQAAgIgEgDQgEgDgHAAQgEAAgFADQgEACgDAEIAAAyIgTAAIAAhLIATAAIAAAKIAHgGIAIgEQAEgCAHAAQANAAAFAHQAHAGAAALIAAA1g");
	this.shape_35.setTransform(219.1,154.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_36.setTransform(210.225,154.275);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_37.setTransform(203.225,153.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAQAnIAAgtQgBgIgDgDQgEgDgHAAQgEAAgFADQgEACgCAEIAAAyIgVAAIAAhLIAVAAIAAAKIAFgGIAJgEQAFgCAGAAQAMAAAHAHQAFAGAAALIAAA1g");
	this.shape_38.setTransform(196,154.175);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgUAiQgKgFgEgJQgFgJAAgLQAAgKAFgJQAEgJAKgFQAIgGAMAAQANAAAJAGQAIAFAFAJQAFAJAAAKQAAALgFAJQgFAJgIAFQgJAFgNABQgMgBgIgFgAgKgSQgDADgDAFQgCAFAAAFQAAAGACAFQADAFADADQAFADAFAAQAGAAAEgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgFgFgDQgEgDgGAAQgFAAgFADg");
	this.shape_39.setTransform(186.9,154.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgHgMQgIgMAAgQQAAgPAIgMQAHgNAMgGQANgHAPAAQALAAAJAEQAIADAGAGIAKAMIgUAKQgDgHgGgEQgHgEgIAAQgJAAgHAEQgHAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAHAFQAHAEAJAAQAIAAAHgEQAGgEADgHIAUAJQgEAHgGAGQgGAGgIADQgJAEgLAAQgPAAgNgHg");
	this.shape_40.setTransform(177.125,152.825);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgVAiQgIgFgFgJQgFgJAAgLQAAgKAFgJQAFgJAIgFQAKgGALAAQAMAAAJAGQAJAFAGAJQAEAJAAAKQAAALgEAJQgGAJgJAFQgJAFgMABQgLgBgKgFgAgKgSQgEADgCAFQgCAFAAAFQAAAGACAFQACAFAEADQAFADAFAAQAGAAAFgDQAEgDADgFQACgFAAgGQAAgFgCgFQgDgFgEgDQgFgDgGAAQgFAAgFADg");
	this.shape_41.setTransform(163,154.275);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_42.setTransform(154.175,154.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgVAwQgHgEgFgJQgFgJABgNQgBgMAFgIQAFgJAHgFQAIgEAJAAQAGAAAGACQAGADAEAGIAAgmIAUAAIAABnIgUAAIAAgJQgEAFgGADQgGADgGAAQgJAAgIgFgAgLgCQgGAFAAAKQAAAKAGAGQAFAGAHAAQAFAAAFgCQAFgCACgEIAAgbQgCgDgFgCQgFgDgFAAQgHAAgFAGg");
	this.shape_43.setTransform(144.95,152.925);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgJA2IAAhLIATAAIAABLgAgHghQgEgDAAgFQAAgFAEgEQADgDAEAAQAFAAADADQAEAEAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_44.setTransform(138.625,152.675);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgNA0IgohnIAZAAIAcBPIAdhPIAZAAIgoBng");
	this.shape_45.setTransform(131.275,152.825);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgbA1IgFgBIADgRIADAAIADABIAHgBQACgCACgDIADgGIgfhMIAVAAIATA0IAUg0IAVAAIgjBXQgDAHgDAEQgFAEgFACQgGABgGAAIgFAAg");
	this.shape_46.setTransform(117.875,155.775);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_47.setTransform(111.225,153.325);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgJA2IAAhLIATAAIAABLgAgHghQgEgDAAgFQAAgFAEgEQADgDAEAAQAFAAADADQAEAEAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_48.setTransform(106.575,152.675);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_49.setTransform(102.65,152.825);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_50.setTransform(96.125,154.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgdAgQgFgGgBgLIAAg1IAVAAIAAAtQAAAIADADQAEADAGAAQAFAAAEgCQAFgDACgDIAAgzIAUAAIAABLIgUAAIAAgJQgDAEgHADQgGADgJABQgNAAgGgHg");
	this.shape_51.setTransform(87.55,154.35);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAZAuIgMAFQgGABgHAAQgPgBgMgGQgNgHgHgMQgHgMAAgPQAAgQAHgMQAHgNANgGQAMgIAPABQAQgBAMAIQAMAGAHANQAHAMABAQQgBAKgDAJQgEAJgGAIIAIAJIgQAMgAgQgfQgHAEgEAIQgEAIAAAKQAAAJAEAIQAEAHAHAEQAHAFAJAAIAGAAIAFgCIgLgNIAPgNIALAOIAEgKQACgEAAgFQAAgKgEgIQgEgIgHgEQgHgEgKgBQgJABgHAEg");
	this.shape_52.setTransform(77.025,153.05);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAQA0IAAguQgBgHgDgDQgEgDgGAAQgFAAgFADQgEADgCACIAAAzIgVAAIAAhnIAVAAIAAAmIAGgFIAIgFQAFgBAGAAQAMAAAHAGQAFAGAAALIAAA1g");
	this.shape_53.setTransform(229.4,152.825);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AglA1IAAhoIATAAIAAAKQAFgGAFgCQAHgDAGAAQAJAAAIAEQAIAFAEAJQAEAJAAAMQAAANgEAIQgEAJgIAEQgIAFgJAAQgGAAgGgDQgGgDgFgFIAAAmgAgKggQgFACgDAEIAAAaQADADAFADQAFACAFAAQAHAAAFgGQAGgFAAgKQAAgKgGgGQgFgGgHAAQgFAAgFADg");
	this.shape_54.setTransform(220.55,155.625);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgDgBIgCAAIgIABIgHADIgDAFIAAAxg");
	this.shape_55.setTransform(204.7,154.175);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgCA2QgJAAgIgDQgIgCgHgGIAJgPQAEAFAHADQAGACAGAAQAEAAAFgCQAFgCADgEQAEgEAAgIIAAgHQgFAGgGADQgGADgGAAQgJAAgIgFQgHgEgFgJQgEgHgBgNQABgMAEgJQAFgIAHgFQAIgEAJAAQAGAAAGACQAGADAFAGIAAgKIAUAAIAABGQAAALgFAHQgDAHgGAEQgGAEgHABQgGACgGAAIgCAAgAgMgeQgEAFgBAKQABAKAEAFQAFAFAJAAQAFAAAEgCQAFgDADgDIAAgYQgDgEgFgCQgEgDgFAAQgJAAgFAGg");
	this.shape_56.setTransform(196.65,155.705);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAQA0IAAguQAAgHgEgDQgEgDgGAAQgFAAgEADQgFADgCACIAAAzIgUAAIAAhnIAUAAIAAAmIAGgFIAIgFQAFgBAGAAQAMAAAHAGQAFAGABALIAAA1g");
	this.shape_57.setTransform(164.35,152.825);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQALAAAIAEQAIAFAEAHQAEAIAAAJQAAAKgEAHQgEAHgIAEQgIAFgLAAIgaAAIAAAlgAgTgEIAXAAQAGAAAFgDQAEgEABgHQgBgGgEgEQgFgEgGAAIgXAAg");
	this.shape_58.setTransform(155.25,152.825);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_59.setTransform(137.475,154.275);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAPAnIAAgtQAAgIgDgDQgEgDgGAAQgGAAgDADQgFACgDAEIAAAyIgTAAIAAhLIATAAIAAAKIAHgGIAIgEQAFgCAGAAQANAAAFAHQAGAGABALIAAA1g");
	this.shape_60.setTransform(128.9,154.175);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgVAiQgIgFgFgJQgFgJAAgLQAAgKAFgJQAFgJAIgFQAKgGALAAQAMAAAJAGQAKAFAFAJQAEAJAAAKQAAALgEAJQgFAJgKAFQgJAFgMABQgLgBgKgFgAgKgSQgEADgCAFQgCAFAAAFQAAAGACAFQACAFAEADQAFADAFAAQAGAAAFgDQAEgDADgFQACgFAAgGQAAgFgCgFQgDgFgEgDQgFgDgGAAQgFAAgFADg");
	this.shape_61.setTransform(119.8,154.275);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_62.setTransform(107.525,154.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_63.setTransform(100.025,154.275);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgPA1IAAg5IgNAAIAAgSIANAAIAAgDQAAgNAHgHQAHgHAKAAQAGAAAFACQAFABAEAEIgIAMIgDgCIgFgBQgEAAgDADQgCADAAAFIAAADIAPAAIAAASIgPAAIAAA5g");
	this.shape_64.setTransform(85.575,152.725);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgVAiQgIgFgFgJQgFgJAAgLQAAgKAFgJQAFgJAIgFQAKgGALAAQAMAAAJAGQAJAFAGAJQAEAJAAAKQAAALgEAJQgGAJgJAFQgJAFgMABQgLgBgKgFgAgKgSQgEADgCAFQgCAFAAAFQAAAGACAFQACAFAEADQAFADAFAAQAGAAAFgDQAEgDADgFQACgFAAgGQAAgFgCgFQgDgFgEgDQgFgDgGAAQgFAAgFADg");
	this.shape_65.setTransform(77.95,154.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAGgDQAHgEAHAAIAAAUIgCgBIgEAAIgHABIgGADIgEAFIAAAxg");
	this.shape_66.setTransform(71,154.175);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQALAAAIAEQAIAFAEAHQAEAIAAAJQAAAKgEAHQgEAHgIAEQgIAFgLAAIgaAAIAAAlgAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgGAAIgXAAg");
	this.shape_67.setTransform(63.25,152.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:96.125}},{t:this.shape_49,p:{x:102.65}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:117.875}},{t:this.shape_45},{t:this.shape_44,p:{x:138.625}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:163}},{t:this.shape_40},{t:this.shape_39,p:{x:186.9}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36,p:{x:210.225}},{t:this.shape_35},{t:this.shape_34,p:{x:226.325}}]},123).to({state:[{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_36,p:{x:92.025}},{t:this.shape_63},{t:this.shape_62},{t:this.shape_44,p:{x:113.325}},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_49,p:{x:144}},{t:this.shape_58},{t:this.shape_57},{t:this.shape_39,p:{x:173.4}},{t:this.shape_34,p:{x:180.625}},{t:this.shape_41,p:{x:187.75}},{t:this.shape_56},{t:this.shape_55},{t:this.shape_50,p:{x:211.175}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_46,p:{x:237.975}}]},86).to({state:[]},87).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:96.125}},{t:this.shape_49,p:{x:102.65}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:117.875}},{t:this.shape_45},{t:this.shape_44,p:{x:138.625}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:163}},{t:this.shape_40},{t:this.shape_39,p:{x:186.9}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36,p:{x:210.225}},{t:this.shape_35},{t:this.shape_34,p:{x:226.325}}]},123).to({state:[{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_36,p:{x:92.025}},{t:this.shape_63},{t:this.shape_62},{t:this.shape_44,p:{x:113.325}},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_49,p:{x:144}},{t:this.shape_58},{t:this.shape_57},{t:this.shape_39,p:{x:173.4}},{t:this.shape_34,p:{x:180.625}},{t:this.shape_41,p:{x:187.75}},{t:this.shape_56},{t:this.shape_55},{t:this.shape_50,p:{x:211.175}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_46,p:{x:237.975}}]},86).to({state:[]},87).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:96.125}},{t:this.shape_49,p:{x:102.65}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:117.875}},{t:this.shape_45},{t:this.shape_44,p:{x:138.625}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:163}},{t:this.shape_40},{t:this.shape_39,p:{x:186.9}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36,p:{x:210.225}},{t:this.shape_35},{t:this.shape_34,p:{x:226.325}}]},123).to({state:[{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_36,p:{x:92.025}},{t:this.shape_63},{t:this.shape_62},{t:this.shape_44,p:{x:113.325}},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_49,p:{x:144}},{t:this.shape_58},{t:this.shape_57},{t:this.shape_39,p:{x:173.4}},{t:this.shape_34,p:{x:180.625}},{t:this.shape_41,p:{x:187.75}},{t:this.shape_56},{t:this.shape_55},{t:this.shape_50,p:{x:211.175}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_46,p:{x:237.975}}]},86).wait(87));

	// t12
	this.instance_2 = new lib.t1222();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.instance_3 = new lib.t12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},123).to({state:[{t:this.instance_2}]},173).to({state:[{t:this.instance_3}]},123).to({state:[{t:this.instance_2}]},173).to({state:[{t:this.instance_3}]},123).wait(173));

	// t11
	this.instance_4 = new lib.t11();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,104.7,0.8928,0.8928,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(888));

	// btn
	this.instance_5 = new lib.btn();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150,190.55,0.8928,0.8928,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(123).to({y:192.55},0).wait(173).to({y:190.55},0).wait(123).to({y:192.55},0).wait(173).to({y:190.55},0).wait(123).to({y:192.55},0).wait(173));

	// Слой_5
	this.instance_6 = new lib.icons();
	this.instance_6.parent = this;
	this.instance_6.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},123).wait(173).to({_off:false},0).to({_off:true},123).wait(173).to({_off:false},0).to({_off:true},123).wait(173));

	// Слой_14
	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("A3bI6IAAxzMAu3AAAIAARzg");
	this.shape_68.setTransform(150,193.175);

	this.timeline.addTween(cjs.Tween.get(this.shape_68).wait(123).to({y:225.175},0).wait(173).to({y:193.175},0).wait(123).to({y:225.175},0).wait(173).to({y:193.175},0).wait(123).to({y:225.175},0).wait(173));

	// Слой_9
	this.instance_7 = new lib.pc31();
	this.instance_7.parent = this;
	this.instance_7.setTransform(160.15,90.1,0.6859,0.6859,0,0,0,233.5,140.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(209).to({_off:false},0).to({x:139.85},86).to({_off:true},1).wait(209).to({_off:false,x:160.15},0).to({x:139.85},86).to({_off:true},1).wait(209).to({_off:false,x:160.15},0).to({x:139.85},86).wait(1));

	// Слой_7
	this.instance_8 = new lib.pc21();
	this.instance_8.parent = this;
	this.instance_8.setTransform(172,103.2,0.7366,0.7366,0,0,0,233.5,140.1);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(123).to({_off:false},0).to({regX:233.4,scaleX:0.6723,scaleY:0.6723,x:143,y:94.2},86).to({_off:true},1).wait(209).to({_off:false,regX:233.5,scaleX:0.7366,scaleY:0.7366,x:172,y:103.2},0).to({regX:233.4,scaleX:0.6723,scaleY:0.6723,x:143,y:94.2},86).to({_off:true},1).wait(209).to({_off:false,regX:233.5,scaleX:0.7366,scaleY:0.7366,x:172,y:103.2},0).to({regX:233.4,scaleX:0.6723,scaleY:0.6723,x:143,y:94.2},86).to({_off:true},1).wait(86));

	// pc11
	this.instance_9 = new lib.pc11();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150,105,0.8928,0.8928,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({y:125},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(173).to({_off:false,y:105},0).to({y:125},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(173).to({_off:false,y:105},0).to({y:125},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(173));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(129.7,101.1,214.3,181.1);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_Trade Program_atlas_P_.png", id:"300x250_Trade Program_atlas_P_"},
		{src:"images/300x250_Trade Program_atlas_NP_.jpg", id:"300x250_Trade Program_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;