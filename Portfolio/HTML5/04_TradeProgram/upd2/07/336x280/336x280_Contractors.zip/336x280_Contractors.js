(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_Contractors_atlas_P_", frames: [[0,0,98,28]]},
		{name:"336x280_Contractors_atlas_NP_", frames: [[0,476,336,192],[58,670,56,43],[116,670,48,45],[0,670,56,47],[0,0,336,280],[0,282,336,192]]}
];


// symbols:



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["336x280_Contractors_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["336x280_Contractors_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["336x280_Contractors_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["336x280_Contractors_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_Contractors_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["336x280_Contractors_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["336x280_Contractors_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape.setTransform(233.3,72.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_1.setTransform(229.95,69.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgLAeQgFgCgEgEQgEgEgDgHQgDgFABgIQgBgFADgHQADgGAEgEQADgEAGgEQAGgCAFAAQAHAAAHACQAFAEAEAEQAEAFABAFQADAHAAAGIAAACIgyAAQAAAFACADQACAFADADQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgFADgJAAQgGAAgGgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_2.setTransform(224.35,70.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgNArQgHgCgFgFIAFgIQAEAFAFACQAFACAGAAIAHgBQAEgBADgCIAEgGQACgEAAgFIAAgJQgEAFgFADQgGAEgGgBQgGAAgEgCQgGgCgEgFQgDgDgDgHQgCgEAAgIQAAgIACgGQACgGAEgEQAEgFAFgCQAGgCAFAAQAGAAAGADQAFADAEAFIAAgKIAKAAIAAA8QAAAJgDAEQgDAGgEADQgEADgFACIgLABQgHAAgGgCgAgGgiQgEADgDADQgDADgBAEIgBAKIABAKIAEAGQADADAEACQADABAEAAIAFAAIAGgDIAEgCIAEgFIAAgaIgEgEIgEgDIgGgDIgFAAQgEAAgDABg");
	this.shape_3.setTransform(216.8,71.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgMAqQgFgDgEgEQgDgEgCgGQgDgGAAgIQAAgHADgGQACgFADgFQAEgEAFgDQAFgCAGAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABVIgKAAIAAgJQgEAFgFADQgGADgGAAQgFAAgGgCgAgGgLQgFACgCAEQgDADgBAEIgBAJIABAKIAEAIQACADAFABQADACAEAAQAGAAAFgDQAFgCADgFIAAgbQgDgEgFgDQgFgDgGAAQgEAAgDABg");
	this.shape_4.setTransform(209.35,69.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIAAAHIADAFIAFACIAFABQAFAAAGgDQAFgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_5.setTransform(202.25,70.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgKApQgFgDgEgFIAAAJIgJAAIAAhVIAJAAIAAAhQAEgFAGgDQAFgDAGAAQAGAAAFACQAFADAEAEQADAFACAFQACAGAAAHQAAAIgCAGQgCAGgDAEQgEAEgFADQgFACgGAAQgGAAgGgDgAgLgJQgFADgDAEIAAAbQADAFAFACQAFADAGAAQAEAAAEgCQADgBADgDQADgEABgEQABgEAAgGQAAgFgBgEQgBgEgDgDQgDgEgDgCQgEgBgEAAQgGAAgFADg");
	this.shape_6.setTransform(195.125,69.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAALQAEgFAEgEQAGgDAGAAIAAAKIgEAAIgEABIgFACIgEADIgDAEIAAArg");
	this.shape_7.setTransform(186.05,70.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgLAeQgFgCgEgEQgEgEgDgHQgCgFgBgIQABgFACgHQADgGAEgEQADgEAGgEQAGgCAFAAQAHAAAHACQAFAEAEAEQADAFADAFQACAHAAAGIAAACIgyAAQAAAFACADQACAFADADQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgFADgIAAQgGAAgHgDgAgIgWIgFAFQgDADgCAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_8.setTransform(179.9,70.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgMAqQgFgDgEgEQgDgEgDgGQgCgGAAgIQAAgHACgGQADgFADgFQAEgEAFgDQAGgCAFAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABVIgKAAIAAgJQgEAFgFADQgGADgGAAQgGAAgFgCgAgGgLQgEACgDAEQgDADgBAEIgBAJIABAKIAEAIQADADAEABQADACAEAAQAGAAAFgDQAFgCADgFIAAgbQgDgEgFgDQgFgDgGAAQgEAAgDABg");
	this.shape_9.setTransform(172.35,69.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgEgDQgEgDgGAAIgEAAIgGADIgEADIgEADIAAAtIgJAAIAAg+IAJAAIAAAKIAFgEIAFgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_10.setTransform(165.2,70.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIABAHIACAFIAFACIAFABQAFAAAGgDQAFgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_11.setTransform(158.05,70.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAqQgGgDgDgEQgEgEgDgGQgBgGAAgIQAAgHABgGQACgFAFgFQADgEAFgDQAGgCAGAAQAFAAAFADQAGADADAFIAAghIAKAAIAABVIgKAAIAAgJQgDAFgGADQgFADgFAAQgHAAgEgCgAgHgLQgEACgCAEQgCADgCAEIgBAJIABAKIAEAIQACADAEABQAEACAEAAQAFAAAGgDQAFgCACgFIAAgbQgCgEgFgDQgGgDgFAAQgEAAgEABg");
	this.shape_12.setTransform(147.2,69.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgDgDQgEgDgHAAIgFAAIgEADIgFADIgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAGgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_13.setTransform(140.05,70.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAgIgGgEQgDgDgCgEQgCgEAAgFQAAgFACgEIAFgGQADgCADgBIAIgBQAGAAAFABQAGADADADIAAgKQABgGgFgEQgFgDgGgBQgLAAgHAJIgFgHQAKgKAOAAQAFAAAFABQADABAEADQADACACAEQACAFABAFIAAAqIgLAAIAAgHQgHAJgNAAIgIgBgAgLADQgEAEAAAFQAAAGAEAEQAFAEAGAAQAEAAAFgCQAEgCADgEIAAgMQgDgEgEgBQgFgBgEAAQgGAAgFADg");
	this.shape_14.setTransform(132.85,70.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAEgEAGgEQAGgCAGAAQAGAAAGACQAGAEAEAEQAEAFACAFQABAHAAAGIAAACIgxAAQAAAFACADQABAFADADQADADAEABQAFACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgHACQgGADgHAAQgHAAgGgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_15.setTransform(122.6,70.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAhAgIAAgpQAAgGgDgEQgCgDgHAAQgEAAgFADQgFACgCAEIAAAtIgJAAIAAgpQAAgGgDgEQgDgDgGAAQgEAAgFADQgEADgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAFgDIAGgDIAGgBQAHAAAFADQADAEABAFIAEgFIAEgDIAHgDIAHgBQAIAAAEAFQAFAEAAAKIAAAsg");
	this.shape_16.setTransform(113.7,70.325);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgDAqIAAg+IAIAAIAAA+gAgDgeQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgEACgBQAAgBABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABABQABABAAAEQAAAAAAABQAAAAAAABQAAAAgBABQAAABAAAAQgBABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_17.setTransform(107,69.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_18.setTransform(103.7,69.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgEgDQgEgDgGAAIgFAAIgEADIgFADIgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAGgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_19.setTransform(94.8,70.325);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgRApQgHgDgGgGQgFgGgEgIQgDgIAAgKQAAgJADgIQAEgIAFgGQAGgGAHgEQAJgDAIAAQAKAAAHADQAIAEAHAGQAFAGADAIQADAIAAAJQAAAKgDAIQgDAIgFAGQgHAGgIADQgHAEgKAAQgIAAgJgEgAgMggQgGADgEAFQgEAEgDAHQgBAGAAAHQAAAIABAGQADAGAEAFQAEAFAGADQAGACAGAAQAHAAAHgCQAFgDAFgFQADgFADgGQACgGAAgIQAAgHgCgGQgDgHgDgEQgFgFgFgDQgHgCgHAAQgGAAgGACg");
	this.shape_20.setTransform(86.2,69.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_21.setTransform(76.4,72.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAALQAEgFAEgEQAGgDAGAAIAAAKIgDAAIgFABIgFACIgEADIgDAEIAAArg");
	this.shape_22.setTransform(73.1,70.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgDgEgDgHQgCgFAAgIQAAgFACgHQADgGADgEQAEgEAGgEQAGgCAFAAQAHAAAHACQAFAEAEAEQADAFADAFQACAHAAAGIAAACIgyAAQAAAFACADQACAFADADQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgFADgIAAQgGAAgHgDgAgIgWIgFAFQgDADgCAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_23.setTransform(66.95,70.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgEAqIAAg+IAJAAIAAA+gAgEgeQAAAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQgBgEACgBQABgBABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAABQACABAAAEQAAAAAAABQAAAAAAABQAAAAgBABQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_24.setTransform(61.85,69.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAGACQAFADAFAAQAIAAADgDQAFgDAAgFQAAgDgDgCIgHgEIgJgCIgJgDQgFgBgCgEQgDgDAAgGIABgHIAEgFQADgDAFgCQAEgBAFAAQAIAAAGADQAFACAEAEIgFAHQgCgEgFgCQgFgCgGAAQgGAAgDADQgEADAAAEQAAAEADABQADACAEABIAJACIAJAEIAHAEQADAEAAAGQAAAEgBADQgCAEgEADQgDACgEABQgEACgHAAQgGAAgHgDg");
	this.shape_25.setTransform(57.3,70.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgMAgIgGgEQgDgDgCgEQgCgEgBgFQABgFACgEIAFgGQADgCADgBIAJgBQAFAAAFABQAGADADADIAAgKQABgGgFgEQgEgDgIgBQgJAAgJAJIgEgHQAKgKAOAAQAFAAAFABQAEABADADQADACACAEQACAFAAAFIAAAqIgKAAIAAgHQgHAJgMAAIgJgBgAgLADQgEAEAAAFQAAAGAEAEQAEAEAHAAQAFAAAEgCQAEgCADgEIAAgMQgDgEgEgBQgEgBgFAAQgHAAgEADg");
	this.shape_26.setTransform(50.75,70.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAEgEAGgEQAGgCAGAAQAGAAAGACQAGAEAEAEQAEAFACAFQABAHAAAGIAAACIgxAAQAAAFACADQABAFADADQADADAFABQAEACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgHACQgGADgHAAQgHAAgGgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_27.setTransform(43.85,70.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAFACQAGADAGAAQAHAAAEgDQADgDAAgFQAAgDgCgCIgIgEIgIgCIgKgDQgEgBgDgEQgCgDAAgGIABgHIAFgFQADgDAEgCQAFgBAEAAQAIAAAFADQAGACAEAEIgEAHQgDgEgFgCQgFgCgGAAQgFAAgFADQgDADAAAEQAAAEADABQACACAFABIAIACIAKAEIAHAEQADAEAAAGQAAAEgCADQgBAEgDADQgDACgFABQgFACgGAAQgHAAgGgDg");
	this.shape_28.setTransform(33.75,70.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKApQgFgDgEgFIAAAJIgJAAIAAhVIAJAAIAAAhQAEgFAGgDQAFgDAGAAQAGAAAFACQAFADAEAEQADAFACAFQACAGAAAHQAAAIgCAGQgCAGgDAEQgEAEgFADQgFACgGAAQgGAAgGgDgAgLgJQgFADgDAEIAAAbQADAFAFACQAFADAGAAQAEAAAEgCQADgBADgDQADgEABgEQABgEAAgGQAAgFgBgEQgBgEgDgDQgDgEgDgCQgEgBgEAAQgGAAgFADg");
	this.shape_29.setTransform(27.275,69.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgMAeQgFgCgEgFQgFgEgCgGQgCgGAAgHQAAgFACgHQACgGAFgEQAEgEAFgEQAGgCAGAAQAHAAAGACQAGAEAEAEQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEAAQAFAAAEgCQAEgCACgDIAEgHQACgFAAgFIgCgIIgEgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_30.setTransform(19.6,70.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgKA2IgGgDIAEgIIADADIAGABQADAAADgDQADgCAAgGIAAhEIAJAAIAABEQAAAJgEAFQgFAFgIAAIgIgBgAAGgrQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAgBAAAAQAAgDACgCQABgBAAAAQABAAAAgBQABAAAAAAQABAAABAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAABQACACAAADQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_31.setTransform(13.4,70.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAALQAEgFAEgEQAGgDAGAAIAAAKIgDAAIgFABIgFACIgEADIgDAEIAAArg");
	this.shape_32.setTransform(7.85,70.35);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIABAHIACAFIAFACIAFABQAGAAAEgDQAGgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_33.setTransform(1.8,70.475);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgMAeQgGgCgEgFQgDgEgCgGQgDgGAAgHQAAgFADgHQACgGADgEQAEgEAGgEQAGgCAGAAQAHAAAGACQAGAEAEAEQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgHAFIgDAIIgBAIIABAKIADAHIAHAFQAEACAEAAQAFAAAEgCQAEgCADgDIADgHQACgFAAgFIgCgIIgDgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_34.setTransform(-5.55,70.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgVAsIgEgBIACgJIACABIADABQADAAACgCQADgBACgEIADgKIgag+IALAAIAUAyIAUgyIALAAIgfBKQgCAHgEADQgFADgGAAIgEAAg");
	this.shape_35.setTransform(-12.4,71.675);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgDgEgDgHQgCgFgBgIQABgFACgHQADgGADgEQAEgEAGgEQAGgCAFAAQAHAAAHACQAFAEAEAEQADAFADAFQACAHAAAGIAAACIgyAAQAAAFACADQACAFADADQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgFADgIAAQgGAAgHgDgAgIgWIgFAFQgDADgCAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_36.setTransform(-22.6,70.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AAPArIgVgcIgLAKIAAASIgKAAIAAhVIAKAAIAAA4IAgghIANAAIgcAcIAcAig");
	this.shape_37.setTransform(-29.225,69.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgMAgIgGgEQgDgDgCgEQgCgEgBgFQABgFACgEIAFgGQADgCADgBIAJgBQAFAAAFABQAGADADADIAAgKQABgGgFgEQgEgDgIgBQgJAAgJAJIgEgHQAKgKAOAAQAFAAAFABQAEABADADQADACACAEQACAFAAAFIAAAqIgKAAIAAgHQgHAJgMAAIgJgBgAgLADQgEAEAAAFQAAAGAEAEQAEAEAHAAQAFAAAEgCQAEgCADgEIAAgMQgDgEgEgBQgEgBgFAAQgHAAgEADg");
	this.shape_38.setTransform(-36.55,70.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AAhAgIAAgpQAAgGgDgEQgCgDgHAAQgFAAgEADQgFACgCAEIAAAtIgJAAIAAgpQAAgGgDgEQgCgDgHAAQgEAAgFADQgFADgCADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAEgDIAHgDIAGgBQAHAAAFADQADAEABAFIAEgFIAEgDIAGgDIAIgBQAIAAAEAFQAFAEAAAKIAAAsg");
	this.shape_39.setTransform(-45.05,70.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgNAeQgHgCgEgFIAFgHQADAEAGACQAFADAFAAQAIAAADgDQAFgDAAgFQAAgDgEgCIgGgEIgJgCIgKgDQgEgBgCgEQgEgDAAgGIACgHIAEgFQADgDAFgCQAFgBAEAAQAIAAAFADQAHACADAEIgFAHQgCgEgFgCQgFgCgGAAQgFAAgEADQgEADAAAEQAAAEADABQACACAFABIAJACIAJAEIAHAEQADAEAAAGQAAAEgBADQgCAEgEADQgCACgFABQgFACgGAAQgHAAgGgDg");
	this.shape_40.setTransform(-56.75,70.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIAAAHIADAFIAFACIAFABQAFAAAGgDQAFgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_41.setTransform(-63.25,70.475);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_42.setTransform(-72.05,69.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAEgEAGgEQAGgCAGAAQAGAAAGACQAGAEAEAEQAEAFACAFQABAHAAAGIAAACIgxAAQAAAFACADQABAFADADQADADAEABQAFACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgHACQgGADgHAAQgHAAgGgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_43.setTransform(-77.65,70.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgZArIAAhVIALAAIAABMIAoAAIAAAJg");
	this.shape_44.setTransform(-84.125,69.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-89.8,61.3,326.7,17), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape.setTransform(249.325,130.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA0IgUglIgQAAIAAAlIgXAAIAAhnIAxAAQALAAAHAEQAIAEAEAIQAFAHAAAKQAAAJgEAHQgDAFgGAEQgEAEgHABIAZAogAgTgEIAWAAQAHAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgHAAIgWAAg");
	this.shape_1.setTransform(239.9,130.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_2.setTransform(228.625,130.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_3.setTransform(218.025,130.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgWAvQgMgHgHgMQgIgMAAgQQAAgPAIgMQAHgNAMgGQANgHAPAAQALAAAJAEQAIADAGAGQAGAGAEAGIgUAKQgDgHgGgEQgHgEgIAAQgJAAgHAEQgHAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAHAFQAHAEAJAAQAIAAAHgEQAGgEADgHIAUAJQgEAHgGAGQgGAGgIADQgJAEgLAAQgPAAgNgHg");
	this.shape_4.setTransform(208.175,130.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_5.setTransform(197.275,130.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAQA0IgTglIgRAAIAAAlIgVAAIAAhnIAvAAQALAAAIAEQAIAEAFAIQADAHABAKQgBAJgDAHQgDAFgFAEQgGAEgGABIAYAogAgUgEIAXAAQAHAAAFgDQADgEABgHQgBgGgDgEQgFgEgHAAIgXAAg");
	this.shape_6.setTransform(187.1,130.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_7.setTransform(177.225,130.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_8.setTransform(166.925,130.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_9.setTransform(155.225,130.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgWAvQgMgHgHgMQgIgMAAgQQAAgPAIgMQAHgNAMgGQANgHAPAAQALAAAJAEQAIADAGAGQAGAGAEAGIgUAKQgDgHgGgEQgHgEgIAAQgJAAgHAEQgHAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAHAFQAHAEAJAAQAIAAAHgEQAGgEADgHIAUAJQgEAHgGAGQgGAGgIADQgJAEgLAAQgPAAgNgHg");
	this.shape_10.setTransform(143.925,130.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAYA0IAAgsIgwAAIAAAsIgWAAIAAhnIAWAAIAAApIAwAAIAAgpIAXAAIAABng");
	this.shape_11.setTransform(128.6,130.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_12.setTransform(118.275,130.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_13.setTransform(111.55,130.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAThKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_14.setTransform(102.2,130.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape_15.setTransform(86.175,130.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AARA0IgegqIgJAKIAAAgIgWAAIAAhnIAWAAIAAAuIAkguIAcAAIgqAxIAtA2g");
	this.shape_16.setTransform(77.075,130.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AARA0IgUglIgQAAIAAAlIgXAAIAAhnIAxAAQALAAAHAEQAIAEAEAIQAFAHAAAKQgBAJgDAHQgDAFgGAEQgEAEgHABIAZAogAgTgEIAWAAQAHAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgHAAIgWAAg");
	this.shape_17.setTransform(66.75,130.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_18.setTransform(55.475,130.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAThKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_19.setTransform(42.25,130.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgQAdQgHgEgFgIQgEgIAAgJQAAgJAEgHQAFgIAHgDQAIgFAIgBQAJABAIAFQAHADAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAEQgIAEgJABQgIgBgIgEgAgNgYQgHAFgDAGQgEAGAAAHQAAAIAEAGQADAHAHAEQAGADAHAAQAIAAAGgDQAHgEADgHQAEgGAAgIQAAgHgEgGQgDgGgHgFQgGgDgIAAQgHAAgGADgAAJATIgJgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAADADQAEADAAAFQAAAFgCACIgEADIgDABIAKAPgAgGAAIAJAAIAFgBQACgCAAgEQAAgCgCgCQgDgCgCAAIgJAAg");
	this.shape_20.setTransform(27.125,128.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_21.setTransform(18.85,130.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgVAvQgNgGgHgMQgIgMAAgRQAAgQAIgMQAHgMANgGQAMgHAPAAQAKAAAJADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgIAEQgGAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAGAFQAIAEAJAAQAHAAAFgCQAHgDADgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgMgHg");
	this.shape_22.setTransform(8.35,130.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_23.setTransform(-2.575,130.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIASBKIAUhKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_24.setTransform(-15.15,130.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_25.setTransform(-26.75,130.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_26.setTransform(-37.225,130.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-45,121.8,301.2,19.700000000000003), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_10.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_12.setTransform(369.675,146.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_13.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0)").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_21.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_22.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_13}]},39).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_24.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,49.275);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_33.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23}]}).to({state:[{t:this.shape_24}]},35).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_33}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_35.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(286.05,146.25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34}]}).to({state:[{t:this.shape_35}]},30).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_43}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,144.45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_53.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44}]}).to({state:[{t:this.shape_44}]},25).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_53}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_55.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(204.875,48.325);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_63.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54}]}).to({state:[{t:this.shape_55}]},20).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_65.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,49.275);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_74.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_64}]}).to({state:[{t:this.shape_65}]},15).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_74}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_76.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(122.675,146.25);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_84.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_75}]}).to({state:[{t:this.shape_76}]},10).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_86.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,145.75);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_85}]}).to({state:[{t:this.shape_86}]},5).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_95}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_103.setTransform(41.5,48.325);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_104.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_96}]}).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_104}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgKgDQgGgBgDgDQgDgEgBgGQAAgFADgFQACgEAGgCQAFgDAIAAQAGAAAGACQAHADAEADIgGALQgDgDgEgCQgFgCgFAAQgEAAgDACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgGADgHAAQgHAAgIgDg");
	this.shape_105.setTransform(310.8,266.225);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAHgBQADgBADgDQACgEAAgGIAAgGQgDAFgFACQgEACgFABQgHgBgGgDQgGgDgDgHQgEgGAAgJQAAgKAEgGQADgIAGgCQAGgEAHAAQAEAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGACIgKABQgHAAgHgCgAgJgXQgEAEAAAIQAAAHAEAEQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgCQgEgBgEAAQgGAAgEAEg");
	this.shape_106.setTransform(304.175,267.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEABQgDACgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_107.setTransform(297.275,266.15);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_108.setTransform(292.175,264.975);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AAMAeIgMgoIgMAoIgQAAIgSg6IAQAAIALAmIANgmIAMAAIAOAmIAKgmIARAAIgSA6g");
	this.shape_109.setTransform(285.95,266.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_110.setTransform(277.775,266.2208);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_111.setTransform(272.725,266.15);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AglApIAAhQIAgAAQAMAAAKAEQAJAFAGAKQAFAIABAMQgBAMgFAJQgGAKgJAEQgKAFgMABgAgTAaIAOAAQAIgBAGgDQAFgDADgHQADgFAAgHQAAgGgDgGQgCgGgGgDQgGgDgIgBIgOAAg");
	this.shape_112.setTransform(266.05,265.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAHgBQADgBADgDQACgEAAgGIAAgGQgDAFgFACQgEACgFABQgHgBgGgDQgGgDgDgHQgEgGAAgJQAAgKAEgGQADgIAGgCQAGgEAHAAQAEAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGACIgKABQgHAAgHgCgAgJgXQgEAEAAAIQAAAHAEAEQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgCQgEgBgEAAQgGAAgEAEg");
	this.shape_113.setTransform(254.625,267.35);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEABQgDACgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_114.setTransform(247.725,266.15);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_115.setTransform(242.675,264.975);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_116.setTransform(239.225,266.15);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgFACgHAAQgJAAgHgEgAAPgFIgCgGIgEgEQgDgCgFAAQgEAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_117.setTransform(233.4,266.225);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgFACgHAAQgJAAgHgEgAAPgFIgCgGIgEgEQgDgCgFAAQgEAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_118.setTransform(226.65,266.225);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEABQgDACgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_119.setTransform(219.725,266.15);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_120.setTransform(214.625,264.975);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAHgBQADgBADgDQACgEAAgGIAAgGQgDAFgFACQgEACgFABQgHgBgGgDQgGgDgDgHQgEgGAAgJQAAgKAEgGQADgIAGgCQAGgEAHAAQAEAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGACIgKABQgHAAgHgCgAgJgXQgEAEAAAIQAAAHAEAEQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgCQgEgBgEAAQgGAAgEAEg");
	this.shape_121.setTransform(209.375,267.35);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEABQgDACgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_122.setTransform(202.475,266.15);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgcApIAAhQIA5AAIAAAOIgnAAIAAARIAmAAIAAAPIgmAAIAAATIAnAAIAAAPg");
	this.shape_123.setTransform(195.525,265.1);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAGADIAHABQAFAAACgBQADgCAAgDQAAgCgDgCIgJgCIgJgDQgFgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAIAAAGACQAFADAFADIgHALQgCgDgFgCQgEgCgGAAQgDAAgDACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgGAAgHgDg");
	this.shape_124.setTransform(123,266.225);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAHgEAHAAQAJAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAFgBIAGgCIAEgDIAHALQgEAEgGACQgHACgHAAQgHAAgIgEgAAPgFIgCgGIgFgEQgCgCgGAAQgDAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_125.setTransform(116.8,266.225);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_126.setTransform(110.425,266.225);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_127.setTransform(105.775,264.975);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgHAeIgYg6IARAAIAOAoIAPgoIARAAIgYA6g");
	this.shape_128.setTransform(101.075,266.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_129.setTransform(96.075,266.15);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAHgEAHAAQAJAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAFgBIAGgCIAEgDIAHALQgEAEgGACQgHACgHAAQgHAAgIgEgAAPgFIgCgGIgFgEQgCgCgGAAQgDAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_130.setTransform(90.25,266.225);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgTAmQgIgDgFgGIAJgNQAEAEAHAEQAGACAIAAQAHAAAEgCQADgDAAgDQAAgEgDgCIgJgDIgKgCIgMgFQgFgCgEgEQgDgFAAgHQAAgHAEgFQADgGAIgDQAGgEAJAAQAKAAAHADQAIADAHAGIgKAMQgFgEgGgDQgGgCgGAAQgFAAgDACQgDADAAADQAAADADADIAJADIAKACQAGABAGAEQAEACAEADQADAGAAAHQAAAHgDAGQgDAGgIADQgHAEgLAAQgKAAgKgEg");
	this.shape_131.setTransform(83.15,265.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgMApIAAgsIgKAAIAAgOIAKAAIAAgCQAAgKAGgGQAFgFAIAAQAEAAAEABQAFABACADIgGAKIgDgCIgDAAQgEAAgCACQgBACAAAEIAAACIALAAIAAAOIgLAAIAAAsg");
	this.shape_132.setTransform(74.8,265.025);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgMApIAAgsIgJAAIAAgOIAJAAIAAgCQAAgKAFgGQAGgFAIAAQAFAAAEABQADABAEADIgHAKIgCgCIgEAAQgDAAgCACQgCACgBAEIAAACIANAAIAAAOIgNAAIAAAsg");
	this.shape_133.setTransform(70.8,265.025);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_134.setTransform(64.9,266.225);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_135.setTransform(58.05,266.225);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AAKApIgPgXIgHAIIAAAPIgQAAIAAhQIAQAAIAAAvIAVgaIATAAIgXAaIAYAhg");
	this.shape_136.setTransform(51.775,265.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_137.setTransform(44.625,266.2208);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgHApIAAhCIgZAAIAAgOIBAAAIAAAOIgXAAIAABCg");
	this.shape_138.setTransform(38,265.1);

	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AUFA0QgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAIgBQADgCADgDQACgDAAgGIAAgGQgDAFgFACQgEACgGAAQgHAAgGgDQgGgDgDgHQgEgHAAgJQAAgJAEgHQADgHAGgDQAGgDAHAAQAFAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGABIgLACQgHAAgHgCgAULgLQgEAEAAAHQAAAHAEAEQAEAFAHAAQAEAAAEgCQADgCACgDIAAgSQgCgDgDgCQgEgCgEAAQgHAAgEAFgAMWA0QgGgCgGgFIAHgLQAEAEAEABQAFACAGAAIAHgBQAEgCACgDQADgDAAgGIAAgGQgEAFgEACQgFACgFAAQgIAAgGgDQgFgDgEgHQgDgHAAgJQAAgJADgHQADgHAGgDQAGgDAIAAQAFAAAFACQAEACAEAEIAAgHIAPAAIAAA2QAAAIgDAGQgCAFgFADQgFADgFABIgLACQgIAAgGgCgAMcgLQgEAEAAAHQAAAHAEAEQAEAFAHAAQADAAAEgCQAEgCACgDIAAgSQgCgDgEgCQgEgCgDAAQgHAAgEAFgAFRA0QgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAIgBQADgCADgDQACgDAAgGIAAgGQgDAFgFACQgEACgGAAQgHAAgGgDQgGgDgDgHQgEgHAAgJQAAgJAEgHQADgHAGgDQAGgDAHAAQAFAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGABIgLACQgHAAgHgCgAFXgLQgEAEAAAHQAAAHAEAEQAEAFAHAAQAEAAAEgCQADgCACgDIAAgSQgCgDgDgCQgEgCgEAAQgHAAgEAFgAVJAdQgHgDgFgEIAHgLIAGAEIAHADIAHABQAFAAADgCQACgBAAgDQAAgDgDgBIgJgCIgKgDQgFgCgEgCQgDgEgBgHQAAgFADgEQADgEAFgDQAGgCAIAAQAHAAAGACQAGACAEAEIgGAKQgDgCgEgCQgFgCgFAAQgFAAgCABQgBABAAAAQgBAAAAABQAAAAgBABQAAABAAAAQAAADAEABIAJACIAKADQAFACAEADQADADAAAHQAAAGgDAEQgDAEgGADQgFACgIAAQgIAAgHgCgAP9AdQgFgCgDgEQgDgFAAgGQAAgHADgEQADgEAFgBQAEgCAFAAQAGAAAFACQAFABADADIAAgHQAAgEgEgDQgDgCgGAAIgJABIgIAGIgGgLQAFgFAHgCQAGgCAIAAQAGgBAGADQAGACAEAEQADAFAAAJIAAAlIgPAAIAAgGQgDADgFACQgFACgGAAQgFAAgEgCgAQFAFQgEADAAAEQAAAEAEACQADADAEAAQAEAAADgCQAEgBACgCIAAgIQgCgCgEgCIgHgBQgEAAgDACgAJCAbQgHgDgEgHQgEgHAAgKQAAgHAEgHQAEgHAHgEQAHgEAJAAQAIAAAHAEQAHAEADAHQAEAHAAAJIAAADIgsAAQABAGAEAEQAFADAHABIAGgBIAFgCIAFgDIAHAKQgFAEgGACQgGACgHAAQgJAAgIgEgAJggEIgCgGIgEgFQgDgCgFAAQgFAAgDACQgDACgCADIgCAGIAdAAIAAAAgAH/AbQgHgDgEgHQgEgHAAgKQAAgHAEgHQADgHAHgEQAHgEAJAAQAJAAAHAEQAGAEAEAHQADAHABAJIAAADIgsAAQABAGAEAEQAEADAIABIAFgBIAGgCIAEgDIAHAKQgEAEgHACQgGACgHAAQgJAAgHgEgAIdgEIgCgGIgFgFQgDgCgFAAQgFAAgDACQgDACgBADIgCAGIAdAAIAAAAgAoMAdQgHgDgFgEIAHgLIAGAEIAHADIAHABQAFAAADgCQACgBAAgDQAAgDgDgBIgJgCIgKgDQgFgCgEgCQgDgEgBgHQAAgFADgEQADgEAFgDQAGgCAIAAQAHAAAGACQAGACAEAEIgGAKQgDgCgEgCQgFgCgFAAQgFAAgCABQgBABAAAAQgBAAAAABQAAAAgBABQAAABAAAAQAAADAEABIAJACIAKADQAFACAEADQADADAAAHQAAAGgDAEQgDAEgGADQgFACgIAAQgIAAgHgCgApLAbQgHgDgEgHQgEgHAAgKQAAgHAEgHQAEgHAHgEQAHgEAJAAQAIAAAHAEQAHAEADAHQAEAHAAAJIAAADIgsAAQABAGAEAEQAFADAHABIAGgBIAFgCIAFgDIAHAKQgFAEgGACQgGACgHAAQgJAAgIgEgAotgEIgCgGIgEgFQgDgCgFAAQgFAAgDACQgDACgCADIgCAGIAdAAIAAAAgAqIAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgDQAHgEAJAAQAGAAAFABIAIAEIAFAFIgLAKQgCgEgDgBQgDgCgEAAQgHAAgEAFQgFAFAAAGQAAAIAFAFQAEAEAHAAQAEAAADgBQADgCACgDIALAJIgFAGIgIAEQgFABgGAAQgJAAgHgEgAtUAbQgHgDgEgHQgEgHAAgKQAAgHAEgHQADgHAHgEQAHgEAJAAQAJAAAHAEQAGAEAEAHQADAHABAJIAAADIgsAAQABAGAEAEQAEADAIABIAFgBIAGgCIAEgDIAHAKQgEAEgHACQgGACgHAAQgJAAgHgEgAs2gEIgCgGIgFgFQgDgCgFAAQgFAAgDACQgDACgBADIgCAGIAdAAIAAAAgAugAcQgIgEgGgGIAKgNQAEAEAHAEQAGADAJAAQAHAAADgDQAEgDAAgDQgBgEgDgBIgJgDIgLgCIgLgEQgFgDgEgFQgDgEAAgIQAAgHAEgFQADgGAHgDQAHgEAKAAQAJAAAIADQAIADAGAGIgJANQgFgFgGgCQgHgCgGAAQgFAAgDACQgDACAAAEQAAADADACIAJADIALACQAGACAFADQAFACAEAFQADAFAAAGQAAAIgDAFQgEAGgHAEQgHADgLAAQgMAAgJgDgAxTAbQgHgEgEgHQgEgHAAgJQAAgHAEgHQAEgHAHgEQAHgEAJAAQAKAAAHAEQAHAEAEAHQADAHAAAHQAAAJgDAHQgEAHgHAEQgHAEgKAAQgJAAgHgEgAxLgNQgDACgCAEQgCAEAAADQAAAFACAEQACAEADACQADACAFAAQAFAAADgCQAEgCACgEQABgEAAgFQAAgDgBgEQgCgEgEgCQgDgDgFAAQgFAAgDADgAyWAbQgHgDgEgHQgEgHAAgKQAAgHAEgHQADgHAHgEQAHgEAJAAQAJAAAHAEQAGAEAEAHQADAHABAJIAAADIgsAAQABAGAEAEQAEADAIABIAFgBIAGgCIAEgDIAHAKQgEAEgHACQgGACgHAAQgJAAgHgEgAx4gEIgCgGIgFgFQgDgCgFAAQgFAAgDACQgDACgBADIgCAGIAdAAIAAAAgA0eAdQgEgCgDgEQgEgFAAgGQAAgHAEgEQADgEAEgBQAFgCAFAAQAGAAAEACQAFABADADIAAgHQAAgEgDgDQgEgCgGAAIgJABIgIAGIgGgLQAGgFAGgCQAHgCAHAAQAHgBAGADQAGACADAEQAEAFAAAJIAAAlIgQAAIAAgGQgDADgFACQgFACgFAAQgFAAgFgCgA0WAFQgDADAAAEQAAAEADACQADADAFAAQAEAAADgCQADgBACgCIAAgIQgCgCgDgCIgHgBQgFAAgDACgATcAeIAAgjQAAgGgDgCQgDgDgFAAQgEAAgEACQgDACgCADIAAAnIgQAAIAAg6IAQAAIAAAHIAFgEIAHgDIAJgBQAJAAAFAFQAFAFAAAIIAAApgASVAeIAAg6IAQAAIAAA6gARrAeIgMgnIgNAnIgQAAIgSg6IAQAAIALAmIANgmIANAAIANAmIALgmIARAAIgSA6gAPJAeIAAg6IAQAAIAAAIQADgEAFgDQAFgCAGAAIAAAPIgCgBIgDAAIgFABIgFADIgEADIAAAmgANyAeIAAhQIAgAAQANAAAKAFQAJAFAGAJQAFAJAAAMQAAALgFAKQgGAJgJAFQgKAFgNAAgAOEAPIAOAAQAIgBAGgDQAGgDADgGQADgFAAgHQAAgHgDgGQgDgGgGgDQgFgDgJAAIgOAAgALtAeIAAgjQAAgGgDgCQgDgDgFAAQgFAAgDACQgEACgCADIAAAnIgPAAIAAg6IAPAAIAAAHIAFgEIAHgDIAJgBQAKAAAEAFQAFAFAAAIIAAApgAKmAeIAAg6IAQAAIAAA6gAJ6AeIAAg6IAQAAIAAAIQADgEAFgDQAFgCAGAAIAAAPIgCgBIgDAAIgFABIgFADIgEADIAAAmgAHVAeIAAgjQAAgGgDgCQgDgDgFAAQgFAAgDACQgEACgCADIAAAnIgPAAIAAg6IAPAAIAAAHIAFgEIAHgDIAJgBQAKAAAEAFQAFAFAAAIIAAApgAGOAeIAAg6IAPAAIAAA6gAEoAeIAAgjQAAgGgDgCQgDgDgFAAQgEAAgEACQgDACgCADIAAAnIgQAAIAAg6IAQAAIAAAHIAFgEIAHgDIAJgBQAJAAAFAFQAFAFAAAIIAAApgAC6AeIAAhQIA5AAIAAAPIgoAAIAAARIAnAAIAAAPIgnAAIAAASIAoAAIAAAPgAqyAeIAAg6IAQAAIAAA6gArhAeIgYg6IARAAIAPAoIAPgoIARAAIgYA6gAscAeIAAg6IAPAAIAAAIQAEgEAFgDQAFgCAFAAIAAAPIgCgBIgCAAIgGABIgFADIgEADIAAAmgAvtAeIAAgtIgJAAIAAgNIAJAAIAAgCQABgKAFgGQAFgGAJAAQAFAAAEACQAEABADADIgGAJIgDgBIgEgBQgDAAgCACQgCACAAAFIAAACIAMAAIAAANIgMAAIAAAtgAwVAeIAAgtIgJAAIAAgNIAJAAIAAgCQABgKAFgGQAFgGAJAAQAFAAAEACQAEABADADIgGAJIgDgBIgEgBQgDAAgCACQgCACAAAFIAAACIAMAAIAAANIgMAAIAAAtgAy8AeIgQgXIgHAIIAAAPIgQAAIAAhQIAQAAIAAAwIAWgaIATAAIgXAbIAYAfgA1YAeIAAhBIgYAAIAAgPIBBAAIAAAPIgYAAIAABBgASXglQgDgDAAgEQAAgEADgCQACgDAEAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgEgBgCgCgAKoglQgDgDAAgEQAAgEADgCQACgDAEAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgEgBgCgCgAGPglQgCgDgBgEQABgEACgCQADgDAEAAQAEAAACADQADACAAAEQAAAEgDADQgCACgEABQgEgBgDgCgAqwglQgDgDAAgEQAAgEADgCQACgDAEAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgEgBgCgCg");
	this.shape_139.setTransform(174.075,266.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105}]}).to({state:[{t:this.shape_139},{t:this.instance}]},86).to({state:[]},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,273.7);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,280), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape.setTransform(185.275,25.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_1.setTransform(181.025,26.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgJAXQgEgCgDgDQgDgDgCgFQgCgFAAgFQAAgEACgFQACgEADgEQADgDAEgCQAFgCAEAAQAGAAAEACQAFACADADIAEAIQACAFAAAEQAAAFgCAFQgCAFgCADQgDADgFACQgEACgGAAQgEAAgFgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_2.setTransform(176.25,26.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAPAhIgPg1IgOA1IgJAAIgThBIAJAAIAPA2IAPg2IAGAAIAQA2IAOg2IAKAAIgTBBg");
	this.shape_3.setTransform(168.975,25.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AANAZIAAgfQAAgGgEgDQgDgCgEAAIgEABIgDABIgEADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIADgCIAFgDIAEgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_4.setTransform(159.2,26.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_5.setTransform(153.425,27.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_6.setTransform(149.575,25.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDIAEgEQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_7.setTransform(146.075,26.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgDgDgDgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACAEADQACAEACAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgDgFIgFgEQgDgBgDAAQgEAAgCABg");
	this.shape_8.setTransform(140.95,26.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgcAhIAAhBIAXAAQAHAAAGACQAHADAEAEQAEAFADAGQACAGAAAGQAAAHgCAGQgDAGgEAFQgEAEgHADQgGACgHAAgAgUAaIAPAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgPAAg");
	this.shape_9.setTransform(134.8,25.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgIAYQgEgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAEAAQAGAAAFACQADACADADQAEAEABAFQABAEAAAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgGAAQgFAAgFgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgCgBgFAAQgDAAgCABg");
	this.shape_10.setTransform(148.4,16.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgDgDgDgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACAEADQACAEACAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_11.setTransform(142.75,16.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_12.setTransform(138.575,16.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_13.setTransform(134.125,15.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_14.setTransform(266.725,27.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AANAZIAAgfQAAgGgEgDQgDgCgEAAIgEABIgDABIgEADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIACgCIAFgDIAEgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_15.setTransform(261.25,26.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(257.375,25.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgEABgCADIgDAGIgBAGIABAIIADAFQACADAEABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_17.setTransform(253.85,26.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(250.175,25.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(247.675,26.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(243.125,25.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgJAgIgHgFIgEgIQgCgEAAgGQAAgGACgEQACgFACgDQADgDAEgCQAEgCAFAAQAEAAAEACQAEADADAEIAAgaIAIAAIAABCIgIAAIAAgHQgCADgFADQgEACgEAAQgFAAgEgCgAgFgIIgFAEIgDAFIgBAIIABAHIADAGIAFAEQADABADAAQAEAAAEgCQAEgCACgDIAAgVQgCgDgEgDQgEgCgEAAQgDAAgDABg");
	this.shape_21.setTransform(265.225,15.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACADADQAEAEABAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_22.setTransform(259.65,16.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_23.setTransform(255.475,16.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEgBgGQABgEACgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgEAAQgCAAgEABg");
	this.shape_24.setTransform(250.7,16.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_25.setTransform(246.775,15.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAhIAAg6IgWAAIAAgHIAyAAIAAAHIgVAAIAAA6g");
	this.shape_26.setTransform(242.8,15.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgQAiIgDgBIABgGIACAAIADABIAEgBIADgFIADgHIgUgwIAIAAIAPAnIAQgnIAIAAIgYA5QgBAFgEADQgDACgFAAIgDAAg");
	this.shape_27.setTransform(69.55,27.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_28.setTransform(65.725,26.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgFAEIgCAFIgCAGIAgAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgDABg");
	this.shape_29.setTransform(60.95,26.125);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgDAYIgUgvIAIAAIAPAnIAQgnIAIAAIgUAvg");
	this.shape_30.setTransform(55.7,26.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(52.125,25.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_32.setTransform(49.875,25.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACADADQAEAEABAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_33.setTransform(45.9,26.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgcAhIAAhBIAXAAQAHAAAGACQAGADAFAEQAEAFADAGQACAGAAAGQAAAHgCAGQgDAGgEAFQgFAEgGADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgFgCgFAAIgOAAg");
	this.shape_34.setTransform(39.75,25.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgIAYQgEgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAEAAQAGAAAFACQADACADADQAEAEABAFQABAEAAAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgGAAQgFAAgFgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgCgBgFAAQgDAAgCABg");
	this.shape_35.setTransform(67.4,16.125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_36.setTransform(63.475,15.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAgQgFgDgCgDIAAAHIgIAAIAAhCIAIAAIAAAaQADgEAEgDQAEgCAEAAQAFAAAEACQAEACADADQACADACAFQACAEAAAGQAAAGgCAEIgEAIIgHAFQgEACgFAAQgEAAgEgCgAgIgHQgEADgCADIAAAVQACADAEACQAEACAEAAQADAAADgBIAFgEIADgGIABgHIgBgIIgDgFIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_37.setTransform(59.625,15.275);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_38.setTransform(55.475,15.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AAPAYIgPgUIgNAUIgJAAIASgYIgRgXIAJAAIAMASIANgSIAJAAIgRAXIASAYg");
	this.shape_39.setTransform(51.925,16.125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgDgDgDgFQgCgEAAgGQAAgEACgFIAGgIQACgDAFgCQAFgCAEAAQAFAAAFACQAEACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_40.setTransform(46.65,16.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_41.setTransform(42.725,15.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_42.setTransform(39.075,15.225);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(113.35,21.45,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(222.15,21.85,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(16.65,21.85,0.515,0.515,0,0,0,0.1,0.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_43.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-8.1,8.7,288.6,30.599999999999998), null);


// stage content:
(lib._336x280_Contractors = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_766 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(766).call(this.frame_766).wait(122));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape.setTransform(168,140);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_1.setTransform(168,140);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_2.setTransform(168,140);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_3.setTransform(168,140);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_4.setTransform(168,140);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_5.setTransform(168,140);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_6.setTransform(168,140);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_7.setTransform(168,140);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_8.setTransform(168,140);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(8));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(167.95,17.9,0.7999,0.7999);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(888));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-137.8,-29.5,-71.9,8.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_9.setTransform(167.825,250.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-129.1,-26.5,-63.3,11.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_10.setTransform(167.825,250.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-120.5,-23.4,-54.6,14.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_11.setTransform(167.825,250.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-111.8,-20.4,-46,17.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_12.setTransform(167.825,250.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-103.2,-17.4,-37.3,20.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_13.setTransform(167.825,250.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-94.5,-14.4,-28.7,23.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_14.setTransform(167.825,250.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.8,-11.4,-20,26.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_15.setTransform(167.825,250.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-77.2,-8.4,-11.3,29.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_16.setTransform(167.825,250.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.5,-5.4,-2.7,32.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_17.setTransform(167.825,250.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-59.9,-2.4,6,35.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_18.setTransform(167.825,250.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.2,0.7,14.6,38.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_19.setTransform(167.825,250.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-42.6,3.7,23.3,41.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_20.setTransform(167.825,250.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-33.9,6.7,31.9,44.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_21.setTransform(167.825,250.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.3,9.7,40.5,47.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_22.setTransform(167.825,250.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,12.7,49.2,50.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_23.setTransform(167.825,250.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-8,15.8,57.8,53.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_24.setTransform(167.825,250.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,18.8,66.5,56.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_25.setTransform(167.825,250.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],9.3,21.8,75.1,59.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_26.setTransform(167.825,250.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],18,24.8,83.8,62.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_27.setTransform(167.825,250.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.6,27.8,92.5,65.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_28.setTransform(167.825,250.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],35.3,30.8,101.1,68.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_29.setTransform(167.825,250.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],43.9,33.9,109.8,71.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_30.setTransform(167.825,250.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],52.6,36.9,118.4,74.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_31.setTransform(167.825,250.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],61.2,39.9,127.1,77.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_32.setTransform(167.825,250.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],69.9,42.9,135.7,80.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_33.setTransform(167.825,250.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},271).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).wait(234));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(888));

	// t11
	this.instance_2 = new lib.t11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(168,117.25,1,1,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(888));

	// btn
	this.instance_3 = new lib.btn();
	this.instance_3.parent = this;
	this.instance_3.setTransform(168,213.4,1,1,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(123).to({y:215.6},0).wait(173).to({y:213.4},0).wait(123).to({y:215.6},0).wait(173).to({y:213.4},0).wait(123).to({y:215.6},0).wait(173));

	// Слой_5
	this.instance_4 = new lib.icons();
	this.instance_4.parent = this;
	this.instance_4.setTransform(168.8,170.55,1.12,1.12,0,0,0,136.4,18.6);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(26).to({_off:false},0).to({alpha:1},6).to({_off:true},91).wait(199).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(199).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(173));

	// Слой_14
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("A6PJ/IAAz8MA0fAAAIAAT8g");
	this.shape_34.setTransform(168,252.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("A6PJ+IAAz8MA0fAAAIAAT8g");
	this.shape_35.setTransform(168,243.25);
	this.shape_35._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(20).to({y:247.7},0).to({_off:true},1).wait(2).to({_off:false,y:234.3},0).wait(1).to({y:229.8},0).wait(1).to({y:225.3},0).to({_off:true},1).wait(97).to({_off:false,y:252.2},0).wait(193).to({y:247.7},0).to({_off:true},1).wait(2).to({_off:false,y:234.3},0).wait(1).to({y:229.8},0).wait(1).to({y:225.3},0).to({_off:true},1).wait(97).to({_off:false,y:252.2},0).wait(193).to({y:247.7},0).to({_off:true},1).wait(2).to({_off:false,y:234.3},0).wait(1).to({y:229.8},0).wait(1).to({y:225.3},0).to({_off:true},1).wait(97).to({_off:false,y:252.2},0).wait(173));
	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(21).to({_off:false},0).wait(1).to({y:238.75},0).to({_off:true},1).wait(3).to({_off:false,y:220.85},0).wait(1).to({y:216.35},0).to({_off:true},96).wait(194).to({_off:false,y:243.25},0).wait(1).to({y:238.75},0).to({_off:true},1).wait(3).to({_off:false,y:220.85},0).wait(1).to({y:216.35},0).to({_off:true},96).wait(194).to({_off:false,y:243.25},0).wait(1).to({y:238.75},0).to({_off:true},1).wait(3).to({_off:false,y:220.85},0).wait(1).to({y:216.35},0).to({_off:true},96).wait(173));

	// Слой_2
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAHgMIAHAEIAIAEIAHABQAGAAACgCQADgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgDgDQgEgEgBgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAJAAAGACQAGADAFAEIgGAMQgEgDgEgDQgGgBgGgBIgGACQgDACAAADQAAACAEABIAJADIALADQAGACAEAEQAEAEAAAHQAAAGgEAFQgDAFgGADQgHACgJAAQgHAAgIgCg");
	this.shape_36.setTransform(318.95,175.05);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_37.setTransform(311.575,176.3063);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_38.setTransform(303.85,174.975);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_39.setTransform(298.175,173.675);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAOAhIgOgsIgNAsIgSAAIgUhBIASAAIAMAsIAOgsIAOAAIAPAsIAMgsIASAAIgUBBg");
	this.shape_40.setTransform(291.15,175.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgRAgQgFgCgEgFQgEgFAAgHQAAgIAEgEQAEgFAFgBQAFgCAFAAQAHAAAEACQAGACADADIAAgIQAAgFgEgCQgEgEgFAAQgGAAgEADQgFABgEAEIgHgMQAGgFAHgDQAIgCAGAAQAJAAAGACQAGACAFAGQADAFAAAJIAAAqIgRAAIAAgHQgDAEgGACQgEACgHAAQgFAAgFgCgAgIAFQgEADAAAFQAAAFAEADQADACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgCQgDgBgEAAQgFAAgDACg");
	this.shape_41.setTransform(282,175.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_42.setTransform(276.375,174.975);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgpAuIAAhaIAkAAQANAAALAFQALAGAGAKQAGAKAAANQAAAOgGAKQgGAKgLAGQgLAGgNAAgAgVAdIAQAAQAIAAAGgFQAHgDADgHQADgGABgIQgBgHgDgHQgDgGgHgDQgFgEgJgBIgQAAg");
	this.shape_43.setTransform(268.9,173.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_44.setTransform(256.075,176.3063);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgGAAQgEAAgEACQgDACgDADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAGAGQAFAGAAAJIAAAug");
	this.shape_45.setTransform(248.35,174.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_46.setTransform(242.675,173.675);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_47.setTransform(238.825,174.975);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIAAgLQAAgJAEgHQAEgIAIgFQAIgEAJAAQAJgBAIAFQAHAEAFAJQADAIAAAKIAAADIgvAAQABAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgGAFgHACQgHACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgBAEAAADIAfAAIAAAAg");
	this.shape_48.setTransform(232.3,175.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAIgEAJAAQAKgBAHAFQAHAEAEAJQAEAIAAAKIAAADIgwAAQACAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgFAFgHACQgIACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgBAEgBADIAgAAIAAAAg");
	this.shape_49.setTransform(224.75,175.05);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_50.setTransform(217,174.975);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_51.setTransform(211.325,173.675);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_52.setTransform(205.375,176.3063);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_53.setTransform(197.65,174.975);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgfAuIAAhaIA/AAIAAAQIgsAAIAAAUIArAAIAAAPIgrAAIAAAWIAsAAIAAARg");
	this.shape_54.setTransform(189.875,173.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIAEIAIABQAGAAACgCQADgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgDgDQgFgEAAgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAIAAAHACQAHADAEAEIgHAMQgCgDgGgDQgFgBgGgBIgHACQgCACAAADQAAACAEABIAJADIALADQAGACAEAEQAEAEAAAHQAAAGgEAFQgCAFgHADQgGACgKAAQgHAAgIgCg");
	this.shape_55.setTransform(133.35,175.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAHgEAJAAQALgBAHAFQAHAEAEAJQAFAIAAAKIAAADIgxAAQABAHAFAEQAFAEAHABIAGgBIAHgDIAFgDIAHALQgFAFgGACQgHACgJAAQgJAAgIgDgAARgFIgCgHQgCgDgEgCQgDgCgGgBQgEABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_56.setTransform(126.4,175.05);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgNAeQgIgEgEgIQgFgIABgKQgBgJAFgIQAEgIAIgEQAIgFAKABQAGAAAFACQAFABAEACIAFAHIgLAKQgDgEgDgBQgEgCgEAAQgHAAgFAFQgFAFAAAIQAAAJAFAFQAFAFAHAAQAEAAAEgCQADgBADgEIALALIgFAGIgJAEQgFABgGAAQgKABgIgFg");
	this.shape_57.setTransform(119.3,175.05);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_58.setTransform(114.075,173.675);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgIAhIgbhBIATAAIAQAtIARgtIATAAIgbBBg");
	this.shape_59.setTransform(108.85,175.05);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_60.setTransform(103.175,174.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgFgIABgLQgBgJAFgHQAEgIAIgFQAIgEAIAAQAKgBAIAFQAHAEAFAJQADAIAAAKIAAADIgvAAQAAAHAFAEQAFAEAIABIAFgBIAGgDIAGgDIAIALQgGAFgHACQgGACgIAAQgKAAgHgDgAARgFIgCgHQgCgDgEgCQgDgCgGgBQgEABgEACQgDACgBADQgCAEAAADIAfAAIAAAAg");
	this.shape_61.setTransform(96.65,175.05);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgHIALgOQAFAEAHAFQAIADAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgDgGAAIgLgEIgNgEQgGgDgEgFQgDgEgBgJQABgIAEgGQAEgGAIgEQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgDgGAAQgGAAgDADQgEACAAAEQABAEADACQAEACAGABIALAEQAHABAGADQAGADAEAEQADAFABAJQAAAIgEAHQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_62.setTransform(88.725,173.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgNAuIAAgxIgLAAIAAgQIALAAIAAgCQAAgMAGgGQAGgGAJAAQAFAAAEABQAFACADADIgHALIgDgCIgEgBQgDAAgDACQgCADAAAFIAAACIANAAIAAAQIgNAAIAAAxg");
	this.shape_63.setTransform(79.375,173.725);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgNAuIAAgxIgLAAIAAgQIALAAIAAgCQAAgMAGgGQAGgGAJAAQAFAAAEABQAFACADADIgHALIgDgCIgEgBQgDAAgDACQgCADAAAFIAAACIANAAIAAAQIgNAAIAAAxg");
	this.shape_64.setTransform(74.875,173.725);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_65.setTransform(68.275,175.05);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAHgEAKAAQAKgBAHAFQAHAEAEAJQAEAIABAKIAAADIgxAAQACAHAEAEQAFAEAHABIAHgBIAGgDIAFgDIAIALQgFAFgHACQgHACgJAAQgIAAgIgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_66.setTransform(60.6,175.05);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AALAuIgRgaIgIAJIAAARIgRAAIAAhaIARAAIAAA1IAYgdIAVAAIgaAeIAbAkg");
	this.shape_67.setTransform(53.575,173.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgEgFABgHQgBgIAEgEQAEgFAEgBQAGgCAFAAQAHAAAFACQAFACADADIAAgIQAAgFgEgCQgEgEgFAAQgFAAgFADQgFABgEAEIgHgMQAGgFAIgDQAHgCAGAAQAJAAAGACQAHACADAGQAEAFABAJIAAAqIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAFQgDADAAAFQAAAFADADQAEACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgCQgEgBgDAAQgFAAgEACg");
	this.shape_68.setTransform(45.6,175.05);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgJAuIAAhKIgaAAIAAgQIBHAAIAAAQIgaAAIAABKg");
	this.shape_69.setTransform(38.125,173.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgEIAHgNIAHAFIAIACIAHACQAGAAADgCQACgCAAgDQAAgDgEgCIgJgCIgLgDQgGgCgDgDQgEgEgBgIQAAgGAEgEQACgFAHgDQAFgDAIAAQAJABAGACQAGADAFADIgGANQgEgDgEgCQgGgCgGgBIgGACQgDACAAACQAAAEAEABIAJACIALADQAGACAEADQAEAFAAAHQAAAGgEAGQgDAEgGADQgHACgIABQgIgBgIgCg");
	this.shape_70.setTransform(262.35,174.55);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQABADABACQAAABABAAQAAAAABABQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgJABQgHAAgFgFg");
	this.shape_71.setTransform(256.85,173.725);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AAPAtIgagkIgHAJIAAAbIgUAAIAAhaIAUAAIAAApIAfgpIAXAAIgkArIAnAvg");
	this.shape_72.setTransform(247.2,173.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgFgHABgLQgBgIAFgJQAEgHAIgFQAIgEAIgBQAKAAAIAFQAHAFAFAIQADAIABAJIAAAFIgwAAQAAAGAFAEQAFAFAIAAIAFgCIAGgCIAGgDIAHALQgEAFgIADQgGABgJAAQgIAAgJgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgEACQgDACgBADQgCAEAAADIAfAAIAAAAg");
	this.shape_73.setTransform(300.4,160.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_74.setTransform(294.825,159.65);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AghAuIAAhaIASAAIAAAJQADgFAGgDQAFgCAFAAQAJAAAGAEQAHAEADAIQAFAHAAALQAAALgFAHQgDAIgHAEQgGAEgJAAQgEAAgGgDQgFgCgEgFIAAAhgAgJgcQgDACgDAEIAAAWQACADAEACQAEACAFAAQAGAAAFgFQAEgEABgJQgBgIgEgFQgFgGgGAAQgFAAgEACg");
	this.shape_75.setTransform(289.4,162.075);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AAhAiIAAgpQgBgFgCgCQgCgDgFAAQgFAAgEACQgEACgBADIAAAsIgRAAIAAgpQAAgFgCgCQgCgDgGAAQgEAAgEACQgDACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAEgEQAEgCAEgCQAFgCAEAAQAIAAAEADQAEAEABAFIAGgGIAIgEQAFgCAFAAQAIAAAFAFQAGAFAAAKIAAAvg");
	this.shape_76.setTransform(279.35,160.825);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgRAgQgGgCgDgFQgDgFgBgHQABgIADgFQADgDAGgCQAFgDAGAAQAGAAAEADQAGACADADIAAgIQAAgFgEgDQgDgDgHAAQgEAAgGACQgEACgEAEIgHgMQAGgGAHgCQAIgDAHAAQAHAAAHADQAGACAFAGQADAFAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEABgGAAQgGABgFgDgAgIAGQgEADAAAEQAAAFAEADQADACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_77.setTransform(269.65,160.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgHIALgPQAFAGAHADQAIAEAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgCgGgBIgLgEIgNgEQgGgDgEgEQgDgGgBgIQABgHAEgHQAEgHAIgDQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgCgGgBQgGABgDACQgEACAAAEQABAEADACQAEACAGABIALADQAHACAGADQAGADAEAFQADAEABAJQAAAJgEAGQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_78.setTransform(261.975,159.65);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_79.setTransform(252.725,159.65);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgEgFABgHQgBgIAEgFQAEgDAEgCQAGgDAFAAQAHAAAFADQAFACADADIAAgIQAAgFgEgDQgEgDgFAAQgFAAgFACQgFACgEAEIgHgMQAGgGAIgCQAHgDAGAAQAJAAAGADQAHACADAGQAEAFAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEABgHAAQgFABgGgDgAgJAGQgDADAAAEQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_80.setTransform(247.1,160.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgFgHAAgLQAAgIAFgJQAEgHAIgFQAHgEAJgBQAKAAAIAFQAHAFAEAIQAFAIAAAJIAAAFIgxAAQACAGAEAEQAFAFAIAAIAFgCIAHgCIAFgDIAHALQgEAFgIADQgHABgIAAQgIAAgJgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgEACQgDACgBADQgCAEgBADIAgAAIAAAAg");
	this.shape_81.setTransform(231.45,160.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQABADABACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgJABQgHAAgFgFg");
	this.shape_82.setTransform(225.35,160.075);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgRAgQgFgCgEgFQgDgFAAgHQAAgIADgFQAEgDAFgCQAFgDAFAAQAHAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgGAAgEACQgFACgEAEIgHgMQAGgGAHgCQAIgDAGAAQAJAAAGADQAHACAEAGQADAFAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEABgHAAQgFABgFgDgAgIAGQgEADAAAEQAAAFAEADQADACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_83.setTransform(219.1,160.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAeAtIAAhAIgaBAIgHAAIgahAIAABAIgTAAIAAhaIAbAAIAVA5IAWg5IAbAAIAABag");
	this.shape_84.setTransform(209.825,159.65);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIADIAIACQAGAAACgCQADgCAAgDQAAgDgEgCIgIgCIgMgDQgGgCgDgDQgFgEAAgHQAAgHADgEQAEgEAFgDQAHgDAHgBQAJAAAGADQAHACAEAEIgHANQgCgEgGgCQgFgCgGAAIgHACQgCACAAADQAAACAEABIAIADIAMADQAGACAEADQAEAFAAAIQAAAGgDAEQgDAFgHADQgGADgKgBQgIABgHgDg");
	this.shape_85.setTransform(111.2,175.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AANAtIAAgnQAAgGgCgDQgEgCgFAAQgFAAgDACQgFACgCACIAAAsIgRAAIAAhaIARAAIAAAiIAGgEIAHgFQAEgBAGAAQAKAAAGAGQAFAFAAAKIAAAtg");
	this.shape_86.setTransform(104.05,174.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQgBADACACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgJABQgIAAgEgFg");
	this.shape_87.setTransform(97.8,174.925);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AANAiIAAgnQABgHgEgDQgDgCgFAAQgEAAgEACQgEACgDADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAGAGQAFAGAAAJIAAAug");
	this.shape_88.setTransform(91.55,175.675);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgFAKgBQALABAIAFQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_89.setTransform(83.675,175.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AAeAtIAAhAIgaBAIgHAAIgahAIAABAIgTAAIAAhaIAbAAIAVA5IAWg5IAbAAIAABag");
	this.shape_90.setTransform(73.925,174.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgTApQgJgHgEgLQgEgKAAgNQAAgMAFgLQAFgLAJgFQAKgHAMAAQAJABAGABQAHAEAFADIgJAQQgDgEgEgCQgFgBgGgBQgFABgGADQgFADgDAGQgCAGAAAHIAAABIAAABQADgFAGgDQAGgDAHAAQAIAAAHACQAHAEAFAGQAEAGAAAKQAAAJgEAHQgFAHgIAEQgHAEgLAAQgNAAgIgGgAgIAFQgFADgDAEQAAAEACAEQACAEAEADQAEADAFAAQAFAAAEgCQAEgCABgDQACgDAAgEQAAgEgCgDQgCgDgEgBIgIgCQgFAAgEACg");
	this.shape_91.setTransform(60.525,174.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgIAAgKQAAgJAEgHQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAHAAAJQAAAKgEAIQgFAHgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAFQgCAEAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_92.setTransform(128.125,162.1);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgSAqQgHgEgDgIQgFgHAAgLQAAgLAFgHQADgHAHgFQAGgEAIAAQAFAAAGADQAFACAEAFIAAghIASAAIAABaIgSAAIAAgJQgEAFgFADQgFACgGAAQgIAAgGgEgAgKgBQgEAEgBAJQABAIAEAGQAFAFAGAAQAFAAADgCQAEgCADgEIAAgXQgDgCgEgCQgDgCgFAAQgGAAgFAFg");
	this.shape_93.setTransform(112,160.925);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgIAuIAAhaIARAAIAABag");
	this.shape_94.setTransform(106.475,160.85);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgPAeQgJgEgEgHQgEgJAAgKQAAgJAEgHQAEgIAIgFQAIgEAJAAQAKgBAHAFQAHAFAEAIQAEAIAAAKIAAADIgwAAQACAHAEAEQAFAEAHABIAHgBIAFgCIAGgEIAIALQgFAFgHACQgIACgHAAQgKAAgHgEgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgBAEgBADIAgAAIAAAAg");
	this.shape_95.setTransform(101,162.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AAVAuIAAgnIgpAAIAAAnIgUAAIAAhaIAUAAIAAAkIApAAIAAgkIAUAAIAABag");
	this.shape_96.setTransform(92.2,160.85);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAHgMIAGAEIAJAEIAHABQAGAAADgCQACgCAAgDQAAgDgEgBIgIgDIgMgDQgGgCgEgDQgEgEAAgIQAAgFADgFQADgFAGgDQAHgCAHAAQAJgBAGADQAGACAGAFIgIAMQgDgEgFgBQgEgDgHAAIgGACQgDACAAACQAAADAEABIAIADIAMADQAGACAEAEQAEAEAAAHQAAAHgDAEQgEAFgGADQgGACgJAAQgJAAgHgCg");
	this.shape_97.setTransform(80.4,162.1);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AAOAiIAAgnQgBgHgDgDQgDgCgFAAQgFAAgDACQgFACgBADIAAAsIgSAAIAAhBIASAAIAAAIIAFgEIAHgEQAEgCAFAAQAMAAAEAGQAGAGAAAJIAAAug");
	this.shape_98.setTransform(73.25,162.025);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIAEIAIABQAGAAACgCQADgCAAgDQAAgDgEgBIgIgDIgMgDQgGgCgDgDQgFgEAAgIQAAgFADgFQAEgFAFgDQAHgCAHAAQAIgBAHADQAHACAEAFIgHAMQgCgEgGgBQgFgDgGAAIgHACQgCACAAACQAAADAEABIAIADIAMADQAGACAEAEQAEAEAAAHQAAAHgDAEQgDAFgHADQgGACgKAAQgIAAgHgCg");
	this.shape_99.setTransform(54.5,162.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgQAeQgIgEgEgHQgEgJgBgKQABgJAEgHQAEgIAIgFQAHgEAKAAQAKgBAHAFQAHAFAEAIQAEAIABAKIAAADIgxAAQACAHAEAEQAFAEAHABIAHgBIAGgCIAFgEIAHALQgEAFgHACQgHACgIAAQgJAAgJgEgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_100.setTransform(47.55,162.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgpAuIAAhaIAkAAQANAAALAFQALAGAGAKQAGAKAAANQAAAOgGAKQgGAKgLAGQgLAFgNABgAgVAdIAQAAQAIAAAGgFQAHgDADgHQADgGABgIQgBgHgDgHQgDgGgHgEQgFgDgJAAIgQAAg");
	this.shape_101.setTransform(39.05,160.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63,p:{x:79.375,y:173.725}},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:211.325,y:173.675}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:238.825,y:174.975}},{t:this.shape_46,p:{x:242.675,y:173.675}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:276.375,y:174.975}},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:298.175,y:173.675}},{t:this.shape_38},{t:this.shape_37,p:{x:311.575,y:176.3063}},{t:this.shape_36}]},123).to({state:[{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_51,p:{x:59.575,y:160.725}},{t:this.shape_37,p:{x:65.075,y:163.3563}},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_63,p:{x:122.375,y:160.775}},{t:this.shape_92},{t:this.shape_47,p:{x:134.775,y:162.025}},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_42,p:{x:237.975,y:160.825}},{t:this.shape_46,p:{x:241.875,y:159.525}},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_39,p:{x:252.825,y:173.175}},{t:this.shape_71},{t:this.shape_70}]},86).to({state:[]},87).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63,p:{x:79.375,y:173.725}},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:211.325,y:173.675}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:238.825,y:174.975}},{t:this.shape_46,p:{x:242.675,y:173.675}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:276.375,y:174.975}},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:298.175,y:173.675}},{t:this.shape_38},{t:this.shape_37,p:{x:311.575,y:176.3063}},{t:this.shape_36}]},123).to({state:[{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_51,p:{x:59.575,y:160.725}},{t:this.shape_37,p:{x:65.075,y:163.3563}},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_63,p:{x:122.375,y:160.775}},{t:this.shape_92},{t:this.shape_47,p:{x:134.775,y:162.025}},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_42,p:{x:237.975,y:160.825}},{t:this.shape_46,p:{x:241.875,y:159.525}},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_39,p:{x:252.825,y:173.175}},{t:this.shape_71},{t:this.shape_70}]},86).to({state:[]},87).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63,p:{x:79.375,y:173.725}},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:211.325,y:173.675}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:238.825,y:174.975}},{t:this.shape_46,p:{x:242.675,y:173.675}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:276.375,y:174.975}},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:298.175,y:173.675}},{t:this.shape_38},{t:this.shape_37,p:{x:311.575,y:176.3063}},{t:this.shape_36}]},123).to({state:[{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_51,p:{x:59.575,y:160.725}},{t:this.shape_37,p:{x:65.075,y:163.3563}},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_63,p:{x:122.375,y:160.775}},{t:this.shape_92},{t:this.shape_47,p:{x:134.775,y:162.025}},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_42,p:{x:237.975,y:160.825}},{t:this.shape_46,p:{x:241.875,y:159.525}},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_39,p:{x:252.825,y:173.175}},{t:this.shape_71},{t:this.shape_70}]},86).wait(87));

	// Слой_9
	this.instance_5 = new lib.pc31("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(233.6,140,1,1,0,0,0,233.6,140);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).wait(87));

	// Слой_7
	this.instance_6 = new lib.pc21("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(233.75,140.85,1.0033,1.0033,0,0,0,233.4,140.3);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(123).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(209).to({_off:false},0).to({_off:true},87).wait(86));

	// pc11
	this.instance_7 = new lib.pc11();
	this.instance_7.parent = this;
	this.instance_7.setTransform(168.05,128.95,1,1,0,0,0,168,139.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({regY:140,x:168,y:129.15},0).wait(1).to({y:129.25},0).wait(1).to({y:129.3},0).wait(1).to({y:129.4},0).wait(1).to({y:129.45},0).wait(1).to({y:129.55},0).wait(1).to({y:129.6},0).wait(1).to({y:129.7},0).wait(1).to({y:129.8},0).wait(1).to({y:129.85},0).wait(1).to({y:129.95},0).wait(1).to({y:130},0).wait(1).to({y:130.1},0).wait(1).to({y:130.2},0).wait(1).to({y:130.25},0).wait(1).to({y:130.35},0).wait(1).to({y:130.4},0).wait(1).to({y:130.5},0).wait(1).to({y:130.6},0).wait(1).to({y:130.65},0).wait(1).to({y:130.75},0).wait(1).to({y:130.8},0).wait(1).to({y:130.9},0).wait(1).to({y:131},0).wait(1).to({y:131.05},0).wait(1).to({y:131.15},0).wait(1).to({y:131.25},0).wait(1).to({y:131.3},0).wait(1).to({y:131.4},0).wait(1).to({y:131.5},0).wait(1).to({y:131.55},0).wait(1).to({y:131.65},0).wait(1).to({y:131.75},0).wait(1).to({y:131.8},0).wait(1).to({y:131.9},0).wait(1).to({y:132},0).wait(1).to({y:132.1},0).wait(1).to({y:132.15},0).wait(1).to({y:132.25},0).wait(1).to({y:132.35},0).wait(1).to({y:132.4},0).wait(1).to({y:132.5},0).wait(1).to({y:132.6},0).wait(1).to({y:132.7},0).wait(1).to({y:132.75},0).wait(1).to({y:132.85},0).wait(1).to({y:132.95},0).wait(1).to({y:133.05},0).wait(1).to({y:133.1},0).wait(1).to({y:133.2},0).wait(1).to({y:133.3},0).wait(1).to({y:133.4},0).wait(1).to({y:133.45},0).wait(1).to({y:133.55},0).wait(1).to({y:133.65},0).wait(1).to({y:133.75},0).wait(1).to({y:133.8},0).wait(1).to({y:133.9},0).wait(1).to({y:134},0).wait(1).to({y:134.1},0).wait(1).to({y:134.2},0).wait(1).to({y:134.25},0).wait(1).to({y:134.35},0).wait(1).to({y:134.45},0).wait(1).to({y:134.55},0).wait(1).to({y:134.65},0).wait(1).to({y:134.7},0).wait(1).to({y:134.8},0).wait(1).to({y:134.9},0).wait(1).to({y:135},0).wait(1).to({y:135.1},0).wait(1).to({y:135.2},0).wait(1).to({y:135.3},0).wait(1).to({y:135.35},0).wait(1).to({y:135.45},0).wait(1).to({y:135.55},0).wait(1).to({y:135.65},0).wait(1).to({y:135.75},0).wait(1).to({y:135.85},0).wait(1).to({y:135.95},0).wait(1).to({y:136.05},0).wait(1).to({y:136.1},0).wait(1).to({y:136.2},0).wait(1).to({y:136.3},0).wait(1).to({y:136.4},0).wait(1).to({y:136.5},0).wait(1).to({y:136.6},0).wait(1).to({y:136.7},0).wait(1).to({y:136.8},0).wait(1).to({y:136.9},0).wait(1).to({y:137},0).wait(1).to({y:137.1},0).wait(1).to({y:137.15},0).wait(1).to({y:137.25},0).wait(1).to({y:137.35},0).wait(1).to({y:137.45},0).wait(1).to({y:137.55},0).wait(1).to({y:137.65},0).wait(1).to({y:137.75},0).wait(1).to({y:137.85},0).wait(1).to({y:137.95},0).wait(1).to({y:138.05},0).wait(1).to({y:138.15},0).wait(1).to({y:138.25},0).wait(1).to({y:138.35},0).wait(1).to({y:138.45},0).wait(1).to({y:138.55},0).wait(1).to({y:138.65},0).wait(1).to({y:138.75},0).wait(1).to({y:138.85},0).wait(1).to({y:138.95},0).wait(1).to({y:139.05},0).wait(1).to({y:139.15},0).wait(1).to({y:139.25},0).wait(1).to({y:139.35},0).wait(1).to({y:139.45},0).wait(1).to({y:139.55},0).wait(1).to({y:139.65},0).wait(1).to({y:139.75},0).wait(1).to({y:139.85},0).wait(1).to({y:139.95},0).wait(1).to({y:140},0).to({_off:true},1).wait(173).to({_off:false,regY:139.9,x:168.05,y:128.95},0).wait(1).to({regY:140,x:168,y:129.15},0).wait(1).to({y:129.25},0).wait(1).to({y:129.3},0).wait(1).to({y:129.4},0).wait(1).to({y:129.45},0).wait(1).to({y:129.55},0).wait(1).to({y:129.6},0).wait(1).to({y:129.7},0).wait(1).to({y:129.8},0).wait(1).to({y:129.85},0).wait(1).to({y:129.95},0).wait(1).to({y:130},0).wait(1).to({y:130.1},0).wait(1).to({y:130.2},0).wait(1).to({y:130.25},0).wait(1).to({y:130.35},0).wait(1).to({y:130.4},0).wait(1).to({y:130.5},0).wait(1).to({y:130.6},0).wait(1).to({y:130.65},0).wait(1).to({y:130.75},0).wait(1).to({y:130.8},0).wait(1).to({y:130.9},0).wait(1).to({y:131},0).wait(1).to({y:131.05},0).wait(1).to({y:131.15},0).wait(1).to({y:131.25},0).wait(1).to({y:131.3},0).wait(1).to({y:131.4},0).wait(1).to({y:131.5},0).wait(1).to({y:131.55},0).wait(1).to({y:131.65},0).wait(1).to({y:131.75},0).wait(1).to({y:131.8},0).wait(1).to({y:131.9},0).wait(1).to({y:132},0).wait(1).to({y:132.1},0).wait(1).to({y:132.15},0).wait(1).to({y:132.25},0).wait(1).to({y:132.35},0).wait(1).to({y:132.4},0).wait(1).to({y:132.5},0).wait(1).to({y:132.6},0).wait(1).to({y:132.7},0).wait(1).to({y:132.75},0).wait(1).to({y:132.85},0).wait(1).to({y:132.95},0).wait(1).to({y:133.05},0).wait(1).to({y:133.1},0).wait(1).to({y:133.2},0).wait(1).to({y:133.3},0).wait(1).to({y:133.4},0).wait(1).to({y:133.45},0).wait(1).to({y:133.55},0).wait(1).to({y:133.65},0).wait(1).to({y:133.75},0).wait(1).to({y:133.8},0).wait(1).to({y:133.9},0).wait(1).to({y:134},0).wait(1).to({y:134.1},0).wait(1).to({y:134.2},0).wait(1).to({y:134.25},0).wait(1).to({y:134.35},0).wait(1).to({y:134.45},0).wait(1).to({y:134.55},0).wait(1).to({y:134.65},0).wait(1).to({y:134.7},0).wait(1).to({y:134.8},0).wait(1).to({y:134.9},0).wait(1).to({y:135},0).wait(1).to({y:135.1},0).wait(1).to({y:135.2},0).wait(1).to({y:135.3},0).wait(1).to({y:135.35},0).wait(1).to({y:135.45},0).wait(1).to({y:135.55},0).wait(1).to({y:135.65},0).wait(1).to({y:135.75},0).wait(1).to({y:135.85},0).wait(1).to({y:135.95},0).wait(1).to({y:136.05},0).wait(1).to({y:136.1},0).wait(1).to({y:136.2},0).wait(1).to({y:136.3},0).wait(1).to({y:136.4},0).wait(1).to({y:136.5},0).wait(1).to({y:136.6},0).wait(1).to({y:136.7},0).wait(1).to({y:136.8},0).wait(1).to({y:136.9},0).wait(1).to({y:137},0).wait(1).to({y:137.1},0).wait(1).to({y:137.15},0).wait(1).to({y:137.25},0).wait(1).to({y:137.35},0).wait(1).to({y:137.45},0).wait(1).to({y:137.55},0).wait(1).to({y:137.65},0).wait(1).to({y:137.75},0).wait(1).to({y:137.85},0).wait(1).to({y:137.95},0).wait(1).to({y:138.05},0).wait(1).to({y:138.15},0).wait(1).to({y:138.25},0).wait(1).to({y:138.35},0).wait(1).to({y:138.45},0).wait(1).to({y:138.55},0).wait(1).to({y:138.65},0).wait(1).to({y:138.75},0).wait(1).to({y:138.85},0).wait(1).to({y:138.95},0).wait(1).to({y:139.05},0).wait(1).to({y:139.15},0).wait(1).to({y:139.25},0).wait(1).to({y:139.35},0).wait(1).to({y:139.45},0).wait(1).to({y:139.55},0).wait(1).to({y:139.65},0).wait(1).to({y:139.75},0).wait(1).to({y:139.85},0).wait(1).to({y:139.95},0).wait(1).to({y:140},0).to({_off:true},1).wait(173).to({_off:false,regY:139.9,x:168.05,y:128.95},0).wait(1).to({regY:140,x:168,y:129.15},0).wait(1).to({y:129.25},0).wait(1).to({y:129.3},0).wait(1).to({y:129.4},0).wait(1).to({y:129.45},0).wait(1).to({y:129.55},0).wait(1).to({y:129.6},0).wait(1).to({y:129.7},0).wait(1).to({y:129.8},0).wait(1).to({y:129.85},0).wait(1).to({y:129.95},0).wait(1).to({y:130},0).wait(1).to({y:130.1},0).wait(1).to({y:130.2},0).wait(1).to({y:130.25},0).wait(1).to({y:130.35},0).wait(1).to({y:130.4},0).wait(1).to({y:130.5},0).wait(1).to({y:130.6},0).wait(1).to({y:130.65},0).wait(1).to({y:130.75},0).wait(1).to({y:130.8},0).wait(1).to({y:130.9},0).wait(1).to({y:131},0).wait(1).to({y:131.05},0).wait(1).to({y:131.15},0).wait(1).to({y:131.25},0).wait(1).to({y:131.3},0).wait(1).to({y:131.4},0).wait(1).to({y:131.5},0).wait(1).to({y:131.55},0).wait(1).to({y:131.65},0).wait(1).to({y:131.75},0).wait(1).to({y:131.8},0).wait(1).to({y:131.9},0).wait(1).to({y:132},0).wait(1).to({y:132.1},0).wait(1).to({y:132.15},0).wait(1).to({y:132.25},0).wait(1).to({y:132.35},0).wait(1).to({y:132.4},0).wait(1).to({y:132.5},0).wait(1).to({y:132.6},0).wait(1).to({y:132.7},0).wait(1).to({y:132.75},0).wait(1).to({y:132.85},0).wait(1).to({y:132.95},0).wait(1).to({y:133.05},0).wait(1).to({y:133.1},0).wait(1).to({y:133.2},0).wait(1).to({y:133.3},0).wait(1).to({y:133.4},0).wait(1).to({y:133.45},0).wait(1).to({y:133.55},0).wait(1).to({y:133.65},0).wait(1).to({y:133.75},0).wait(1).to({y:133.8},0).wait(1).to({y:133.9},0).wait(1).to({y:134},0).wait(1).to({y:134.1},0).wait(1).to({y:134.2},0).wait(1).to({y:134.25},0).wait(1).to({y:134.35},0).wait(1).to({y:134.45},0).wait(1).to({y:134.55},0).wait(1).to({y:134.65},0).wait(1).to({y:134.7},0).wait(1).to({y:134.8},0).wait(1).to({y:134.9},0).wait(1).to({y:135},0).wait(1).to({y:135.1},0).wait(1).to({y:135.2},0).wait(1).to({y:135.3},0).wait(1).to({y:135.35},0).wait(1).to({y:135.45},0).wait(1).to({y:135.55},0).wait(1).to({y:135.65},0).wait(1).to({y:135.75},0).wait(1).to({y:135.85},0).wait(1).to({y:135.95},0).wait(1).to({y:136.05},0).wait(1).to({y:136.1},0).wait(1).to({y:136.2},0).wait(1).to({y:136.3},0).wait(1).to({y:136.4},0).wait(1).to({y:136.5},0).wait(1).to({y:136.6},0).wait(1).to({y:136.7},0).wait(1).to({y:136.8},0).wait(1).to({y:136.9},0).wait(1).to({y:137},0).wait(1).to({y:137.1},0).wait(1).to({y:137.15},0).wait(1).to({y:137.25},0).wait(1).to({y:137.35},0).wait(1).to({y:137.45},0).wait(1).to({y:137.55},0).wait(1).to({y:137.65},0).wait(1).to({y:137.75},0).wait(1).to({y:137.85},0).wait(1).to({y:137.95},0).wait(1).to({y:138.05},0).wait(1).to({y:138.15},0).wait(1).to({y:138.25},0).wait(1).to({y:138.35},0).wait(1).to({y:138.45},0).wait(1).to({y:138.55},0).wait(1).to({y:138.65},0).wait(1).to({y:138.75},0).wait(1).to({y:138.85},0).wait(1).to({y:138.95},0).wait(1).to({y:139.05},0).wait(1).to({y:139.15},0).wait(1).to({y:139.25},0).wait(1).to({y:139.35},0).wait(1).to({y:139.45},0).wait(1).to({y:139.55},0).wait(1).to({y:139.65},0).wait(1).to({y:139.75},0).wait(1).to({y:139.85},0).wait(1).to({y:139.95},0).wait(1).to({y:140},0).to({_off:true},1).wait(173));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(165.2,113.2,247.10000000000002,202.90000000000003);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_Contractors_atlas_P_.png", id:"336x280_Contractors_atlas_P_"},
		{src:"images/336x280_Contractors_atlas_NP_.jpg", id:"336x280_Contractors_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;