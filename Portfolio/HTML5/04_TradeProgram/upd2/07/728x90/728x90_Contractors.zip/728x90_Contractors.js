(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_Contractors_atlas_P_", frames: [[0,128,143,51],[0,0,380,126]]},
		{name:"728x90_Contractors_atlas_NP_", frames: [[58,282,56,43],[116,282,48,45],[0,282,56,47],[0,0,392,280]]}
];


// symbols:



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["728x90_Contractors_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["728x90_Contractors_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["728x90_Contractors_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.logoblack = function() {
	this.initialize(ss["728x90_Contractors_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen111111 = function() {
	this.initialize(ss["728x90_Contractors_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen21111 = function() {
	this.initialize(ss["728x90_Contractors_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape.setTransform(619.675,-104.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_1.setTransform(613.275,-105.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgFAxIAAhHIALAAIAABHgAgFgjQgCgCAAgDQAAgDACgDQADgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgDgCg");
	this.shape_2.setTransform(609.35,-106.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQADgDAGgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape_3.setTransform(604.05,-104.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgLAvQgHgDgEgGIAAALIgLAAIAAhjIALAAIAAAnQAFgHAGgDQAGgEAHAAQAHAAAGAEQAGACAEAFQAEAFADAHQACAGAAAJQAAAIgCAIQgDAHgEAFQgEAFgGACQgGADgHAAQgHAAgGgEgAgNgLQgGAEgDAFIAAAfQADAFAGADQAGAEAHAAQAEAAAFgDQAEgBADgEQADgEACgFQABgFAAgGQAAgGgBgGQgCgEgDgDQgDgEgEgCQgFgCgEAAQgHAAgGADg");
	this.shape_4.setTransform(596.525,-106.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_5.setTransform(587.775,-104.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_6.setTransform(578.075,-104.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_7.setTransform(566.575,-104.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgXAfQgGgFAAgMIAAgyIALAAIAAAvIABAHIAEAGQACACACAAIAHABQAGAAAFgDQAHgEACgEIAAg0IAMAAIAABHIgMAAIAAgKQgDAFgIADQgGAEgHAAQgMAAgFgGg");
	this.shape_8.setTransform(559.6,-104.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_9.setTransform(551.125,-104.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgYAyIgFAAIACgLIADABIADABQAEAAADgCQACgCACgEIAFgLIgehIIAMAAIAXA7IAYg7IAMAAIgkBWQgCAIgGADQgFADgHABIgEgBg");
	this.shape_10.setTransform(543.175,-103.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAHAAQAIAAAEgEQAFgDAAgGQAAgEgEgCQgDgDgFgBIgKgDIgKgDQgFgCgEgEQgDgDAAgHIACgIQACgEADgDQADgDAFgBQAGgCAFAAQAJAAAHADQAGADAFAEIgGAIQgDgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAIADIAKADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgEADQgDADgFABQgFACgIAAQgIAAgHgDg");
	this.shape_11.setTransform(532,-104.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_12.setTransform(524.375,-104.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_13.setTransform(517.975,-105.65);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAlQgEgCgEgDQgEgDgCgFQgCgEAAgGQAAgGACgEQACgEAEgDQAEgDAEgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgFgEgJAAQgLAAgJAKIgFgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgEAEAAAHQAAAHAEAFQAFAEAIAAQAFAAAFgCQAFgDAEgEIAAgOQgEgEgFgCQgFgCgFAAQgIAAgFAEg");
	this.shape_14.setTransform(511.6,-104.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgFAkIgehHIAMAAIAXA6IAYg6IAMAAIgeBHg");
	this.shape_15.setTransform(504.175,-104.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_16.setTransform(496.275,-104.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_17.setTransform(490.325,-106.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_18.setTransform(484.425,-104.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_19.setTransform(474.125,-105.65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMARAAQAFAAAFABQAFACAEADQAEADACAEQADAFgBAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_20.setTransform(467.75,-104.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AATAyIAAgwQAAgEgBgDQgBgDgCgCQgDgCgDAAIgHgBIgFABIgGACIgFADIgEAFIAAA0IgLAAIAAhjIALAAIAAAmIAEgFIAHgDIAHgDIAHgCQAMABAFAFQAGAGAAAMIAAAyg");
	this.shape_21.setTransform(459.85,-106.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_22.setTransform(453.525,-105.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_23.setTransform(445.225,-105.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_24.setTransform(438.85,-104.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_25.setTransform(430.475,-104.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgEAqQgEgEAAgIIAAguIgMAAIAAgKIAMAAIAAgUIALAAIAAAUIAOAAIAAAKIgOAAIAAAsQAAAEABACQACADAEAAIAEgBIAEgCIADAIQgCADgEABQgDABgFAAQgHAAgEgFg");
	this.shape_26.setTransform(424.075,-105.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AATAlIAAguQAAgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_27.setTransform(417.7,-104.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(409.225,-104.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_29.setTransform(401.325,-104.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAlQgFgCgDgDQgEgDgCgFQgDgEAAgGQAAgGADgEQACgEAEgDQADgDAFgBIAJgCQAGAAAHADQAFACAFAEIAAgMQAAgHgFgEQgGgEgHAAQgMAAgKAKIgEgIQALgMAQAAQAGAAAFABQAFACAEADQAEADACAEQACAFAAAGIAAAxIgLAAIAAgIQgJAKgOAAIgJgBgAgNADQgFAEABAHQgBAHAFAFQAFAEAIAAQAFAAAGgCQAEgDAEgEIAAgOQgEgEgEgCQgGgCgFAAQgIAAgFAEg");
	this.shape_30.setTransform(389.45,-104.775);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgEAxIAAhHIAKAAIAABHgAgEgjQgDgCAAgDQAAgDADgDQACgCACAAQADAAACACQACADABADQgBADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_31.setTransform(384,-106.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgOAwQgFgCgFgFQgEgFgDgHQgCgIAAgIQAAgJACgGQACgHAFgFQAEgFAGgCQAGgEAIAAQAFAAAHAEQAGADAEAHIAAgnIAMAAIAABjIgMAAIAAgLQgDAGgHADQgGAEgGAAQgIAAgGgDgAgIgMQgEACgDAEQgDADgCAEQgBAGAAAGQAAAGABAFQACAFADAEQADAEAEABQAFADAEAAQAHAAAFgEQAHgDACgFIAAgfQgCgFgHgEQgFgDgHAAQgEAAgFACg");
	this.shape_32.setTransform(377.75,-106.05);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_33.setTransform(369.425,-104.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AAmAlIAAgwQAAgHgDgEQgDgEgHAAQgGAAgFADQgFAEgDAEIAAA0IgLAAIAAgwQAAgHgDgEQgDgEgHAAQgGAAgEADQgGAEgDAEIAAA0IgLAAIAAhHIALAAIAAAKIADgEIAGgEIAHgDIAHgBQAJAAAFAEQADAEACAFIAEgEIAGgFIAGgDIAIgBQAKAAAFAFQAGAGAAALIAAAzg");
	this.shape_34.setTransform(359.15,-104.875);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgRAlIAAhHIAMAAIAAALQAEgFAFgEQAGgEAIAAIAAAMIgFgBIgFABIgGACIgEAEIgDAFIAAAyg");
	this.shape_35.setTransform(347.125,-104.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_36.setTransform(340.025,-104.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAFgGQAGgGAJAAIAIABIAHAFIgFAHIgDgDIgGgBQgFAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_37.setTransform(334.2,-106.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgLAzIAAg+IgMAAIAAgKIAMAAIAAgFQAAgMAGgGQAFgGAJAAIAIABIAHAFIgEAHIgFgDIgEgBQgGAAgDAEQgCAEAAAHIAAAFIAOAAIAAAKIgOAAIAAA+g");
	this.shape_38.setTransform(329.95,-106.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_39.setTransform(322.975,-104.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_40.setTransform(310.575,-104.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAWAyIgWhPIgVBPIgNAAIgdhjIAOAAIAWBTIAXhTIAJAAIAYBTIAVhTIAOAAIgdBjg");
	this.shape_41.setTransform(299.7,-106.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(291,-115,335,19), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape.setTransform(630.25,-103.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEABACQACACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_1.setTransform(626.9,-106.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgKAeQgGgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAFgFAFgDQAGgCAGAAQAGAAAGACQAGADAEAFQADAEACAGQACAHAAAGIAAACIgxAAQAAAFACADQABAEADAEQAEADADABQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgGADgIAAQgHAAgFgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgDgDgDgCQgEgCgFAAQgFAAgDACg");
	this.shape_2.setTransform(621.3,-105.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgOArQgFgCgGgGIAFgHQAEAFAFACQAEACAHAAIAHgBQADgBADgCIAFgGQACgEgBgFIAAgJQgDAFgGADQgFADgFAAQgHAAgEgCQgGgCgDgFQgEgDgCgHQgCgEAAgIQAAgIACgGQABgGAFgEQADgEAFgDQAFgCAHAAQAFAAAFADQAGADADAFIAAgKIAKAAIAAA8QABAIgDAGQgDAFgEADQgEADgGABIgKACQgIAAgGgCgAgHgiQgDACgDAEQgCADgCAEIgBAKIABAKIAEAGQADADADACQAEABAEAAIAGAAIAFgDIAFgCIACgFIAAgaIgCgEIgFgDIgFgDIgGAAQgEAAgEABg");
	this.shape_3.setTransform(613.75,-104.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgLAqQgGgCgDgEQgEgFgDgGQgBgGAAgIQAAgHABgGQACgFAFgFQADgEAFgDQAGgCAFAAQAGAAAFADQAGADADAFIAAghIAKAAIAABVIgKAAIAAgJQgDAFgGADQgFADgGAAQgFAAgFgCgAgHgLQgEACgCAEQgCADgCAEIgBAJIABAKIAEAIQACADAEABQAEACAEABQAGgBAFgDQAFgCACgFIAAgbQgCgEgFgDQgFgDgGAAQgEAAgEABg");
	this.shape_4.setTransform(606.3,-107);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIACAHIADAFIAEACIAGABQAEAAAFgDQAFgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgGADQgFADgGAAQgKAAgFgFg");
	this.shape_5.setTransform(599.2,-105.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgKApQgFgDgEgFIAAAJIgJAAIAAhVIAJAAIAAAhQAEgFAGgDQAFgDAGAAQAGAAAFACQAFADAEAEQADAFACAFQACAGAAAHQAAAIgCAGQgCAGgDAFQgEAEgFACQgFACgGAAQgGAAgGgDgAgLgJQgFADgDAEIAAAbQADAFAFACQAFADAGABQAEgBAEgCQADgBADgDQADgEABgEQABgEAAgGQAAgFgBgEQgBgEgDgDQgDgEgDgCQgEgBgEAAQgGAAgFADg");
	this.shape_6.setTransform(592.075,-107);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgOAgIAAg+IAKAAIAAAKQADgEAFgEQAFgDAGAAIAAAKIgDAAIgFABIgFABIgEAEIgCAEIAAArg");
	this.shape_7.setTransform(583,-105.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgKAeQgGgCgEgEQgEgEgDgHQgCgFAAgIQAAgFACgHQADgGAEgEQAEgFAFgDQAGgCAFAAQAIAAAFACQAGADAEAFQADAEACAGQACAHAAAGIAAACIgxAAQAAAFACADQACAEACAEQAEADADABQAFACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgHADgIAAQgFAAgGgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgDgDgEgCQgEgCgFAAQgEAAgDACg");
	this.shape_8.setTransform(576.85,-105.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgLAqQgGgCgDgEQgEgFgDgGQgBgGAAgIQAAgHABgGQACgFAFgFQADgEAFgDQAFgCAHAAQAFAAAFADQAGADADAFIAAghIAKAAIAABVIgKAAIAAgJQgDAFgGADQgFADgFAAQgHAAgEgCgAgHgLQgEACgCAEQgCADgCAEIgBAJIABAKIAEAIQACADAEABQAEACAEABQAFgBAGgDQAFgCACgFIAAgbQgCgEgFgDQgGgDgFAAQgEAAgEABg");
	this.shape_9.setTransform(569.3,-107);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgEgDQgDgDgHAAIgFAAIgEADIgFADIgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAGgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_10.setTransform(562.15,-105.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIABAHIAEAFIAEACIAGABQAEAAAFgDQAFgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_11.setTransform(555,-105.825);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAqQgFgCgEgEQgDgFgCgGQgDgGAAgIQAAgHADgGQACgFADgFQAEgEAFgDQAFgCAGAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABVIgKAAIAAgJQgEAFgFADQgGADgGAAQgFAAgGgCgAgGgLQgFACgCAEQgDADgBAEIgBAJIABAKIAEAIQACADAFABQADACAEABQAGgBAFgDQAFgCADgFIAAgbQgDgEgFgDQgFgDgGAAQgEAAgDABg");
	this.shape_12.setTransform(544.15,-107);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgDgDQgFgDgGAAIgEAAIgGADIgEADIgEADIAAAtIgJAAIAAg+IAJAAIAAAKIAFgEIAFgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_13.setTransform(537,-105.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgLAgIgHgEQgDgDgDgEQgCgEAAgFQAAgFACgEIAGgGQADgCAEgBIAIgBQAFAAAFABQAGADAEADIAAgKQgBgGgEgEQgEgDgIgBQgKAAgIAJIgEgHQAKgKAOAAQAFAAAEABQAFABADADQAEACACAEQABAFAAAGIAAApIgJAAIAAgGQgJAIgLAAIgIgBgAgLACQgEAEAAAGQAAAHAEADQAFAEAGAAQAEAAAFgCQAFgCADgEIAAgLQgDgFgFgBQgFgBgEAAQgGAAgFACg");
	this.shape_14.setTransform(529.8,-105.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAeQgFgCgEgEQgEgEgDgHQgDgFABgIQgBgFADgHQADgGAEgEQADgFAGgDQAGgCAFAAQAHAAAHACQAFADAEAFQAEAEABAGQADAHAAAGIAAACIgyAAQAAAFACADQACAEADAEQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgFADgJAAQgGAAgGgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_15.setTransform(519.55,-105.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAhAgIAAgpQAAgGgCgEQgDgDgGAAQgFAAgFADQgEACgDAEIAAAtIgJAAIAAgpQAAgGgCgEQgEgDgFAAQgGAAgEADQgEADgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAFgDIAFgDIAHgBQAIAAADADQAEAEABAFIADgFIAGgDIAFgDIAHgBQAJAAAFAFQAEAEAAAKIAAAsg");
	this.shape_16.setTransform(510.65,-105.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgEAqIAAg+IAJAAIAAA+gAgEgeQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgEACgCQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQADACAAAEQAAAAgBABQAAAAAAABQAAAAgBABQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_17.setTransform(503.95,-107);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_18.setTransform(500.65,-106.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgDgDQgFgDgGAAIgFAAIgFADIgEADIgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAGgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_19.setTransform(491.75,-105.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgQApQgJgDgFgGQgGgGgDgIQgDgIAAgKQAAgJADgIQADgIAGgGQAFgGAJgEQAHgDAJAAQAKAAAIADQAHAEAGAGQAGAGADAIQADAIAAAJQAAAKgDAIQgDAIgGAGQgGAGgHADQgIAEgKAAQgJAAgHgEgAgMggQgGADgEAFQgFAEgBAHQgDAGAAAHQAAAIADAGQABAGAFAFQAEAFAGADQAGACAGAAQAIAAAFgCQAGgDAEgFQAFgFABgGQADgGAAgIQAAgHgDgGQgBgHgFgEQgEgFgGgDQgFgCgIAAQgGAAgGACg");
	this.shape_20.setTransform(483.15,-107.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_21.setTransform(473.35,-103.325);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgOAgIAAg+IAKAAIAAAKQADgEAFgEQAFgDAHAAIAAAKIgEAAIgFABIgFABIgEAEIgCAEIAAArg");
	this.shape_22.setTransform(470.05,-105.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgKAeQgGgCgEgEQgEgEgDgHQgCgFAAgIQAAgFACgHQADgGAEgEQAEgFAFgDQAGgCAFAAQAHAAAGACQAGADAEAFQADAEACAGQACAHAAAGIAAACIgxAAQAAAFACADQACAEACAEQAEADADABQAFACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgHADgIAAQgFAAgGgDgAgIgWIgGAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgDgDgDgCQgFgCgFAAQgDAAgFACg");
	this.shape_23.setTransform(463.9,-105.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgDAqIAAg+IAIAAIAAA+gAgDgeQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgEACgCQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQABACAAAEQAAAAAAABQAAAAAAABQAAAAgBABQAAABAAAAQgBABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_24.setTransform(458.8,-107);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAFACQAGADAGAAQAHAAADgDQAEgDAAgFQAAgEgDgBIgHgEIgIgCIgKgDQgEgCgDgDQgDgDAAgGIACgHIAFgFQADgDAEgCQAEgBAFAAQAIAAAFADQAHACADAEIgEAHQgDgEgFgCQgFgCgGAAQgFAAgEADQgEADAAAEQAAADADACQACACAFABIAIACIAKAEIAHAEQADAEAAAGQAAAEgCADQgBAEgDADQgDACgFABQgEACgHAAQgGAAgHgDg");
	this.shape_25.setTransform(454.25,-105.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgLAgIgHgEQgEgDgCgEQgBgEgBgFQABgFABgEIAGgGQADgCAEgBIAHgBQAGAAAGABQAFADAEADIAAgKQgBgGgEgEQgFgDgHgBQgKAAgHAJIgFgHQAKgKAOAAQAFAAAEABQAFABADADQAEACACAEQACAFAAAGIAAApIgKAAIAAgGQgJAIgMAAIgHgBgAgLACQgEAEAAAGQAAAHAEADQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgLQgDgFgFgBQgEgBgFAAQgHAAgEACg");
	this.shape_26.setTransform(447.7,-105.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgLAeQgFgCgEgEQgEgEgDgHQgDgFABgIQgBgFADgHQADgGAEgEQADgFAGgDQAGgCAFAAQAHAAAHACQAFADAEAFQAEAEABAGQADAHAAAGIAAACIgyAAQAAAFACADQACAEADAEQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgGACQgGADgJAAQgGAAgGgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_27.setTransform(440.8,-105.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAGACQAFADAFAAQAIAAADgDQAFgDAAgFQAAgEgEgBIgGgEIgJgCIgJgDQgFgCgCgDQgDgDgBgGIACgHIAEgFQADgDAFgCQAFgBAEAAQAIAAAGADQAGACADAEIgFAHQgCgEgFgCQgFgCgGAAQgGAAgDADQgEADAAAEQAAADADACQADACAEABIAJACIAJAEIAHAEQADAEAAAGQAAAEgBADQgCAEgEADQgDACgEABQgFACgGAAQgHAAgGgDg");
	this.shape_28.setTransform(430.7,-105.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKApQgFgDgEgFIAAAJIgJAAIAAhVIAJAAIAAAhQAEgFAGgDQAFgDAGAAQAGAAAFACQAFADAEAEQADAFACAFQACAGAAAHQAAAIgCAGQgCAGgDAFQgEAEgFACQgFACgGAAQgGAAgGgDgAgLgJQgFADgDAEIAAAbQADAFAFACQAFADAGABQAEgBAEgCQADgBADgDQADgEABgEQABgEAAgGQAAgFgBgEQgBgEgDgDQgDgEgDgCQgEgBgEAAQgGAAgFADg");
	this.shape_29.setTransform(424.225,-107);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgMAeQgGgCgEgFQgDgEgCgGQgDgGAAgHQAAgFADgHQACgGADgEQAEgFAGgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgHAFIgDAIIgBAIIABAKIADAHIAHAFQAEACAEABQAFgBAEgCQAEgCADgDIAEgHQABgFAAgFIgBgIIgEgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_30.setTransform(416.55,-105.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgKA2IgGgDIADgIIAFADIAEABQAEAAADgDQADgCAAgGIAAhEIAKAAIAABEQgBAJgFAFQgEAFgIAAIgIgBgAAGgrQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgDACgCQAAgBABAAQABAAAAgBQABAAAAAAQABAAAAAAQABAAABAAQABAAAAAAQABABAAAAQABAAAAABQACACAAADQAAAAAAABQAAABgBAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQgBAAAAgBg");
	this.shape_31.setTransform(410.35,-105.725);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgOAgIAAg+IAKAAIAAAKQADgEAFgEQAFgDAHAAIAAAKIgEAAIgFABIgFABIgEAEIgCAEIAAArg");
	this.shape_32.setTransform(404.8,-105.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIABAHIAEAFIAEACIAGABQAFAAAFgDQAEgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_33.setTransform(398.75,-105.825);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgMAeQgGgCgDgFQgEgEgDgGQgCgGAAgHQAAgFACgHQADgGAEgEQADgFAGgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEABQAFgBAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_34.setTransform(391.4,-105.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgVAsIgEgBIACgJIADABIACABQAEAAACgCQACgBABgEIAFgKIgag+IAKAAIAUAyIAVgyIALAAIggBKQgCAHgFADQgEADgHAAIgDAAg");
	this.shape_35.setTransform(384.55,-104.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgKAeQgGgCgEgEQgEgEgDgHQgCgFAAgIQAAgFACgHQADgGAEgEQAEgFAFgDQAGgCAFAAQAIAAAFACQAGADAEAFQADAEACAGQACAHAAAGIAAACIgxAAQAAAFACADQACAEACAEQAEADADABQAFACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgHADgIAAQgFAAgGgDgAgIgWIgGAFQgDADAAAEIgCAHIAoAAIgBgHIgEgHQgDgDgEgCQgEgCgFAAQgDAAgFACg");
	this.shape_36.setTransform(374.35,-105.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AAPArIgVgcIgLAKIAAASIgKAAIAAhVIAKAAIAAA4IAgghIANAAIgcAcIAcAig");
	this.shape_37.setTransform(367.725,-107.075);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgLAgIgHgEQgEgDgCgEQgCgEABgFQgBgFACgEIAGgGQADgCAEgBIAHgBQAGAAAGABQAFADAEADIAAgKQgBgGgEgEQgFgDgHgBQgKAAgHAJIgFgHQAKgKAOAAQAFAAAEABQAEABAEADQAEACACAEQACAFAAAGIAAApIgKAAIAAgGQgJAIgMAAIgHgBgAgLACQgEAEAAAGQAAAHAEADQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgLQgDgFgFgBQgEgBgFAAQgHAAgEACg");
	this.shape_38.setTransform(360.4,-105.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AAhAgIAAgpQAAgGgCgEQgEgDgFAAQgFAAgFADQgEACgDAEIAAAtIgJAAIAAgpQAAgGgCgEQgEgDgFAAQgGAAgEADQgEADgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAFgDIAFgDIAHgBQAHAAAEADQAEAEABAFIADgFIAGgDIAGgDIAGgBQAJAAAFAFQAEAEAAAKIAAAsg");
	this.shape_39.setTransform(351.9,-105.975);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAFACQAGADAGAAQAHAAAEgDQADgDAAgFQAAgEgCgBIgIgEIgIgCIgJgDQgFgCgDgDQgCgDAAgGIABgHIAFgFQADgDAEgCQAFgBAEAAQAIAAAFADQAGACAEAEIgEAHQgDgEgFgCQgFgCgGAAQgFAAgFADQgDADAAAEQAAADADACQACACAFABIAIACIAKAEIAHAEQADAEAAAGQAAAEgCADQgBAEgDADQgDACgFABQgFACgGAAQgHAAgGgDg");
	this.shape_40.setTransform(340.2,-105.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIACAHIADAFIAEACIAFABQAFAAAFgDQAFgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_41.setTransform(333.7,-105.825);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_42.setTransform(324.9,-106.675);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AgLAeQgFgCgEgEQgEgEgDgHQgDgFABgIQgBgFADgHQADgGAEgEQADgFAGgDQAGgCAFAAQAHAAAHACQAFADAEAFQAEAEABAGQADAHAAAGIAAACIgyAAQAAAFACADQACAEADAEQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgGACQgGADgJAAQgGAAgGgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_43.setTransform(319.3,-105.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgZArIAAhVIALAAIAABMIAoAAIAAAJg");
	this.shape_44.setTransform(312.825,-107.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(307.2,-115,326.7,17), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYAyQgMgEgHgIIAMgSQAGAGAJAFQAIAEAKAAQAKAAAEgEQAFgDAAgFQAAgEgFgDQgEgCgHgCIgOgEIgPgFQgHgDgEgGQgEgGgBgKQABgJAEgHQAFgHAJgFQAJgEAMAAQANAAAKAEQALAEAIAHIgNARQgHgGgIgDQgIgDgHAAQgHAAgEADQgEADAAAFQAAAEAEACIAMAEIANAEQAIACAHADQAHAEAFAFQAEAGAAAKQAAAKgFAHQgEAIgKAFQgJAEgPAAQgOAAgLgFg");
	this.shape.setTransform(649.075,-41.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_1.setTransform(639.425,-41.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_2.setTransform(627.925,-41.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgLA1IAAhVIgfAAIAAgUIBUAAIAAAUIgfAAIAABVg");
	this.shape_3.setTransform(617.15,-41.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgWAwQgNgHgHgMQgIgNAAgQQAAgQAIgMQAHgMANgHQANgHAPAAQAMAAAIAEQAJADAGAGQAGAGAEAHIgUAJQgDgGgHgEQgHgFgIAAQgJAAgHAFQgIAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAIAEQAHAFAJAAQAIAAAHgFQAHgEADgGIAUAJQgEAHgGAGQgGAGgJADQgIAEgMAAQgPAAgNgHg");
	this.shape_4.setTransform(607.125,-41.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAeA1IgHgSIgtAAIgHASIgZAAIAphpIAbAAIApBpgAARAPIgRgtIgQAtIAhAAg");
	this.shape_5.setTransform(596.025,-41.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_6.setTransform(585.625,-41.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgKA1IAAhVIggAAIAAgUIBVAAIAAAUIggAAIAABVg");
	this.shape_7.setTransform(575.6,-41.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_8.setTransform(565.125,-41.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_9.setTransform(553.175,-41.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgWAwQgNgHgHgMQgIgNAAgQQAAgQAIgMQAHgMANgHQANgHAPAAQAMAAAIAEQAJADAGAGQAGAGAEAHIgUAJQgDgGgHgEQgHgFgIAAQgJAAgHAFQgIAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAIAEQAHAFAJAAQAIAAAHgFQAHgEADgGIAUAJQgEAHgGAGQgGAGgJADQgIAEgMAAQgPAAgNgHg");
	this.shape_10.setTransform(541.675,-41.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAZA1IAAgtIgxAAIAAAtIgXAAIAAhpIAXAAIAAApIAxAAIAAgpIAXAAIAABpg");
	this.shape_11.setTransform(526.1,-41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgLA1IAAhVIgeAAIAAgUIBTAAIAAAUIgeAAIAABVg");
	this.shape_12.setTransform(515.6,-41.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgKA1IAAhpIAWAAIAABpg");
	this.shape_13.setTransform(508.75,-41.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_14.setTransform(499.175,-41.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgYAyQgMgEgHgIIAMgSQAGAGAJAFQAIAEAKAAQAKAAAEgEQAFgDAAgFQAAgEgFgDQgEgCgHgCIgOgEIgPgFQgHgDgEgGQgEgGgBgKQABgJAEgHQAFgHAJgFQAJgEAMAAQANAAAKAEQALAEAIAHIgNARQgHgGgIgDQgIgDgHAAQgHAAgEADQgEADAAAFQAAAEAEACIAMAEIANAEQAIACAHADQAHAEAFAFQAEAGAAAKQAAAKgFAHQgEAIgKAFQgJAEgPAAQgOAAgLgFg");
	this.shape_15.setTransform(482.875,-41.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AASA1IgggrIgIAKIAAAhIgXAAIAAhpIAXAAIAAAvIAlgvIAcAAIgrAyIAuA3g");
	this.shape_16.setTransform(473.575,-41.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_17.setTransform(463.025,-41.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_18.setTransform(451.525,-41.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_19.setTransform(438.025,-41.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgQAdQgHgEgGgIQgEgHAAgKQAAgIAEgIQAGgIAHgEQAHgEAJgBQAJABAIAEQAIAEAFAIQAEAIAAAIQAAAKgEAHQgFAIgIAEQgIAFgJAAQgJAAgHgFgAgOgYQgGAEgEAGQgDAHgBAHQABAIADAGQAEAHAGAEQAHAEAHAAQAIAAAGgEQAHgEAEgHQADgGABgIQgBgHgDgHQgEgGgHgEQgGgEgIABQgHgBgHAEgAAKATIgKgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAAEADQADADAAAFQAAAFgCACIgDADIgFABIALAPgAgGAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQADgDAAgDQAAgCgDgDQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIgJAAg");
	this.shape_20.setTransform(422.65,-43.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_21.setTransform(414.175,-41.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgWAwQgNgGgHgNQgIgMAAgRQAAgQAIgMQAHgNANgGQANgHAPAAQALAAAJADQAHADAHAGQAGAFAEAHIgTAKQgDgGgHgEQgGgEgJAAQgJAAgHAFQgIAEgFAIQgDAIAAAJQAAAKADAIQAFAIAIAEQAHAFAJAAQAHAAAGgDQAGgCAEgDIAAgNIgcAAIAAgTIAyAAIAAAoQgIAJgMAGQgLAFgOAAQgPAAgNgHg");
	this.shape_22.setTransform(403.5,-41.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAeA1IgHgSIgtAAIgHASIgZAAIAphpIAbAAIApBpgAARAPIgRgtIgQAtIAhAAg");
	this.shape_23.setTransform(392.375,-41.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_24.setTransform(379.525,-41.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_25.setTransform(367.675,-41.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_26.setTransform(357.025,-41.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(349.2,-51,306.90000000000003,20), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen21111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,392,280);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen111111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,380,126), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape.setTransform(16.9,45.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAFgDQAGgEADgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(9.4,45.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_2.setTransform(-2.8,44.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_3.setTransform(-9.125,44.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(-13.05,44.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(-20.225,45.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_6.setTransform(-31.825,44.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(-37.675,45.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(-45.725,45.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(-54.1,45.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(-62.4,45.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(-70.875,45.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgMAwQgKgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAKgDQAJgEAKAAQAGAAAGACIAKAEQAFACADAEIAHAIIgKAGQgEgHgHgEQgIgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAIgEQAHgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgJgEg");
	this.shape_12.setTransform(-80.05,44.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApJCAQgqAAAAgqIAAirQAAgqAqAAISUAAQApAAAAAqIAACrQAAAqgpAAg");
	this.shape_13.setTransform(-32.4,44.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-95.2,32,125.6,25.700000000000003), null);


(lib.biglogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logoblack();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6129,0.6129);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.biglogo, new cjs.Rectangle(0,0,87.7,31.3), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape.setTransform(46.175,-56.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_1.setTransform(41.925,-55.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgJAXQgEgCgEgDQgDgDgBgFQgCgFAAgFQAAgEACgFQABgEADgEQAEgDAEgCQAEgCAFAAQAGAAAEACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgDAFgDADQgDADgEACQgEACgGAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_2.setTransform(37.15,-55.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAPAhIgPg1IgOA1IgJAAIgThBIAJAAIAPA2IAPg2IAGAAIAQA2IAOg2IAKAAIgTBBg");
	this.shape_3.setTransform(29.875,-56.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AANAZIAAgfQgBgGgDgDQgDgCgEAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIACgCIAFgDIAEgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_4.setTransform(76.2,-65.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_5.setTransform(70.425,-64.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_6.setTransform(66.575,-66.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_7.setTransform(63.075,-65.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgIAYQgEgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAEAAQAGAAAFACQAEACACADQAEAEABAFQABAEAAAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgGAAQgFAAgFgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgCgBgFAAQgDAAgCABg");
	this.shape_8.setTransform(57.95,-65.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAGADAFAEQAEAFADAGQADAGgBAGQABAHgDAGQgDAGgEAFQgFAEgGADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAEgCAEgEQADgDACgFQACgFgBgFIgBgJQgCgFgDgDQgDgEgFgCQgFgCgFAAIgOAAg");
	this.shape_9.setTransform(51.8,-66.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgDgEAAgGQAAgEADgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAEACAEADQADAEABAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgDgBgFAAQgDAAgDABg");
	this.shape_10.setTransform(42.7,-65.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgDgFIgGgEQgCgBgFAAQgCAAgEABg");
	this.shape_11.setTransform(37.05,-65.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_12.setTransform(32.875,-65.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_13.setTransform(28.425,-66.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADAEAEABQADACAFAAIAFgCQADAAACgCQADgBABgDQABgDAAgEIAAgHQgCADgFADQgEADgEgBQgFABgEgCIgHgFIgEgIQgCgDAAgHQAAgFACgFIAEgIIAHgFQAEgBAFAAQAEAAAEACQAEACADAEIAAgHIAIAAIAAAuQAAAFgCAEQgCAEgDADQgEACgEABIgIABQgGABgEgCgAgFgaIgFAFIgDAFIgBAHIABAIQABADACACIAFADQADACADAAIAEgBIAEgCIAEgCIACgDIAAgUIgCgDIgEgCIgEgCIgEgBQgDAAgDABg");
	this.shape_14.setTransform(52.225,-82);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(46.75,-82.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(42.875,-83.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAFgCQAEgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgEgBg");
	this.shape_17.setTransform(39.35,-82.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(35.675,-83.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(33.175,-82.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(28.625,-83.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgJAgIgHgFIgEgIQgCgEAAgGQAAgGACgEQACgFACgDQADgDAEgCQAEgCAFAAQAEAAAEACQAEADADAEIAAgaIAIAAIAABCIgIAAIAAgHQgCADgFADQgEACgEAAQgFAAgEgCgAgFgIIgFAEIgDAFIgBAIIABAHIADAGIAFAEQADABADAAQAEAAAEgCQAEgCACgDIAAgVQgCgDgEgDQgEgCgEAAQgDAAgDABg");
	this.shape_21.setTransform(50.725,-93.775);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAfAAIAAgGIgDgFIgGgEQgCgBgFAAQgCAAgEABg");
	this.shape_22.setTransform(45.15,-92.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_23.setTransform(40.975,-92.975);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgFAEIgCAFIgCAGIAgAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgDABg");
	this.shape_24.setTransform(36.2,-92.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_25.setTransform(32.275,-93.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAhIAAg6IgWAAIAAgHIAzAAIAAAHIgWAAIAAA6g");
	this.shape_26.setTransform(28.3,-93.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgQAiIgCAAIABgHIABAAIACABIAFgBIADgFIADgHIgUgwIAIAAIAPAnIAQgnIAIAAIgYA6QgBAFgEACQgDACgFAAIgDAAg");
	this.shape_27.setTransform(58.9,-109.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_28.setTransform(55.075,-110.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgIAYQgEgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAEAAQAGAAAFACQADACADADQAEAEABAFQABAEAAAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgGAAQgFAAgFgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgCgBgFAAQgDAAgCABg");
	this.shape_29.setTransform(50.3,-110.475);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgDAYIgUgvIAIAAIAPAnIAQgnIAIAAIgUAvg");
	this.shape_30.setTransform(45.05,-110.475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(41.475,-111.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_32.setTransform(39.225,-111.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAfAAIAAgGIgDgFIgFgEQgDgBgFAAQgCAAgEABg");
	this.shape_33.setTransform(35.25,-110.475);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGABAGQgBAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_34.setTransform(29.1,-111.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgCgEgBgGQABgEACgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAFACADADQACAEACAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgEAAQgCAAgEABg");
	this.shape_35.setTransform(56.75,-120.475);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_36.setTransform(52.825,-121.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgHAgQgFgDgCgDIAAAHIgIAAIAAhCIAIAAIAAAaQADgEAEgDQAEgCAEAAQAFAAAEACQAEACADADQACADACAFQACAEAAAGQAAAGgCAEIgEAIIgHAFQgEACgFAAQgEAAgEgCgAgIgHQgEADgCADIAAAVQACADAEACQAEACAEAAQADAAADgBIAFgEIADgGIABgHIgBgIIgDgFIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_37.setTransform(48.975,-121.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_38.setTransform(44.825,-121.325);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AAPAYIgPgUIgNAUIgJAAIASgYIgRgXIAJAAIAMASIANgSIAJAAIgRAXIASAYg");
	this.shape_39.setTransform(41.275,-120.475);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACADADQAEAEABAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_40.setTransform(36,-120.475);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_41.setTransform(32.075,-121.375);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_42.setTransform(28.425,-121.375);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(6.25,-60.1,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.75,-87.1,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(7.4,-114.1,0.515,0.515,0,0,0,0.1,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_2
	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("An8HYIAAuwIP5AAIAAOwg");
	this.shape_43.setTransform(36.225,-87.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_43).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-14.6,-135.1,101.69999999999999,94.5), null);


// stage content:
(lib._728x90_Contractors = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_751 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(751).call(this.frame_751).wait(353));

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape.setTransform(364.225,45.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_1.setTransform(364.225,45.9);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_2.setTransform(364.225,45.9);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_3.setTransform(364.225,45.9);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_4.setTransform(364.225,45.9);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_5.setTransform(364.225,45.9);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_6.setTransform(364.225,45.9);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_7.setTransform(364.225,45.9);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_8.setTransform(364.225,45.9);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_9.setTransform(364.225,45.9);
	this.shape_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(224));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(225));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(226));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(227));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(228));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(229));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(230));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(231));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(232));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(233));

	// t11
	this.instance = new lib.t11();
	this.instance.parent = this;
	this.instance.setTransform(154.5,118.35,1,1,0,0,0,105.6,41);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},105).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).to({_off:true},114).wait(224));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(154.5,173.35,1,1,0,0,0,73.5,17);

	this.instance_2 = new lib.t22();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[]},114).wait(224));

	// Лого
	this.instance_3 = new lib.biglogo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(551.55,15.95,0.5748,0.5748,0,0,0,43.9,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(660).to({_off:true},220).wait(224));

	// Слой_5
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.3,-51.8,-51.6,-21.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_10.setTransform(551.525,73.35);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-98,-49.2,-45.3,-18.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_11.setTransform(551.525,73.35);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91.8,-46.6,-39.1,-16.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_12.setTransform(551.525,73.35);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.5,-43.9,-32.8,-13.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_13.setTransform(551.525,73.35);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-79.2,-41.3,-26.5,-10.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_14.setTransform(551.525,73.35);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-73,-38.6,-20.3,-8.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_15.setTransform(551.525,73.35);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-66.7,-36,-14,-5.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_16.setTransform(551.525,73.35);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-60.5,-33.4,-7.8,-2.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_17.setTransform(551.525,73.35);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-54.2,-30.7,-1.5,-0.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_18.setTransform(551.525,73.35);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-48,-28.1,4.7,2.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_19.setTransform(551.525,73.35);
	this.shape_19._off = true;

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-41.7,-25.5,11,5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_20.setTransform(551.525,73.35);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-35.5,-22.8,17.2,7.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_21.setTransform(551.525,73.35);
	this.shape_21._off = true;

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-29.2,-20.2,23.5,10.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_22.setTransform(551.525,73.35);
	this.shape_22._off = true;

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-23,-17.6,29.7,12.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_23.setTransform(551.525,73.35);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,-14.9,36,15.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_24.setTransform(551.525,73.35);
	this.shape_24._off = true;

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-10.5,-12.3,42.2,18.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_25.setTransform(551.525,73.35);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-4.2,-9.7,48.5,20.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_26.setTransform(551.525,73.35);
	this.shape_26._off = true;

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],2,-7,54.7,23.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_27.setTransform(551.525,73.35);
	this.shape_27._off = true;

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,-4.4,61,26.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_28.setTransform(551.525,73.35);
	this.shape_28._off = true;

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],14.5,-1.8,67.2,28.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_29.setTransform(551.525,73.35);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],20.8,0.9,73.5,31.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_30.setTransform(551.525,73.35);
	this.shape_30._off = true;

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],27.1,3.5,79.8,34).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_31.setTransform(551.525,73.35);
	this.shape_31._off = true;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],33.3,6.2,86,36.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_32.setTransform(551.525,73.35);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.6,8.8,92.3,39.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_33.setTransform(551.525,73.35);
	this.shape_33._off = true;

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.8,11.4,98.5,41.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_34.setTransform(551.525,73.35);
	this.shape_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(38).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(293));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(39).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(292));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(40).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(291));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(41).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(290));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(42).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(289));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(43).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(288));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(44).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(287));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(45).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(286));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(46).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(285));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(47).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(284));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(48).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(283));
	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(49).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(282));
	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(50).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(281));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(51).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(280));
	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(52).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(279));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(53).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(278));
	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(54).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(277));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(55).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(276));
	this.timeline.addTween(cjs.Tween.get(this.shape_28).wait(56).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(275));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(57).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(274));
	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(58).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(273));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(59).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(272));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(60).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(271));
	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(61).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(270));
	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(62).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(269));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(570.65,65.75,0.801,0.801,0,0,0,-8.5,35.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(660).to({_off:true},220).wait(224));

	// Слой_2
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("A7zHIIAAuPMA3nAAAIAAOPg");
	this.shape_35.setTransform(550.45,45.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(660).to({_off:true},220).wait(224));

	// Слой_4
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABADADIgEAJIgGgEQgDgBgFAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABIAGABIAIADQADABADACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_36.setTransform(239.3,82.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_37.setTransform(235.425,81.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_38.setTransform(232.625,81.425);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAKAgIgSgZIgFAFIAAAUIgNAAIAAg/IANAAIAAAdIAWgdIAQAAIgZAeIAbAhg");
	this.shape_39.setTransform(228.675,81.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQAAgGAEgFQADgGAFgDQAGgDAFAAQAHAAAFADQAGADACAGQADAGABAGIAAADIghAAQAAAEADADQADADAFAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgDAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_40.setTransform(265.9,72.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_41.setTransform(262.05,71.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgXAhIAAg/IANAAIAAAFIAGgEQADgCAEAAQAGAAAEADQAFADACAFQADAFABAIQgBAHgDAFQgCAGgFACQgEADgGAAIgHgBIgGgGIAAAYgAgGgTIgEADIAAAQIAEAEIAGACQAFgBADgEQADgCAAgGQAAgGgDgEQgDgDgFAAIgGABg");
	this.shape_42.setTransform(258.25,73.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_43.setTransform(251.225,72.725);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_44.setTransform(244.4,72.775);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_45.setTransform(239.025,71.925);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_46.setTransform(232.5,71.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAFgBQAEgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_47.setTransform(228.55,72.775);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_48.setTransform(224.925,71.825);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIALAAIAAAGQACgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_49.setTransform(222.2,72.725);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgEgFABgIQAAgGADgFQACgGAGgDQAGgDAFAAQAHAAAGADQAFADADAGQADAGAAAGIAAADIgiAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgCAAgCABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_50.setTransform(217.6,72.775);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_51.setTransform(213.375,72.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEgBgFQABgFACgEQADgCADgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAFgCAEAAQAGAAAEACQAFABADAEQACAEAAAGIAAAdIgLAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgDACg");
	this.shape_52.setTransform(209,72.775);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAVAgIAAgtIgSAtIgFAAIgSgtIAAAtIgNAAIAAg/IATAAIAOAnIAPgnIATAAIAAA/g");
	this.shape_53.setTransform(202.5,71.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgKAWQgGgBgDgEIAFgJIAEAEIAGACIAFABQAEAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDACgEQACgDAFgCQAEgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgDgBgFAAIgEABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAAAABIAGABIAIADQAEABAEACQACADAAAGQABAEgDADQgDAEgEABQgFACgGAAQgFAAgFgCg");
	this.shape_54.setTransform(62.95,82.375);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAKAgIAAgcQAAgEgDgBQgCgCgEAAQgDAAgCABIgEADIAAAfIgNAAIAAg/IANAAIAAAXIADgCIAFgDQADgCAEAAQAHAAAEAFQAEAEAAAGIAAAgg");
	this.shape_55.setTransform(57.975,81.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_56.setTransform(53.575,81.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_57.setTransform(49.225,82.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgEgFAAgHQAAgGAEgFQADgFAFgEQAGgDAGAAQAIAAAFADQAFAEADAFQAEAFAAAGQAAAHgEAFQgDAGgFADQgFADgIAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_58.setTransform(43.7,82.375);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAVAgIAAgtIgSAtIgFAAIgSgtIAAAtIgNAAIAAg/IATAAIAOAnIAPgnIATAAIAAA/g");
	this.shape_59.setTransform(36.9,81.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgNAcQgGgEgDgIQgDgHAAgJQAAgJAEgHQADgIAHgEQAGgEAJAAQAGAAAEACQAFACAEADIgHAKIgFgEIgHgBQgEAAgEACQgDADgCAEQgCAEAAAFIAAABIAAAAQACgDAFgCQAEgDAEAAQAGAAAFADQAFACADAEQADAEAAAHQAAAGgDAFQgDAFgGADQgFADgHAAQgJAAgGgFgAgFADIgGAFIACAGQABADADACQACACAEAAQADAAADgCIAEgDQAAgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAgBQAAgDgCgCQgBgCgDgBIgGgBQgCAAgDABg");
	this.shape_60.setTransform(27.4464,81.525);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgCACIAAAeg");
	this.shape_61.setTransform(79.5,72.725);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAGgDAGAAQAIAAAFADQAGAEACAFQADAFAAAGQAAAHgDAFQgCAGgGADQgFADgIAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_62.setTransform(74.8,72.775);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgJAgIAAgiIgIAAIAAgLIAIAAIAAgCQAAgIAEgEQAEgEAHAAIAGABIAGADIgFAHIgCgBIgDgBQgBAAAAAAQgBAAgBABQAAAAAAAAQgBABAAAAQgCACAAADIAAACIAKAAIAAALIgKAAIAAAig");
	this.shape_63.setTransform(70.825,71.875);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgMAeQgFgDgCgGQgDgFgBgHQABgIADgFQACgFAFgDQAEgDAGAAQADAAAEACQADABADAEIAAgYIANAAIAAA/IgNAAIAAgFIgGAFQgDACgEAAQgGAAgEgDgAgHAAQgDACAAAHQAAAFADAEQADAEAFAAIAGgCIAEgDIAAgRIgEgCIgGgCQgFAAgDAEg");
	this.shape_64.setTransform(63.5,71.95);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_65.setTransform(59.6,71.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQAAgGAEgFQADgGAFgDQAGgDAFAAQAIAAAEADQAGADACAGQADAGABAGIAAADIghAAQAAAEADADQADADAFAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgDAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_66.setTransform(55.75,72.775);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AAPAgIAAgbIgdAAIAAAbIgOAAIAAg/IAOAAIAAAaIAdAAIAAgaIAOAAIAAA/g");
	this.shape_67.setTransform(49.6,71.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABADADIgEAJIgGgEQgDgBgFAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABABAAIAGABIAIADQADABADACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_68.setTransform(41.3,72.775);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_69.setTransform(36.275,72.725);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAAAhQgHAAgEgCQgFgBgEgEIAFgJQADADAEACQADABAFAAIAEgBQAEgBACgDQABgCAAgFIAAgEIgGAFIgHACQgGAAgFgDQgEgCgCgGQgEgEAAgIQAAgHAEgFQACgGAEgCQAFgDAGAAQADAAAEACQADABADAEIAAgGIANAAIAAAqQAAAHgDAEQgCAEgEADQgDACgFABIgGABIgBAAgAgHgSQgDADAAAGQAAAGADADQADADAFAAIAGgBIAEgDIAAgPIgEgEIgGgBQgFAAgDADg");
	this.shape_70.setTransform(30.55,73.6583);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_71.setTransform(26.725,71.825);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQAEAAABgCQABAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQABgDAFgCQAEgCAFAAQAGAAAFACQAEABAEADIgFAJIgGgEQgDgBgFAAIgEABQAAAAgBABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABAAAAIAGABIAJADQADABAEACQACADAAAGQAAAEgCADQgCAEgFABQgEACgHAAQgFAAgGgCg");
	this.shape_72.setTransform(23.15,72.775);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFABgIQAAgGACgFQADgGAGgDQAGgDAFAAQAHAAAGADQAFADADAGQADAGAAAGIAAADIgiAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgCAAgCABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_73.setTransform(18.25,72.775);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgdAgIAAg/IAZAAQAJAAAIAEQAIAEAEAIQAEAGABAJQgBAKgEAHQgEAHgIAEQgIAEgJAAgAgPAUIALAAQAGAAAEgDQAFgDACgEQACgFAAgFQAAgFgCgEQgCgFgFgCQgEgDgGAAIgLAAg");
	this.shape_74.setTransform(12.35,71.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAADgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDACgEQADgDADgCQAFgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgEgBgEAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABIAGABIAHADQAFABACACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_75.setTransform(344.95,82.375);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgBAhQgFAAgFgCQgFgBgFgEIAGgJQADADADACQAEABAEAAIAFgBQADgBADgDQABgCABgFIAAgEIgHAFIgHACQgGAAgFgDQgEgCgDgGQgCgEAAgIQAAgHACgFQADgGAEgCQAFgDAGAAQADAAAEACQAEABADAEIAAgGIALAAIAAAqQABAHgDAEQgCAEgEADQgEACgEABIgGABIgCAAgAgGgSQgEADAAAGQAAAGAEADQADADAEAAIAGgBIAFgDIAAgPIgFgEIgGgBQgEAAgDADg");
	this.shape_76.setTransform(339.75,83.2583);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_77.setTransform(334.325,82.325);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_78.setTransform(330.325,81.425);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAKAXIgKgfIgJAfIgNAAIgOgtIANAAIAJAeIAKgeIAJAAIALAeIAIgeIANAAIgOAtg");
	this.shape_79.setTransform(325.425,82.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_80.setTransform(319.05,82.375);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIAMAAIAAAGQACgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_81.setTransform(315.1,82.325);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgcAgIAAg/IAYAAQAJAAAIAEQAIAEAEAHQAEAIAAAIQAAAKgEAHQgEAHgIAEQgIAEgJAAgAgPAUIALAAQAGAAAFgCQAEgDACgFQADgFAAgFQAAgEgDgFQgCgEgEgDQgFgDgGAAIgLAAg");
	this.shape_82.setTransform(309.9,81.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgBAhQgFAAgFgCQgFgBgEgEIAFgJQADADADACQAEABAEAAIAGgBQACgBACgDQACgCABgFIAAgEIgHAFIgHACQgGAAgEgDQgFgCgCgGQgDgEAAgIQAAgHADgFQACgGAFgCQAEgDAGAAQADAAAEACQAEABADAEIAAgGIAMAAIAAAqQgBAHgCAEQgCAEgEADQgEACgEABIgGABIgCAAgAgHgSQgDADAAAGQAAAGADADQADADAFAAIAGgBIAFgDIAAgPIgFgEIgGgBQgFAAgDADg");
	this.shape_83.setTransform(349.9,73.6583);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_84.setTransform(344.525,72.725);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_85.setTransform(340.525,71.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgFACIgBACIAAAeg");
	this.shape_86.setTransform(337.8,72.725);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQADgGAGgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_87.setTransform(333.2,72.775);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_88.setTransform(327.9,72.775);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_89.setTransform(322.525,72.725);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_90.setTransform(318.525,71.825);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgBAhQgFAAgFgCQgFgBgEgEIAFgJQADADADACQAEABAEAAIAGgBQACgBACgDQACgCABgFIAAgEIgHAFIgHACQgGAAgEgDQgFgCgDgGQgCgEAAgIQAAgHACgFQADgGAFgCQAEgDAGAAQADAAAEACQADABAEAEIAAgGIAMAAIAAAqQgBAHgCAEQgCAEgEADQgEACgEABIgGABIgCAAgAgHgSQgDADAAAGQAAAGADADQADADAFAAIAGgBIAFgDIAAgPIgFgEIgGgBQgFAAgDADg");
	this.shape_91.setTransform(314.35,73.6583);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_92.setTransform(308.925,72.725);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgVAgIAAg/IAsAAIAAAMIgfAAIAAAOIAeAAIAAAKIgeAAIAAAPIAfAAIAAAMg");
	this.shape_93.setTransform(303.55,71.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDACgEQADgDADgCQAFgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgEgBgEAAIgEABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABIAGABIAHADQAFABACACQADADABAGQAAAEgDADQgCAEgFABQgFACgGAAQgFAAgGgCg");
	this.shape_94.setTransform(164.5,82.375);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_95.setTransform(160.625,81.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_96.setTransform(157.825,81.425);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AAKAgIgSgZIgFAFIAAAUIgNAAIAAg/IANAAIAAAdIAWgdIAQAAIgZAeIAbAhg");
	this.shape_97.setTransform(153.875,81.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFAAgIQAAgGACgFQADgGAGgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgBABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_98.setTransform(145.35,82.375);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_99.setTransform(141.45,81.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgWAhIAAg/IALAAIAAAFIAHgEQAEgDADAAQAGAAAFAEQAEACADAGQACAFAAAIQAAAHgCAFQgDAFgEADQgFADgGAAIgHgBIgHgGIAAAYgAgGgTIgFADIAAAQIAFAEIAGACQAEgBADgEQAEgCAAgGQAAgGgEgEQgDgDgEAAIgGABg");
	this.shape_100.setTransform(137.7,83.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_101.setTransform(130.625,82.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAFgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_102.setTransform(123.85,82.375);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAABQABAAAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_103.setTransform(118.475,81.525);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_104.setTransform(157.65,71.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQAEAEAAAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgCACg");
	this.shape_105.setTransform(153.7,72.775);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_106.setTransform(150.075,71.825);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgCACIAAAeg");
	this.shape_107.setTransform(147.35,72.725);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQAEgGAFgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_108.setTransform(142.75,72.775);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_109.setTransform(138.525,72.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_110.setTransform(134.15,72.775);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AAVAgIAAgtIgSAtIgFAAIgSgtIAAAtIgOAAIAAg/IAUAAIAOAnIAPgnIATAAIAAA/g");
	this.shape_111.setTransform(127.6,71.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[]},115).wait(224));

	// pc11
	this.instance_5 = new lib.pc11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.45,-10.1,0.9813,0.9813);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105).to({_off:false},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(105).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(105).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(105).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(224));

	// Слой_3
	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_112.setTransform(364,45);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("rgba(255,255,255,0.898)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_113.setTransform(364,45);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("rgba(255,255,255,0.8)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_114.setTransform(364,45);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("rgba(255,255,255,0.698)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_115.setTransform(364,45);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_116.setTransform(364,45);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("rgba(255,255,255,0.502)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_117.setTransform(364,45);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("rgba(255,255,255,0.4)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_118.setTransform(364,45);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("rgba(255,255,255,0.302)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_119.setTransform(364,45);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_120.setTransform(364,45);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_121.setTransform(364,45);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_122.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_112}]}).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[]},1).to({state:[{t:this.shape_112}]},209).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[]},1).to({state:[{t:this.shape_112}]},209).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[]},1).to({state:[{t:this.shape_112}]},209).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[]},1).to({state:[]},209).wait(224));

	// Слой_6
	this.instance_6 = new lib.icons();
	this.instance_6.parent = this;
	this.instance_6.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).to({alpha:1},6).to({_off:true},95).wait(119).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(119).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(119).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(339));

	// screen21.jpg - копия
	this.instance_7 = new lib.pc21("synched",15);
	this.instance_7.parent = this;
	this.instance_7.setTransform(306.45,92.45,0.71,0.71,0,0,0,296,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(115).to({_off:false,y:92.45,startPosition:15},0).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(115).to({_off:false,y:92.45,startPosition:15},0).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(115).to({_off:false,y:92.45,startPosition:15},0).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(339));

	// Слой_1
	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_123.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_123).wait(660).to({_off:true},220).wait(224));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728.5,191.9);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_Contractors_atlas_P_.png", id:"728x90_Contractors_atlas_P_"},
		{src:"images/728x90_Contractors_atlas_NP_.jpg", id:"728x90_Contractors_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;