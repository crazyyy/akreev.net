(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_B2B_atlas_P_", frames: [[0,0,98,28]]},
		{name:"300x250_B2B_atlas_NP_", frames: [[0,282,336,192],[0,670,336,192],[58,864,56,43],[116,864,48,45],[0,864,56,47],[0,0,336,280],[0,476,336,192]]}
];


// symbols:



(lib.Растровоеизображение14 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение151 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["300x250_B2B_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen111 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.screen211 = function() {
	this.initialize(ss["300x250_B2B_atlas_NP_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t121 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgKAfQgGgDgEgEQgEgFgDgFQgCgHAAgHQAAgGACgFQADgHAEgEQAEgEAFgDQAGgDAFAAQAIAAAFADQAGADAEAEQADAEACAHQACAGAAAGIAAADIgxAAQAAAEACADQACAFACACQAEADADACQAFACADAAQAGAAAFgCQAFgCAEgEIAFAHQgFAEgGADQgHACgIAAQgFAAgGgCgAgIgWIgGAFQgDADAAAEIgCAHIAoAAIgBgHIgEgHQgDgDgEgCQgEgCgFAAQgDAAgFACg");
	this.shape.setTransform(199.3,71.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIABAHIAEAFIAEACIAGABQAFAAAFgDQAEgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_1.setTransform(192.1,71.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEArIAAhVIAJAAIAABVg");
	this.shape_2.setTransform(187.05,70.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgMAgIgGgEQgDgDgCgEQgCgDAAgFQAAgGACgEIAFgFQADgDADgBIAIgCQAGAAAGACQAFADAEADIAAgKQAAgGgFgEQgFgEgGAAQgLABgHAIIgFgGQAKgLAOAAQAFAAAEACQAEAAAEADQAEACABAFQADADAAAHIAAAqIgKAAIAAgHQgJAIgMAAIgIgBgAgLACQgEAFAAAGQAAAGAEADQAFAEAGAAQAFAAAEgCQAFgCADgEIAAgLQgDgEgFgDQgEgBgFAAQgGAAgFADg");
	this.shape_3.setTransform(182,71.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEAgIgbg+IALAAIAUAyIAVgyIAKAAIgaA+g");
	this.shape_4.setTransform(175.6,71.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAAKQAEgFAEgDQAGgDAHAAIAAAKIgFgBIgEABIgFACIgDAEIgEADIAAAsg");
	this.shape_5.setTransform(167.25,71.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgLAfQgFgDgFgEQgDgFgDgFQgCgHgBgHQABgGACgFQADgHADgEQAEgEAGgDQAGgDAGAAQAHAAAFADQAGADAEAEQAEAEACAHQACAGAAAGIAAADIgyAAQAAAEACADQACAFACACQADADAFACQADACAFAAQAFAAAFgCQAFgCAEgEIAEAHQgEAEgHADQgGACgHAAQgGAAgHgCgAgHgWIgGAFQgDADgCAEIgBAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_6.setTransform(161.1,71.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgFAgIgag+IALAAIAUAyIAUgyIALAAIgaA+g");
	this.shape_7.setTransform(154.3,71.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgDArIAAg+IAIAAIAAA+gAgDgeQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAgBQAAgCACgDQAAAAABAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAABAAQAAAAABABQAAAAABAAQACADAAACQAAABgBABQAAAAAAABQAAAAgBABQAAABAAAAQgBAAAAABQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_8.setTransform(149.65,70.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEArIAAhVIAJAAIAABVg");
	this.shape_9.setTransform(146.75,70.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgLAfQgFgDgEgEQgEgFgDgFQgCgHgBgHQABgGACgFQADgHAEgEQADgEAGgDQAGgDAFAAQAHAAAHADQAFADAEAEQADAEADAHQACAGAAAGIAAADIgyAAQAAAEACADQACAFADACQACADAFACQADACAFAAQAFAAAFgCQAFgCAEgEIAEAHQgEAEgHADQgFACgIAAQgGAAgHgCgAgIgWIgFAFQgDADgCAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_10.setTransform(141.65,71.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgMAqQgFgDgEgDQgDgFgDgGQgCgGAAgIQAAgIACgEQADgHADgEQAEgEAFgCQAGgDAFAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABWIgKAAIAAgKQgEAFgFADQgGADgGAAQgGAAgFgCgAgGgKQgEACgDADQgDADgBADIgBAKIABAKIAEAHQADAEAEACQADACAEAAQAGAAAFgDQAFgEADgDIAAgcQgDgEgFgDQgFgDgGAAQgEAAgDACg");
	this.shape_11.setTransform(134.1,70.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAfQgFgDgEgEQgFgFgCgGQgCgGAAgHQAAgGACgFQACgHAFgEQAEgEAFgDQAGgDAGAAQAHAAAGADQAGADAEAEQAEAEACAHQACAFAAAGQAAAHgCAGQgCAGgEAFQgEAEgGADQgGACgHAAQgGAAgGgCgAgIgVIgHAFIgDAIIgBAIIABAJIADAIIAHAGQAEACAEAAQAFAAAEgCQAEgCADgEIADgIQACgEAAgFIgCgIIgDgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_12.setTransform(123.45,71.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_13.setTransform(117.9,70.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgLAqQgGgDgDgDQgEgFgDgGQgCgGAAgIQAAgIACgEQADgHAEgEQADgEAFgCQAGgDAFAAQAGAAAFADQAGADADAFIAAghIALAAIAABWIgLAAIAAgKQgDAFgGADQgFADgGAAQgFAAgFgCgAgHgKQgEACgCADQgCADgCADIgBAKIABAKIAEAHQACAEAEACQAEACAEAAQAFAAAGgDQAFgEACgDIAAgcQgCgEgFgDQgGgDgFAAQgEAAgEACg");
	this.shape_14.setTransform(108.7,70.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAfQgFgDgEgEQgEgFgDgFQgDgHABgHQgBgGADgFQADgHAEgEQADgEAGgDQAGgDAFAAQAHAAAHADQAFADAEAEQAEAEABAHQADAGAAAGIAAADIgyAAQAAAEACADQACAFADACQACADAFACQADACAFAAQAFAAAFgCQAFgCAEgEIAEAHQgEAEgHADQgFACgJAAQgGAAgGgCgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_15.setTransform(101.5,71.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgEgDQgDgDgHAAIgFAAIgEADIgFADIgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAGgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_16.setTransform(94.25,71.625);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgNArQgHgCgFgGIAFgGQAEAEAFACQAFACAGAAIAHgBQAEgBADgDIAEgFQACgEAAgFIAAgJQgEAFgFADQgGADgGABQgGgBgFgCQgFgCgEgEQgDgFgDgFQgCgGAAgHQAAgIACgGQACgGAEgEQAEgEAFgCQAGgDAFAAQAGAAAGADQAFADAEAFIAAgJIAKAAIAAA7QAAAJgDAFQgDAFgEADQgEADgFABIgLACQgHAAgGgCgAgGghQgEACgDACQgDADgBAFIgBAKIABAJIAEAHQADADAEACQADABAEABIAFgBIAGgDIAEgDIAEgDIAAgbIgEgEIgEgDIgGgCIgFgBQgEAAgDACg");
	this.shape_17.setTransform(86.75,72.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgEArIAAg+IAJAAIAAA+gAgEgeQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAgCACgDQABAAABAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAABAAQAAAAABABQAAAAAAAAQACADABACQAAABgBABQAAAAAAABQAAAAgBABQAAABgBAAQAAAAAAABQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBgBAAg");
	this.shape_18.setTransform(81.75,70.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgNAfQgHgDgEgFIAFgHQADAEAFADQAGACAFAAQAIAAAEgDQADgDAAgEQABgFgDgCIgHgDIgJgCIgJgDQgFgBgCgDQgDgEAAgGIABgHIAEgGQAEgCAEgBQAEgCAFAAQAIAAAGADQAFADAEADIgFAHQgCgDgFgCQgFgDgGAAQgGAAgEADQgDADAAAEQAAADADACQADACAEABIAJADIAJACIAHAGQADADAAAGQAAAEgBAEQgCADgEACQgDADgEACQgFABgGAAQgGAAgHgCg");
	this.shape_19.setTransform(77.2,71.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgKAfQgGgDgEgEQgEgFgDgFQgCgHAAgHQAAgGACgFQADgHAEgEQAEgEAFgDQAGgDAGAAQAHAAAFADQAGADAEAEQADAEACAHQACAGAAAGIAAADIgxAAQAAAEACADQACAFACACQAEADADACQAFACADAAQAGAAAFgCQAFgCAEgEIAFAHQgFAEgGADQgGACgJAAQgFAAgGgCgAgHgWIgHAFQgDADAAAEIgCAHIAoAAIgBgHIgEgHQgDgDgEgCQgEgCgEAAQgEAAgEACg");
	this.shape_20.setTransform(70.6,71.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgLAqQgGgDgDgDQgEgFgDgGQgBgGAAgIQAAgIABgEQACgHAFgEQADgEAFgCQAGgDAGAAQAFAAAFADQAGADADAFIAAghIAKAAIAABWIgKAAIAAgKQgDAFgGADQgFADgFAAQgHAAgEgCgAgHgKQgEACgCADQgCADgCADIgBAKIABAKIAEAHQACAEAEACQAEACAEAAQAFAAAGgDQAFgEACgDIAAgcQgCgEgFgDQgGgDgFAAQgEAAgEACg");
	this.shape_21.setTransform(63.05,70.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAfQgHgDgEgFIAFgHQADAEAGADQAFACAFAAQAIAAADgDQAFgDAAgEQAAgFgEgCIgGgDIgJgCIgKgDQgEgBgCgDQgEgEAAgGIACgHIAEgGQADgCAFgBQAFgCAEAAQAIAAAFADQAHADADADIgFAHQgCgDgFgCQgFgDgGAAQgFAAgEADQgEADAAAEQAAADADACQACACAFABIAJADIAJACIAHAGQADADAAAGQAAAEgBAEQgCADgEACQgCADgFACQgFABgGAAQgHAAgGgCg");
	this.shape_22.setTransform(53.05,71.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgLAfQgFgDgFgEQgEgFgCgFQgCgHgBgHQABgGACgFQACgHAEgEQAFgEAFgDQAGgDAGAAQAHAAAFADQAGADAEAEQAEAEACAHQABAGAAAGIAAADIgxAAQAAAEACADQABAFADACQAEADAEACQAEACAEAAQAFAAAFgCQAFgCAEgEIAFAHQgFAEgHADQgGACgHAAQgHAAgGgCgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_23.setTransform(46.45,71.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgIAfQgFgDgFgEQgEgFgCgGQgCgGAAgHQAAgGACgGQACgGAEgEQAFgFAFgCQAGgDAGAAQAJAAAFADQAGAEADAEIgGAGQgDgEgEgCQgEgCgFAAQgFAAgDACQgEACgDADQgDADgBAEQgCAFAAAEQAAAFACAEQABAFADADQADAEAEACQADACAFAAQAKAAAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgCg");
	this.shape_24.setTransform(39.675,71.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgDArIAAg+IAIAAIAAA+gAgDgeQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAgBQAAgCACgDQAAAAABAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAABAAQAAAAABABQAAAAABAAQABADAAACQAAABAAABQAAAAAAABQAAAAgBABQAAABAAAAQgBAAAAABQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_25.setTransform(34.9,70.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgEAgIgag+IAKAAIAUAyIAUgyIAMAAIgbA+g");
	this.shape_26.setTransform(30.3,71.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgOAgIAAg+IAJAAIAAAKQAEgFAEgDQAGgDAGAAIAAAKIgDgBIgFABIgFACIgEAEIgDADIAAAsg");
	this.shape_27.setTransform(25.3,71.65);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgKAfQgGgDgEgEQgEgFgDgFQgDgHABgHQgBgGADgFQADgHAEgEQADgEAGgDQAGgDAFAAQAHAAAHADQAFADAEAEQAEAEABAHQADAGAAAGIAAADIgyAAQAAAEACADQACAFADACQACADAFACQADACAFAAQAFAAAFgCQAFgCAEgEIAEAHQgEAEgHADQgFACgJAAQgGAAgFgCgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_28.setTransform(19.15,71.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAfQgHgDgEgFIAFgHQADAEAFADQAGACAFAAQAIAAAEgDQAEgDgBgEQAAgFgCgCIgHgDIgJgCIgJgDQgFgBgDgDQgCgEAAgGIABgHIAEgGQAEgCAEgBQAEgCAFAAQAIAAAGADQAFADAEADIgFAHQgCgDgFgCQgFgDgGAAQgGAAgEADQgDADAAAEQAAADADACQADACAEABIAJADIAJACIAHAGQADADAAAGQAAAEgBAEQgCADgEACQgDADgEACQgFABgGAAQgGAAgHgCg");
	this.shape_29.setTransform(12.4,71.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgUArQgFgBgDgDQgEgDgCgFQgCgEgBgGQAAgFACgEIAFgHIAFgFIAHgEIgEgKQgCgFAAgFQAAgEACgEQABgDADgDIAIgEQADgCAFAAIAHABQADABADADQACACACADQABADAAAEQABAFgCAEQgCADgEADIgHAFIgGAFIAEAFIAFAGIAEAGIAGAGQADgGACgFIAEgJIAJAEIgGALIgGALIAHAIIAJAIIgNAAIgFgEIgEgFQgFAFgGADQgFADgJAAQgFAAgFgCgAgWAJQgEAEAAAHQAAAEABADIAFAFQACADADABIAGABQAGAAADgDIAJgGIgHgHIgEgGIgGgGIgFgIQgGAEgDAEgAgHgjIgDACIgDAEIAAAGIABAHIADAHIAHgDIAEgEIAFgFIABgFQAAgFgDgDQgDgCgDAAIgGABg");
	this.shape_30.setTransform(1.95,70.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgNAfQgHgDgEgFIAFgHQADAEAGADQAFACAGAAQAHAAADgDQAEgDABgEQgBgFgDgCIgHgDIgIgCIgKgDQgEgBgCgDQgEgEAAgGIACgHIAFgGQADgCAEgBQAFgCAEAAQAIAAAFADQAHADADADIgEAHQgDgDgFgCQgFgDgGAAQgFAAgEADQgEADAAAEQAAADADACQADACAEABIAIADIAKACIAHAGQADADAAAGQAAAEgCAEQgBADgDACQgDADgFACQgFABgGAAQgHAAgGgCg");
	this.shape_31.setTransform(-8.7,71.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_32.setTransform(-13.5,70.925);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgIAfQgFgDgFgEQgEgFgCgGQgCgGAAgHQAAgGACgGQACgGAEgEQAFgFAFgCQAGgDAGAAQAJAAAFADQAGAEADAEIgGAGQgDgEgEgCQgEgCgFAAQgFAAgDACQgEACgDADQgDADgBAEQgCAFAAAEQAAAFACAEQABAFADADQADAEAEACQADACAFAAQAKAAAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgCg");
	this.shape_33.setTransform(-18.575,71.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIAAAHIADAFIAFACIAFABQAFAAAGgDQAFgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_34.setTransform(-25.45,71.775);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgMAqQgFgDgEgDQgDgFgDgGQgCgGAAgIQAAgIACgEQACgHAEgEQAEgEAFgCQAGgDAFAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABWIgKAAIAAgKQgEAFgFADQgGADgGAAQgGAAgFgCgAgGgKQgEACgDADQgDADgBADIgBAKIABAKIAEAHQADAEAEACQADACAEAAQAFAAAGgDQAFgEADgDIAAgcQgDgEgFgDQgGgDgFAAQgEAAgDACg");
	this.shape_35.setTransform(-32.95,70.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAfQgFgDgEgEQgFgFgCgGQgCgGAAgHQAAgGACgFQACgHAFgEQAEgEAFgDQAGgDAGAAQAHAAAGADQAGADAEAEQAEAEACAHQACAFAAAGQAAAHgCAGQgCAGgEAFQgEAEgGADQgGACgHAAQgGAAgGgCgAgIgVIgGAFIgFAIIgBAIIABAJIAFAIIAGAGQAEACAEAAQAFAAAEgCQAEgCACgEIAEgIQACgEAAgFQAAgEgCgEIgEgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_36.setTransform(-40.25,71.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgPAgIAAg+IALAAIAAAKQADgFAFgDQAFgDAHAAIAAAKIgFgBIgEABIgFACIgDAEIgDADIAAAsg");
	this.shape_37.setTransform(-45.75,71.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgeArIAAhVIAiAAQAGAAAGACQAFACADADQADAEACAFQACAEAAAGIgCAKQgCAEgDADQgDAEgFACQgGACgGAAIgXAAIAAAigAgTAAIAVAAQAJAAAEgEQAFgFAAgHQAAgIgFgEQgEgFgJAAIgVAAg");
	this.shape_38.setTransform(-51.8,70.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t121, new cjs.Rectangle(-57.9,62.6,263,16.999999999999993), null);


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape.setTransform(180.8,74.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_1.setTransform(177.45,71.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgIAfQgFgDgFgFQgEgEgCgGQgCgGAAgHQAAgGACgGQACgGAEgEQAFgFAFgDQAGgCAGAAQAJAAAFADQAGADADAFIgGAGQgDgEgEgCQgEgCgFAAQgFAAgDABQgEACgDAEQgDADgBAFQgCAEAAAEQAAAGACAEQABAEADAEQADADAEABQADACAFAAQAKABAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgCg");
	this.shape_2.setTransform(172.375,72.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgKAfQgGgDgEgEQgEgFgDgGQgDgFABgIQgBgFADgHQADgGAEgEQADgFAGgDQAGgCAFAAQAHAAAHACQAFADAEAFQAEAFABAFQADAHAAAGIAAACIgyAAQAAAFACAEQACADADAEQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHADQgFACgJAAQgGAAgFgCgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_3.setTransform(165.4,72.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgKA2IgGgDIADgIIAFADIAEABQAEAAADgDQADgCAAgGIAAhEIAKAAIAABEQgBAJgFAFQgEAFgIAAIgIgBgAAGgrQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgDACgCQAAgBABAAQABAAAAgBQABAAAAAAQABAAAAAAQABAAABAAQABAAAAAAQABABAAAAQABAAAAABQACACAAADQAAAAAAABQAAABgBAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQgBAAAAgBg");
	this.shape_4.setTransform(159.25,72.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAfQgGgDgEgFQgDgEgCgGQgDgGAAgHQAAgFADgHQACgGADgEQAEgFAGgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGADQgGACgHAAQgGAAgGgCgAgIgVIgHAFIgDAIIgBAIIABAKIADAHIAHAFQAEACAEAAQAFAAAEgCQAEgCADgDIAEgHQABgFAAgFIgBgIIgEgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_5.setTransform(155.1,72.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgOAgIAAg+IAJAAIAAALQAEgFAEgEQAGgDAGAAIAAAKIgEAAIgEABIgFACIgEADIgDAEIAAArg");
	this.shape_6.setTransform(149.6,72.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgcAsIAAhWIAJAAIAAAKQAEgFAFgDQAGgDAGAAQAGAAAFACQAFACAEAFQADAEACAGQACAGAAAIQAAAHgCAGQgCAGgDAEQgEAEgFADQgFACgGAAQgGAAgFgDQgGgDgEgFIAAAhgAgLgfQgFACgDAFIAAAbQADAEAFADQAFADAGAAQAEAAADgCQAEgBADgEIAEgHQABgEAAgFQAAgFgBgFQgCgEgCgDQgDgEgEgCQgDgBgEAAQgGAAgFADg");
	this.shape_7.setTransform(143.575,73.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAALQAEgFAEgEQAGgDAHAAIAAAKIgFAAIgEABIgFACIgDADIgEAEIAAArg");
	this.shape_8.setTransform(134.5,72.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIABAHIACAFIAFACIAFABQAFAAAGgDQAFgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_9.setTransform(128.45,72.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgMAfQgFgDgEgFQgFgEgBgGQgDgGAAgHQAAgFADgHQABgGAFgEQAEgFAFgDQAGgCAGAAQAIAAAFACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGADQgFACgIAAQgGAAgGgCgAgIgVIgHAFIgDAIIgBAIIABAKIADAHIAHAFQAEACAEAAQAFAAAEgCQAEgCADgDIADgHQACgFAAgFIgCgIIgDgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_10.setTransform(121.1,72.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgVAsIgEgBIACgJIADABIACABQAEAAABgCQADgBACgEIADgKIgag+IALAAIAUAyIAUgyIALAAIgfBKQgCAHgFADQgFADgFAAIgEAAg");
	this.shape_11.setTransform(114.25,73.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAfQgFgDgFgEQgEgFgCgGQgCgFgBgIQABgFACgHQACgGAEgEQAFgFAFgDQAGgCAGAAQAHAAAFACQAGADAEAFQAEAFACAFQACAHgBAGIAAACIgxAAQAAAFACAEQABADADAEQAEADAEABQAEACAEAAQAFAAAFgCQAFgCAEgEIAFAGQgFAFgHADQgGACgHAAQgGAAgHgCgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_12.setTransform(104.05,72.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_13.setTransform(98.55,71.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgLAfQgFgDgEgEQgEgFgDgGQgDgFABgIQgBgFADgHQADgGAEgEQADgFAGgDQAGgCAFAAQAHAAAHACQAFADAEAFQAEAFABAFQADAHAAAGIAAACIgyAAQAAAFACAEQACADADAEQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHADQgFACgJAAQgGAAgGgCgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgDgDgEgCQgDgCgGAAQgDAAgFACg");
	this.shape_14.setTransform(92.95,72.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgEArIAAhVIAJAAIAABVg");
	this.shape_15.setTransform(87.85,70.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgcAsIAAhWIAJAAIAAAKQAEgFAFgDQAGgDAGAAQAGAAAFACQAFACAEAFQADAEACAGQACAGAAAIQAAAHgCAGQgCAGgDAEQgEAEgFADQgFACgGAAQgGAAgFgDQgGgDgEgFIAAAhgAgLgfQgFACgDAFIAAAbQADAEAFADQAFADAGAAQAEAAADgCQAEgBADgEIAEgHQABgEAAgFQAAgFgBgFQgCgEgCgDQgDgEgEgCQgDgBgEAAQgGAAgFADg");
	this.shape_16.setTransform(82.875,73.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAhAgIAAgpQAAgGgCgEQgDgDgGAAQgFAAgFADQgEACgDAEIAAAtIgJAAIAAgpQAAgGgCgEQgEgDgFAAQgGAAgEADQgEADgDADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAFgDIAFgDIAHgBQAIAAADADQAEAEABAFIADgFIAGgDIAFgDIAHgBQAJAAAFAFQAEAEAAAKIAAAsg");
	this.shape_17.setTransform(73.7,72.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAfQgGgDgDgFQgEgEgDgGQgCgGAAgHQAAgFACgHQADgGAEgEQADgFAGgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGADQgGACgHAAQgGAAgGgCgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEAAQAFAAAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_18.setTransform(64.7,72.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgIAfQgFgDgFgFQgEgEgCgGQgCgGAAgHQAAgGACgGQACgGAEgEQAFgFAFgDQAGgCAGAAQAJAAAFADQAGADADAFIgGAGQgDgEgEgCQgEgCgFAAQgFAAgDABQgEACgDAEQgDADgBAFQgCAEAAAEQAAAGACAEQABAEADAEQADADAEABQADACAFAAQAKABAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgCg");
	this.shape_19.setTransform(57.875,72.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgMAfQgFgDgFgFQgDgEgCgGQgDgGAAgHQAAgFADgHQACgGADgEQAFgFAFgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGADQgGACgHAAQgGAAgGgCgAgIgVIgHAFIgDAIIgCAIIACAKIADAHIAHAFQAEACAEAAQAFAAAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_20.setTransform(47.45,72.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEABACQACACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_21.setTransform(41.9,71.325);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAfQgGgDgFgFIAFgHQADAEAFACQAGADAGAAQAHAAADgDQAEgDAAgFQAAgDgDgCIgHgEIgIgCIgKgDQgEgCgDgDQgDgDAAgGIACgHIAFgFQADgDAEgCQAEgBAFAAQAIAAAFADQAHACADAEIgEAHQgDgEgFgCQgFgCgGAAQgFAAgEADQgEADAAAEQAAAEADABQACACAFABIAIACIAKADIAHAFQADAEAAAGQAAAEgCAEQgBADgDADQgDACgFABQgEACgHAAQgGAAgHgCg");
	this.shape_22.setTransform(33.5,72.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAKAAIAAAoIABAHIACAFIAFACIAFABQAGAAAEgDQAGgDACgEIAAgtIAKAAIAAA+IgKAAIAAgJQgDAEgHADQgFADgGAAQgKAAgFgFg");
	this.shape_23.setTransform(27,72.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AAQArIAAgpIgBgGIgCgEQgCgCgDgBIgGAAIgEAAIgGADIgEADIgEADIAAAtIgJAAIAAhVIAJAAIAAAhIAFgEIAFgEIAGgCIAGgBQAKAAAFAFQAFAFAAAKIAAArg");
	this.shape_24.setTransform(16.45,70.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_25.setTransform(11,71.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgEAqIAAg+IAJAAIAAA+gAgEgeQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAgDACgBQABgBABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAABQADABAAADQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBgBgBAAg");
	this.shape_26.setTransform(7.6,71);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AAQAfIgQgxIgPAxIgKAAIgUg+IAKAAIAPAyIARgyIAHAAIARAyIAPgyIAKAAIgUA+g");
	this.shape_27.setTransform(1.375,72.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AAPArIgVgcIgLAKIAAASIgKAAIAAhVIAKAAIAAA4IAgghIANAAIgcAcIAcAig");
	this.shape_28.setTransform(-9.725,70.925);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAALQAEgFAEgEQAGgDAHAAIAAAKIgFAAIgEABIgFACIgDADIgEAEIAAArg");
	this.shape_29.setTransform(-15.25,72.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgMAfQgGgDgEgFQgDgEgDgGQgCgGAAgHQAAgFACgHQADgGADgEQAEgFAGgDQAGgCAGAAQAIAAAFACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGADQgFACgIAAQgGAAgGgCgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEAAQAFAAAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_30.setTransform(-21.5,72.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AATArIgThFIgTBFIgLAAIgZhVIANAAIATBHIAThHIAIAAIAUBHIAThHIANAAIgaBVg");
	this.shape_31.setTransform(-30.95,70.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(-38.8,63,223.2,17), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgrA0IAAhnIA3AAQAJAAAHADQAHAEADAGQADAGABAHQgBAHgCAFQgDAFgDADQgEADgFABQAFABAFADQAEADADAGQADAFgBAHQAAAIgDAGQgDAHgHADQgGAEgLAAgAgUAhIAbAAQAHAAADgEQAEgDAAgFQAAgFgEgEQgDgDgHAAIgbAAgAgUgKIAbAAQAFAAADgDQAEgDAAgFQAAgFgEgDQgDgDgFAAIgbAAg");
	this.shape.setTransform(206.35,130.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AglA1IAAgRIAagVQALgIAFgGQAHgFADgFQACgFAAgFQAAgEgCgDQgDgDgEgCIgIgBQgHAAgHADQgIADgFAGIgMgPQAFgGAGgEQAHgDAHgCQAHgCAHAAQALAAAJAEQAJAEAFAHQAGAIAAAKQAAAJgFAJQgFAHgJAJQgJAJgNAKIAqAAIAAATg");
	this.shape_1.setTransform(196.1,130.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgrA0IAAhnIA3AAQAJAAAHADQAHAEADAGQADAGABAHQgBAHgCAFQgDAFgDADQgEADgFABQAFABAFADQAEADADAGQADAFgBAHQAAAIgDAGQgDAHgHADQgGAEgLAAgAgUAhIAbAAQAHAAADgEQAEgDAAgFQAAgFgEgEQgDgDgHAAIgbAAgAgUgKIAaAAQAGAAADgDQAEgDAAgFQAAgFgEgDQgDgDgGAAIgaAAg");
	this.shape_2.setTransform(186.55,130.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAYA0IAAgsIgwAAIAAAsIgWAAIAAhnIAWAAIAAApIAwAAIAAgpIAXAAIAABng");
	this.shape_3.setTransform(171.35,130.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIgfAAIAABUg");
	this.shape_4.setTransform(161.025,130.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_5.setTransform(154.3,130.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAThKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_6.setTransform(144.95,130.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgYAxQgLgEgHgIIAMgRQAGAGAIAEQAJAEAJAAQAKAAAEgDQAFgEAAgEQgBgFgEgCQgEgDgHgBIgOgEQgHgCgHgDQgHgDgEgFQgFgGAAgKQAAgJAFgHQAFgHAJgFQAJgEALAAQANAAAKAEQAKADAIAIIgNAQQgGgGgIgCQgIgDgHAAQgHAAgEADQgEACAAAFQAAAEAFACQAEADAHABIANAEQAIACAHADQAHAEAEAFQAEAGAAAKQAAAJgEAIQgFAHgJAFQgJAEgPAAQgOAAgLgFg");
	this.shape_7.setTransform(128.925,130.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AARA0IgegqIgJAKIAAAgIgWAAIAAhnIAWAAIAAAuIAkguIAcAAIgqAxIAtA2g");
	this.shape_8.setTransform(119.825,130.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AARA0IgUglIgQAAIAAAlIgXAAIAAhnIAxAAQALAAAHAEQAIAEAEAIQAFAHAAAKQgBAJgDAHQgDAFgGAEQgEAEgHABIAZAogAgTgEIAWAAQAHAAAFgDQAEgEAAgHQAAgGgEgEQgFgEgHAAIgWAAg");
	this.shape_9.setTransform(109.5,130.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_10.setTransform(98.225,130.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAUhKIAQAAIATBKIAThKIAZAAIgeBng");
	this.shape_11.setTransform(85,130.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgQAdQgHgEgFgIQgEgIAAgJQAAgJAEgHQAFgIAHgDQAIgFAIgBQAJABAIAFQAHADAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAEQgIAEgJABQgIgBgIgEgAgNgYQgHAFgDAGQgEAGAAAHQAAAIAEAGQADAHAHAEQAGADAHAAQAIAAAGgDQAHgEADgHQAEgGAAgIQAAgHgEgGQgDgGgHgFQgGgDgIAAQgHAAgGADgAAJATIgJgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAADADQAEADAAAFQAAAFgCACIgEADIgDABIAKAPgAgGAAIAJAAIAFgBQACgCAAgEQAAgCgCgCQgDgCgCAAIgJAAg");
	this.shape_12.setTransform(69.875,128.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_13.setTransform(61.6,130.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgVAvQgNgGgHgMQgIgMAAgRQAAgQAIgMQAHgMANgGQAMgHAPAAQAKAAAJADQAIADAGAGQAGAFAEAGIgSAKQgEgFgGgEQgHgEgIAAQgJAAgHAEQgHAFgFAHQgEAIAAAJQAAAKAEAIQAFAHAHAFQAHAEAJAAQAHAAAFgCQAHgDADgDIAAgMIgcAAIAAgTIAyAAIAAAnQgIAKgLAFQgLAFgOAAQgPAAgMgHg");
	this.shape_14.setTransform(51.1,130.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_15.setTransform(40.175,130.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AASA0IgShHIgRBHIgYAAIgehnIAZAAIATBKIAThKIARAAIATBKIAThKIAZAAIgeBng");
	this.shape_16.setTransform(27.6,130.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_17.setTransform(16,130.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAZA0IgxhDIAABDIgWAAIAAhnIAXAAIAwBAIAAhAIAWAAIAABng");
	this.shape_18.setTransform(5.525,130.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-2.2,121.8,215.7,19.700000000000003), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_1
	this.instance = new lib.Растровоеизображение151();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},32).to({state:[]},1).wait(94));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},38).to({state:[]},1).wait(94));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},41).to({state:[]},1).wait(94));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},47).to({state:[]},1).wait(94));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},51).to({state:[]},1).wait(94));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},57).to({state:[]},1).wait(94));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},61).to({state:[]},1).wait(94));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},67).to({state:[]},1).wait(94));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},71).to({state:[]},1).wait(94));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},77).to({state:[]},1).wait(94));

	// Слой_1
	this.instance = new lib.screen211();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(85).to({_off:true},1).wait(94));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,280), null);


(lib.pc4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},33).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},39).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},42).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},48).to({state:[]},1).wait(93));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},52).to({state:[]},1).wait(93));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},58).to({state:[]},1).wait(93));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},62).to({state:[]},1).wait(93));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},68).to({state:[]},1).wait(93));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},72).to({state:[]},1).wait(93));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},78).to({state:[]},1).wait(93));

	// Слой_2
	this.instance = new lib.Растровоеизображение14();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:true},1).wait(93));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape.setTransform(151.875,25.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_1.setTransform(147.625,26.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgJAXQgEgCgDgDQgDgDgCgFQgCgFAAgFQAAgEACgFQACgEADgEQADgDAEgCQAEgCAFAAQAGAAAEACQAEACAEADIAEAIQACAFAAAEQAAAFgCAFQgCAFgCADQgEADgEACQgEACgGAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_2.setTransform(142.85,26.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAPAhIgPg1IgOA1IgJAAIgThBIAJAAIAPA2IAPg2IAGAAIAQA2IAOg2IAKAAIgTBBg");
	this.shape_3.setTransform(135.575,25.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgEgCgEAAIgEABIgDABIgEADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_4.setTransform(181.9,16.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_5.setTransform(176.125,17.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_6.setTransform(172.275,15.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_7.setTransform(168.775,16.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgHAYQgFgCgEgEQgCgDgDgFQgCgEAAgGQAAgEACgFIAFgIQADgDAFgCQAFgCAEAAQAFAAAEACQAFACADADQADAEABAFQABAEAAAFIAAACIgmAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgEgBgDAAQgDAAgEABg");
	this.shape_8.setTransform(163.65,16.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgcAhIAAhBIAXAAQAHAAAGACQAGADAFAEQAEAFADAGQADAGAAAGQAAAHgDAGQgDAGgEAFQgFAEgGADQgGACgHAAgAgUAaIAPAAQAFAAAFgCQAEgCAEgEQAEgDABgFQACgFAAgFIgCgJQgBgFgEgDQgDgEgFgCQgFgCgFAAIgPAAg");
	this.shape_9.setTransform(157.5,15.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgIAYQgEgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAEAAQAGAAAFACQADACADADQAEAEABAFQABAEAAAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgGAAQgFAAgFgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgCgBgFAAQgDAAgCABg");
	this.shape_10.setTransform(148.4,16.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgDgDgDgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACAEADQACAEACAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_11.setTransform(142.75,16.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_12.setTransform(138.575,16.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_13.setTransform(134.125,15.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_14.setTransform(256.225,27.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AANAZIAAgfQAAgGgDgDQgEgCgEAAIgEABIgDABIgEADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(250.75,26.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(246.875,25.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAFgCQAEgCAFAAQAGAAAEACIAHAGIgFAFQgDgEgCgBQgEgCgDAAQgEAAgCACQgDABgDADIgDAGIgBAGIABAIIADAFQADADADABQACACAEAAQAHAAAFgHIAFAFIgHAGQgEACgGAAQgFAAgEgBg");
	this.shape_17.setTransform(243.35,26.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(239.675,25.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(237.175,26.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(232.625,25.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_21.setTransform(266.475,15.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AANAZIAAgfQAAgGgEgDQgDgCgEAAIgEABIgDABIgEADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIADgCIAFgDIAEgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_22.setTransform(262.25,16.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAIAAIAAAfIABAGIABADIAEACIAEAAQADAAAEgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgEADQgFACgEAAQgIAAgEgEg");
	this.shape_23.setTransform(256.75,16.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAXQgFgCgDgDQgDgDgBgFQgCgFAAgFQAAgEACgFQABgEADgEQADgDAFgCQAFgCAEAAQAFAAAFACQAFACACADIAGAIQABAFAAAEQAAAFgBAFQgDAFgDADQgCADgFACQgFACgFAAQgEAAgFgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_24.setTransform(251.15,16.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_25.setTransform(245.9,16.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_26.setTransform(240.975,16.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_27.setTransform(237.575,15.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgcAhIAAhBIAXAAQAHAAAGACQAGADAFAEQAEAFADAGQADAGAAAGQAAAHgDAGQgDAGgEAFQgFAEgGADQgGACgHAAgAgUAaIAPAAQAFAAAFgCQAEgCAEgEQAEgDABgFQACgFAAgFIgCgJQgBgFgEgDQgDgEgFgCQgFgCgFAAIgPAAg");
	this.shape_28.setTransform(233.1,15.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgBABgEQABgCAAgEIAAgHQgCAEgFACQgEACgEABQgFgBgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAvQAAAFgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAFIgDAFIgBAIIABAHQABADACABIAFAFQADABADAAIAEgBIAEgBIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_29.setTransform(73.625,27.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgEABIgEABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_30.setTransform(68.15,26.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(64.275,25.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_32.setTransform(60.475,27);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgFAFgBQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAGAAAGQAAAFgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgCQgEgCgDgEIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgEIADgEIABgHIgBgIIgDgGIgFgEQgDgCgDAAQgEAAgEADg");
	this.shape_33.setTransform(54.775,27);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_34.setTransform(50.625,25.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AAMAhIAAggIAAgEIgCgDQgBgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgDABIgFACIgDACIgCADIAAAiIgIAAIAAhBIAIAAIAAAZIADgDIADgDIAFgCIAFAAQAHAAAFADQADAEAAAIIAAAhg");
	this.shape_35.setTransform(46.75,25.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAFgGIADADIAGADIAFACIAFABQAFAAADgBIAFgDQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAABgBIAAgDQAAgEgBgCIgFgDIgGgDIgGgCIgIgCIgGgCIgEgFQgCgDAAgFQAAgEACgDIAEgGIAHgEIAJgBQAHAAAHACQAFACAFAFIgGAGQgDgEgGgCQgEgCgFAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAEADIAHADIAHACIAHACIAGADIAFAFQABADAAAFIgBAHQgBAEgEACQgDADgEACQgFABgHAAQgHAAgGgDg");
	this.shape_36.setTransform(41.1,25.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape_37.setTransform(61.425,15.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAFgCQAEgCAFAAQAGAAAEACIAHAGIgFAFQgDgEgCgBQgEgCgDAAQgEAAgCACQgDABgDADIgDAGIgBAGIABAIIADAFQADADADABQACACAEAAQAHAAAFgHIAFAFIgHAGQgEACgGAAQgFAAgEgBg");
	this.shape_38.setTransform(56.15,16.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_39.setTransform(52.475,15.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIABAGIACADIAEACIAEAAQAEAAADgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_40.setTransform(48.6,16.175);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AASAdIgIADIgKABQgGABgHgDQgGgDgEgEQgEgFgDgGQgCgHAAgGQAAgHACgGQADgHAEgEQAEgFAGgCQAHgDAGAAQAHAAAGADQAHACAEAFQAEAEADAHQACAGAAAHQAAAGgCAHQgDAGgEAFIAGAHIgGAEgAgJgZQgFACgDAEQgDAEgCAEQgCAFAAAGQAAAFACAFQACAFADAEQADADAFACQAEACAFAAQAHAAAGgDIgKgKIAGgGIAJALQADgDACgFQABgFAAgFQAAgGgBgFQgCgEgDgEQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_41.setTransform(42.025,15.3);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(113.35,21.45,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(211.65,21.85,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(18.75,21.85,0.515,0.515,0,0,0,0.1,0.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_42.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-8.1,8.7,288.6,30.599999999999998), null);


// stage content:
(lib._300x250_B2B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_750 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(750).call(this.frame_750).wait(16));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_1.setTransform(150,125);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_2.setTransform(150,125);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_3.setTransform(150,125);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_4.setTransform(150,125);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_5.setTransform(150,125);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_6.setTransform(150,125);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_7.setTransform(150,125);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_8.setTransform(150,125);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(8));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(150,16,0.7142,0.7142);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(766));

	// t12
	this.instance_1 = new lib.t22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.instance_2 = new lib.t121();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},123).to({state:[{t:this.instance_2}]},173).to({state:[{t:this.instance_1}]},87).to({state:[{t:this.instance_2}]},123).to({state:[{t:this.instance_2}]},173).wait(87));

	// t11
	this.instance_3 = new lib.t11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,104.7,0.8928,0.8928,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(766));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-123,-26.3,-64.2,7.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_9.setTransform(149.85,225.375);
	this.shape_9._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-115.3,-23.6,-56.5,10.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_10.setTransform(149.85,225.375);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-107.6,-20.9,-48.8,13.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_11.setTransform(149.85,225.375);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-99.8,-18.2,-41,15.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_12.setTransform(149.85,225.375);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-92.1,-15.5,-33.3,18.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_13.setTransform(149.85,225.375);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-84.4,-12.8,-25.6,21.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_14.setTransform(149.85,225.375);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-76.7,-10.1,-17.9,23.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_15.setTransform(149.85,225.375);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.9,-7.5,-10.1,26.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_16.setTransform(149.85,225.375);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-61.2,-4.8,-2.4,29.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_17.setTransform(149.85,225.375);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-53.5,-2.1,5.3,31.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_18.setTransform(149.85,225.375);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-45.8,0.6,13,34.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_19.setTransform(149.85,225.375);
	this.shape_19._off = true;

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-38,3.3,20.8,37.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_20.setTransform(149.85,225.375);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-30.3,6,28.5,40).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_21.setTransform(149.85,225.375);
	this.shape_21._off = true;

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-22.6,8.7,36.2,42.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_22.setTransform(149.85,225.375);
	this.shape_22._off = true;

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-14.8,11.4,44,45.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_23.setTransform(149.85,225.375);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-7.1,14.1,51.7,48.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_24.setTransform(149.85,225.375);
	this.shape_24._off = true;

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,16.8,59.4,50.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_25.setTransform(149.85,225.375);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,19.5,67.1,53.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_26.setTransform(149.85,225.375);
	this.shape_26._off = true;

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],16.1,22.2,74.9,56.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_27.setTransform(149.85,225.375);
	this.shape_27._off = true;

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],23.8,24.9,82.6,58.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_28.setTransform(149.85,225.375);
	this.shape_28._off = true;

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],31.5,27.6,90.3,61.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_29.setTransform(149.85,225.375);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.2,30.3,98,64.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_30.setTransform(149.85,225.375);
	this.shape_30._off = true;

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],47,33,105.8,66.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_31.setTransform(149.85,225.375);
	this.shape_31._off = true;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],54.7,35.7,113.5,69.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_32.setTransform(149.85,225.375);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],62.4,38.4,121.2,72.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_33.setTransform(149.85,225.375);
	this.shape_33._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(169).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(170).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(50));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(171).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(172).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(48));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(173).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(47));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(174).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(46));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(175).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(45));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(176).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(44));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(177).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(43));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(178).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(42));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(179).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(41));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(180).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(40));
	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(181).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(39));
	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(182).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(38));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(183).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(37));
	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(184).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(36));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(185).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(35));
	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(186).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(34));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(187).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.shape_28).wait(188).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(189).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(190).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(30));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(191).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(29));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(192).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(193).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(220).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(86).to({_off:false},0).to({_off:true},1).wait(27));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,192.55,0.8928,0.8928,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(766));

	// Слой_5
	this.instance_5 = new lib.icons();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(26).to({_off:false},0).to({alpha:1},6).to({_off:true},91).wait(286).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},91).wait(260));

	// Слой_14
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("A3bI6IAAxzMAu3AAAIAARzg");
	this.shape_34.setTransform(150,225.175);

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(20).to({y:221.175},0).wait(1).to({y:217.175},0).wait(1).to({y:213.175},0).wait(1).to({y:209.175},0).wait(1).to({y:205.175},0).wait(1).to({y:201.175},0).wait(1).to({y:197.175},0).wait(1).to({y:193.175},0).wait(96).to({y:225.175},0).wait(280).to({y:221.175},0).wait(1).to({y:217.175},0).wait(1).to({y:213.175},0).wait(1).to({y:209.175},0).wait(1).to({y:205.175},0).wait(1).to({y:201.175},0).wait(1).to({y:197.175},0).wait(1).to({y:193.175},0).wait(96).to({y:225.175},0).wait(260));

	// Слой_4
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_35.setTransform(252.475,154.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_36.setTransform(249.375,154.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_37.setTransform(244.375,155.9208);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAMAdIgMgmIgMAmIgQAAIgSg6IAQAAIALAnIANgnIANAAIAMAnIALgnIARAAIgSA6g");
	this.shape_38.setTransform(236.55,155.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_39.setTransform(229.775,155.175);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_40.setTransform(224.225,155.9208);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_41.setTransform(219.525,154.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgTAnQgIgEgFgGIAJgOQAEAFAHADQAHADAHAAQAHAAAEgCQADgDAAgEQgBgDgCgBIgKgEIgJgDIgMgDQgFgDgDgEQgEgEAAgIQAAgHAEgGQADgFAIgEQAGgDAJAAQAKAAAIADQAIADAFAFIgJAOQgFgFgGgCQgGgCgGAAQgFAAgDACQgDACAAADQAAAEAEABIAIADIAKADQAGABAFADQAFADAEAEQAEAEgBAIQABAHgEAGQgDAGgIAEQgHADgLAAQgLAAgJgDg");
	this.shape_42.setTransform(214.3,154.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgXAoQgGgEgEgFQgDgEAAgIQAAgHACgEQADgEADgDIAJgFIgEgJIgBgIQAAgGADgEQADgEAFgEQAFgCAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAHgDAEIgHAHIgJAEIADAEIADAEIAHAIIAFgIIADgGIAMAEIgFAKIgGAKIAHAIIAIAIIgTAAIgDgCIgDgEQgFAEgGACQgEACgHAAQgHAAgGgCgAgSAKQgCADAAAEQAAAEACADIAEAEQADABAEABIAGgBIAEgEIgEgFIgEgFIgEgFIgEgGIgFAGgAgGgcQgDADAAAEIABAFIADAGIAHgFQAEgEAAgEQAAgDgCgCQgCgBgCgBQgEAAgCACg");
	this.shape_43.setTransform(203.725,154.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAHADIAGABQAFAAACgBQADgCAAgDQAAgCgEgCIgIgCIgKgDQgEgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAHAAAHACQAFADAFADIgHALQgCgDgEgCQgGgCgFAAQgDAAgCACQgBAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgHAAgGgDg");
	this.shape_44.setTransform(264.95,143.725);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_45.setTransform(258.75,143.725);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgHAdIgYg5IARAAIAOAnIAPgnIARAAIgYA5g");
	this.shape_46.setTransform(252.225,143.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_47.setTransform(247.525,142.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_48.setTransform(242.65,143.725);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAMAoIAAgkQAAgEgDgCQgDgDgFAAQgDAAgEACQgDACgCACIAAAnIgQAAIAAhQIAQAAIAAAeIAFgEIAGgDIAJgBQAJgBAFAFQAFAFAAAJIAAAog");
	this.shape_49.setTransform(235.725,142.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgTAmQgIgDgFgGIAJgNQAEAEAHAEQAGADAIAAQAHgBAEgCQADgDAAgDQAAgEgDgCIgJgDIgKgCIgMgFQgFgCgEgEQgDgEAAgIQAAgHAEgFQADgGAIgDQAGgEAJAAQAKAAAHADQAIADAHAGIgKAMQgFgEgGgDQgGgBgGgBQgFABgDABQgDADAAAEQAAACADACIAJAEIAKACQAGABAGAEQAEACAEADQADAGAAAHQAAAHgDAGQgDAGgIADQgHAEgLAAQgKAAgKgEg");
	this.shape_50.setTransform(228.5,142.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgIAMQADgCADgDQACgDABgDIgBAAIgBAAQgDAAgDgBQgCgDAAgDQAAgFADgDQADgCADAAQAEAAADADQADADAAAGQAAAGgDAGQgDAFgFAFg");
	this.shape_51.setTransform(220.275,146.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAGADIAHABQAFAAACgBQADgCAAgDQAAgCgEgCIgHgCIgKgDQgFgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAIAAAGACQAFADAFADIgHALQgCgDgFgCQgEgCgGAAQgDAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgGAAgHgDg");
	this.shape_52.setTransform(215.7,143.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAKAoIgPgWIgHAIIAAAOIgQAAIAAhQIAQAAIAAAwIAVgZIATAAIgXAaIAYAfg");
	this.shape_53.setTransform(209.975,142.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_54.setTransform(203.375,143.725);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_55.setTransform(196.775,143.7208);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AANAoIgPgdIgMAAIAAAdIgSAAIAAhQIAlAAQAIABAHADQAGADADAGQADAGAAAHQABAHgDAGQgDADgEAEQgEADgFABIATAegAgOgCIARAAQAFgBADgDQADgCAAgGQAAgEgDgEQgDgDgFAAIgRAAg");
	this.shape_56.setTransform(189.9,142.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgVApIgDgBIACgNIACABIADAAIAFgBIADgEIACgFIgYg7IARAAIAOApIAPgpIARAAIgcBEQgCAFgCAEQgDADgFABQgEABgFAAIgEAAg");
	this.shape_57.setTransform(100.075,158.15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCgBIgCAAIgGABIgFADIgDADIAAAmg");
	this.shape_58.setTransform(95.025,156.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_59.setTransform(90.475,156.225);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_60.setTransform(85.05,156.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgCgFgBQgDAAgEACQgDADgCADIAAAmIgQAAIAAg6IAQAAIAAAHIAFgEIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_61.setTransform(78.175,156.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_62.setTransform(73.075,155.725);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgFAnQgFgCgEgFIAAAIIgPAAIAAhQIAPAAIAAAdQAEgEAFgCQAEgCAFAAQAHAAAGADQAGAEAEAHQADAGAAAJQAAAKgDAHQgEAHgGAEQgGADgHAAQgFAAgEgCgAgHgEIgHAEIAAAVIAHAFQADABAEAAQAGAAAEgEQAEgFAAgIQAAgHgEgEQgEgFgGAAQgEAAgDACg");
	this.shape_63.setTransform(68.15,155.925);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_64.setTransform(60.925,156.9708);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgKgBgMQABgLAFgKQAGgJAKgGQAJgFAMAAQAJAAAGADQAHADAEAEQAFAEADAGIgPAHQgDgFgFgDQgFgDgGgBQgHABgGADQgFADgDAGQgEAGAAAHQAAAHAEAHQADAFAFAEQAGADAHAAQAGAAAFgDQAFgDADgFIAPAHIgIAKQgEAEgHADQgGADgJAAQgMAAgJgGg");
	this.shape_65.setTransform(53.725,155.85);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_66.setTransform(115.125,143.725);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_67.setTransform(108.2,144.775);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgEgHQgEgHAAgIQAAgIAEgHQAEgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQAEgDABgEQACgEAAgEQAAgEgCgEQgBgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_68.setTransform(101.2,144.775);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAOAoIgOg2IgNA2IgSAAIgYhQIAUAAIAOA6IAPg6IANAAIAPA6IAPg6IATAAIgXBQg");
	this.shape_69.setTransform(92.125,143.65);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgFgCgCQgCgDgFAAQgEABgDACIgFAEIAAAnIgPAAIAAgkQAAgFgCgCQgCgDgEAAQgFABgDACIgFAEIAAAnIgPAAIAAg6IAPAAIAAAIIAEgEIAHgEQAEgBAFAAQAGAAADACQAEADACAFIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAEAAAKIAAApg");
	this.shape_70.setTransform(78.175,144.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_71.setTransform(69.475,144.825);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_72.setTransform(64.425,143.525);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgFgCgCQgCgDgFAAQgEABgDACIgFAEIAAAnIgPAAIAAgkQAAgFgCgCQgCgDgEAAQgFABgDACIgFAEIAAAnIgPAAIAAg6IAPAAIAAAIIAEgEIAHgEQAEgBAFAAQAGAAADACQAEADACAFIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAEAAAKIAAApg");
	this.shape_73.setTransform(57.675,144.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_74.setTransform(49.15,144.775);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_75.setTransform(43.825,144.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AggAoIAAhQIAlAAQAJABAGADQAGADADAHQAEAFAAAHQAAAIgEAFQgDAGgGADQgGADgJABIgTAAIAAAcgAgOgDIARAAQAFAAADgCQAEgEAAgFQAAgEgEgEQgDgCgFAAIgRAAg");
	this.shape_76.setTransform(37.825,143.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35}]},296).to({state:[]},87).to({state:[{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35}]},296).wait(87));

	// Слой_3
	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFACQAFABAFAAIAHgBQADgCADgDQACgDAAgGIAAgGQgDAFgFACQgEACgFAAQgHAAgGgDQgGgDgDgHQgEgFAAgLQAAgJAEgHQADgHAGgDQAGgDAHAAQAEAAAFACQAFACADAFIAAgIIAQAAIAAA2QAAAIgDAGQgDAGgFADQgEADgGAAIgKACQgHAAgHgCgAgJgXQgEAEAAAHQAAAJAEADQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgBQgEgDgEAAQgGAAgEAFg");
	this.shape_77.setTransform(245.925,157.05);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AAMAeIAAgiQAAgHgDgCQgDgDgFAAQgDAAgEADQgDACgCACIAAAnIgQAAIAAg6IAQAAIAAAIIAFgFIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_78.setTransform(239.075,155.85);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_79.setTransform(233.975,154.675);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCgBIgCAAIgGACIgFACIgDADIAAAmg");
	this.shape_80.setTransform(230.525,155.85);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgPAaQgHgEgFgHQgDgHAAgIQAAgIADgHQAFgHAHgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_81.setTransform(224.55,155.925);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_82.setTransform(217.55,155.925);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_83.setTransform(212.475,154.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgcAoIAAhQIA5AAIAAAQIgnAAIAAARIAmAAIAAAOIgmAAIAAAhg");
	this.shape_84.setTransform(207.675,154.8);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgFACgIAAQgIAAgHgEgAAPgFIgCgGIgEgEQgDgCgFAAQgEAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_85.setTransform(275.25,143.725);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_86.setTransform(268.075,142.675);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_87.setTransform(261.225,143.7208);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_88.setTransform(256.175,143.65);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgRAkQgJgEgGgKQgFgJgBgNQABgMAFgKQAGgIAJgGQAKgFAMAAQAIAAAHADQAFACAGAEQAEAEADAFIgOAIQgDgEgFgEQgFgDgGAAQgHABgGADQgGADgDAGQgDAGAAAHQAAAIADAFQADAHAGADQAGADAHABQAFAAAEgCQAFgCADgDIAAgKIgWAAIAAgOIAnAAIAAAfQgGAGgJAFQgIAEgLAAQgMAAgKgGg");
	this.shape_89.setTransform(249.2,142.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgOAHIAAgNIAdAAIAAANg");
	this.shape_90.setTransform(243.075,143.7);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_91.setTransform(239.725,142.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_92.setTransform(234.675,143.7208);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_93.setTransform(230.025,142.475);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_94.setTransform(225.525,143.725);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_95.setTransform(220.475,143.65);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_96.setTransform(214.65,143.725);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgEgCgDQgCgDgFABQgEAAgDABIgFAGIAAAmIgPAAIAAgkQAAgEgCgDQgCgDgEABQgFAAgDABIgFAGIAAAmIgPAAIAAg6IAPAAIAAAHIAEgDIAHgEQAEgBAFAAQAGAAADADQAEADACAEIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAFAAAIIAAAqg");
	this.shape_97.setTransform(206.025,143.65);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgEgCgDQgCgDgFABQgEAAgDABIgFAGIAAAmIgPAAIAAgkQAAgEgCgDQgCgDgEABQgFAAgDABIgFAGIAAAmIgPAAIAAg6IAPAAIAAAHIAEgDIAHgEQAEgBAFAAQAGAAADADQAEADACAEIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAFAAAIIAAAqg");
	this.shape_98.setTransform(195.625,143.65);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_99.setTransform(186.95,143.725);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgKgBgMQABgLAFgKQAGgKAKgEQAJgGAMAAQAJAAAGADQAHADAEAEQAFAFADAFIgPAHQgDgFgFgDQgFgDgGgBQgHABgGADQgFADgDAGQgEAGAAAHQAAAIAEAFQADAHAFADQAGADAHABQAGgBAFgDQAFgDADgFIAPAHIgIAJQgEAFgHADQgGADgJAAQgMAAgJgGg");
	this.shape_100.setTransform(179.375,142.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAGAEAEAHQAEAIAAAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_101.setTransform(100.1,156.975);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAHgBQADgBADgDQACgEAAgGIAAgGQgDAFgFACQgEADgFgBQgHAAgGgDQgGgDgDgHQgEgFAAgKQAAgKAEgHQADgHAGgCQAGgEAHAAQAEAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGACIgKABQgHAAgHgCgAgJgXQgEAEAAAIQAAAHAEAEQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgCQgEgCgEAAQgGABgEAEg");
	this.shape_102.setTransform(92.975,158.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_103.setTransform(86.125,156.9708);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCgBIgCAAIgGABIgFADIgDADIAAAmg");
	this.shape_104.setTransform(81.075,156.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgEgHQgEgHAAgIQAAgIAEgHQAEgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQAEgDABgEQACgEAAgEQAAgEgCgEQgBgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_105.setTransform(75.1,156.975);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_106.setTransform(69.525,156.225);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgSAmQgJgDgGgGIAKgNQAEAEAHAEQAGACAIAAQAHABADgDQAEgDAAgEQgBgDgDgBIgJgEIgKgCIgLgFQgFgCgDgEQgEgFAAgHQAAgHAEgFQAEgGAGgDQAIgEAIAAQAJAAAJADQAHADAGAGIgJAMQgFgEgGgDQgHgCgEAAQgGAAgDACQgDADAAADQAAAEAEACIAIADIAKACQAGACAFADQAFACAEAEQAEAFAAAHQAAAHgEAGQgEAGgHADQgHAEgLAAQgKAAgJgEg");
	this.shape_107.setTransform(63.75,155.85);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgXAoQgGgEgEgEQgDgGAAgIQAAgFACgFQADgFADgDIAJgEIgEgJIgBgIQAAgGADgEQADgFAFgCQAFgDAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAGgDAFIgHAGIgJAGIADADIADAFIAHAIIAFgIIADgHIAMAFIgFAKIgGAJIAHAIIAIAJIgTAAIgDgDIgDgDQgFADgGACQgEACgHAAQgHAAgGgCgAgSAKQgCADAAAEQAAAEACADIAEAEQADABAEAAIAGgBIAEgDIgEgFIgEgEIgEgGIgEgFIgFAFgAgGgcQgDADAAAEIABAFIADAGIAHgGQAEgDAAgEQAAgDgCgCQgCgCgCABQgEAAgCABg");
	this.shape_108.setTransform(53.175,155.85);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_109.setTransform(122.95,144.775);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_110.setTransform(117.625,144.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_111.setTransform(111.625,144.825);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_112.setTransform(106.075,144.025);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_113.setTransform(102.425,143.525);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AAMAeIAAgiQAAgHgDgCQgDgDgFAAQgDABgEACQgDACgCACIAAAnIgQAAIAAg6IAQAAIAAAIIAFgFIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_114.setTransform(97.375,144.7);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_115.setTransform(91.925,144.7);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_116.setTransform(85.925,144.825);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgcAoIAAhQIA5AAIAAAQIgnAAIAAARIAmAAIAAAOIgmAAIAAAhg");
	this.shape_117.setTransform(79.125,143.65);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_118.setTransform(70.425,144.7);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_119.setTransform(64.45,144.775);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgQAaQgHgEgDgHQgEgHAAgIQAAgIAEgHQADgHAHgEQAIgEAIAAQAJAAAIAEQAHAEAEAHQADAHAAAIQAAAIgDAHQgEAHgHAEQgIAFgJAAQgIAAgIgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_120.setTransform(57.45,144.775);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_121.setTransform(50.175,143.725);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_122.setTransform(44.725,144.025);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_123.setTransform(39.125,144.825);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgVAlQgJgGgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgFQAJgGAMAAQANAAAJAGQAKAFAFAJQAFAJAAAMQAAAMgFAKQgFAJgKAGQgJAFgNAAQgMAAgJgFgAgMgWQgGAEgDAFQgCAHAAAGQAAAIACAFQADAGAGAEQAFAEAHAAQAHAAAGgEQAGgEADgGQACgFAAgIQAAgGgCgHQgDgFgGgEQgGgEgHABQgHgBgFAEg");
	this.shape_124.setTransform(30.95,143.65);

	this.instance_6 = new lib.pc4("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(208.55,125,0.8929,0.8929,0,0,0,233.6,140);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77}]},209).to({state:[{t:this.instance_6}]},87).to({state:[]},87).to({state:[{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77}]},209).to({state:[{t:this.instance_6}]},87).wait(87));

	// Слой_9
	this.instance_7 = new lib.pc31("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(208.55,125,0.8929,0.8929,0,0,0,233.6,140);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(209).to({_off:false},0).to({_off:true},87).wait(296).to({_off:false},0).to({_off:true},87).wait(87));

	// Слой_2
	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgKgDQgGgBgDgDQgDgEgBgGQAAgFADgFQADgEAFgCQAFgDAHAAQAIAAAFACQAHADAEADIgGALQgDgDgFgCQgFgCgFAAQgDAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgHAAgHgDg");
	this.shape_125.setTransform(278.95,156.325);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAHgEAIAAQAJAAAHAEQAHAEADAHQAEAIAAAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAEgDIAIALQgFAEgGACQgHACgHAAQgHAAgIgEgAAPgFIgCgGIgEgEQgEgCgFAAQgEAAgDACQgDABgBADIgCAGIAcAAIAAAAg");
	this.shape_126.setTransform(272.75,156.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_127.setTransform(266.425,156.325);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEACQgDABgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_128.setTransform(259.775,156.25);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_129.setTransform(252.725,156.3208);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_130.setTransform(248.075,155.075);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_131.setTransform(244.975,155.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgdApIAAhQIAQAAIAAAHQADgEAFgCQAFgCAEAAQAHAAAGADQAGAEADAHQADAGABAKQgBAKgDAGQgDAHgGADQgGAEgHAAQgFAAgEgCQgEgCgEgFIAAAegAgIgZQgDACgCADIAAAUQACADADABQAEACAEAAQAFAAAEgEQAFgEAAgIQAAgHgFgFQgEgFgFAAQgEAAgEACg");
	this.shape_132.setTransform(240.1,157.375);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgdApIAAhQIAQAAIAAAHQADgEAFgCQAFgCAEAAQAHAAAGADQAGAEADAHQAEAGAAAKQAAAKgEAGQgDAHgGADQgGAEgHAAQgEAAgFgCQgEgCgEgFIAAAegAgIgZQgDACgCADIAAAUQABADAEABQAEACAEAAQAFAAAEgEQAFgEAAgIQAAgHgFgFQgEgFgFAAQgEAAgEACg");
	this.shape_133.setTransform(233,157.375);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AAWAoIgFgNIghAAIgGANIgTAAIAfhQIAVAAIAfBQgAANALIgNgiIgMAiIAZAAg");
	this.shape_134.setTransform(225.075,155.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_135.setTransform(215.875,156.25);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_136.setTransform(209.9,156.325);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgEgHQgEgHAAgIQAAgIAEgHQAEgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQAEgDABgEQACgEAAgEQAAgEgCgEQgBgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_137.setTransform(202.9,156.325);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_138.setTransform(195.625,155.275);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_139.setTransform(190.175,155.575);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_140.setTransform(184.625,156.375);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgVAkQgKgFgFgKQgFgIAAgNQAAgLAFgKQAFgJAKgFQAJgGAMAAQANAAAJAGQAKAFAFAJQAGAKgBALQABANgGAIQgFAKgKAFQgJAGgNAAQgMAAgJgGgAgMgWQgGADgDAGQgCAHAAAGQAAAIACAFQADAHAGADQAFADAHABQAIgBAFgDQAGgDADgHQACgFAAgIQAAgGgCgHQgDgGgGgDQgFgDgIAAQgHAAgFADg");
	this.shape_141.setTransform(176.4,155.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgVApIgDAAIACgPIACACIADAAIAFgCIADgDIACgFIgYg6IARAAIAOAoIAPgoIARAAIgcBDQgCAFgCADQgDAEgFABQgEACgFgBIgEAAg");
	this.shape_142.setTransform(115.625,157.5);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_143.setTransform(110.575,156.25);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_144.setTransform(106.075,155.575);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgFACgIAAQgIAAgHgEgAAPgFIgCgGIgEgEQgDgCgFAAQgEAAgDACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_145.setTransform(100.65,156.325);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEACQgDABgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_146.setTransform(93.725,156.25);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_147.setTransform(88.625,155.075);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgFAnQgFgCgEgFIAAAIIgPAAIAAhQIAPAAIAAAdQAEgEAFgCQAFgCAEAAQAIAAAFADQAGAEAEAHQACAGABAJQgBAKgCAHQgEAHgGAEQgFADgIAAQgEAAgFgCgAgIgEIgGAEIAAAVIAGAFQAEABAEAAQAGAAAEgEQAEgFAAgIQAAgHgEgEQgEgFgGAAQgEAAgEACg");
	this.shape_148.setTransform(83.75,155.275);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_149.setTransform(76.475,156.3208);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgKgBgMQABgLAFgKQAGgKAKgEQAJgGAMAAQAJAAAGADQAHADAEAEQAFAFADAFIgPAHQgDgFgFgDQgFgDgGAAQgHAAgGADQgFADgDAGQgEAGAAAHQAAAIAEAFQADAHAFADQAGADAHABQAGgBAFgDQAFgDADgFIAPAHIgIAJQgEAFgHADQgGADgJAAQgMAAgJgGg");
	this.shape_150.setTransform(69.275,155.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_151.setTransform(60.325,155.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_152.setTransform(55.45,156.325);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_153.setTransform(48.7,156.325);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_154.setTransform(43.275,155.575);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgTAmQgIgDgGgGIAKgNQAEAEAHAEQAHADAHAAQAHgBAEgCQADgDAAgDQgBgEgCgCIgJgDIgLgCIgLgFQgFgCgEgEQgDgEAAgIQAAgHAEgFQAEgGAGgDQAIgEAIAAQAKAAAHADQAIADAHAGIgKAMQgFgEgGgDQgHgCgFABQgFgBgDACQgDADAAAEQAAACADACIAJAEIAKACQAGABAGAEQAFACADADQADAGABAHQgBAHgDAGQgEAGgHADQgHAEgLAAQgKAAgKgEg");
	this.shape_155.setTransform(37.5,155.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125}]},123).to({state:[]},86).to({state:[{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125}]},297).to({state:[]},86).wait(174));

	// Слой_7
	this.instance_8 = new lib.pc21("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(208.7,125.7,0.8958,0.8958,0,0,0,233.4,140.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(123).to({_off:false},0).to({_off:true},86).wait(297).to({_off:false},0).to({_off:true},86).wait(174));

	// pc11
	this.instance_9 = new lib.pc11();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150,123.5,0.8928,0.8928,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({y:105},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(260).to({_off:false,y:123.5},0).to({y:105},122,cjs.Ease.get(-0.5)).to({_off:true},1).wait(260));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(147.5,101.1,220.60000000000002,181.1);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_B2B_atlas_P_.png", id:"300x250_B2B_atlas_P_"},
		{src:"images/300x250_B2B_atlas_NP_.jpg", id:"300x250_B2B_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;