(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_B2B_atlas_P_", frames: [[0,128,143,51],[0,0,380,126]]},
		{name:"728x90_B2B_atlas_NP_", frames: [[0,282,380,126],[382,331,56,43],[382,376,48,45],[382,282,56,47],[0,0,392,280]]}
];


// symbols:



(lib.Растровоеизображение14 = function() {
	this.initialize(ss["728x90_B2B_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["728x90_B2B_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["728x90_B2B_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["728x90_B2B_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.logoblack = function() {
	this.initialize(ss["728x90_B2B_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen111111 = function() {
	this.initialize(ss["728x90_B2B_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.screen21111 = function() {
	this.initialize(ss["728x90_B2B_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t222 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape.setTransform(566.5,-103.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_1.setTransform(563.15,-106.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgIAeQgFgCgFgFQgEgEgCgGQgCgGAAgHQAAgGACgGQACgGAEgFQAFgEAFgDQAGgCAGAAQAJAAAFADQAGAEADAEIgGAGQgDgFgEgBQgEgCgFAAQgFAAgDABQgEACgDAEQgDADgBAFQgCAEAAAEQAAAGACAEQABAEADAEQADADAEABQADACAFABQAKAAAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgDg");
	this.shape_2.setTransform(558.075,-105.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgKAeQgGgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAFgFAFgDQAGgCAGAAQAGAAAGACQAGADAEAFQADAEADAGQABAHAAAGIAAACIgxAAQAAAFACADQABAEADAEQAEADADABQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgGADgIAAQgHAAgFgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgDgDgDgCQgEgCgFAAQgFAAgDACg");
	this.shape_3.setTransform(551.1,-105.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgKA2IgGgDIADgIIAEADIAFABQAEAAADgDQADgCAAgGIAAhEIAJAAIAABEQAAAJgEAFQgFAFgIAAIgIgBgAAGgrQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAgBAAAAQAAgDACgCQABgBAAAAQABAAAAgBQABAAAAAAQABAAABAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAABQACACAAADQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_4.setTransform(544.95,-105.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgMAeQgGgCgDgFQgEgEgDgGQgCgGAAgHQAAgFACgHQADgGAEgEQADgFAGgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEABQAFgBAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_5.setTransform(540.8,-105.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgOAgIAAg+IAKAAIAAAKQADgEAFgEQAFgDAGAAIAAAKIgDAAIgFABIgFABIgEAEIgCAEIAAArg");
	this.shape_6.setTransform(535.3,-105.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgcAsIAAhWIAJAAIAAAKQAEgFAFgDQAGgDAGAAQAGAAAFACQAFACAEAFQADAEACAGQACAGAAAIQAAAHgCAGQgCAGgDAEQgEAEgFADQgFACgGAAQgGAAgFgDQgGgDgEgFIAAAhgAgLgfQgFACgDAFIAAAbQADAEAFADQAFADAGAAQAEAAADgCQAEgBADgEIAEgHQABgEAAgFQAAgFgBgFQgCgEgCgDQgDgEgEgCQgDgBgEAAQgGAAgFADg");
	this.shape_7.setTransform(529.275,-104.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgOAgIAAg+IAKAAIAAAKQADgEAFgEQAFgDAGAAIAAAKIgDAAIgFABIgFABIgEAEIgCAEIAAArg");
	this.shape_8.setTransform(520.2,-105.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIACAHIADAFIAEACIAFABQAFAAAFgDQAFgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgGADQgFADgGAAQgKAAgFgFg");
	this.shape_9.setTransform(514.15,-105.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgMAeQgGgCgEgFQgDgEgDgGQgCgGAAgHQAAgFACgHQADgGADgEQAEgFAGgDQAGgCAGAAQAIAAAFACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgFADgIAAQgGAAgGgDgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEABQAFgBAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_10.setTransform(506.8,-105.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgVAsIgEgBIACgJIACABIADABQADAAADgCQACgBABgEIAFgKIgbg+IALAAIAUAyIAVgyIALAAIggBKQgCAHgEADQgGADgGAAIgDAAg");
	this.shape_11.setTransform(499.95,-104.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgKAeQgGgCgEgEQgFgEgCgHQgDgFABgIQgBgFADgHQACgGAFgEQAEgFAFgDQAGgCAFAAQAIAAAGACQAFADAEAFQADAEACAGQACAHABAGIAAACIgyAAQAAAFACADQABAEAEAEQACADAEABQAFACADAAQAGAAAFgCQAFgCAEgEIAEAGQgEAFgGACQgHADgIAAQgGAAgFgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgCgDgFgCQgDgCgGAAQgEAAgEACg");
	this.shape_12.setTransform(489.75,-105.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_13.setTransform(484.25,-106.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAeQgGgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAFgFAFgDQAGgCAGAAQAGAAAGACQAGADAEAFQADAEADAGQABAHAAAGIAAACIgxAAQAAAFACADQABAEADAEQAEADADABQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgGADgJAAQgGAAgFgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgDgDgDgCQgEgCgFAAQgEAAgEACg");
	this.shape_14.setTransform(478.65,-105.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgEArIAAhVIAJAAIAABVg");
	this.shape_15.setTransform(473.55,-107.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgcAsIAAhWIAJAAIAAAKQAEgFAFgDQAGgDAGAAQAGAAAFACQAFACAEAFQADAEACAGQACAGAAAIQAAAHgCAGQgCAGgDAEQgEAEgFADQgFACgGAAQgGAAgFgDQgGgDgEgFIAAAhgAgLgfQgFACgDAFIAAAbQADAEAFADQAFADAGAAQAEAAADgCQAEgBADgEIAEgHQABgEAAgFQAAgFgBgFQgCgEgCgDQgDgEgEgCQgDgBgEAAQgGAAgFADg");
	this.shape_16.setTransform(468.575,-104.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAhAgIAAgpQAAgGgDgEQgCgDgHAAQgFAAgEADQgFACgCAEIAAAtIgJAAIAAgpQAAgGgDgEQgCgDgHAAQgEAAgFADQgFADgCADIAAAtIgKAAIAAg+IAKAAIAAAKIADgEIAEgDIAHgDIAGgBQAHAAAFADQADAEABAFIAEgFIAEgDIAHgDIAHgBQAIAAAEAFQAFAEAAAKIAAAsg");
	this.shape_17.setTransform(459.4,-105.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgMAeQgFgCgFgFQgDgEgCgGQgDgGAAgHQAAgFADgHQACgGADgEQAFgFAFgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgHAFIgDAIIgBAIIABAKIADAHIAHAFQAEACAEABQAFgBAEgCQAEgCADgDIADgHQACgFAAgFIgCgIIgDgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_18.setTransform(450.4,-105.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgIAeQgFgCgFgFQgEgEgCgGQgCgGAAgHQAAgGACgGQACgGAEgFQAFgEAFgDQAGgCAGAAQAJAAAFADQAGAEADAEIgGAGQgDgFgEgBQgEgCgFAAQgFAAgDABQgEACgDAEQgDADgBAFQgCAEAAAEQAAAGACAEQABAEADAEQADADAEABQADACAFABQAKAAAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgDg");
	this.shape_19.setTransform(443.575,-105.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgMAeQgFgCgEgFQgFgEgCgGQgCgGAAgHQAAgFACgHQACgGAFgEQAEgFAFgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgGAFIgFAIIAAAIIAAAKIAFAHIAGAFQAEACAEABQAFgBAEgCQAEgCACgDIAEgHQACgFAAgFIgCgIIgEgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_20.setTransform(433.15,-105.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_21.setTransform(427.6,-106.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAeQgHgCgEgFIAFgHQADAEAFACQAGADAFAAQAIAAAEgDQADgDABgFQgBgEgCgBIgHgEIgJgCIgJgDQgFgCgDgDQgCgDAAgGIABgHIAEgFQAEgDAEgCQAEgBAFAAQAIAAAGADQAFACAEAEIgFAHQgCgEgFgCQgFgCgGAAQgGAAgEADQgDADAAAEQAAADADACQADACAEABIAJACIAJAEIAHAEQADAEAAAGQAAAEgBADQgCAEgEADQgDACgEABQgFACgGAAQgGAAgHgDg");
	this.shape_22.setTransform(419.2,-105.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIABAHIAEAFIAEACIAGABQAFAAAEgDQAFgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_23.setTransform(412.7,-105.825);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AAQArIAAgpIgBgGIgDgEQgCgCgCgBIgGAAIgFAAIgEADIgFADIgDADIAAAtIgKAAIAAhVIAKAAIAAAhIADgEIAGgEIAGgCIAGgBQAKAAAFAFQAFAFAAAKIAAArg");
	this.shape_24.setTransform(402.15,-107.075);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgDAlQgEgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIANAAIAAAJIgNAAIAAAmQAAAEACACQABACADAAIAEgBIADgBIADAHIgFADIgHABQgGAAgDgEg");
	this.shape_25.setTransform(396.7,-106.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAqIAAg+IAIAAIAAA+gAgDgeQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgEACgCQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQABACAAAEQAAAAAAABQAAAAAAABQAAAAgBABQAAABAAAAQgBABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_26.setTransform(393.3,-107);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AAQAfIgQgxIgPAxIgKAAIgUg+IAKAAIAPAyIARgyIAHAAIARAyIAPgyIAKAAIgUA+g");
	this.shape_27.setTransform(387.075,-105.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AAPArIgVgcIgLAKIAAASIgKAAIAAhVIAKAAIAAA4IAgghIANAAIgcAcIAcAig");
	this.shape_28.setTransform(375.975,-107.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAgIAAg+IAJAAIAAAKQAEgEAEgEQAGgDAGAAIAAAKIgDAAIgFABIgFABIgEAEIgDAEIAAArg");
	this.shape_29.setTransform(370.45,-105.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgMAeQgFgCgEgFQgFgEgBgGQgDgGAAgHQAAgFADgHQABgGAFgEQAEgFAFgDQAGgCAGAAQAIAAAFACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgFADgIAAQgGAAgGgDgAgIgVIgHAFIgEAIIAAAIIAAAKIAEAHIAHAFQAEACAEABQAFgBAEgCQAEgCADgDIADgHQACgFAAgFIgCgIIgDgIQgDgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_30.setTransform(364.2,-105.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AATArIgThFIgTBFIgLAAIgZhVIAMAAIATBHIAVhHIAIAAIAUBHIAThHIALAAIgYBVg");
	this.shape_31.setTransform(354.75,-107.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t222, new cjs.Rectangle(346.9,-115,223.20000000000005,17), null);


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgKAeQgGgCgEgEQgFgEgCgHQgDgFABgIQgBgFADgHQACgGAFgEQAEgFAFgDQAGgCAFAAQAHAAAHACQAFADAEAFQADAEACAGQACAHABAGIAAACIgyAAQAAAFACADQABAEAEAEQACADAEABQAFACADAAQAGAAAFgCQAFgCAEgEIAEAGQgEAFgGACQgHADgIAAQgGAAgFgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgCgDgFgCQgDgCgGAAQgDAAgFACg");
	this.shape.setTransform(584.25,-105.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIABAHIAEAFIAEACIAGABQAEAAAFgDQAFgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_1.setTransform(577.05,-105.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEArIAAhVIAJAAIAABVg");
	this.shape_2.setTransform(572,-107.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgLAgIgHgEQgEgDgCgEQgCgEAAgFQAAgFACgEIAGgGQADgCAEgBIAHgBQAGAAAGABQAFADAEADIAAgKQgBgGgEgEQgFgDgHgBQgKAAgHAJIgFgHQAKgKAOAAQAFAAAEABQAEABAEADQADACADAEQACAFAAAGIAAApIgKAAIAAgGQgJAIgMAAIgHgBgAgLACQgEAEAAAGQAAAHAEADQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgLQgEgFgEgBQgEgBgFAAQgHAAgEACg");
	this.shape_3.setTransform(566.95,-105.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgFAfIgag+IALAAIAUAzIAUgzIALAAIgaA+g");
	this.shape_4.setTransform(560.55,-105.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAAKQAEgEAEgEQAGgDAHAAIAAAKIgFAAIgEABIgFABIgDAEIgEAEIAAArg");
	this.shape_5.setTransform(552.2,-105.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAEgFAGgDQAGgCAGAAQAGAAAGACQAGADAEAFQAEAEACAGQABAHAAAGIAAACIgxAAQAAAFACADQABAEADAEQADADAEABQAFACADAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgHACQgGADgHAAQgHAAgGgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_6.setTransform(546.05,-105.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgEAfIgag+IAKAAIAUAzIAUgzIAMAAIgbA+g");
	this.shape_7.setTransform(539.25,-105.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgEAqIAAg+IAJAAIAAA+gAgEgeQAAAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgEABgCQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQACACAAAEQAAAAAAABQAAAAAAABQAAAAgBABQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_8.setTransform(534.6,-107);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEArIAAhVIAJAAIAABVg");
	this.shape_9.setTransform(531.7,-107.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgEgEgCgHQgCgFgBgIQABgFACgHQACgGAEgEQAFgFAFgDQAGgCAGAAQAHAAAFACQAGADAEAFQAEAEACAGQABAHAAAGIAAACIgxAAQAAAFACADQABAEADAEQAEADAEABQADACAFAAQAFAAAFgCQAFgCAEgEIAFAGQgFAFgHACQgGADgHAAQgHAAgGgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_10.setTransform(526.6,-105.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgMAqQgFgCgEgEQgDgFgCgGQgCgGgBgIQABgHACgGQACgFADgFQAEgEAFgDQAFgCAHAAQAFAAAGADQAFADAEAFIAAghIAKAAIAABVIgKAAIAAgJQgEAFgFADQgGADgFAAQgGAAgGgCgAgGgLQgEACgDAEQgDADgBAEIgBAJIABAKIAEAIQADADAEABQADACAEABQAGgBAFgDQAFgCADgFIAAgbQgDgEgFgDQgFgDgGAAQgEAAgDABg");
	this.shape_11.setTransform(519.05,-107);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAeQgGgCgDgFQgEgEgDgGQgCgGAAgHQAAgFACgHQADgGAEgEQADgFAGgDQAGgCAGAAQAHAAAGACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgGADgHAAQgGAAgGgDgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEABQAFgBAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_12.setTransform(508.4,-105.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_13.setTransform(502.85,-106.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgMAqQgFgCgEgEQgDgFgDgGQgCgGAAgIQAAgHACgGQADgFADgFQAEgEAFgDQAGgCAFAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABVIgKAAIAAgJQgEAFgFADQgGADgGAAQgGAAgFgCgAgGgLQgEACgDAEQgDADgBAEIgBAJIABAKIAEAIQADADAEABQADACAEABQAGgBAFgDQAFgCADgFIAAgbQgDgEgFgDQgFgDgGAAQgEAAgDABg");
	this.shape_14.setTransform(493.65,-107);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgDgEgDgHQgCgFgBgIQABgFACgHQADgGADgEQAEgFAGgDQAGgCAGAAQAHAAAFACQAGADAEAFQADAEADAGQACAHAAAGIAAACIgyAAQAAAFACADQACAEADAEQACADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgGADgHAAQgGAAgHgDgAgHgWIgGAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_15.setTransform(486.45,-105.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AAQAgIAAgoQAAgIgEgDQgEgDgGAAIgEAAIgFADIgFADIgEADIAAAtIgJAAIAAg+IAJAAIAAAKIAFgEIAFgEIAGgCIAGgBQAUAAAAAUIAAArg");
	this.shape_16.setTransform(479.2,-105.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgNArQgGgCgGgGIAFgHQAEAFAFACQAEACAHAAIAHgBQADgBADgCIAFgGQABgEABgFIAAgJQgEAFgFADQgGADgGAAQgFAAgGgCQgFgCgEgFQgDgDgCgHQgDgEAAgIQAAgIADgGQACgGADgEQAEgEAFgDQAFgCAGAAQAGAAAGADQAFADAEAFIAAgKIAKAAIAAA8QgBAIgCAGQgCAFgFADQgEADgFABIgLACQgIAAgFgCgAgGgiQgFACgCAEQgDADgBAEIgBAKIABAKIAEAGQACADAFACQADABAEAAIAFAAIAGgDIAEgCIAEgFIAAgaIgEgEIgEgDIgGgDIgFAAQgEAAgDABg");
	this.shape_17.setTransform(471.7,-104.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAqIAAg+IAIAAIAAA+gAgDgeQgBAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgEADgCQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQACACAAAEQAAAAgBABQAAAAAAABQAAAAgBABQAAABAAAAQgBABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_18.setTransform(466.7,-107);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAFACQAGADAGAAQAHAAAEgDQADgDAAgFQAAgEgCgBIgIgEIgIgCIgKgDQgEgCgDgDQgCgDAAgGIABgHIAFgFQADgDAEgCQAFgBAEAAQAIAAAGADQAFACAEAEIgEAHQgDgEgFgCQgFgCgGAAQgFAAgFADQgDADAAAEQAAADADACQACACAFABIAIACIAKAEIAHAEQADAEAAAGQAAAEgCADQgBAEgDADQgDACgFABQgFACgGAAQgHAAgGgDg");
	this.shape_19.setTransform(462.15,-105.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgKAeQgGgCgEgEQgFgEgCgHQgDgFABgIQgBgFADgHQACgGAFgEQAEgFAFgDQAGgCAFAAQAHAAAHACQAFADAEAFQADAEACAGQACAHABAGIAAACIgyAAQAAAFACADQABAEAEAEQACADAEABQAFACADAAQAGAAAFgCQAFgCAEgEIAEAGQgEAFgGACQgHADgIAAQgGAAgFgDgAgIgWIgFAFQgEADgBAEIgBAHIAoAAIgBgHIgEgHQgCgDgFgCQgDgCgGAAQgDAAgFACg");
	this.shape_20.setTransform(455.55,-105.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgLAqQgGgCgDgEQgEgFgDgGQgBgGgBgIQABgHABgGQADgFAEgFQADgEAFgDQAGgCAFAAQAGAAAFADQAGADADAFIAAghIALAAIAABVIgLAAIAAgJQgDAFgGADQgFADgGAAQgFAAgFgCgAgHgLQgEACgCAEQgCADgCAEIgBAJIABAKIAEAIQACADAEABQAEACAEABQAFgBAGgDQAFgCACgFIAAgbQgCgEgFgDQgGgDgFAAQgEAAgEABg");
	this.shape_21.setTransform(448,-107);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAGACQAFADAFAAQAIAAADgDQAFgDAAgFQAAgEgDgBIgHgEIgJgCIgJgDQgFgCgCgDQgDgDAAgGIABgHIAEgFQADgDAFgCQAEgBAFAAQAIAAAGADQAFACAEAEIgFAHQgCgEgFgCQgFgCgGAAQgGAAgEADQgDADAAAEQAAADADACQADACAEABIAJACIAJAEIAHAEQADAEAAAGQAAAEgBADQgCAEgEADQgDACgEABQgEACgHAAQgGAAgHgDg");
	this.shape_22.setTransform(438,-105.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgKAeQgGgCgFgEQgEgEgCgHQgDgFAAgIQAAgFADgHQACgGAEgEQAFgFAFgDQAGgCAGAAQAGAAAGACQAGADAEAFQADAEADAGQABAHAAAGIAAACIgxAAQAAAFACADQABAEADAEQAEADADABQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGACQgGADgJAAQgGAAgFgDgAgHgWIgHAFQgCADgBAEIgCAHIAoAAIgBgHIgEgHQgDgDgDgCQgEgCgFAAQgEAAgEACg");
	this.shape_23.setTransform(431.4,-105.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgIAeQgFgCgFgFQgEgEgCgGQgCgGAAgHQAAgGACgGQACgGAEgFQAFgEAFgDQAGgCAGAAQAJAAAFADQAGAEADAEIgGAGQgDgFgEgBQgEgCgFAAQgFAAgDABQgEACgDAEQgDADgBAFQgCAEAAAEQAAAGACAEQABAEADAEQADADAEABQADACAFABQAKAAAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgDg");
	this.shape_24.setTransform(424.625,-105.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAqIAAg+IAJAAIAAA+gAgEgeQAAAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgEABgCQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQACACAAAEQAAAAAAABQAAAAAAABQAAAAgBABQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_25.setTransform(419.85,-107);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgEAfIgag+IAKAAIAUAzIAVgzIALAAIgbA+g");
	this.shape_26.setTransform(415.25,-105.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgPAgIAAg+IAKAAIAAAKQAEgEAEgEQAGgDAHAAIAAAKIgFAAIgEABIgFABIgDAEIgEAEIAAArg");
	this.shape_27.setTransform(410.25,-105.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgLAeQgFgCgFgEQgDgEgDgHQgCgFgBgIQABgFACgHQADgGADgEQAEgFAGgDQAGgCAGAAQAHAAAFACQAGADAEAFQAEAEACAGQACAHAAAGIAAACIgyAAQAAAFACADQACAEACAEQADADAFABQADACAFAAQAFAAAFgCQAFgCAEgEIAEAGQgEAFgHACQgGADgHAAQgGAAgHgDgAgHgWIgGAFQgDADgCAEIgBAHIAoAAIgBgHIgEgHQgCgDgEgCQgFgCgEAAQgFAAgDACg");
	this.shape_28.setTransform(404.1,-105.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgNAeQgGgCgFgFIAFgHQADAEAFACQAGADAGAAQAHAAAEgDQADgDAAgFQAAgEgCgBIgIgEIgIgCIgKgDQgEgCgDgDQgCgDAAgGIABgHIAFgFQADgDAEgCQAFgBAEAAQAIAAAFADQAGACAEAEIgEAHQgDgEgFgCQgFgCgGAAQgGAAgEADQgDADAAAEQAAADADACQACACAFABIAIACIAKAEIAHAEQADAEAAAGQAAAEgCADQgBAEgDADQgDACgFABQgFACgGAAQgHAAgGgDg");
	this.shape_29.setTransform(397.35,-105.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgUArQgFgBgEgDQgDgDgCgFQgCgEgBgGQAAgFACgEIAFgHIAGgFIAGgEIgEgKQgCgFAAgFQAAgEACgEQABgDADgDIAHgEQAEgCAFAAIAHABQAEABACADQACACACADQACADgBAEQAAAFgBAEQgCADgEADIgGAFIgHAFIAEAFIAFAGIAEAGIAGAGQAEgGACgFIADgJIAIAEIgFALIgGALIAIAIIAJAIIgOAAIgEgEIgFgFQgFAFgGADQgGADgIAAQgFAAgFgCgAgWAJQgEAEAAAHQAAAEACADIAEAFQACADADABIAGABQAGAAADgDIAJgGIgHgHIgEgGIgGgGIgFgIQgFAEgEAEgAgGgjIgEACIgDAEIAAAGIABAHIADAHIAHgDIAFgEIADgFIABgFQAAgFgCgDQgDgCgEAAIgEABg");
	this.shape_30.setTransform(386.9,-107.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgNAeQgHgCgEgFIAFgHQADAEAGACQAFADAFAAQAIAAADgDQAFgDAAgFQAAgEgEgBIgGgEIgJgCIgJgDQgFgCgCgDQgDgDgBgGIACgHIAEgFQADgDAFgCQAFgBAEAAQAIAAAGADQAGACADAEIgFAHQgCgEgFgCQgFgCgGAAQgGAAgDADQgEADAAAEQAAADADACQACACAFABIAJACIAJAEIAHAEQADAEAAAGQAAAEgBADQgCAEgEADQgDACgEABQgFACgGAAQgHAAgGgDg");
	this.shape_31.setTransform(376.25,-105.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEAlQgDgEAAgHIAAgoIgKAAIAAgJIAKAAIAAgRIAJAAIAAARIAMAAIAAAJIgMAAIAAAmQAAAEABACQACACAEAAIADgBIADgBIADAHIgFADIgHABQgGAAgEgEg");
	this.shape_32.setTransform(371.45,-106.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgIAeQgFgCgFgFQgEgEgCgGQgCgGAAgHQAAgGACgGQACgGAEgFQAFgEAFgDQAGgCAGAAQAJAAAFADQAGAEADAEIgGAGQgDgFgEgBQgEgCgFAAQgFAAgDABQgEACgDAEQgDADgBAFQgCAEAAAEQAAAGACAEQABAEADAEQADADAEABQADACAFABQAKAAAGgJIAGAGQgDAFgGADQgFADgJAAQgGAAgGgDg");
	this.shape_33.setTransform(366.375,-105.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgUAbQgFgEAAgLIAAgrIAJAAIAAAoIABAHIAEAFIAEACIAGABQAFAAAFgDQAEgDADgEIAAgtIAKAAIAAA+IgKAAIAAgJQgEAEgFADQgGADgGAAQgKAAgFgFg");
	this.shape_34.setTransform(359.5,-105.825);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgMAqQgFgCgEgEQgDgFgCgGQgDgGAAgIQAAgHADgGQACgFADgFQAEgEAFgDQAFgCAGAAQAGAAAGADQAFADAEAFIAAghIAKAAIAABVIgKAAIAAgJQgEAFgFADQgGADgGAAQgFAAgGgCgAgGgLQgFACgCAEQgDADgBAEIgBAJIABAKIAEAIQACADAFABQADACAEABQAGgBAFgDQAFgCADgFIAAgbQgDgEgFgDQgFgDgGAAQgEAAgDABg");
	this.shape_35.setTransform(352,-107);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAeQgGgCgEgFQgEgEgCgGQgCgGAAgHQAAgFACgHQACgGAEgEQAEgFAGgDQAGgCAGAAQAIAAAFACQAGADAEAFQAEAEACAGQACAHAAAFQAAAHgCAGQgCAGgEAEQgEAFgGACQgFADgIAAQgGAAgGgDgAgIgVIgGAFIgFAIIgBAIIABAKIAFAHIAGAFQAEACAEABQAFgBAEgCQAEgCACgDIAFgHQABgFAAgFIgBgIIgFgIQgCgDgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_36.setTransform(344.7,-105.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgOAgIAAg+IAKAAIAAAKQADgEAFgEQAFgDAGAAIAAAKIgDAAIgFABIgFABIgEAEIgCAEIAAArg");
	this.shape_37.setTransform(339.2,-105.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgeArIAAhVIAiAAQAHAAAFACQAEACAEADQAEAEABAFQACAEAAAGQAAAFgCAFQgBAEgEADQgEAEgEACQgFACgHAAIgXAAIAAAigAgTAAIAVAAQAJAAAEgEQAFgFAAgHQAAgIgFgEQgEgFgJAAIgVAAg");
	this.shape_38.setTransform(333.15,-107.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(327,-115,263,17), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgsA1IAAhpIA3AAQALAAAGADQAIAEADAGQADAHABAHQgBAGgCAGQgDAFgDADQgFADgFABQAGABAFADQAEADADAGQACAGABAGQgBAIgDAHQgDAHgIADQgGAEgKAAgAgUAhIAcAAQAGAAADgDQAEgDAAgGQAAgFgDgEQgEgDgGAAIgcAAgAgUgKIAbAAQAFAAAEgDQADgDAAgFQAAgFgDgDQgEgDgFAAIgbAAg");
	this.shape.setTransform(605.3,-41.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgmA2IAAgSIAcgUIAQgPQAGgFADgFQACgFABgFQgBgFgCgDQgDgDgDgBQgEgCgFAAQgIAAgHADQgHAEgFAFIgOgPQAGgGAHgDQAGgEAIgCQAHgCAHAAQAMAAAIAEQAKAEAFAIQAGAHgBALQAAAJgEAJQgGAHgJAJQgKAJgMAKIArAAIAAAUg");
	this.shape_1.setTransform(594.85,-41.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgrA1IAAhpIA3AAQAKAAAHADQAGAEAEAGQAEAHgBAHQAAAGgCAGQgDAFgEADQgEADgFABQAGABAEADQAFADADAGQADAGAAAGQAAAIgEAHQgEAHgHADQgGAEgLAAgAgVAhIAcAAQAHAAAEgDQADgDABgGQgBgFgDgEQgDgDgIAAIgcAAgAgVgKIAbAAQAHAAADgDQADgDAAgFQAAgFgDgDQgDgDgHAAIgbAAg");
	this.shape_2.setTransform(585.1,-41.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAZA1IAAgtIgxAAIAAAtIgXAAIAAhpIAXAAIAAApIAxAAIAAgpIAXAAIAABpg");
	this.shape_3.setTransform(569.65,-41.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgKA1IAAhVIgfAAIAAgUIBTAAIAAAUIgeAAIAABVg");
	this.shape_4.setTransform(559.15,-41.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgKA1IAAhpIAVAAIAABpg");
	this.shape_5.setTransform(552.3,-41.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_6.setTransform(542.725,-41.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgYAyQgMgEgHgIIAMgSQAGAGAJAFQAIAEAKAAQAKAAAEgEQAFgDAAgFQAAgEgFgDQgEgCgHgCIgOgEIgPgFQgHgDgEgGQgEgGgBgKQABgJAEgHQAFgHAJgFQAJgEAMAAQANAAAKAEQALAEAIAHIgNARQgHgGgIgDQgIgDgHAAQgHAAgEADQgEADAAAFQAAAEAEACIAMAEIANAEQAIACAHADQAHAEAFAFQAEAGAAAKQAAAKgFAHQgEAIgKAFQgJAEgPAAQgOAAgLgFg");
	this.shape_7.setTransform(526.425,-41.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AASA1IgggrIgIAKIAAAhIgXAAIAAhpIAXAAIAAAvIAlgvIAcAAIgrAyIAuA3g");
	this.shape_8.setTransform(517.125,-41.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AARA1IgUgmIgQAAIAAAmIgXAAIAAhpIAxAAQALAAAIAEQAIAEAEAIQAFAIAAAKQAAAJgEAHQgDAFgGAEQgFAEgGACIAYAogAgTgEIAXAAQAGAAAFgDQAEgEAAgHQAAgHgEgEQgFgDgGAAIgXAAg");
	this.shape_9.setTransform(506.575,-41.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgcAwQgMgHgIgMQgHgNAAgQQAAgPAHgNQAIgMAMgHQANgHAPAAQAQAAANAHQAMAHAHAMQAIANAAAPQAAAQgIANQgHAMgMAHQgNAHgQAAQgPAAgNgHgAgQgdQgHAEgEAIQgEAIAAAJQAAAKAEAIQAEAIAHAEQAHAFAJAAQAKAAAHgFQAHgEAEgIQAEgIAAgKQAAgJgEgIQgEgIgHgEQgHgFgKAAQgJAAgHAFg");
	this.shape_10.setTransform(495.075,-41.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_11.setTransform(481.575,-41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgQAdQgHgEgGgIQgEgHAAgKQAAgIAEgIQAGgIAHgEQAIgEAIgBQAJABAIAEQAIAEAFAIQAEAIAAAIQAAAKgEAHQgFAIgIAEQgIAFgJAAQgIAAgIgFgAgNgYQgHAEgEAGQgDAHgBAHQABAIADAGQAEAHAHAEQAGAEAHAAQAIAAAGgEQAHgEAEgHQADgGABgIQgBgHgDgHQgEgGgHgEQgGgEgIABQgHgBgGAEgAAKATIgKgPIgGAAIAAAPIgGAAIAAglIAPAAQAFAAAEADQADADAAAFQAAAFgCACIgDADIgFABIALAPgAgGAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQADgDAAgDQAAgCgDgDQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIgJAAg");
	this.shape_12.setTransform(466.2,-43.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_13.setTransform(457.725,-41.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgWAwQgMgGgIgNQgIgMAAgRQAAgQAIgMQAIgNAMgGQANgHAPAAQALAAAJADQAHADAHAGQAGAFAEAHIgTAKQgEgGgGgEQgGgEgJAAQgJAAgIAFQgHAEgFAIQgDAIAAAJQAAAKADAIQAFAIAHAEQAIAFAJAAQAHAAAGgDQAGgCAEgDIAAgNIgcAAIAAgTIAyAAIAAAoQgIAJgMAGQgLAFgOAAQgPAAgNgHg");
	this.shape_14.setTransform(447.05,-41.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAeA1IgHgSIgtAAIgHASIgZAAIAphpIAbAAIApBpgAARAPIgRgtIgQAtIAhAAg");
	this.shape_15.setTransform(435.925,-41.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AATA1IgThIIgRBIIgZAAIgehpIAZAAIATBMIAUhMIARAAIAUBMIAThMIAZAAIgeBpg");
	this.shape_16.setTransform(423.075,-41.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AglA1IAAhpIBLAAIAAAUIg0AAIAAAWIAzAAIAAATIgzAAIAAAYIA0AAIAAAUg");
	this.shape_17.setTransform(411.225,-41.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAaA1IgyhEIAABEIgXAAIAAhpIAYAAIAwBCIAAhCIAXAAIAABpg");
	this.shape_18.setTransform(400.575,-41.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(392.7,-51,219.8,20), null);


(lib.pc111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение14();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc111, new cjs.Rectangle(0,0,380,126), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen21111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,392,280);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen111111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,380,126), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape.setTransform(16.9,45.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAFgDQAGgEADgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(9.4,45.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_2.setTransform(-2.8,44.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_3.setTransform(-9.125,44.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(-13.05,44.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(-20.225,45.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_6.setTransform(-31.825,44.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(-37.675,45.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(-45.725,45.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(-54.1,45.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(-62.4,45.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(-70.875,45.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgMAwQgKgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAKgDQAJgEAKAAQAGAAAGACIAKAEQAFACADAEIAHAIIgKAGQgEgHgHgEQgIgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAIgEQAHgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgJgEg");
	this.shape_12.setTransform(-80.05,44.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApJCAQgqAAAAgqIAAirQAAgqAqAAISUAAQApAAAAAqIAACrQAAAqgpAAg");
	this.shape_13.setTransform(-32.4,44.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-95.2,32,125.6,25.700000000000003), null);


(lib.biglogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logoblack();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6129,0.6129);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.biglogo, new cjs.Rectangle(0,0,87.7,31.3), null);


(lib._3DesignServices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;
	this.instance.setTransform(-28,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._3DesignServices, new cjs.Rectangle(-28,-24,56,47), null);


(lib._2DiscountPricing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;
	this.instance.setTransform(-24,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2DiscountPricing, new cjs.Rectangle(-24,-23,48,45), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape.setTransform(46.175,-56.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_1.setTransform(41.925,-55.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgJAXQgEgCgEgDQgDgDgBgFQgCgFAAgFQAAgEACgFQABgEADgEQAEgDAEgCQAEgCAFAAQAGAAAEACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgDAFgDADQgDADgEACQgEACgGAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_2.setTransform(37.15,-55.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AAPAhIgPg1IgOA1IgJAAIgThBIAJAAIAPA2IAPg2IAGAAIAQA2IAOg2IAKAAIgTBBg");
	this.shape_3.setTransform(29.875,-56.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AANAZIAAgfQgBgGgDgDQgDgCgEAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIACgCIAFgDIAEgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_4.setTransform(76.2,-65.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADADAEACQADACAFgBIAFgBQADAAACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEADgEAAQgFAAgEgCIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgBAFgBQAEAAAEACQAEADADAEIAAgIIAIAAIAAAuQAAAGgCAFQgCAEgDACQgEADgEABIgIABQgGgBgEgBgAgFgaIgFAEIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgCIAEgDIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_5.setTransform(70.425,-64.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_6.setTransform(66.575,-66.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_7.setTransform(63.075,-65.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgIAYQgEgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAEAAQAGAAAFACQAEACACADQAEAEABAFQABAEAAAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgEABgGAAQgFAAgFgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgCgBgFAAQgDAAgCABg");
	this.shape_8.setTransform(57.95,-65.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAGADAFAEQAEAFADAGQADAGgBAGQABAHgDAGQgDAGgEAFQgFAEgGADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAEgCAEgEQADgDACgFQACgFgBgFIgBgJQgCgFgDgDQgDgEgFgCQgFgCgFAAIgOAAg");
	this.shape_9.setTransform(51.8,-66.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgDgEAAgGQAAgEADgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAEACAEADQADAEABAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgDgBgFAAQgDAAgDABg");
	this.shape_10.setTransform(42.7,-65.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgDgDgBgFQgCgEAAgGQAAgEACgFIAEgIQAEgDAEgCQAFgCADAAQAGAAAEACQAFACACADQADAEACAFQABAEABAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgEABgHAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgDgFIgGgEQgCgBgFAAQgCAAgEABg");
	this.shape_11.setTransform(37.05,-65.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_12.setTransform(32.875,-65.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgVAhIAAhBIArAAIAAAHIgjAAIAAAVIAiAAIAAAHIgiAAIAAAeg");
	this.shape_13.setTransform(28.425,-66.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgKAhQgFgCgEgEIAEgFQADAEAEABQADACAFAAIAFgCQADAAACgCQADgBABgDQABgDAAgEIAAgHQgCADgFADQgEADgEgBQgFABgEgCIgHgFIgEgIQgCgDAAgHQAAgFACgFIAEgIIAHgFQAEgBAFAAQAEAAAEACQAEACADAEIAAgHIAIAAIAAAuQAAAFgCAEQgCAEgDADQgEACgEABIgIABQgGABgEgCgAgFgaIgFAFIgDAFIgBAHIABAIQABADACACIAFADQADACADAAIAEgBIAEgCIAEgCIACgDIAAgUIgCgDIgEgCIgEgCIgEgBQgDAAgDABg");
	this.shape_14.setTransform(52.225,-82);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_15.setTransform(46.75,-82.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_16.setTransform(42.875,-83.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAFgCQAEgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgEgBg");
	this.shape_17.setTransform(39.35,-82.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_18.setTransform(35.675,-83.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_19.setTransform(33.175,-82.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_20.setTransform(28.625,-83.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_21.setTransform(62.475,-93.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgEABIgEABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_22.setTransform(58.25,-92.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIABAGIADADIADACIAEAAQAEAAADgCQAFgCACgDIAAgjIAHAAIAAAwIgHAAIAAgHQgDADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_23.setTransform(52.75,-92.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAXQgFgCgDgDQgCgDgCgFQgCgFAAgFQAAgEACgFQACgEACgEQADgDAFgCQAEgCAFAAQAFAAAFACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgCAFgEADQgDADgEACQgFACgFAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_24.setTransform(47.15,-92.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgDgDgCgFQgCgFAAgFQAAgEACgFQACgFADgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgEABgCADIgDAGIgBAGIABAIIADAFQACADAEABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_25.setTransform(41.9,-92.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDIAEgEQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_26.setTransform(36.975,-92.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_27.setTransform(33.575,-93.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgbAhIAAhBIAWAAQAHAAAGACQAHADAEAEQAFAFACAGQACAGABAGQgBAHgCAGQgCAGgFAFQgEAEgHADQgGACgHAAgAgTAaIAOAAQAFAAAFgCQAFgCADgEQADgDACgFQABgFAAgFIgBgJQgCgFgDgDQgDgEgFgCQgEgCgGAAIgOAAg");
	this.shape_28.setTransform(29.1,-93.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgKAhQgFgBgEgFIAEgFQADADAEACQADABAFAAIAFgBQADAAACgCQADgCABgCQABgDAAgEIAAgHQgCAEgFACQgEACgEAAQgFAAgEgBIgHgFIgEgIQgCgDAAgHQAAgFACgFIAEgIIAHgFQAEgCAFAAQAEABAEACQAEACADAEIAAgHIAIAAIAAAuQAAAGgCAEQgCADgDADQgEACgEABIgIABQgGABgEgCgAgFgaIgFAFIgDAFIgBAHIABAIQABADACACIAFADQADACADAAIAEgBIAEgCIAEgCIACgDIAAgUIgCgDIgEgDIgEgBIgEgBQgDAAgDABg");
	this.shape_29.setTransform(60.875,-109.55);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgDgDQgDgCgEAAIgDABIgFABIgDADIgCACIAAAjIgIAAIAAgwIAIAAIAAAHIADgCIADgDIAFgCIAFgBQAPAAAAAQIAAAhg");
	this.shape_30.setTransform(55.4,-110.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_31.setTransform(51.525,-111.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgEAFgDQAEgCAEAAQAFAAAEABIAHAGQADADABAFQACAEAAAHQAAAFgCAEQgBAFgDADIgHAFQgEACgFAAQgEgBgEgCQgEgCgDgEIAAAagAgIgYQgEACgCAEIAAAUQACADAEADQAEACAEAAQADAAADgBIAFgFIADgEIABgHIgBgIIgDgGIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_32.setTransform(47.725,-109.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAIQACgEAFgDQAEgCAEAAQAFAAAEABIAHAGQADADABAFQACAEAAAHQAAAFgCAEQgBAFgDADIgHAFQgEACgFAAQgEgBgEgCQgEgCgDgEIAAAagAgIgYQgEACgCAEIAAAUQACADAEADQAEACAEAAQADAAADgBIAFgFIADgEIABgHIgBgIIgDgGIgFgEQgDgBgDAAQgEAAgEACg");
	this.shape_33.setTransform(42.025,-109.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_34.setTransform(37.875,-111.325);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AANAhIAAggIgBgEIgDgDQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgEABIgDACIgEACIgCADIAAAiIgIAAIAAhBIAIAAIAAAZIACgDIAFgDIAEgCIAFAAQAIAAADADQAEAEAAAIIAAAhg");
	this.shape_35.setTransform(34,-111.375);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAEgGIAFADIAEADIAGACIAGABQAEAAADgBIAFgDQAAAAABgBQAAAAABgBQAAAAAAgBQAAAAAAgBIABgDQAAgEgCgCIgDgDIgHgDIgHgCIgHgCIgGgCIgFgFQgBgDAAgFQAAgEABgDIAGgGIAGgEIAJgBQAIAAAFACQAGACAEAFIgEAGQgFgEgEgCQgGgCgEAAQgGAAgEADQgDADAAAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAFADIAGADIAGACIAIACIAGADIAEAFQACADAAAFIgCAHQgBAEgCACQgEADgEACQgFABgGAAQgJAAgFgDg");
	this.shape_36.setTransform(28.35,-111.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape_37.setTransform(48.675,-121.375);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgFAYQgFgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAFgCQAEgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgEgBg");
	this.shape_38.setTransform(43.4,-120.475);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_39.setTransform(39.725,-121.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAHAAIAAAfIACAGIACADIADACIAFAAQACAAAFgCQADgCACgDIAAgjIAIAAIAAAwIgIAAIAAgHQgCADgFADQgEACgFAAQgHAAgEgEg");
	this.shape_40.setTransform(35.85,-120.425);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AASAdIgIADIgKABQgGAAgHgCQgGgDgEgEQgEgFgDgGQgCgGAAgHQAAgHACgHQADgGAEgEQAEgFAGgDQAHgCAGAAQAHAAAGACQAHADAEAFQAEAEADAGQACAHAAAHQAAAHgCAGQgDAGgEAFIAGAGIgGAGgAgJgZQgFACgDAEQgDADgCAFQgCAGAAAFQAAAFACAFQACAFADAEQADADAFACQAEADAFAAQAHAAAGgEIgKgLIAGgEIAJAKQADgEACgEQABgFAAgFQAAgFgBgGQgCgFgDgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_41.setTransform(29.275,-121.3);

	this.instance = new lib._3DesignServices();
	this.instance.parent = this;
	this.instance.setTransform(6.25,-60.1,0.515,0.515,0,0,0,0,-0.5);

	this.instance_1 = new lib._2DiscountPricing();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.75,-87.1,0.515,0.515,0,0,0,0.1,-0.5);

	this.instance_2 = new lib._1flexibleShipping();
	this.instance_2.parent = this;
	this.instance_2.setTransform(7.4,-114.1,0.515,0.515,0,0,0,0.1,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("An8HYIAAuwIP5AAIAAOwg");
	this.shape_42.setTransform(36.225,-87.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_42).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-14.6,-135.1,101.69999999999999,94.5), null);


// stage content:
(lib._728x90_B2B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_759 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(759).call(this.frame_759).wait(345));

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape.setTransform(364.225,45.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_1.setTransform(364.225,45.9);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_2.setTransform(364.225,45.9);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_3.setTransform(364.225,45.9);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_4.setTransform(364.225,45.9);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_5.setTransform(364.225,45.9);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_6.setTransform(364.225,45.9);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_7.setTransform(364.225,45.9);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_8.setTransform(364.225,45.9);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_9.setTransform(364.225,45.9);
	this.shape_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(99));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(100));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(101));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(102));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(103));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(104));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(105));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(106));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(107));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(108));

	// t11
	this.instance = new lib.t11();
	this.instance.parent = this;
	this.instance.setTransform(154.5,118.35,1,1,0,0,0,105.6,41);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},105).wait(1).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).wait(114).to({_off:true},105).wait(1).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(99));

	// t12
	this.instance_1 = new lib.t222();
	this.instance_1.parent = this;
	this.instance_1.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);

	this.instance_2 = new lib.t22();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[]},114).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[]},114).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},114).to({state:[]},105).to({state:[{t:this.instance_2}]},1).to({state:[]},114).to({state:[{t:this.instance_2}]},1).to({state:[]},114).wait(99));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(106).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(106).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(106).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(99));

	// Лого
	this.instance_3 = new lib.biglogo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(551.55,15.95,0.5748,0.5748,0,0,0,43.9,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(890).to({_off:true},115).wait(99));

	// Слой_5
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.3,-51.8,-51.6,-21.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_10.setTransform(551.525,73.35);
	this.shape_10._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-98,-49.2,-45.3,-18.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_11.setTransform(551.525,73.35);
	this.shape_11._off = true;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91.8,-46.6,-39.1,-16.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_12.setTransform(551.525,73.35);
	this.shape_12._off = true;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.5,-43.9,-32.8,-13.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_13.setTransform(551.525,73.35);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-79.2,-41.3,-26.5,-10.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_14.setTransform(551.525,73.35);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-73,-38.6,-20.3,-8.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_15.setTransform(551.525,73.35);
	this.shape_15._off = true;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-66.7,-36,-14,-5.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_16.setTransform(551.525,73.35);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-60.5,-33.4,-7.8,-2.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_17.setTransform(551.525,73.35);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-54.2,-30.7,-1.5,-0.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_18.setTransform(551.525,73.35);
	this.shape_18._off = true;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-48,-28.1,4.7,2.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_19.setTransform(551.525,73.35);
	this.shape_19._off = true;

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-41.7,-25.5,11,5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_20.setTransform(551.525,73.35);
	this.shape_20._off = true;

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-35.5,-22.8,17.2,7.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_21.setTransform(551.525,73.35);
	this.shape_21._off = true;

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-29.2,-20.2,23.5,10.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_22.setTransform(551.525,73.35);
	this.shape_22._off = true;

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-23,-17.6,29.7,12.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_23.setTransform(551.525,73.35);
	this.shape_23._off = true;

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,-14.9,36,15.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_24.setTransform(551.525,73.35);
	this.shape_24._off = true;

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-10.5,-12.3,42.2,18.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_25.setTransform(551.525,73.35);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-4.2,-9.7,48.5,20.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_26.setTransform(551.525,73.35);
	this.shape_26._off = true;

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],2,-7,54.7,23.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_27.setTransform(551.525,73.35);
	this.shape_27._off = true;

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,-4.4,61,26.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_28.setTransform(551.525,73.35);
	this.shape_28._off = true;

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],14.5,-1.8,67.2,28.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_29.setTransform(551.525,73.35);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],20.8,0.9,73.5,31.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_30.setTransform(551.525,73.35);
	this.shape_30._off = true;

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],27.1,3.5,79.8,34).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_31.setTransform(551.525,73.35);
	this.shape_31._off = true;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],33.3,6.2,86,36.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_32.setTransform(551.525,73.35);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.6,8.8,92.3,39.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_33.setTransform(551.525,73.35);
	this.shape_33._off = true;

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.8,11.4,98.5,41.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_34.setTransform(551.525,73.35);
	this.shape_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(150).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(168));
	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(151).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(167));
	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(152).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(166));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(153).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(165));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(154).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(164));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(155).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(163));
	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(156).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(162));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(157).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(161));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(158).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(160));
	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(159).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(159));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(160).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(158));
	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(161).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(157));
	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(162).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(156));
	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(163).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(155));
	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(164).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(154));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(165).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(153));
	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(166).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(152));
	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(167).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(151));
	this.timeline.addTween(cjs.Tween.get(this.shape_28).wait(168).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(150));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(169).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(149));
	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(170).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(148));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(171).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(147));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(172).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(146));
	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(173).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(145));
	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(174).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(219).to({_off:false},0).to({_off:true},1).wait(114).to({_off:false},0).to({_off:true},1).wait(144));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(570.65,65.75,0.801,0.801,0,0,0,-8.5,35.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},220).wait(1).to({_off:false},0).wait(114).to({_off:true},220).wait(1).to({_off:false},0).wait(114).to({_off:true},220).wait(1).to({_off:false},0).to({_off:true},114).wait(99));

	// Слой_2
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("A7zHIIAAuPMA3nAAAIAAOPg");
	this.shape_35.setTransform(550.45,45.9);
	this.shape_35._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_35).wait(106).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(106).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(106).to({_off:false},0).to({_off:true},114).wait(1).to({_off:false},0).to({_off:true},114).wait(99));

	// Слой_4
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgKAWQgGgBgDgEIAFgJIAEAEIAGACIAFABQADAAADgCQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDACgEQACgDAFgCQAEgCAFAAQAGAAAFACQAEABAEADIgFAJIgGgEQgDgBgFAAIgEABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABAAAAIAGABIAJADQAEABADACQACADAAAGQABAEgDADQgDAEgEABQgFACgGAAQgFAAgFgCg");
	this.shape_36.setTransform(351.3,76.475);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgEgFABgIQAAgGACgFQADgGAGgDQAGgDAFAAQAHAAAGADQAFADADAGQACAGABAGIAAADIgiAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgDgBgEAAQgCAAgCABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_37.setTransform(346.4,76.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgIAVQgGgDgDgFQgEgGAAgHQAAgGAEgFQADgGAGgDQAFgDAGAAQAFAAADABIAHADIADAEIgIAIIgDgEIgHgBQgEAAgEADQgDAEAAAFQAAAGADAEQAEADAEABQAEAAADgCIADgDIAIAHIgDAEIgHADIgIABQgGAAgFgDg");
	this.shape_38.setTransform(341.4,76.475);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_39.setTransform(336.225,76.425);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAEgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_40.setTransform(330.7,76.475);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_41.setTransform(327.075,75.525);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_42.setTransform(324.6,75.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgXAgIAAg+IANAAIAAAGIAGgFQADgCAEAAQAGAAAEACQAFAEACAFQADAFABAIQgBAHgDAFQgCAGgFACQgEADgGAAIgHgBIgGgGIAAAXgAgGgTIgEAEIAAAPIAEAEIAGABQAFAAADgDQADgDAAgGQAAgGgDgEQgDgDgFAAIgGABg");
	this.shape_43.setTransform(320.8,77.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgXAgIAAg+IANAAIAAAGIAGgFQADgCAEAAQAGAAAEACQAFAEACAFQADAFAAAIQAAAHgDAFQgCAGgFACQgEADgGAAIgHgBIgGgGIAAAXgAgGgTIgEAEIAAAPIAEAEIAGABQAEAAAEgDQADgDAAgGQAAgGgDgEQgEgDgEAAIgGABg");
	this.shape_44.setTransform(315.3,77.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AASAgIgEgLIgbAAIgEALIgPAAIAYg/IAQAAIAZA/gAAKAJIgKgaIgJAaIATAAg");
	this.shape_45.setTransform(309.075,75.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIALAAIAAAGQACgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_46.setTransform(301.85,76.425);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgEgGQgDgFABgHQgBgGADgFQAEgFAFgEQAGgDAGAAQAHAAAGADQAFAEADAFQADAFAAAGQAAAHgDAFQgDAGgFADQgGADgHAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgDACg");
	this.shape_47.setTransform(297.2,76.475);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAGgDAGAAQAIAAAFADQAGAEADAFQACAFAAAGQAAAHgCAFQgDAGgGADQgFADgIAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_48.setTransform(291.7,76.475);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgMAeQgFgDgDgGQgCgFAAgIQAAgHACgEQADgGAFgDQAEgDAGAAQADAAAEACQAEABADAEIAAgYIAMAAIAABAIgMAAIAAgGIgHAFQgDACgEAAQgGAAgEgDgAgHAAQgDADAAAFQAAAGADAEQADAEAFAAIAGgCIAFgDIAAgRIgFgCIgGgCQgFAAgDAEg");
	this.shape_49.setTransform(286,75.65);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_50.setTransform(281.725,75.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgRATQgEgDAAgHIAAggIAMAAIAAAcQAAAEADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAuIgNAAIAAgGQgCACgEACQgDADgGAAQgHAAgEgFg");
	this.shape_51.setTransform(277.375,76.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgQAdQgIgFgEgHQgEgHAAgKQAAgIAEgIQAEgHAIgFQAHgEAJAAQAKAAAHAEQAIAFAEAHQAEAIAAAIQAAAKgEAHQgEAHgIAFQgHAEgKAAQgJAAgHgEgAgJgRQgFACgCAFQgCAFgBAFQABAGACAFQACAFAFADQAEACAFAAQAGAAAEgCQAEgDADgFQACgFAAgGQAAgFgCgFQgDgFgEgCQgEgCgGgBQgFABgEACg");
	this.shape_52.setTransform(270.975,75.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgQAgIgDAAIABgLIADABIACAAIADgBIADgDIACgEIgTgtIANAAIALAfIAMgfIANAAIgVA0IgEAHIgFADIgIABIgDAAg");
	this.shape_53.setTransform(91.7,77.425);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIAMAAIAAAGQABgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgFACIgBACIAAAeg");
	this.shape_54.setTransform(87.8,76.425);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_55.setTransform(84.225,75.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_56.setTransform(79.95,76.475);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_57.setTransform(74.575,76.425);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_58.setTransform(70.575,75.525);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgEAfIgHgFIAAAGIgMAAIAAhAIAMAAIAAAYQAEgEADgBQAEgCADAAQAGAAAEADQAFADADAGQACAEAAAHQAAAIgCAFQgDAGgFADQgEADgGAAQgDAAgEgCgAgGgCIgFACIAAARIAFADIAGACQAEAAADgEQAEgEAAgGQAAgFgEgDQgDgEgEAAIgGACg");
	this.shape_59.setTransform(66.7,75.65);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAGAAAEACQAFABACAEQAEAEAAAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgCACg");
	this.shape_60.setTransform(61,76.475);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgIQgEgHAAgKQAAgJAEgHQAFgHAHgFQAIgEAJAAQAHAAAFACQAFACADAEIAGAIIgMAFQgCgEgEgCQgDgCgFgBQgFABgFACQgEACgDAFQgCAFgBAFQABAGACAFQADAFAEADQAFACAFAAQAFAAADgCQAEgDACgEIAMAFIgGAIQgDADgFADQgFACgHAAQgJAAgIgEg");
	this.shape_61.setTransform(55.375,75.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_62.setTransform(48.3,75.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgEgFABgIQAAgGACgFQADgGAGgDQAGgDAFAAQAHAAAGADQAFADADAGQADAGgBAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgDgBgEAAQgDAAgBABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_63.setTransform(44.45,76.475);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFAAgIQAAgGACgFQADgGAGgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgBABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_64.setTransform(39.15,76.475);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_65.setTransform(34.875,75.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_66.setTransform(30.325,75.625);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgEgFABgIQAAgGACgFQADgGAGgDQAGgDAFAAQAHAAAGADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgDgBgEAAQgDAAgBABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_67.setTransform(206.9,81.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgBAhQgGAAgEgCQgFgBgFgEIAGgJQADADAEACQADABAEAAIAFgBQAEgBACgDQABgCABgFIAAgEIgHAFIgHACQgGAAgFgDQgEgCgDgGQgDgEAAgIQAAgHADgFQADgGAEgCQAFgDAGAAQADAAAEACQAEABADAEIAAgGIALAAIAAAqQABAHgDAEQgCAEgEADQgDACgFABIgGABIgCAAgAgGgSQgEADAAAGQAAAGAEADQADADAEAAIAGgBIAFgDIAAgPIgFgEIgGgBQgEAAgDADg");
	this.shape_68.setTransform(201.25,82.1583);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAGAAAEACQAFABACAEQADAEABAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_69.setTransform(195.9,81.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIALAAIAAAGQACgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgFACIgCACIAAAeg");
	this.shape_70.setTransform(191.95,81.225);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAGgDAGAAQAIAAAFADQAGAEACAFQADAFAAAGQAAAHgDAFQgCAGgGADQgFADgIAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_71.setTransform(187.3,81.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgGIAAgXIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_72.setTransform(182.925,80.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAABQABAAAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_73.setTransform(178.375,80.425);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEIAGgEQACgCABgEIgCgEQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_74.setTransform(170.075,80.425);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQADgGAGgDQAFgDAHAAQAGAAAFADQAGADADAGQACAGAAAGIAAADIggAAQAAAEADADQAEADAFAAIAEAAIAEgCIAEgCIAGAIQgEADgGACQgEABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_75.setTransform(224.75,71.675);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIAMAAIAAAGQACgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_76.setTransform(220.6,71.625);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgRAUQgEgEAAgHIAAggIAMAAIAAAbQAAAFADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAtIgNAAIAAgFQgCADgEABQgDACgGAAQgHAAgEgDg");
	this.shape_77.setTransform(215.925,71.75);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_78.setTransform(211.575,71.1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_79.setTransform(208.725,70.725);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_80.setTransform(204.725,71.625);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIALAAIAAAGQACgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgFACIgCACIAAAeg");
	this.shape_81.setTransform(200.5,71.625);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgRAUQgEgEAAgHIAAggIAMAAIAAAbQAAAFADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAtIgNAAIAAgFQgCADgEABQgDACgGAAQgHAAgEgDg");
	this.shape_82.setTransform(195.775,71.75);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgWAgIAAg/IAsAAIAAAMIgeAAIAAANIAeAAIAAAMIgeAAIAAAag");
	this.shape_83.setTransform(190.45,70.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgFACIgBACIAAAeg");
	this.shape_84.setTransform(183.55,71.625);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFAAgHQAAgGADgFQADgFAFgEQAGgDAGAAQAHAAAGADQAFAEAEAFQACAFAAAGQAAAHgCAFQgEAGgFADQgGADgHAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgCACg");
	this.shape_85.setTransform(178.9,71.675);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFgBgHQABgGADgFQADgFAFgEQAGgDAGAAQAIAAAFADQAGAEADAFQADAFAAAGQAAAHgDAFQgDAGgGADQgFADgIAAQgGAAgGgDgAgGgKQgCABgCADQgBADAAADQAAAEABADIAEAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_86.setTransform(173.4,71.675);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgNAeQgEgDgCgGQgEgFAAgHQAAgIAEgFQACgFAEgDQAFgDAGAAQADAAAEACQADACADADIAAgYIAMAAIAAA/IgMAAIAAgFIgGAFQgEABgDAAQgGAAgFgCgAgHAAQgDACAAAHQAAAFADAEQADADAFABIAGgBIAEgEIAAgRIgEgDIgGgBQgFAAgDAEg");
	this.shape_87.setTransform(167.7,70.85);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_88.setTransform(163.475,71.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgRAUQgEgEAAgHIAAggIAMAAIAAAbQAAAFADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAtIgNAAIAAgFQgCADgEABQgDACgGAAQgHAAgEgDg");
	this.shape_89.setTransform(159.075,71.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgQAdQgIgEgEgIQgEgHAAgKQAAgJAEgHQAEgIAIgEQAHgDAJgBQAKABAHADQAIAEAEAIQAEAHAAAJQAAAKgEAHQgEAIgIAEQgHAEgKAAQgJAAgHgEgAgJgRQgFADgCAFQgCAEgBAFQABAGACAFQACAEAFADQAEADAFAAQAGAAAEgDQAEgDADgEQACgFAAgGQAAgFgCgEQgDgFgEgDQgEgDgGAAQgFAAgEADg");
	this.shape_90.setTransform(152.675,70.8);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgQAgIgDAAIABgLIACABIADAAIADgBIADgDIABgEIgSgtIANAAIALAfIAMgfIANAAIgVA0IgEAHIgGADIgHABIgDAAg");
	this.shape_91.setTransform(329.1,82.525);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQAEgGAFgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_92.setTransform(317.35,81.575);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgEAfIgGgFIAAAFIgNAAIAAg/IANAAIAAAYQACgDAEgCQAEgCADAAQAGAAAEADQAFADACAFQADAFAAAIQAAAHgDAFQgCAGgFADQgEACgGAAQgEAAgDgBgAgGgDIgEAEIAAAQIAEADIAGACQAEgBAEgDQADgEAAgFQAAgHgDgCQgEgEgEAAIgGABg");
	this.shape_93.setTransform(304.05,80.75);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_94.setTransform(298.4,81.575);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgIQgEgHAAgKQAAgJAEgHQAFgIAHgEQAIgEAJAAQAHAAAFADQAFACADADIAGAIIgMAGQgCgEgEgDQgDgDgFAAQgFAAgFADQgEADgDAFQgCAEgBAFQABAGACAFQADAEAEADQAFADAFAAQAFAAADgDQAEgCACgEIAMAFIgGAIQgDAEgFACQgFACgHAAQgJAAgIgEg");
	this.shape_95.setTransform(292.775,80.7);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgMAeQgFgDgCgGQgDgFAAgIQAAgHADgEQACgGAFgDQAEgDAGAAQADAAAEACQAEABADAEIAAgYIAMAAIAABAIgMAAIAAgGIgHAFQgDACgEAAQgGAAgEgDgAgHAAQgDADAAAFQAAAGADAEQADAEAFAAIAGgCIAFgDIAAgRIgFgCIgGgCQgFAAgDAEg");
	this.shape_96.setTransform(340.9,71.15);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgDgFAAgHQAAgGADgFQADgFAGgEQAGgDAGAAQAHAAAGADQAFAEADAFQADAFABAGQgBAHgDAFQgDAGgFADQgGADgHAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIAEgFQABgDAAgEQAAgDgBgDQgCgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_97.setTransform(335.55,71.975);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AALAgIgLgrIgKArIgOAAIgTg/IAQAAIALAtIAMgtIAKAAIAMAtIALgtIAPAAIgSA/g");
	this.shape_98.setTransform(322.875,71.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_99.setTransform(311.925,71.925);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_100.setTransform(295.825,71.925);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFAAgIQAAgGADgFQADgGAFgDQAGgDAFAAQAHAAAGADQAFADACAGQAEAGAAAGIAAADIghAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgFABgFAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQAAgCgDgCQgCgBgFAAQgCAAgCABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_101.setTransform(289.05,71.975);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgYAgIAAg/IAcAAQAHABAFACQAEADADAEQADAFgBAGQABAGgDAEQgDADgEADQgFADgHAAIgPAAIAAAXgAgLgCIANAAQAEAAADgCQADgCAAgEQAAgFgDgBQgDgDgEAAIgNAAg");
	this.shape_102.setTransform(280.25,71.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAFAAAFACQAFABACAEQAEAEAAAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgCACg");
	this.shape_103.setTransform(74.6,81.575);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AAKAXIgKgfIgJAfIgNAAIgOgtIANAAIAJAeIAKgeIAJAAIALAeIAIgeIANAAIgOAtg");
	this.shape_104.setTransform(68.475,81.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEAAgFQAAgFACgEQACgCAEgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAFAAAFACQAFABACAEQAEAEAAAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgCACg");
	this.shape_105.setTransform(58.85,81.575);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_106.setTransform(55.15,80.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBQgFgCgEAAQgFAAgCACQgCABAAADQAAABAAAAQAAABAAABQABAAAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_107.setTransform(51.025,80.725);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEIAGgEQACgCABgEIgCgEQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABg");
	this.shape_108.setTransform(42.725,80.725);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABADADIgEAJIgGgEQgDgBgFAAIgEABQgBAAAAAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABABAAIAGABIAIADQAEABACACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_109.setTransform(90.8,71.975);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQAAgGAEgFQADgGAFgDQAGgDAFAAQAIAAAEADQAGADACAGQADAGABAGIAAADIghAAQAAAEADADQADADAFAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgDAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_110.setTransform(85.9,71.975);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgGAXIgSgtIANAAIALAfIAMgfIANAAIgTAtg");
	this.shape_111.setTransform(80.75,72);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_112.setTransform(77.1,71.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AAKAgIAAgcQAAgEgDgCQgCgCgEABQgDAAgCABIgEADIAAAfIgNAAIAAg/IANAAIAAAYIADgEIAFgCQADgCAEABQAHAAAEADQAEAFAAAGIAAAgg");
	this.shape_113.setTransform(67.825,71.1);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgGAJIAFgDIACgGIgBABIAAAAQgBAAgBAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgCgCAAgDQAAgDACgDQADgCACAAQADAAACADQADACAAAFQAAAEgDAFQgDAFgDADg");
	this.shape_114.setTransform(55.65,74.225);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgLAWQgFgBgEgEIAGgJIAEAEIAGACIAFABQADAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIgFgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDADgEQACgDADgCQAFgCAFAAQAGAAAFACQAEABADADIgEAJIgGgEQgDgBgFAAIgEABQgBAAAAAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABABAAIAGABIAIADQADABADACQADADABAGQAAAEgDADQgDAEgEABQgFACgGAAQgFAAgGgCg");
	this.shape_115.setTransform(52.1,71.975);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AAIAgIgMgSIgFAGIAAAMIgNAAIAAg/IANAAIAAAlIAQgTIAPAAIgSATIASAag");
	this.shape_116.setTransform(47.55,71.1);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgEgGABgHQgBgGAEgFQADgGAFgDQAGgDAGAAQAFAAADABIAGADIAEAEIgHAIIgFgEIgGgBQgEAAgEADQgDAEAAAFQAAAGADAEQAEADAEABQAEAAACgCIAFgDIAHAHIgEAEIgGADIgIABQgGAAgGgDg");
	this.shape_117.setTransform(42.35,71.975);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAFgBQAEgCAFAAQAFAAAFACQAFABADAEQACAEAAAGIAAAdIgLAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgDACg");
	this.shape_118.setTransform(37.2,71.975);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AAKAgIgLgWIgKAAIAAAWIgOAAIAAg/IAdAAQAHAAAEADQAFACADAFQACAFAAAFQAAAHgCADIgFAFQgDADgEAAIAPAZgAgLgCIANAAQAEABADgDQACgCAAgFQAAgDgCgCQgDgDgEAAIgNAAg");
	this.shape_119.setTransform(31.825,71.1);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgBAhQgFAAgFgCQgFgBgEgEIAFgJQADADADACQAEABAEAAIAGgBQACgBACgDQACgCABgFIAAgEIgHAFIgHACQgGAAgEgDQgFgCgDgGQgCgEAAgIQAAgHACgFQADgGAFgCQAEgDAGAAQADAAAEACQAEABADAEIAAgGIAMAAIAAAqQgBAHgCAEQgCAEgEADQgEACgEABIgGABIgCAAgAgHgSQgDADAAAGQAAAGADADQADADAFAAIAGgBIAFgDIAAgPIgFgEIgGgBQgFAAgDADg");
	this.shape_120.setTransform(203.2,82.4583);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgCACIAAAeg");
	this.shape_121.setTransform(191.1,81.525);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgEgFAAgHQAAgGAEgFQADgFAFgEQAGgDAGAAQAIAAAFADQAFAEADAFQAEAFAAAGQAAAHgEAFQgDAGgFADQgFADgIAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_122.setTransform(180.95,81.575);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_123.setTransform(176.95,80.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgVAgIAAg/IAsAAIAAAMIgfAAIAAANIAeAAIAAAMIgeAAIAAAag");
	this.shape_124.setTransform(173.15,80.7);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_125.setTransform(226.2,71.975);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgNAeQgEgDgDgGQgCgFAAgIQAAgHACgEQADgGAEgDQAFgDAGAAQADAAAEACQAEABADAEIAAgYIALAAIAABAIgLAAIAAgGIgHAFQgEACgDAAQgGAAgFgDgAgGAAQgEADAAAFQAAAGAEAEQADAEAEAAIAGgCIAFgDIAAgRIgFgCIgGgCQgEAAgDAEg");
	this.shape_126.setTransform(220.6,71.15);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAFgCAEAAQAGAAAEACQAFABADAEQACAEAAAGIAAAdIgLAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_127.setTransform(215.2,71.975);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgCACIAAAeg");
	this.shape_128.setTransform(211.25,71.925);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgIQgFgHAAgKQAAgJAFgHQAFgIAHgEQAIgEAIAAQAHAAAFACQAFACADAEIAHAGIgLAGQgDgDgEgDQgEgBgFgBQgEABgFACQgEACgDAFQgDAFAAAFQAAAGADAFQADAFAEADQAFACAEAAQAEAAAEgBIAGgEIAAgIIgRAAIAAgLIAeAAIAAAYQgFAGgGADQgHADgJAAQgIAAgIgEg");
	this.shape_129.setTransform(205.85,71.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgLAFIAAgJIAXAAIAAAJg");
	this.shape_130.setTransform(201.05,71.975);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_131.setTransform(198.35,71.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_132.setTransform(194.4,71.975);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_133.setTransform(190.775,71.025);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgDgGgBgHQABgGADgFQADgGAFgDQAGgDAGAAQAFAAAEABIAFADIAFAEIgIAIIgEgEIgGgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAADgCIAEgDIAIAHIgFAEIgFADIgJABQgGAAgGgDg");
	this.shape_134.setTransform(187.2,71.975);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIAMAAIAAAGQACgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_135.setTransform(183.25,71.925);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_136.setTransform(171.925,71.925);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_137.setTransform(163.725,71.925);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgDgFAAgHQAAgGADgFQADgFAGgEQAFgDAHAAQAHAAAGADQAFAEADAFQADAFABAGQgBAHgDAFQgDAGgFADQgGADgHAAQgHAAgFgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_138.setTransform(156.9,71.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_90},{t:this.shape_89},{t:this.shape_88,p:{x:163.475,y:71.1}},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79,p:{x:208.725,y:70.725}},{t:this.shape_78,p:{x:211.575,y:71.1}},{t:this.shape_77},{t:this.shape_76,p:{x:220.6,y:71.625}},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70,p:{x:191.95,y:81.225}},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66,p:{x:30.325,y:75.625}},{t:this.shape_65},{t:this.shape_64,p:{x:39.15,y:76.475}},{t:this.shape_63},{t:this.shape_62,p:{x:48.3,y:75.6}},{t:this.shape_61,p:{x:55.375,y:75.6}},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{x:70.575,y:75.525}},{t:this.shape_57,p:{x:74.575,y:76.425}},{t:this.shape_56,p:{x:79.95,y:76.475}},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:277.375,y:76.55}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48,p:{x:291.7,y:76.475}},{t:this.shape_47,p:{x:297.2,y:76.475}},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:324.6,y:75.6}},{t:this.shape_41,p:{x:327.075,y:75.525}},{t:this.shape_40},{t:this.shape_39,p:{x:336.225,y:76.425}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[{t:this.shape_61,p:{x:150.975,y:71.1}},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_64,p:{x:178.65,y:71.975}},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_48,p:{x:186.4,y:81.575}},{t:this.shape_121},{t:this.shape_79,p:{x:193.775,y:80.625}},{t:this.shape_57,p:{x:197.775,y:81.525}},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_66,p:{x:62.125,y:71.125}},{t:this.shape_113},{t:this.shape_56,p:{x:73.2,y:71.975}},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_88,p:{x:63.175,y:81}},{t:this.shape_104},{t:this.shape_103},{t:this.shape_62,p:{x:78.5,y:80.7}},{t:this.shape_42,p:{x:80.95,y:80.7}},{t:this.shape_102},{t:this.shape_76,p:{x:284.95,y:71.925}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_58,p:{x:301.125,y:71.025}},{t:this.shape_51,p:{x:305.125,y:72.05}},{t:this.shape_99},{t:this.shape_98},{t:this.shape_47,p:{x:330.05,y:71.975}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_41,p:{x:307.975,y:80.625}},{t:this.shape_39,p:{x:311.925,y:81.525}},{t:this.shape_92},{t:this.shape_78,p:{x:321.625,y:81}},{t:this.shape_70,p:{x:325.15,y:81.525}},{t:this.shape_91}]},115).to({state:[]},115).to({state:[{t:this.shape_90},{t:this.shape_89},{t:this.shape_88,p:{x:163.475,y:71.1}},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79,p:{x:208.725,y:70.725}},{t:this.shape_78,p:{x:211.575,y:71.1}},{t:this.shape_77},{t:this.shape_76,p:{x:220.6,y:71.625}},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70,p:{x:191.95,y:81.225}},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66,p:{x:30.325,y:75.625}},{t:this.shape_65},{t:this.shape_64,p:{x:39.15,y:76.475}},{t:this.shape_63},{t:this.shape_62,p:{x:48.3,y:75.6}},{t:this.shape_61,p:{x:55.375,y:75.6}},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{x:70.575,y:75.525}},{t:this.shape_57,p:{x:74.575,y:76.425}},{t:this.shape_56,p:{x:79.95,y:76.475}},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:277.375,y:76.55}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48,p:{x:291.7,y:76.475}},{t:this.shape_47,p:{x:297.2,y:76.475}},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:324.6,y:75.6}},{t:this.shape_41,p:{x:327.075,y:75.525}},{t:this.shape_40},{t:this.shape_39,p:{x:336.225,y:76.425}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[{t:this.shape_61,p:{x:150.975,y:71.1}},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_64,p:{x:178.65,y:71.975}},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_48,p:{x:186.4,y:81.575}},{t:this.shape_121},{t:this.shape_79,p:{x:193.775,y:80.625}},{t:this.shape_57,p:{x:197.775,y:81.525}},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_66,p:{x:62.125,y:71.125}},{t:this.shape_113},{t:this.shape_56,p:{x:73.2,y:71.975}},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_88,p:{x:63.175,y:81}},{t:this.shape_104},{t:this.shape_103},{t:this.shape_62,p:{x:78.5,y:80.7}},{t:this.shape_42,p:{x:80.95,y:80.7}},{t:this.shape_102},{t:this.shape_76,p:{x:284.95,y:71.925}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_58,p:{x:301.125,y:71.025}},{t:this.shape_51,p:{x:305.125,y:72.05}},{t:this.shape_99},{t:this.shape_98},{t:this.shape_47,p:{x:330.05,y:71.975}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_41,p:{x:307.975,y:80.625}},{t:this.shape_39,p:{x:311.925,y:81.525}},{t:this.shape_92},{t:this.shape_78,p:{x:321.625,y:81}},{t:this.shape_70,p:{x:325.15,y:81.525}},{t:this.shape_91}]},115).to({state:[]},115).to({state:[{t:this.shape_90},{t:this.shape_89},{t:this.shape_88,p:{x:163.475,y:71.1}},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79,p:{x:208.725,y:70.725}},{t:this.shape_78,p:{x:211.575,y:71.1}},{t:this.shape_77},{t:this.shape_76,p:{x:220.6,y:71.625}},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70,p:{x:191.95,y:81.225}},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66,p:{x:30.325,y:75.625}},{t:this.shape_65},{t:this.shape_64,p:{x:39.15,y:76.475}},{t:this.shape_63},{t:this.shape_62,p:{x:48.3,y:75.6}},{t:this.shape_61,p:{x:55.375,y:75.6}},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{x:70.575,y:75.525}},{t:this.shape_57,p:{x:74.575,y:76.425}},{t:this.shape_56,p:{x:79.95,y:76.475}},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:277.375,y:76.55}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48,p:{x:291.7,y:76.475}},{t:this.shape_47,p:{x:297.2,y:76.475}},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:324.6,y:75.6}},{t:this.shape_41,p:{x:327.075,y:75.525}},{t:this.shape_40},{t:this.shape_39,p:{x:336.225,y:76.425}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},105).to({state:[{t:this.shape_61,p:{x:150.975,y:71.1}},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_64,p:{x:178.65,y:71.975}},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_48,p:{x:186.4,y:81.575}},{t:this.shape_121},{t:this.shape_79,p:{x:193.775,y:80.625}},{t:this.shape_57,p:{x:197.775,y:81.525}},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_66,p:{x:62.125,y:71.125}},{t:this.shape_113},{t:this.shape_56,p:{x:73.2,y:71.975}},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_88,p:{x:63.175,y:81}},{t:this.shape_104},{t:this.shape_103},{t:this.shape_62,p:{x:78.5,y:80.7}},{t:this.shape_42,p:{x:80.95,y:80.7}},{t:this.shape_102},{t:this.shape_76,p:{x:284.95,y:71.925}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_58,p:{x:301.125,y:71.025}},{t:this.shape_51,p:{x:305.125,y:72.05}},{t:this.shape_99},{t:this.shape_98},{t:this.shape_47,p:{x:330.05,y:71.975}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_41,p:{x:307.975,y:80.625}},{t:this.shape_39,p:{x:311.925,y:81.525}},{t:this.shape_92},{t:this.shape_78,p:{x:321.625,y:81}},{t:this.shape_70,p:{x:325.15,y:81.525}},{t:this.shape_91}]},115).to({state:[]},115).wait(99));

	// pc11
	this.instance_5 = new lib.pc11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.45,-10.1,0.9813,0.9813);
	this.instance_5._off = true;

	this.instance_6 = new lib.pc111();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-0.45,-10.1,0.9813,0.9813);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105).to({_off:false},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true,regX:0,regY:0,x:-0.45,y:-10.1},1).wait(220).to({_off:false},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true,regX:0,regY:0,x:-0.45,y:-10.1},1).wait(220).to({_off:false},0).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true,regX:0,regY:0,x:-0.45,y:-10.1},1).wait(214));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(219).to({_off:false},1).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(219).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},1).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(219).to({_off:false,regX:0,regY:0,x:-0.45,y:-10.1},1).to({regX:-0.1,regY:-0.1,x:-0.1,y:-33.75},114).to({_off:true},1).wait(99));

	// Слой_3
	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_139.setTransform(364,45);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("rgba(255,255,255,0.898)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_140.setTransform(364,45);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("rgba(255,255,255,0.8)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_141.setTransform(364,45);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("rgba(255,255,255,0.698)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_142.setTransform(364,45);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_143.setTransform(364,45);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("rgba(255,255,255,0.502)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_144.setTransform(364,45);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("rgba(255,255,255,0.4)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_145.setTransform(364,45);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("rgba(255,255,255,0.302)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_146.setTransform(364,45);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_147.setTransform(364,45);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_148.setTransform(364,45);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_149.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_139}]}).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[]},1).to({state:[{t:this.shape_139}]},324).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[]},1).to({state:[{t:this.shape_139}]},324).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[]},1).to({state:[]},324).wait(99));

	// Слой_6
	this.instance_7 = new lib.icons();
	this.instance_7.parent = this;
	this.instance_7.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({_off:false},0).to({alpha:1},6).to({_off:true},95).wait(234).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(234).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(329));

	// screen21.jpg - копия
	this.instance_8 = new lib.pc21("synched",15);
	this.instance_8.parent = this;
	this.instance_8.setTransform(306.45,99.45,0.71,0.71,0,0,0,296,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(230).to({_off:false,y:99.45,startPosition:15},0).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(230).to({_off:false,y:99.45,startPosition:15},0).to({y:65.45,startPosition:119},104).to({_off:true},1).wait(329));

	// Слой_1
	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_150.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_150).wait(670).to({_off:true},335).wait(99));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728.5,198.9);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_B2B_atlas_P_.png", id:"728x90_B2B_atlas_P_"},
		{src:"images/728x90_B2B_atlas_NP_.jpg", id:"728x90_B2B_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;