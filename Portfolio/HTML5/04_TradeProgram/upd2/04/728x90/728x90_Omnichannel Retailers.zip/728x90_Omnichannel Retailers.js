(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_Omnichannel Retailers_atlas_P_", frames: [[0,0,143,51]]},
		{name:"728x90_Omnichannel Retailers_atlas_NP_", frames: [[641,128,54,44],[529,128,52,49],[583,173,45,40],[529,0,380,126],[583,128,56,43],[426,282,425,254],[0,282,424,280],[0,0,527,280]]}
];


// symbols:



(lib.Растровоеизображение11 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение12 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение13 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение16 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.logoblack = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen111111111 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.screen2111111 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.screen311 = function() {
	this.initialize(ss["728x90_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQACAFAEADQADADAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFADgCADQgDADgCAFIgCAIIAtAAIgBgIQgCgEgCgEQgDgDgEgDQgFgCgGAAQgEAAgEACg");
	this.shape.setTransform(599.05,-105.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAGgDQAFgEADgEIAAgyIALAAIAABFIgLAAIAAgKQgEAFgHADQgGAEgHAAQgLAAgGgFg");
	this.shape_1.setTransform(590.95,-104.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_2.setTransform(585.325,-106.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMABgJAJIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMADQgFAEAAAHQAAAGAFAEQAEAFAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIAAgEAEg");
	this.shape_3.setTransform(579.675,-105.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_4.setTransform(572.5,-105.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_5.setTransform(563.2,-105.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAFADADQAEADAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEADgDADQgDADgBAFIgBAIIAsAAIgBgIQgCgEgDgEQgCgDgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_6.setTransform(556.35,-105.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgFAjIgdhFIAMAAIAWA5IAXg5IAMAAIgdBFg");
	this.shape_7.setTransform(548.7,-105.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_8.setTransform(543.525,-106.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_9.setTransform(540.275,-106.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAGgDQAHgDAHAAQAIAAAFADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQADAFADADQADADAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgJgZQgEADgCADQgEADgBAFIgCAIIAtAAIgBgIQgBgEgEgEQgCgDgEgDQgFgCgGAAQgEAAgFACg");
	this.shape_10.setTransform(534.6,-105.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_11.setTransform(526.125,-106.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFABAFQgBAGACAEQACAFACAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgEAAgGQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_12.setTransform(514.25,-105.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEApQgDgEgBgIIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACACAEABIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_13.setTransform(508,-105.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_14.setTransform(497.725,-106.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAFgFQAEgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFACAEQACAFAEADQADADAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFADgCADQgDADgCAFIgCAIIAtAAIgBgIQgCgEgCgEQgDgDgEgDQgFgCgGAAQgEAAgEACg");
	this.shape_15.setTransform(489.7,-105.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgFACIgGADIgDAFIAAAyIgLAAIAAhFIALAAIAAAKIAEgEIAGgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_16.setTransform(481.6,-105.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_17.setTransform(473.225,-103.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_18.setTransform(467.625,-106.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgEQAEgDAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgCgDgDQgDgEAAgHQAAgEACgDQABgEAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEAEAAAEQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADAEAAAGQAAAFgCAEQgCAEgDADQgEADgFABQgFACgHAAQgHAAgHgDg");
	this.shape_19.setTransform(462.525,-105.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAFAEADQADADAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEADgDADQgCADgCAFIgBAIIAsAAIgBgIQgCgEgDgEQgCgDgFgDQgEgCgGAAQgEAAgFACg");
	this.shape_20.setTransform(455.2,-105.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_21.setTransform(446.725,-106.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgEQAEgDAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgCgDgDQgDgEAAgHQAAgEACgDQABgEAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEAEAAAEQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADAEAAAGQAAAFgCAEQgCAEgDADQgEADgFABQgFACgHAAQgHAAgHgDg");
	this.shape_22.setTransform(435.525,-105.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAFAEADQADADAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEADgDADQgCADgCAFIgBAIIAsAAIgBgIQgCgEgDgEQgCgDgFgDQgEgCgGAAQgEAAgFACg");
	this.shape_23.setTransform(428.2,-105.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAGQgEAGgGADQgGAEgJAAQgHAAgHgDg");
	this.shape_24.setTransform(420.625,-105.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_25.setTransform(415.275,-106.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgFAjIgdhFIAMAAIAWA5IAXg5IAMAAIgdBFg");
	this.shape_26.setTransform(410.1,-105.05);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_27.setTransform(404.55,-105.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAFADQAHADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAFAEADQADADAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEADgCADQgEADgBAFIgBAIIAsAAIgBgIQgBgEgEgEQgCgDgEgDQgFgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(397.7,-105.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgEQAEgDAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgCgDgDQgDgEAAgHQAAgEACgDQABgEAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEAEAAAEQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADAEAAAGQAAAFgCAEQgCAEgDADQgEADgFABQgFACgHAAQgHAAgHgDg");
	this.shape_29.setTransform(390.125,-105.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgXAwQgFgCgEgDQgEgDgCgFQgDgGAAgGQAAgGACgFQABgEADgDIAIgFIAIgFIgGgLQgCgGAAgEQAAgGACgDQACgFADgDQADgDAFgCQAEgBAGAAIAIABIAGAEQADACACAEQABAEAAAEQABAFgDAEQgCAFgEACIgHAGIgJAFIAGAGIAFAHIAFAHIAHAGIAGgMIAEgKIAJAEIgGAMQgDAHgEAFIAJAJIAKAKIgPAAIgFgEIgGgGQgFAFgHADQgGAEgIAAQgHAAgGgCgAgZAKQgEAFAAAHQAAAEACAEQABADADADQACADAEAAQAEACAEAAQAFAAAEgDQAFgDAEgEIgHgIIgEgGIgHgHIgGgJQgGAEgEAFgAgIgoIgDAEQgCABgCADIgBAGIACAIIAFAIIAHgEIAEgEIAFgGQABgCABgEQgBgFgDgDQgDgCgEgBIgGABg");
	this.shape_30.setTransform(378.5,-106.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgEQAEgDAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgCgDgDQgDgEAAgHQAAgEACgDQABgEAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEAEAAAEQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADAEAAAGQAAAFgCAEQgCAEgDADQgEADgFABQgFACgHAAQgHAAgHgDg");
	this.shape_31.setTransform(366.575,-105.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEApQgDgEAAgIIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACACAEABIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_32.setTransform(361.2,-105.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAGQgEAGgGADQgGAEgJAAQgHAAgHgDg");
	this.shape_33.setTransform(355.575,-105.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAGgDQAFgEADgEIAAgyIALAAIAABFIgLAAIAAgKQgEAFgHADQgGAEgHAAQgLAAgFgFg");
	this.shape_34.setTransform(347.85,-104.95);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_35.setTransform(339.475,-106.275);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgDgIAAgHQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgDAEgBAEQgBAFAAAFQAAAGABAEQABAFADAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgEAAgGQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_36.setTransform(331.35,-105.05);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_37.setTransform(325.2,-105.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AghAwIAAhfIAlAAQAHAAAGACQAFACAEAEQAFAEACAFQABAGAAAGQAAAGgBAFQgCAFgFADQgEAEgFACQgGADgHAAIgZAAIAAAmgAgVAAIAYAAQAJAAAEgFQAGgFAAgIQAAgJgGgFQgEgFgJAAIgYAAg");
	this.shape_38.setTransform(318.5,-106.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t22, new cjs.Rectangle(311.8,-115,293.40000000000003,18.5), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgFAGQgCgDAAgDQAAgDACgCQADgCACAAQAEAAACACQACACAAADQAAADgCADQgCACgEAAQgCAAgDgCg");
	this.shape.setTransform(568.65,-102.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgEQAEgDAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgCgDgDQgDgEAAgHQAAgEACgDQABgEAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEAEAAAEQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADAEAAAGQAAAFgCAEQgCAEgDADQgEADgFABQgFACgHAAQgHAAgHgDg");
	this.shape_1.setTransform(563.525,-105.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAHABQAFAAAFgDQAGgEADgEIAAgyIALAAIAABFIgLAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgGgFg");
	this.shape_2.setTransform(556.25,-104.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAGQgEAGgGADQgGAEgJAAQgHAAgHgDg");
	this.shape_3.setTransform(548.775,-105.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgEACgDAEQgEAEgBAEQgCAFABAFQgBAGACAEQABAFAEAEQADADAEADQAFACAEAAQAFAAAFgCIAHgGQADgEACgFQABgEAAgGQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_4.setTransform(540.9,-105.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgLAxIAAg8IgLAAIAAgJIALAAIAAgFQAAgMAGgFQAFgGAIAAIAIABQAEABADADIgEAIIgEgEIgFAAQgFAAgDAEQgCADAAAHIAAAFIANAAIAAAJIgNAAIAAA8g");
	this.shape_5.setTransform(535.225,-106.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_6.setTransform(526.9,-105.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgEIAAgyIALAAIAABFIgLAAIAAgKQgEAFgHADQgGAEgHAAQgLAAgFgFg");
	this.shape_7.setTransform(520.1,-104.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIABgHQgBgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAFAFQAEAFACAHQADAGAAAHQAAAHgDAIQgCAGgEAFQgFAFgHADQgGADgIAAQgHAAgHgDgAgJgYQgEACgDAEQgDAEgCAEQgBAFgBAFQABAGABAEQACAFADAEQADADAEADQAFACAEAAQAGAAAEgCIAHgGQADgEABgFQACgEAAgGQAAgFgCgFQgBgEgDgEIgHgGQgEgCgGAAQgEAAgFACg");
	this.shape_8.setTransform(511.95,-105.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgXAxIgFgBIACgKIADABIADAAQAEAAACgBQADgCABgEIAFgLIgdhFIALAAIAXA4IAXg4IAMAAIgjBTQgCAIgFADQgGADgHAAIgDAAg");
	this.shape_9.setTransform(500.5,-103.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_10.setTransform(492.575,-103.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAFAEADQADADAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEADgCADQgEADgBAFIgBAIIAsAAIgBgIQgBgEgEgEQgCgDgEgDQgFgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(484.55,-105.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgEApQgDgEAAgIIAAgtIgMAAIAAgJIAMAAIAAgTIAKAAIAAATIANAAIAAAJIgNAAIAAArQgBAEACACQACACAEABIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_12.setTransform(478.35,-105.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMABgJAJIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMADQgFAEAAAHQAAAGAFAEQAEAFAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIAAgEAEg");
	this.shape_13.setTransform(472.175,-105.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_14.setTransform(466.55,-105.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgEApQgEgEAAgIIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACACAEABIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_15.setTransform(461.65,-105.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgEQAEgDAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgCgDgDQgDgEAAgHQAAgEACgDQABgEAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEAEAAAEQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADAEAAAGQAAAFgCAEQgCAEgDADQgEADgFABQgFACgHAAQgHAAgHgDg");
	this.shape_16.setTransform(456.025,-105.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgEAAIgFABIgGACIgEAEIgEAEIAAAxg");
	this.shape_17.setTransform(447,-105.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAGgDQAFgEADgEIAAgyIALAAIAABFIgLAAIAAgKQgEAFgHADQgGAEgHAAQgLAAgFgFg");
	this.shape_18.setTransform(440.2,-104.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgDAEgBAEQgCAFAAAFQAAAGACAEQABAFADAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgEAAgGQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_19.setTransform(432.05,-105.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgXAxIgFgBIACgKIADABIADAAQAEAAACgBQADgCABgEIAFgLIgdhFIAMAAIAWA4IAXg4IAMAAIgjBTQgCAIgFADQgFADgIAAIgDAAg");
	this.shape_20.setTransform(424.35,-103.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_21.setTransform(412.675,-103.725);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgEgEgIAAIgEABIgHACIgEADQgDADgBACIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAHgBQAWAAAAAXIAAAwg");
	this.shape_22.setTransform(404.7,-105.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_23.setTransform(399.075,-106.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AARAwIgYgfIgMALIAAAUIgLAAIAAhfIALAAIAAA+IAkgkIAOAAIgfAfIAfAmg");
	this.shape_24.setTransform(394.175,-106.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMABgJAJIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMADQgFAEAAAHQAAAGAFAEQAEAFAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIAAgEAEg");
	this.shape_25.setTransform(385.975,-105.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AAjAwIAAhOIghBOIgEAAIgghOIAABOIgMAAIAAhfIARAAIAdBHIAehHIARAAIAABfg");
	this.shape_26.setTransform(376.475,-106.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(368.6,-115,203.89999999999998,18.5), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgVAsQgKgEgHgGIALgQQAFAFAIADQAHAEAJABQAIgBAEgDQAEgDAAgEQAAgEgEgCIgKgEIgMgDIgNgFQgGgCgDgFQgEgFgBgJQABgIAEgGQAEgGAIgFQAIgDAKAAQALAAAJADQAJAEAHAFIgLAQQgGgFgGgDQgIgDgGABQgHgBgDADQgDACAAAFQAAADAEACQAEADAFABIANADQAHABAFAEQAHADADAEQAFAGAAAIQAAAJgFAHQgEAGgIAEQgIAEgNAAQgMAAgKgEg");
	this.shape.setTransform(667.7,-42.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAPAvIgSghIgOAAIAAAhIgUAAIAAhdIArAAQAJAAAIAEQAHAEADAHQAEAHABAIQAAAJgEAFQgCAFgGAEQgEADgFABIAVAkgAgRgDIAUAAQAGAAAEgDQAEgEAAgGQAAgFgEgEQgEgDgGAAIgUAAg");
	this.shape_1.setTransform(659.25,-42.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AggAvIAAhdIBBAAIAAASIgtAAIAAATIAsAAIAAARIgsAAIAAAVIAtAAIAAASg");
	this.shape_2.setTransform(650.625,-42.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAvIAAhdIAUAAIAABLIAnAAIAAASg");
	this.shape_3.setTransform(643.025,-42.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgJAvIAAhdIATAAIAABdg");
	this.shape_4.setTransform(637.25,-42.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAaAvIgGgQIgnAAIgGAQIgXAAIAkhdIAYAAIAkBdgAAOANIgOgnIgOAnIAcAAg");
	this.shape_5.setTransform(630.55,-42.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgJAvIAAhLIgbAAIAAgSIBJAAIAAASIgbAAIAABLg");
	this.shape_6.setTransform(621.675,-42.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AggAvIAAhdIBBAAIAAASIgtAAIAAATIAsAAIAAARIgsAAIAAAVIAtAAIAAASg");
	this.shape_7.setTransform(613.675,-42.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAPAvIgSghIgOAAIAAAhIgUAAIAAhdIArAAQAJAAAIAEQAHAEADAHQAEAHABAIQgBAJgDAFQgCAFgGAEQgEADgFABIAVAkgAgRgDIAUAAQAGAAAEgDQAEgEAAgGQAAgFgEgEQgEgDgGAAIgUAAg");
	this.shape_8.setTransform(605.15,-42.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAvIAAhdIAUAAIAABLIAnAAIAAASg");
	this.shape_9.setTransform(593.475,-42.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AggAvIAAhdIBBAAIAAASIgtAAIAAATIAsAAIAAARIgsAAIAAAVIAtAAIAAASg");
	this.shape_10.setTransform(585.725,-42.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAWAvIgrg8IAAA8IgUAAIAAhdIAVAAIAqA6IAAg6IAUAAIAABdg");
	this.shape_11.setTransform(576.4,-42.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAWAvIgrg8IAAA8IgUAAIAAhdIAUAAIArA6IAAg6IAUAAIAABdg");
	this.shape_12.setTransform(566.2,-42.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAaAvIgGgQIgnAAIgGAQIgXAAIAkhdIAYAAIAkBdgAAOANIgOgnIgOAnIAcAAg");
	this.shape_13.setTransform(556.3,-42.625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAWAvIAAgoIgrAAIAAAoIgUAAIAAhdIAUAAIAAAlIArAAIAAglIAUAAIAABdg");
	this.shape_14.setTransform(546.35,-42.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgTAqQgLgGgHgLQgGgKAAgPQAAgNAGgLQAHgLALgGQALgGANAAQALAAAHADQAIADAFAGQAFAFADAGIgRAIQgDgGgGgEQgFgDgIAAQgHAAgHAEQgGAEgEAGQgEAHAAAIQAAAJAEAHQAEAHAGAEQAHAEAHAAQAIAAAFgEQAGgEADgGIARAIQgDAGgFAGQgFAFgIADQgHADgLAAQgNAAgLgGg");
	this.shape_15.setTransform(536.575,-42.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgJAvIAAhdIATAAIAABdg");
	this.shape_16.setTransform(529.7,-42.625);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAXAvIgsg8IAAA8IgUAAIAAhdIAVAAIAqA6IAAg6IAUAAIAABdg");
	this.shape_17.setTransform(522.7,-42.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAfAvIAAhDIgbBDIgHAAIgbhDIAABDIgUAAIAAhdIAcAAIAWA6IAXg6IAcAAIAABdg");
	this.shape_18.setTransform(511.625,-42.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgYAqQgLgGgHgLQgGgLAAgOQAAgNAGgLQAHgLALgGQALgGANAAQAOAAALAGQALAGAGALQAGALABANQgBAOgGALQgGALgLAGQgLAGgOAAQgNAAgLgGgAgOgZQgHAEgDAGQgDAHgBAIQABAJADAHQADAHAHAEQAGAEAIAAQAJAAAGgEQAGgEAEgHQADgHAAgJQAAgIgDgHQgEgGgGgEQgGgEgJAAQgIAAgGAEg");
	this.shape_19.setTransform(500.325,-42.625);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAWAvIAAgoIgrAAIAAAoIgUAAIAAhdIAUAAIAAAlIArAAIAAglIAUAAIAABdg");
	this.shape_20.setTransform(486.2,-42.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgJAvIAAhLIgbAAIAAgSIBJAAIAAASIgbAAIAABLg");
	this.shape_21.setTransform(477.025,-42.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgJAvIAAhdIATAAIAABdg");
	this.shape_22.setTransform(471,-42.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAQAvIgQg/IgPA/IgVAAIgbhdIAWAAIARBDIARhDIAPAAIASBDIAQhDIAWAAIgaBdg");
	this.shape_23.setTransform(462.675,-42.625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgWAsQgJgEgHgGIALgQQAFAFAIADQAHAEAJABQAIgBAEgDQAEgDAAgEQAAgEgEgCIgKgEIgMgDIgNgFQgGgCgEgFQgDgFAAgJQAAgIADgGQAFgGAIgFQAIgDAKAAQALAAAJADQAKAEAGAFIgLAQQgFgFgIgDQgHgDgGABQgGgBgEADQgDACAAAFQAAADAEACQADADAHABIALADQAIABAFAEQAGADAFAEQADAGABAIQgBAJgDAHQgFAGgIAEQgJAEgMAAQgNAAgKgEg");
	this.shape_24.setTransform(448.4,-42.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAQAvIgbgmIgIAJIAAAdIgUAAIAAhdIAUAAIAAAqIAggqIAYAAIglAsIAoAxg");
	this.shape_25.setTransform(440.25,-42.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAPAvIgRghIgPAAIAAAhIgUAAIAAhdIArAAQAKAAAGAEQAIAEAEAHQADAHAAAIQAAAJgCAFQgDAFgFAEQgFADgFABIAVAkgAgRgDIAUAAQAGAAAEgDQAEgEAAgGQAAgFgEgEQgEgDgGAAIgUAAg");
	this.shape_26.setTransform(431.05,-42.625);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgYAqQgLgGgHgLQgGgLAAgOQAAgNAGgLQAHgLALgGQALgGANAAQAOAAALAGQALAGAGALQAGALABANQgBAOgGALQgGALgLAGQgLAGgOAAQgNAAgLgGgAgOgZQgHAEgDAGQgDAHgBAIQABAJADAHQADAHAHAEQAGAEAIAAQAJAAAGgEQAGgEAEgHQADgHAAgJQAAgIgDgHQgEgGgGgEQgGgEgJAAQgIAAgGAEg");
	this.shape_27.setTransform(421.025,-42.625);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAQAvIgQg/IgPA/IgVAAIgbhdIAWAAIARBDIARhDIAPAAIASBDIAQhDIAWAAIgaBdg");
	this.shape_28.setTransform(409.225,-42.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgOAZQgHgEgEgGQgEgHAAgIQAAgIAEgGQAEgHAHgDQAHgFAHAAQAIAAAHAFQAHADADAHQAEAGABAIQgBAIgEAHQgDAGgHAEQgHAFgIAAQgHAAgHgFgAgMgVQgGADgDAGQgDAGAAAGQAAAHADAFQADAGAGADQAGAEAGAAQAHAAAGgEQAFgDAEgGQADgFAAgHQAAgGgDgGQgEgGgFgDQgGgDgHAAQgGAAgGADgAAIARIgIgOIgGAAIAAAOIgFAAIAAghIANAAQAFAAADADQADADAAAFQAAADgBACIgEADIgDAAIAJAOgAgGAAIAIAAQABAAAAAAQABAAABAAQAAgBABAAQAAAAABgBIACgDQAAgBgBgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBgBgBAAQAAAAgBAAIgIAAg");
	this.shape_29.setTransform(395.775,-44.45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AggAvIAAhdIBBAAIAAASIgtAAIAAATIAsAAIAAARIgsAAIAAAVIAtAAIAAASg");
	this.shape_30.setTransform(388.375,-42.625);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgTAqQgLgGgHgKQgHgLABgPQgBgOAHgLQAHgKALgGQALgGANAAQAKAAAHADQAIADAFAEIAIALIgQAJQgDgFgGgEQgGgDgHAAQgIAAgGAEQgGADgFAHQgDAHAAAIQAAAJADAHQAFAHAGAEQAGAEAIAAQAGAAAFgDQAGgCADgCIAAgMIgZAAIAAgQIAtAAIAAAjQgIAIgJAFQgKAEgNAAQgNAAgLgGg");
	this.shape_31.setTransform(379,-42.625);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAaAvIgGgQIgnAAIgGAQIgWAAIAkhdIAYAAIAkBdgAAPANIgPgnIgNAnIAcAAg");
	this.shape_32.setTransform(369.25,-42.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAQAvIgQg/IgPA/IgVAAIgbhdIAWAAIARBDIARhDIAPAAIASBDIAQhDIAWAAIgaBdg");
	this.shape_33.setTransform(358.025,-42.625);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AggAvIAAhdIBBAAIAAASIgtAAIAAATIAsAAIAAARIgsAAIAAAVIAtAAIAAASg");
	this.shape_34.setTransform(347.675,-42.625);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AAWAvIgrg8IAAA8IgUAAIAAhdIAVAAIAqA6IAAg6IAUAAIAABdg");
	this.shape_35.setTransform(338.35,-42.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(331.2,-51,342.90000000000003,18), null);


(lib.PC33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.PC33, new cjs.Rectangle(0,0,380,126), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen2111111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,424,280);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen111111111();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,425,254), null);


(lib.pc3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen311();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc3, new cjs.Rectangle(0,0,527,280), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgLgDQgGgCgDgEQgDgDAAgHIABgIQADgEADgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAJADIALADQAFACADAEQAEAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgHAAgIgDg");
	this.shape.setTransform(16.9,45.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQACACAEAAIAGABQAGAAAFgDQAGgEADgEIAAg0IAMAAIAABHIgMAAIAAgKQgEAFgGADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(9.4,45.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgEgCgDQgBgDgCgCQgCgCgDgBIgGAAIgGAAIgGADIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgCQAMAAAFAHQAGAFAAAMIAAAyg");
	this.shape_2.setTransform(-2.8,44.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_3.setTransform(-9.125,44.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhIIAJAAIAABIgAgEgjQgCgCAAgDQAAgDACgCQACgDACAAQADAAACADQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(-13.05,44.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(-20.225,45.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAqQgEgEAAgIIAAgvIgMAAIAAgKIAMAAIAAgTIALAAIAAATIAOAAIAAAKIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCADgEAAQgDACgFAAQgHAAgEgFg");
	this.shape_6.setTransform(-31.825,44.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(-37.675,45.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(-45.725,45.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(-54.1,45.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(-62.4,45.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(-70.875,45.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgMAwQgKgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAKgDQAJgEAKAAQAGAAAGACIAKAEQAFACADAEIAHAIIgKAGQgEgHgHgEQgIgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAIgEQAHgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgJgEg");
	this.shape_12.setTransform(-80.05,44.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApJCAQgqAAAAgqIAAirQAAgqAqAAISUAAQApAAAAAqIAACrQAAAqgpAAg");
	this.shape_13.setTransform(-32.4,44.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-95.2,32,125.6,25.700000000000003), null);


(lib.biglogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logoblack();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6129,0.6129);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.biglogo, new cjs.Rectangle(0,0,87.7,31.3), null);


(lib._8AssortmentSelection = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение13();
	this.instance.parent = this;
	this.instance.setTransform(-23,-20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._8AssortmentSelection, new cjs.Rectangle(-23,-20,45,40), null);


(lib._7CustomPrograms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение12();
	this.instance.parent = this;
	this.instance.setTransform(-26,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._7CustomPrograms, new cjs.Rectangle(-26,-23,52,49), null);


(lib._5Multiple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение11();
	this.instance.parent = this;
	this.instance.setTransform(-28,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._5Multiple, new cjs.Rectangle(-28,-23,54,44), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgHAWQgFgCgDgCQgDgEgCgEQgBgEAAgGQAAgEABgEQACgFADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAAEIAAABIgkAAIACAHIADAEIAFAEQADABADABQAEAAADgCQAEgCADgDIADAFQgDADgFACQgEACgGAAQgEAAgEgCgAgFgPIgFADIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgCgDgBQgDgCgEAAQgCAAgDACg");
	this.shape.setTransform(86.425,-54.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAgIAAg/IAGAAIAAA/g");
	this.shape_1.setTransform(82.65,-55.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgHAeQgEgCgCgEIAAAHIgHAAIAAg+IAHAAIAAAYQACgEAEgCQAFgCADAAIAIACIAHAFQADADABAEQACAEAAAFQAAAGgCAEIgEAIQgDADgEACIgIABQgDAAgFgCgAgIgGQgEACgBADIAAAUQABADAEACQAEACAEAAQADAAADgBIAEgEQADgCABgEIABgHIgBgHQgBgCgDgCIgEgEIgGgBQgEAAgEACg");
	this.shape_2.setTransform(79,-55.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgIAXQgDAAgCgDIgEgFQgBgDAAgDQAAgEABgDIAEgEIAFgDIAGAAQAEAAADABQAEACADACIAAgHQAAgFgDgDQgDgCgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEABACABIAEAFQABADAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDADAAAEQAAAFADACQADADAFAAQADAAAEgBIAFgFIAAgJIgFgDQgEgBgDAAQgFAAgDACg");
	this.shape_3.setTransform(73.525,-54.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgDAgIAAg/IAGAAIAAA/g");
	this.shape_4.setTransform(70.05,-55.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_5.setTransform(67.925,-55.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgIAXQgDAAgCgDIgEgFQgBgDAAgDQAAgEABgDIAEgEIAFgDIAGAAQAEAAADABQAEACADACIAAgHQAAgFgDgDQgDgCgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEABACABIAEAFQABADAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDADAAAEQAAAFADACQADADAFAAQADAAAEgBIAFgFIAAgJIgFgDQgEgBgDAAQgFAAgDACg");
	this.shape_6.setTransform(64.225,-54.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgDAXIgTgtIAIAAIAOAkIAPgkIAIAAIgTAtg");
	this.shape_7.setTransform(59.525,-54.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgIAXQgDAAgCgDIgEgFQgBgDAAgDQAAgEABgDIAEgEIAFgDIAGAAQAEAAADABQAEACADACIAAgHQAAgFgDgDQgDgCgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEABACABIAEAFQABADAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDADAAAEQAAAFADACQADADAFAAQADAAAEgBIAFgFIAAgJIgFgDQgEgBgDAAQgFAAgDACg");
	this.shape_8.setTransform(54.575,-54.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgJAWQgFgCgDgDIADgFQADACAEADQAEACAEAAQAFgBADgCQACgCAAgDQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAgBgBIgFgCIgGgCIgHgCIgFgDQgCgDAAgEIABgFQABgDACgBIAFgDIAHgBQAGAAAEACQAFACACADIgEAEQgCgCgDgBQgDgCgFAAQgEAAgDACQgCACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAIAFACIAGABIAHADIAFADQACADABAFIgCAEQgBAEgDABQgCACgDABIgIABQgEAAgFgCg");
	this.shape_9.setTransform(47.55,-54.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAMAYIAAgeQAAgGgDgCQgDgCgEAAIgDAAIgEACIgEACIgBADIAAAhIgIAAIAAgtIAIAAIAAAGIACgDIAEgCIAEgCIAFAAQAOAAAAAOIAAAgg");
	this.shape_10.setTransform(42.8,-54.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgJAWQgEgCgDgDQgDgDgBgEQgCgFAAgFQAAgEACgEQABgFADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAIQACAEAAAEQAAAFgCAFIgEAHQgDADgFACQgEACgFAAQgEAAgFgCgAgGgPIgEADIgDAGIgBAGIABAHIADAFIAEAFQADABADAAQAEAAACgBIAFgFIADgFIABgHIgBgGIgDgGIgFgDQgCgCgEABQgDgBgDACg");
	this.shape_11.setTransform(37.475,-54.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_12.setTransform(33.675,-55.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQABAAAAAAQABAAAAABQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_13.setTransform(31.225,-54.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgVAgIAAg+IAIAAIAAAHQACgEAFgCQAEgCAEAAQAEAAAEABQAEACACADQADADABAFQACAEgBAGQABAFgCAEQgBAEgDADQgCAEgEABQgEACgEAAQgEAAgEgCQgEgCgDgEIAAAYgAgHgXQgFACgBADIAAAUQABADAFACQADADAEAAQADAAACgCIAGgEIACgEIABgHIgBgHIgCgGIgGgEIgFgBQgEAAgDACg");
	this.shape_14.setTransform(27.2,-53.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgJAWQgEgCgDgDQgDgDgBgEQgCgFAAgFQAAgEACgEQABgFADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAIQACAEAAAEQAAAFgCAFIgEAHQgDADgFACQgEACgFAAQgEAAgFgCgAgGgPIgEADIgDAGIgBAGIABAHIADAFIAEAFQADABADAAQAEAAACgBIAFgFIADgFIABgHIgBgGIgDgGIgFgDQgCgCgEABQgDgBgDACg");
	this.shape_15.setTransform(21.625,-54.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_16.setTransform(89.025,-64.325);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAMAXIAAgcQAAgGgDgDQgCgCgFAAIgDABIgEABIgDACIgCADIAAAgIgIAAIAAgtIAIAAIAAAIIACgDIAEgDIAEgCIAEgBQAPABAAAPIAAAeg");
	this.shape_17.setTransform(85,-63.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgHAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAADIAAACIgkAAIACAGIADAGIAFADQADACADgBQAEAAADgCQAEgBADgCIADAEQgDAEgFACQgEABgGAAQgEAAgEgBgAgFgQIgFAEIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDgBQgDgBgEAAQgCAAgDABg");
	this.shape_18.setTransform(79.725,-63.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAYAXIAAgdQAAgFgCgDQgCgCgEAAQgEAAgDACQgEACgBADIAAAgIgHAAIAAgdQAAgFgBgDQgCgCgFAAQgDAAgEACQgDACgCADIAAAgIgHAAIAAgtIAHAAIAAAIIACgDIAEgDIAEgCIAFgBQAFABADACQACACABAEIADgDIADgDIAFgCIAFgBQAGABADADQADADAAAIIAAAfg");
	this.shape_19.setTransform(73.175,-63.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgPAgIgDAAIABgHIACABIACAAIAEgBIADgEIADgHIgTgtIAIAAIAOAkIAPgkIAIAAIgXA2QgBAFgDACQgEACgEAAIgDAAg");
	this.shape_20.setTransform(67.025,-62.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgIAXQgDAAgCgDIgEgEQgBgDAAgEQAAgEABgDIAEgDIAFgDIAGgBQAEAAADACQAEABADACIAAgHQAAgFgDgDQgDgCgGAAQgHAAgGAHIgDgGQAHgHAKAAIAHABQAEABACACIAEAEQABAEAAADIAAAfIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQADADAFAAQADAAAEgCIAFgDIAAgJIgFgFQgEAAgDAAQgFAAgDACg");
	this.shape_21.setTransform(62.075,-63.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgUAgIAAg+IAHAAIAAAHQACgEAEgCQAEgCAEAAQAFAAADABQAEACADADQADADABAFQABAEAAAGQAAAFgBAEQgBAEgDADQgDAEgEABQgDACgFAAQgEAAgEgCQgDgCgDgEIAAAYgAgIgXQgDACgCADIAAAUQACADADACQAEADAEAAQADAAADgCIAEgEIADgEIABgHIgBgHIgDgGIgEgEIgGgBQgEAAgEACg");
	this.shape_22.setTransform(57.1,-62.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgHAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAADIAAACIgkAAIACAGIADAGIAFADQADACADgBQAEAAADgCQAEgBADgCIADAEQgDAEgFACQgEABgGAAQgEAAgEgBgAgFgQIgFAEIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDgBQgDgBgEAAQgCAAgDABg");
	this.shape_23.setTransform(49.175,-63.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgCAgIAAg/IAFAAIAAA/g");
	this.shape_24.setTransform(45.4,-64.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgVAgIAAg+IAIAAIAAAHQACgEAFgCQADgCAFAAQAEAAADABQAEACADADQADADABAFQABAEABAGQgBAFgBAEQgBAEgDADQgDAEgEABQgDACgEAAQgFAAgDgCQgEgCgDgEIAAAYgAgIgXQgEACgBADIAAAUQABADAEACQAEADAEAAQADAAACgCIAGgEIACgEIABgHIgBgHIgCgGIgGgEIgFgBQgEAAgEACg");
	this.shape_25.setTransform(41.75,-62.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_26.setTransform(37.825,-64.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_27.setTransform(35.375,-64.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_28.setTransform(32.85,-64.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAUQgEgDAAgIIAAggIAIAAIAAAeIAAAFIACADIADACIAFABQACAAAFgDIAFgEIAAgiIAHAAIAAAtIgHAAIAAgGQgCADgFACQgEACgEAAQgIABgDgEg");
	this.shape_29.setTransform(29.2,-63.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAXAgIAAgzIgWAzIgCAAIgVgzIAAAzIgIAAIAAg/IALAAIATAvIATgvIAMAAIAAA/g");
	this.shape_30.setTransform(22.75,-64.625);

	this.instance = new lib._5Multiple();
	this.instance.parent = this;
	this.instance.setTransform(1,-57,0.4,0.4,0,0,0,0.7,0.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AANAZIAAgfQAAgGgDgDQgDgCgFAAIgEABIgDABIgEADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIADgCIAFgDIAEgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_31.setTransform(109.35,-80.625);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgJAXQgEgCgEgDQgDgDgBgFQgCgFAAgFQAAgEACgFQABgEADgEQAEgDAEgCQAEgCAFAAQAGAAAEACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgDAFgDADQgDADgEACQgEACgGAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_32.setTransform(103.75,-80.575);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_33.setTransform(99.775,-81.425);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_34.setTransform(97.225,-81.175);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgCgEgDgBQgEgCgEAAQgDAAgCACQgDABgCADIgEAGIgBAGIABAIIAEAFQACADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_35.setTransform(93.35,-80.575);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgCgEAAgGQAAgEACgFIAGgIQADgDAEgCQAFgCAEAAQAFAAAFACQADACAEADQADAEABAFQABAEAAAFIAAACIglAAIABAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgGgRIgFAEIgCAFIgBAGIAfAAIgCgGIgDgFIgEgEQgEgBgDAAQgEAAgDABg");
	this.shape_36.setTransform(87.95,-80.575);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgDAhIAAhBIAHAAIAABBg");
	this.shape_37.setTransform(84.025,-81.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgDgEAAgGQAAgEADgFIAEgIQADgDAFgCQAFgCADAAQAGAAAEACQAEACAEADQADAEABAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgDgBgFAAQgDAAgDABg");
	this.shape_38.setTransform(80.05,-80.575);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgNAfQgHgCgEgFIAEgGIAFADIAEADIAGACIAGABQAEAAADgBIAFgDQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIABgDQAAgEgCgCIgDgDIgHgDIgHgCIgHgCIgGgCIgFgFQgBgDAAgFQAAgEABgDIAGgGIAHgEIAIgBQAIAAAFACQAHACADAFIgEAGQgFgEgEgCQgGgCgEAAQgGAAgEADQgEADABAFQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAIAFADIAGADIAGACIAHACIAHADIAEAFQACADAAAFIgCAHQgBAEgCACQgDADgFACQgFABgGAAQgJAAgFgDg");
	this.shape_39.setTransform(74.35,-81.475);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_40.setTransform(67.425,-81.175);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAMAZIAAgfQAAgGgCgDQgDgCgFAAIgEABIgEABIgDADIgDACIAAAjIgHAAIAAgwIAHAAIAAAHIAEgCIADgDIAFgCIAEgBQAQAAAAAQIAAAhg");
	this.shape_41.setTransform(63.2,-80.625);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgHAYQgFgCgDgEQgEgDgCgFQgBgEAAgGQAAgEABgFIAGgIQADgDAEgCQAEgCAFAAQAFAAAFACQADACADADQAEAEABAFQACAEgBAFIAAACIglAAIABAGIADAFQADADADABQADABADAAIAIgBQAEgCADgDIAEAFQgEAEgFACQgFABgFAAQgFAAgEgBgAgFgRIgGAEIgCAFIgBAGIAeAAIgBgGIgCgFIgGgEQgDgBgDAAQgEAAgCABg");
	this.shape_42.setTransform(57.6,-80.575);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AAZAZIAAggQABgFgDgCQgCgDgFAAQgEAAgDACQgDACgCADIAAAjIgHAAIAAggQAAgFgCgCQgCgDgFAAQgEAAgDACIgFAFIAAAjIgIAAIAAgwIAIAAIAAAHIACgCIADgDIAFgCIAFgBQAGAAADADQACACABAEIADgDIADgDIAFgCIAGgBQAGAAAEAEQADAEAAAHIAAAig");
	this.shape_43.setTransform(50.75,-80.625);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_44.setTransform(45.275,-81.175);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_45.setTransform(42.425,-80.625);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AgJAXQgEgCgDgDQgDgDgCgFQgCgFAAgFQAAgEACgFQACgEADgEQADgDAEgCQAFgCAEAAQAGAAAEACQAFACADADIAEAIQACAFAAAEQAAAFgCAFQgCAFgCADQgDADgFACQgEACgGAAQgEAAgFgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_46.setTransform(37.65,-80.575);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_47.setTransform(32.425,-80.575);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDIAEgEQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGQgBACgDACIgGADIgIABQgFAAgFgBg");
	this.shape_48.setTransform(27.775,-80.575);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#333333").s().p("AAXAhIgGgPIghAAIgFAPIgKAAIAbhBIAJAAIAbBBgAgNALIAbAAIgOgjg");
	this.shape_49.setTransform(22.2,-81.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDIAEgEQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_50.setTransform(94.575,-99.725);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AAaAZIAAggQgBgFgCgCQgCgDgEAAQgEAAgEACQgDACgDADIAAAjIgGAAIAAggQAAgFgCgCQgCgDgFAAQgDAAgEACIgGAFIAAAjIgHAAIAAgwIAHAAIAAAHIACgCIAFgDIAEgCIAFgBQAGAAADADQACACABAEIADgDIADgDIAFgCIAFgBQAHAAADAEQAEAEAAAHIAAAig");
	this.shape_51.setTransform(88.25,-99.775);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#333333").s().p("AgJAYIgFgDIgEgFQgBgDAAgEQAAgEABgDIAEgEIAFgDIAGAAQAEAAAFABQAEACADACIAAgIQgBgEgDgDQgDgDgFAAQgIAAgGAHIgEgFQAIgIALAAIAGABIAGACQADACACAEQABADAAAEIAAAgIgHAAIAAgFQgHAGgJAAIgGgBgAgIACQgDADgBAFQABAEADADQADADAFAAQAEAAADgBQAEgCACgDIAAgJQgCgDgEgCQgDAAgEAAQgFAAgDACg");
	this.shape_52.setTransform(81.45,-99.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_53.setTransform(77.575,-99.775);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("AgKAhQgFgBgEgEIAEgGQADADAEACQADABAFABIAFgBQADgBACgCQADgCABgDQABgCAAgEIAAgHQgCADgFADQgEACgEAAQgFAAgEgBIgHgFIgEgIQgCgEAAgFQAAgGACgFIAEgIIAHgFQAEgCAFABQAEAAAEABQAEADADAEIAAgIIAIAAIAAAuQAAAHgCADQgCAEgDADQgEACgEABIgIACQgGAAgEgCgAgFgZIgFADIgDAGIgBAIIABAHQABACACACIAFAFQADABADAAIAEAAIAEgDIAEgCIACgDIAAgUIgCgDIgEgCIgEgCIgEgBQgDAAgDACg");
	this.shape_54.setTransform(72.625,-98.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("AgJAXQgEgCgDgDQgEgDgBgFQgCgFAAgFQAAgEACgFQABgEAEgEQADgDAEgCQAFgCAEAAQAFAAAFACQAEACADADIAFAIQACAFAAAEQAAAFgCAFQgBAFgEADQgDADgEACQgFACgFAAQgEAAgFgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_55.setTransform(67.05,-99.725);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#333333").s().p("AgLAZIAAgwIAIAAIAAAIQADgEADgCQAEgDAFAAIAAAIIgDAAIgEAAIgEACIgCADIgCADIAAAhg");
	this.shape_56.setTransform(62.825,-99.775);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#333333").s().p("AgXAhIAAhBIAaAAQAFAAAEABQAEACACADIAEAGIACAIQAAAEgCADQgBAEgDACQgCADgEABQgEACgFAAIgSAAIAAAagAgPAAIARAAQAGAAAEgDQADgEAAgFQAAgGgDgEQgEgDgGAAIgRAAg");
	this.shape_57.setTransform(58.275,-100.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#333333").s().p("AAaAZIAAggQAAgFgDgCQgCgDgEAAQgEAAgEACQgEACgCADIAAAjIgGAAIAAggQAAgFgCgCQgCgDgFAAQgEAAgDACIgGAFIAAAjIgHAAIAAgwIAHAAIAAAHIACgCIAFgDIAEgCIAFgBQAGAAADADQACACABAEIADgDIAEgDIAEgCIAFgBQAHAAADAEQAEAEAAAHIAAAig");
	this.shape_58.setTransform(48.45,-99.775);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#333333").s().p("AgJAXQgFgCgDgDQgDgDgBgFQgCgFAAgFQAAgEACgFQABgEADgEQADgDAFgCQAEgCAFAAQAFAAAFACQAEACADADIAGAIQABAFAAAEQAAAFgBAFQgCAFgEADQgDADgEACQgFACgFAAQgFAAgEgCgAgGgQIgFAEIgDAGIgBAGIABAHIADAGIAFAEQADACADAAQAEAAADgCIAFgEIADgGIABgHIgBgGIgDgGIgFgEQgDgCgEAAQgDAAgDACg");
	this.shape_59.setTransform(41.55,-99.725);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#333333").s().p("AgCAdQgDgDAAgGIAAgeIgIAAIAAgHIAIAAIAAgNIAHAAIAAANIAKAAIAAAHIgKAAIAAAdIABAEQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAIADgBIACgBIACAFIgEADIgFAAQgFAAgCgCg");
	this.shape_60.setTransform(37.275,-100.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_61.setTransform(33.425,-99.725);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAIAAIAAAfIABAGIABADIAEACIAFAAQACAAAFgCQADgCACgDIAAgjIAIAAIAAAwIgIAAIAAgHQgCADgEADQgFACgEAAQgIAAgEgEg");
	this.shape_62.setTransform(28.4,-99.675);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#333333").s().p("AgIAgQgHgCgEgFQgFgFgCgFQgDgHAAgIQAAgGADgHQACgGAFgFQAEgEAHgDQAGgDAHAAIAIABIAHAEIAFADIAFAGIgHAEQgDgFgFgCQgFgDgFAAQgFAAgFACQgEACgEADQgEAFgCAEQgCAFABAFQgBAGACAFQACAFAEADQAEAFAEABQAFACAFAAQAFAAAFgCQAFgDADgFIAHAFQgEAFgGAEQgGADgJAAQgHAAgGgCg");
	this.shape_63.setTransform(22.4,-100.65);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#333333").s().p("AgKAYQgFgCgDgEIADgGQADADAEACQAEACAEAAQAGAAADgCQADgCAAgEQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAIgGgDIgGgCIgHgCQgEgBgCgCQgCgDAAgEQAAgDABgDQABgCADgCQACgCADgBIAHgBQAGAAAEACQAFACADADIgEAFQgCgDgEgBQgDgCgFAAQgEAAgDACQgDACAAADQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAGADIAGACIAHACQAEABACACQACADAAAFIgBAGIgEAEIgGADIgIABQgFAAgFgBg");
	this.shape_64.setTransform(92.825,-121.325);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#333333").s().p("AgIAYQgEgCgEgEQgCgDgCgFQgDgEAAgGQAAgEADgFIAEgIQADgDAFgCQAFgCAEAAQAFAAAEACQAEACAEADQADAEABAFQACAEAAAFIAAACIgnAAIACAGIAEAFQACADADABQADABADAAIAIgBQAEgCADgDIADAFQgDAEgFACQgFABgGAAQgEAAgFgBgAgGgRIgEAEIgDAFIgCAGIAgAAIgBgGIgEgFIgEgEQgDgBgEAAQgEAAgDABg");
	this.shape_65.setTransform(87.7,-121.325);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#333333").s().p("AAaAZIAAggQAAgFgDgCQgCgDgEAAQgEAAgEACQgEACgCADIAAAjIgGAAIAAggQAAgFgCgCQgCgDgFAAQgDAAgEACIgGAFIAAAjIgHAAIAAgwIAHAAIAAAHIACgCIAFgDIAEgCIAFgBQAGAAADADQACACABAEIADgDIAEgDIAEgCIAFgBQAHAAADAEQAEAEAAAHIAAAig");
	this.shape_66.setTransform(80.85,-121.375);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_67.setTransform(75.675,-122.175);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#333333").s().p("AgDAhIAAg6IgWAAIAAgHIAyAAIAAAHIgVAAIAAA6g");
	this.shape_68.setTransform(71.7,-122.225);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#333333").s().p("AgWAiIAAhCIAIAAIAAAHQACgDAFgCQAEgDAEAAQAFAAAEACIAHAEQADAEABAEQACAFAAAGQAAAGgCAEQgBAFgDADIgHAFQgEABgFAAQgEAAgEgBQgEgCgDgFIAAAagAgIgYQgEACgCADIAAAVQACADAEACQAEADAEAAQADAAADgCIAFgDIADgFIABgIIgBgHIgDgGIgFgEQgDgBgDgBQgEABgEACg");
	this.shape_69.setTransform(63.575,-120.45);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_70.setTransform(59.425,-122.175);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#333333").s().p("AAMAhIAAggIAAgEIgCgDQgBgBAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIgEgBIgEABIgEACIgDACIgDADIAAAiIgHAAIAAhBIAHAAIAAAZIAEgDIADgDIAFgCIAFAAQAHAAAFADQADAEAAAIIAAAhg");
	this.shape_71.setTransform(55.55,-122.225);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#333333").s().p("AgOAfQgGgCgEgFIAFgGIADADIAGADIAFACIAGABQAEAAADgBIAFgDQABAAAAgBQAAAAABAAQAAgBAAgBQAAAAABgBIABgDQAAgEgCgCIgFgDIgGgDIgGgCIgHgCIgHgCIgEgFQgCgDAAgFQAAgEACgDIAEgGIAIgEIAIgBQAIAAAFACQAGACAFAFIgFAGQgFgEgFgCQgEgCgFAAQgGAAgDADQgFADAAAFQAAAAABABQAAABAAAAQAAABAAAAQABABAAAAIAEADIAHADIAHACIAGACIAHADIAFAFQABADAAAFIgBAHQgCAEgDACQgDADgEACQgFABgGAAQgIAAgHgDg");
	this.shape_72.setTransform(49.9,-122.225);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#333333").s().p("AAMAhIgRgVIgIAHIAAAOIgHAAIAAhBIAHAAIAAArIAZgZIAJAAIgVAVIAVAag");
	this.shape_73.setTransform(42.125,-122.225);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#333333").s().p("AgGAYQgEgCgDgEQgEgDgBgFQgCgFAAgFQAAgEACgFQABgFAEgDQADgDAEgCQAFgCAEAAQAHAAAEACIAHAGIgFAFQgDgEgDgBQgCgCgFAAQgDAAgCACQgDABgDADIgDAGIgBAGIABAIIADAFQADADADABQACACADAAQAJAAAEgHIAFAFIgHAGQgEACgHAAQgEAAgFgBg");
	this.shape_74.setTransform(36.85,-121.325);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#333333").s().p("AgDAhIAAgwIAHAAIAAAwgAgDgXQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBg");
	this.shape_75.setTransform(33.175,-122.175);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#333333").s().p("AgPAVQgEgEAAgHIAAgiIAIAAIAAAfIABAGIACADIADACIAFAAQACAAAFgCQADgCACgDIAAgjIAIAAIAAAwIgIAAIAAgHQgCADgEADQgFACgEAAQgIAAgEgEg");
	this.shape_76.setTransform(29.3,-121.275);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#333333").s().p("AASAcIgIAFIgKAAQgGAAgHgCQgGgCgEgFQgEgFgDgGQgCgHAAgGQAAgHACgGQADgHAEgFQAEgEAGgCQAHgEAGAAQAHAAAGAEQAHACAEAEQAEAFADAHQACAGAAAHQAAAGgCAHQgDAGgEAFIAGAHIgGAEgAgJgZQgFACgDAEQgDAEgCAEQgCAFAAAGQAAAFACAFQACAFADADQADAEAFACQAEADAFgBQAHABAGgEIgKgKIAGgGIAJALQADgDACgGQABgEAAgFQAAgGgBgFQgCgEgDgEQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_77.setTransform(22.725,-122.15);

	this.instance_1 = new lib._8AssortmentSelection();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1.5,-79.6,0.4,0.4,0,0,0,0.1,-0.7);

	this.instance_2 = new lib._7CustomPrograms();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1.9,-100.7,0.4,0.4,0,0,0,0.3,-0.5);

	this.instance_3 = new lib._1flexibleShipping();
	this.instance_3.parent = this;
	this.instance_3.setTransform(2.6,-119.75,0.4,0.4,0,0,0,0.3,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.instance},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_2
	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AnjHYIAAuwIPHAAIAAOwg");
	this.shape_78.setTransform(53.3633,-87.9,1.4069,1);

	this.timeline.addTween(cjs.Tween.get(this.shape_78).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-14.6,-135.1,136,94.5), null);


// stage content:
(lib._728x90_OmnichannelRetailers = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_845 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(845).call(this.frame_845).wait(259));

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape.setTransform(364.225,45.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.89)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_1.setTransform(364.225,45.9);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.776)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_2.setTransform(364.225,45.9);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.667)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_3.setTransform(364.225,45.9);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.557)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_4.setTransform(364.225,45.9);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.443)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_5.setTransform(364.225,45.9);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.333)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_6.setTransform(364.225,45.9);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.224)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_7.setTransform(364.225,45.9);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.11)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_8.setTransform(364.225,45.9);
	this.shape_8._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0)").s().p("Eg45AHIIAAuPMBxzAAAIAAOPg");
	this.shape_9.setTransform(364.225,45.9);
	this.shape_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(146).to({_off:false},0).wait(1).to({_off:true},1).wait(140).to({_off:false},0).wait(1).to({_off:true},1).wait(103).to({_off:false},0).wait(1).to({_off:true},1).wait(113).to({_off:false},0).wait(1).to({_off:true},1).wait(146).to({_off:false},0).wait(1).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(84));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(144).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(144).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(85));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(142).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(142).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(86));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(140).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(87));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(138).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(88));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(93).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(103).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(136).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(89));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(91).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(101).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(134).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(90));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(126).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(89).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(99).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(132).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(126).to({_off:false},0).to({_off:true},1).wait(91));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(124).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(87).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(97).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(130).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(124).to({_off:false},0).to({_off:true},1).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(122).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(85).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(95).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(128).to({_off:false},0).to({_off:true},1).wait(18).to({_off:false},0).to({_off:true},1).wait(122).to({_off:false},0).to({_off:true},1).wait(93));

	// t11
	this.instance = new lib.t11();
	this.instance.parent = this;
	this.instance.setTransform(154.5,118.35,1,1,0,0,0,105.6,41);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(510).to({_off:true},510).wait(84));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(154.5,173.35,1,1,0,0,0,73.5,17);

	this.instance_2 = new lib.t22();
	this.instance_2.parent = this;
	this.instance_2.setTransform(167.95,173.35,1,1,0,0,0,73.5,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[]},367).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},142).to({state:[]},367).to({state:[{t:this.instance_2}]},1).to({state:[]},142).wait(84));

	// Лого
	this.instance_3 = new lib.biglogo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(551.55,15.95,0.5748,0.5748,0,0,0,43.9,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(510).to({_off:true},510).wait(84));

	// Слой_5
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.3,-51.8,-51.6,-21.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_10.setTransform(551.525,73.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-98,-49.2,-45.3,-18.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_11.setTransform(551.525,73.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91.8,-46.6,-39.1,-16.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_12.setTransform(551.525,73.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.5,-43.9,-32.8,-13.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_13.setTransform(551.525,73.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-79.2,-41.3,-26.5,-10.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_14.setTransform(551.525,73.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-73,-38.6,-20.3,-8.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_15.setTransform(551.525,73.35);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-66.7,-36,-14,-5.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_16.setTransform(551.525,73.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-60.5,-33.4,-7.8,-2.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_17.setTransform(551.525,73.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-54.2,-30.7,-1.5,-0.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_18.setTransform(551.525,73.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-48,-28.1,4.7,2.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_19.setTransform(551.525,73.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-41.7,-25.5,11,5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_20.setTransform(551.525,73.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-35.5,-22.8,17.2,7.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_21.setTransform(551.525,73.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-29.2,-20.2,23.5,10.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_22.setTransform(551.525,73.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-23,-17.6,29.7,12.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_23.setTransform(551.525,73.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,-14.9,36,15.5).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_24.setTransform(551.525,73.35);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-10.5,-12.3,42.2,18.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_25.setTransform(551.525,73.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-4.2,-9.7,48.5,20.8).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_26.setTransform(551.525,73.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],2,-7,54.7,23.4).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_27.setTransform(551.525,73.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,-4.4,61,26.1).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_28.setTransform(551.525,73.35);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],14.5,-1.8,67.2,28.7).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_29.setTransform(551.525,73.35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],20.8,0.9,73.5,31.3).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_30.setTransform(551.525,73.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],27.1,3.5,79.8,34).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_31.setTransform(551.525,73.35);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],33.3,6.2,86,36.6).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_32.setTransform(551.525,73.35);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.6,8.8,92.3,39.2).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_33.setTransform(551.525,73.35);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.8,11.4,98.5,41.9).s().p("AnRBeQgdAAAAgcIAAiDQAAgcAdAAIOjAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_34.setTransform(551.525,73.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],45.9,11.4,98.6,41.9).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_35.setTransform(546.45,73.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.4,10.1,92.1,40.5).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_36.setTransform(546.45,73.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],32.9,8.7,85.6,39.1).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_37.setTransform(546.45,73.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.4,7.3,79.1,37.8).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_38.setTransform(546.45,73.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],19.8,6,72.5,36.4).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_39.setTransform(546.45,73.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],13.3,4.6,66,35.1).s().p("AmPBfQgdAAgBgdIAAiDQABgcAdAAIMgAAQAdAAAAAcIAACDQAAAdgdAAg");
	this.shape_40.setTransform(546.45,73.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],6.8,3.2,59.5,33.6).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_41.setTransform(546.45,73.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.2,1.8,52.9,32.3).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_42.setTransform(546.45,73.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-6.3,0.5,46.4,30.9).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_43.setTransform(546.45,73.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-12.8,-0.9,39.9,29.5).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_44.setTransform(546.45,73.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-19.3,-2.3,33.4,28.2).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_45.setTransform(546.45,73.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.8,-3.6,26.9,26.8).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_46.setTransform(546.45,73.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-32.4,-5,20.3,25.5).s().p("AmPBeQgdAAgBgdIAAiBQABgdAdgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_47.setTransform(546.45,73.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-38.9,-6.4,13.8,24.1).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_48.setTransform(546.4,73.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-45.4,-7.7,7.3,22.7).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_49.setTransform(546.4,73.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.9,-9.1,0.8,21.4).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_50.setTransform(546.4,73.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-58.4,-10.5,-5.7,20).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_51.setTransform(546.4,73.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-64.9,-11.8,-12.2,18.6).s().p("AmQBeQgcAAAAgdIAAiBQAAgdAcgBIMgAAQAdABAAAdIAACBQAAAdgdAAg");
	this.shape_52.setTransform(546.4,73.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-71.5,-13.2,-18.8,17.2).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_53.setTransform(546.4,73.35);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-78,-14.6,-25.3,15.8).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_54.setTransform(546.4,73.35);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-84.5,-16,-31.8,14.5).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_55.setTransform(546.4,73.35);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-91,-17.3,-38.3,13.1).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_56.setTransform(546.4,73.35);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-97.6,-18.7,-44.9,11.8).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_57.setTransform(546.4,73.35);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-104.1,-20.1,-51.4,10.4).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_58.setTransform(546.4,73.35);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-110.6,-21.4,-57.9,9).s().p("AmQBeQgcAAAAgcIAAiDQAAgcAcAAIMgAAQAdAAAAAcIAACDQAAAcgdAAg");
	this.shape_59.setTransform(546.4,73.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10}]},38).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},87).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},114).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},234).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_10}]},87).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[]},1).to({state:[{t:this.shape_35}]},114).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).to({state:[]},196).wait(84));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(570.65,65.75,0.801,0.801,0,0,0,-8.5,35.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(510).to({_off:true},510).wait(84));

	// Слой_2
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("A7zHIIAAuPMA3nAAAIAAOPg");
	this.shape_60.setTransform(550.45,45.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_60).wait(510).to({_off:true},510).wait(84));

	// Слой_7
	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgEAEgEQADgDAFgBQAFABAEADQADAEABAEQgBAGgDADQgEAEgFAAQgFAAgDgEg");
	this.shape_61.setTransform(302.275,80.525);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_62.setTransform(296.425,77.875);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_63.setTransform(288.425,77.875);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_64.setTransform(282.1,76.425);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_65.setTransform(275.575,77.875);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_66.setTransform(267.725,77.875);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_67.setTransform(255.675,77.875);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgKAmIgehLIAVAAIATA0IAUg0IAVAAIgeBLg");
	this.shape_68.setTransform(247.325,77.85);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgJA2IAAhLIATAAIAABLgAgHghQgEgDAAgFQAAgFAEgEQADgDAEAAQAFAAADADQAEAEAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_69.setTransform(241.325,76.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgCgBIgDAAIgHABIgIADIgDAFIAAAxg");
	this.shape_70.setTransform(236.9,77.775);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgVAwQgIgEgEgJQgEgJAAgNQAAgMAEgIQAEgJAIgFQAIgEAJAAQAGAAAGACQAGADAEAGIAAgmIAVAAIAABnIgVAAIAAgJQgEAFgGADQgGADgGAAQgJAAgIgFgAgLgCQgFAFgBAKQABAKAFAGQAFAGAHAAQAGAAAEgCQAFgCACgEIAAgbQgCgDgFgCQgEgDgGAAQgHAAgFAGg");
	this.shape_71.setTransform(228.85,76.525);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_72.setTransform(217.825,76.925);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_73.setTransform(210.625,77.875);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AAQA0IAAguQAAgHgEgDQgEgDgGAAQgFAAgEADQgFADgCACIAAAzIgUAAIAAhnIAUAAIAAAmIAGgFIAIgFQAFgBAGAAQAMAAAHAGQAFAGAAALIAAA1g");
	this.shape_74.setTransform(202.05,76.425);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_75.setTransform(194.875,76.925);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_76.setTransform(184.325,77.875);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAlAnIAAgvQAAgGgDgDQgCgDgHAAQgFAAgEADQgEACgCAEIAAAyIgTAAIAAgvQAAgGgDgDQgDgDgFAAQgGAAgEADQgEACgCAEIAAAyIgUAAIAAhLIAUAAIAAAKIAFgFIAJgFQAFgCAGAAQAIAAAEAEQAGADABAHIAHgHQAEgDAFgCQAFgCAFAAQAMAAAFAGQAGAFAAAMIAAA2g");
	this.shape_77.setTransform(173.95,77.775);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgUAlQgGgDgEgFQgEgGAAgIQAAgJAEgGQAEgEAGgDQAGgCAGAAQAIAAAFACQAGADAEAEIAAgJQAAgGgEgEQgFgDgGAAQgHAAgFACQgGADgEAEIgIgOQAHgGAIgDQAJgDAIAAQAJAAAHADQAIACAFAHQAEAGAAALIAAAwIgUAAIAAgIQgEAEgGADQgFADgIAAQgGAAgGgDgAgKAGQgEADAAAGQAAAFAEADQAEADAGAAQAEAAAEgCQAFgBACgDIAAgKQgCgDgFgCQgEgCgEAAQgGAAgEADg");
	this.shape_78.setTransform(162.725,77.875);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgCgBIgEAAIgGABIgHADIgEAFIAAAxg");
	this.shape_79.setTransform(156.25,77.775);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgBA2QgKAAgIgDQgIgCgHgGIAJgPQAEAFAGADQAGACAIAAQADAAAFgCQAFgCADgEQAEgEgBgIIAAgHQgEAGgGADQgGADgGAAQgKAAgHgFQgHgEgFgJQgEgHAAgNQAAgMAEgJQAFgIAHgFQAHgEAKAAQAGAAAGACQAGADAEAGIAAgKIAUAAIAABGQAAALgEAHQgDAHgGAEQgGAEgHABQgGACgGAAIgBAAgAgLgeQgGAFAAAKQAAAKAGAFQAFAFAHAAQAGAAAEgCQAFgDACgDIAAgYQgCgEgFgCQgEgDgGAAQgHAAgFAGg");
	this.shape_80.setTransform(148.2,79.305);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgUAiQgKgFgEgJQgFgJAAgLQAAgKAFgJQAEgJAKgFQAJgGALAAQANAAAJAGQAIAFAFAJQAFAJAAAKQAAALgFAJQgFAJgIAFQgJAFgNABQgLgBgJgFgAgKgSQgDADgDAFQgCAFAAAFQAAAGACAFQADAFADADQAFADAFAAQAGAAAEgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgFgFgDQgEgDgGAAQgFAAgFADg");
	this.shape_81.setTransform(139.3,77.875);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAGgDQAHgEAHAAIAAAUIgDgBIgCAAIgIABIgHADIgDAFIAAAxg");
	this.shape_82.setTransform(132.35,77.775);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgmA1IAAhoIAVAAIAAAKQADgGAHgCQAGgDAFAAQAKAAAIAEQAHAFAFAJQAEAJAAAMQAAANgEAIQgFAJgHAEQgIAFgKAAQgFAAgGgDQgGgDgEgFIAAAmgAgKggQgFACgCAEIAAAaQACADAEADQAGACAFAAQAHAAAFgGQAFgFABgKQgBgKgFgGQgFgGgHAAQgGAAgEADg");
	this.shape_83.setTransform(124.85,79.225);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_84.setTransform(111.625,77.875);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgDgBIgCAAIgHABIgIADIgDAFIAAAxg");
	this.shape_85.setTransform(104.8,77.775);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgVAiQgIgFgFgJQgFgJAAgLQAAgKAFgJQAFgJAIgFQAJgGAMAAQANAAAIAGQAJAFAGAJQAEAJAAAKQAAALgEAJQgGAJgJAFQgIAFgNABQgMgBgJgFgAgJgSQgEADgDAFQgCAFAAAFQAAAGACAFQADAFAEADQAEADAFAAQAHAAADgDQAFgDADgFQABgFABgGQgBgFgBgFQgDgFgFgDQgDgDgHAAQgFAAgEADg");
	this.shape_86.setTransform(97.05,77.875);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgGAsQgGgFAAgLIAAgmIgMAAIAAgSIAMAAIAAgUIATAAIAAAUIAQAAIAAASIgQAAIAAAhQAAAEACACQACACADAAIAEAAIADgCIAEAPQgCACgEACQgEABgGAAQgKAAgFgFg");
	this.shape_87.setTransform(89.925,76.925);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgRAkQgJgDgGgFIAIgPIAHAGIAKADIAIACQAHAAADgCQADgCAAgEQAAgEgFgBIgKgDIgNgEQgHgCgEgDQgFgFAAgJQAAgHAEgFQADgFAHgEQAHgDAJAAQAKAAAIADQAHADAGAEIgIAPQgEgEgGgDQgGgCgHAAQgEAAgDACQgEACAAADQABADAEACIAKADIAOADQAGACAFAEQAEAFAAAJQAAAHgDAGQgEAFgIADQgHAEgKAAQgKAAgIgEg");
	this.shape_88.setTransform(83.425,77.875);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgSAIIAAgPIAlAAIAAAPg");
	this.shape_89.setTransform(77.4,77.85);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AAQAnIAAgtQAAgIgEgDQgEgDgGAAQgFAAgEADQgFACgDAEIAAAyIgTAAIAAhLIATAAIAAAKIAHgGIAIgEQAEgCAHAAQAMAAAGAHQAHAGAAALIAAA1g");
	this.shape_90.setTransform(70.5,77.775);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_91.setTransform(63.8,76.425);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgBA2QgKAAgIgDQgIgCgHgGIAJgPQAFAFAFADQAHACAHAAQAEAAAEgCQAFgCADgEQADgEABgIIAAgHQgFAGgGADQgGADgGAAQgKAAgHgFQgIgEgEgJQgFgHABgNQgBgMAFgJQAEgIAIgFQAHgEAKAAQAGAAAGACQAGADAFAGIAAgKIATAAIAABGQAAALgDAHQgEAHgGAEQgGAEgHABQgGACgGAAIgBAAgAgMgeQgFAFAAAKQAAAKAFAFQAFAFAJAAQAEAAAFgCQAFgDADgDIAAgYQgDgEgFgCQgFgDgEAAQgJAAgFAGg");
	this.shape_92.setTransform(336.45,79.305);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AAQAnIAAgtQAAgIgEgDQgEgDgHAAQgEAAgFADQgEACgDAEIAAAyIgUAAIAAhLIAUAAIAAAKIAHgGIAIgEQAEgCAHAAQANAAAFAHQAHAGAAALIAAA1g");
	this.shape_93.setTransform(327.55,77.775);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAGgDQAHgEAHAAIAAAUIgDgBIgDAAIgHABIgGADIgEAFIAAAxg");
	this.shape_94.setTransform(316.6,77.775);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgPA1IAAg5IgNAAIAAgSIANAAIAAgDQAAgNAHgHQAHgHAKAAQAGAAAFACQAFABAEAEIgIAMIgDgCIgFgBQgEAAgDADQgCADAAAFIAAADIAPAAIAAASIgPAAIAAA5g");
	this.shape_95.setTransform(302.625,76.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgPA1IAAg5IgNAAIAAgSIANAAIAAgDQAAgNAHgHQAHgHAKAAQAGAAAFACQAFABAEAEIgIAMIgDgCIgFgBQgEAAgDADQgCADAAAFIAAADIAPAAIAAASIgPAAIAAA5g");
	this.shape_96.setTransform(297.475,76.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgbAvQgNgHgHgMQgHgMAAgQQAAgPAHgMQAHgMANgHQAMgHAPAAQAQAAAMAHQAMAHAHAMQAHAMABAPQgBAQgHAMQgHAMgMAHQgMAHgQAAQgPAAgMgHgAgQgdQgHAFgEAHQgEAIAAAJQAAAKAEAIQAEAHAHAFQAHAEAJAAQAKAAAHgEQAHgFAEgHQAEgIAAgKQAAgJgEgIQgEgHgHgFQgHgEgKAAQgJAAgHAEg");
	this.shape_97.setTransform(288.425,76.425);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgOAiQgJgFgGgIQgFgJAAgMQAAgLAFgJQAGgJAJgFQAJgFAKAAQAIAAAGACQAFACAFADQAEADACAEIgNAMQgDgEgEgCQgEgCgFAAQgIAAgFAGQgGAGAAAJQAAAKAGAGQAFAGAIAAQAFAAAEgCQAEgCADgEIANAMQgCADgEADQgFAEgFACQgGACgIAAQgKAAgJgGg");
	this.shape_98.setTransform(269.2,77.875);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgdAgQgFgGAAgLIAAg1IAUAAIAAAtQAAAIADADQAEADAGAAQAFAAAFgCQAEgDACgEIAAgyIAVAAIAABLIgVAAIAAgJQgEAEgGADQgGADgJABQgMAAgHgHg");
	this.shape_99.setTransform(260.65,77.95);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgVAwQgHgEgFgJQgEgJAAgNQAAgMAEgIQAFgJAHgFQAHgEAKAAQAGAAAGACQAGADAEAGIAAgmIAUAAIAABnIgUAAIAAgJQgEAFgGADQgGADgGAAQgKAAgHgFgAgLgCQgGAFAAAKQAAAKAGAGQAFAGAHAAQAGAAAEgCQAFgCACgEIAAgbQgCgDgFgCQgEgDgGAAQgHAAgFAGg");
	this.shape_100.setTransform(251.25,76.525);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgDgBIgCAAIgIABIgHADIgDAFIAAAxg");
	this.shape_101.setTransform(235.4,77.775);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQAMAAAHAEQAIAFAEAHQAEAIAAAJQAAAKgEAHQgEAHgIAEQgIAFgLAAIgaAAIAAAlgAgTgEIAWAAQAIAAAEgDQAEgEAAgHQAAgGgEgEQgEgEgIAAIgWAAg");
	this.shape_102.setTransform(227.65,76.425);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_103.setTransform(212.45,76.425);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgdAgQgFgGgBgLIAAg1IAVAAIAAAtQAAAIADADQAEADAGAAQAFAAAEgCQAFgDACgEIAAgyIAUAAIAABLIgUAAIAAgJQgDAEgHADQgGADgJABQgNAAgGgHg");
	this.shape_104.setTransform(205.9,77.95);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAArg");
	this.shape_105.setTransform(197.15,76.425);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgVAnIAAhLIAUAAIAAAKQADgFAHgDQAGgEAHAAIAAAUIgDgBIgCAAIgIABIgHADIgDAFIAAAxg");
	this.shape_106.setTransform(185.9,77.775);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgcAgQgHgGAAgLIAAg1IAUAAIAAAtQABAIADADQAEADAHAAQAEAAAFgCQAEgDADgEIAAgyIAUAAIAABLIgUAAIAAgJQgFAEgGADQgGADgJABQgNAAgFgHg");
	this.shape_107.setTransform(178.15,77.95);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgVAiQgIgFgFgJQgFgJAAgLQAAgKAFgJQAFgJAIgFQAJgGAMAAQANAAAIAGQAJAFAGAJQAEAJAAAKQAAALgEAJQgGAJgJAFQgIAFgNABQgMgBgJgFgAgJgSQgEADgDAFQgCAFAAAFQAAAGACAFQADAFAEADQAEADAFAAQAHAAADgDQAFgDADgFQABgFAAgGQAAgFgBgFQgDgFgFgDQgDgDgHAAQgFAAgEADg");
	this.shape_108.setTransform(169.05,77.875);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgUAiQgKgFgEgJQgFgJAAgLQAAgKAFgJQAEgJAKgFQAJgGALAAQANAAAJAGQAIAFAFAJQAFAJAAAKQAAALgFAJQgFAJgIAFQgJAFgNABQgLgBgJgFgAgKgSQgDADgDAFQgCAFAAAFQAAAGACAFQADAFADADQAFADAFAAQAGAAAEgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgFgFgDQgEgDgGAAQgFAAgFADg");
	this.shape_109.setTransform(155.95,77.875);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgOAiQgKgFgFgIQgFgJAAgMQAAgLAFgJQAFgJAKgFQAIgFALAAQAIAAAGACQAFACAEADQAFADACAEIgNAMQgDgEgEgCQgDgCgGAAQgIAAgGAGQgFAGAAAJQAAAKAFAGQAGAGAIAAQAGAAADgCQAEgCADgEIANAMQgCADgFADQgEAEgFACQgGACgIAAQgLAAgIgGg");
	this.shape_110.setTransform(114.55,77.875);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgPAiQgIgFgFgIQgGgJAAgMQAAgLAGgJQAFgJAIgFQAJgFALAAQAIAAAGACQAFACAEADQAFADACAEIgNAMQgCgEgEgCQgFgCgFAAQgIAAgGAGQgFAGgBAJQABAKAFAGQAGAGAIAAQAFAAAFgCQAEgCACgEIANAMQgCADgFADQgEAEgFACQgGACgIAAQgLAAgJgGg");
	this.shape_111.setTransform(106.7,77.875);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AAdA0IgHgRIgrAAIgHARIgZAAIAohnIAbAAIAoBngAAQAPIgQgsIgPAsIAfAAg");
	this.shape_112.setTransform(97.325,76.425);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgVAwQgIgEgEgJQgEgJgBgNQABgMAEgIQAEgJAIgFQAIgEAJAAQAGAAAGACQAGADAEAGIAAgmIAVAAIAABnIgVAAIAAgJQgEAFgGADQgGADgGAAQgJAAgIgFgAgLgCQgFAFgBAKQABAKAFAGQAFAGAHAAQAGAAAEgCQAFgCACgEIAAgbQgCgDgFgCQgEgDgGAAQgHAAgFAGg");
	this.shape_113.setTransform(83.05,76.525);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgVAwQgIgEgEgJQgEgJgBgNQABgMAEgIQAEgJAIgFQAIgEAJAAQAGAAAGACQAGADAEAGIAAgmIAVAAIAABnIgVAAIAAgJQgEAFgGADQgGADgGAAQgJAAgIgFgAgLgCQgFAFgBAKQABAKAFAGQAEAGAJAAQAFAAAEgCQAFgCACgEIAAgbQgCgDgFgCQgEgDgFAAQgJAAgEAGg");
	this.shape_114.setTransform(65.15,76.525);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AAPAnIAAgtQABgIgEgDQgEgDgGAAQgGAAgDADQgFACgCAEIAAAyIgUAAIAAhLIAUAAIAAAKIAFgGIAJgEQAFgCAGAAQAMAAAHAHQAFAGAAALIAAA1g");
	this.shape_115.setTransform(56.25,77.775);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgSAjQgJgFgFgJQgGgJAAgMQAAgKAFgJQAFgJAJgFQAJgGAKAAQAMAAAIAFQAJAGAFAJQAEAJABAMIAAAEIg4AAQABAHAGAFQAFAFAJAAIAHgBQAEAAADgCIAGgEIAJANQgGAFgIADQgIADgJAAQgLAAgJgFgAATgGQAAgEgCgEQgCgEgEgCQgEgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIAkAAIAAAAg");
	this.shape_116.setTransform(47.375,77.875);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AARAmIgRgZIgQAZIgXAAIAbgmIgZglIAXAAIAOAYIAPgYIAXAAIgZAlIAbAmg");
	this.shape_117.setTransform(33.75,77.85);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgkA0IAAhnIBJAAIAAATIgzAAIAAAWIAyAAIAAATIgyAAIAAAYIAzAAIAAATg");
	this.shape_118.setTransform(25.4,76.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87,p:{x:89.925}},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84,p:{x:111.625}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81,p:{x:139.3}},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75,p:{x:194.875}},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72,p:{x:217.825}},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69,p:{x:241.325}},{t:this.shape_68},{t:this.shape_67,p:{x:255.675}},{t:this.shape_66,p:{x:267.725}},{t:this.shape_65},{t:this.shape_64,p:{x:282.1}},{t:this.shape_63,p:{x:288.425}},{t:this.shape_62,p:{x:296.425}},{t:this.shape_61,p:{x:302.275}}]},105).to({state:[{t:this.shape_118},{t:this.shape_117},{t:this.shape_87,p:{x:40.375}},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_84,p:{x:74.375}},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_67,p:{x:122.775}},{t:this.shape_66,p:{x:130.775}},{t:this.shape_62,p:{x:138.275}},{t:this.shape_75,p:{x:148.825}},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_64,p:{x:216.4}},{t:this.shape_102},{t:this.shape_101},{t:this.shape_81,p:{x:242.35}},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_72,p:{x:275.725}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_63,p:{x:309.075}},{t:this.shape_94},{t:this.shape_69,p:{x:321.025}},{t:this.shape_93},{t:this.shape_92},{t:this.shape_61,p:{x:343.325}}]},115).to({state:[]},148).to({state:[{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87,p:{x:89.925}},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84,p:{x:111.625}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81,p:{x:139.3}},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75,p:{x:194.875}},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72,p:{x:217.825}},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69,p:{x:241.325}},{t:this.shape_68},{t:this.shape_67,p:{x:255.675}},{t:this.shape_66,p:{x:267.725}},{t:this.shape_65},{t:this.shape_64,p:{x:282.1}},{t:this.shape_63,p:{x:288.425}},{t:this.shape_62,p:{x:296.425}},{t:this.shape_61,p:{x:302.275}}]},247).to({state:[{t:this.shape_118},{t:this.shape_117},{t:this.shape_87,p:{x:40.375}},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_84,p:{x:74.375}},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_67,p:{x:122.775}},{t:this.shape_66,p:{x:130.775}},{t:this.shape_62,p:{x:138.275}},{t:this.shape_75,p:{x:148.825}},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_64,p:{x:216.4}},{t:this.shape_102},{t:this.shape_101},{t:this.shape_81,p:{x:242.35}},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_72,p:{x:275.725}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_63,p:{x:309.075}},{t:this.shape_94},{t:this.shape_69,p:{x:321.025}},{t:this.shape_93},{t:this.shape_92},{t:this.shape_61,p:{x:343.325}}]},115).to({state:[]},148).to({state:[]},142).wait(84));

	// Слой_8
	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],8.5,-22.5,8.5,25.1).s().p("EglWADgIAAm/MBKtAAAIAAG/g");
	this.shape_119.setTransform(221.125,74.025);
	this.shape_119._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_119).wait(105).to({_off:false},0).to({_off:true},263).wait(247).to({_off:false},0).to({_off:true},263).wait(226));

	// Слой_10
	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgKAWQgGgBgDgEIAFgJIAEAEIAGACIAFABQAEAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgEgBgDgCQgDgDAAgGQAAgDACgEQACgDAFgCQAEgCAFAAQAGAAAEACQAFABAEADIgFAJIgGgEQgDgBgFAAIgEABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABAAAAABIAGABIAIADQAEABAEACQACADAAAGQABAEgDADQgDAEgEABQgFACgGAAQgFAAgFgCg");
	this.shape_120.setTransform(261.4,82.275);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFAAgIQAAgGACgFQADgGAGgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgBABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_121.setTransform(256.5,82.275);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgIAVQgGgDgDgFQgDgGAAgHQAAgGADgFQADgGAGgDQAFgDAGAAQAFAAADABIAHADIADAEIgIAIIgEgEIgGgBQgEAAgEADQgDAEAAAFQAAAGADAEQAEADAEABQAEAAACgCIAEgDIAIAHIgDAEIgHADIgIABQgGAAgFgDg");
	this.shape_122.setTransform(251.5,82.275);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_123.setTransform(246.275,82.225);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_124.setTransform(240.8,82.275);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_125.setTransform(237.125,81.325);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_126.setTransform(234.65,81.4);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgXAgIAAg+IANAAIAAAFIAGgFQAEgCADAAQAGAAAFAEQAEADACAEQAEAGAAAIQAAAHgEAFQgCAFgEADQgFADgGAAIgHgCIgGgFIAAAXgAgGgTIgEADIAAAQIAEAEIAGABQAFAAADgDQADgDAAgGQAAgGgDgEQgDgEgFAAIgGACg");
	this.shape_127.setTransform(230.9,83.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgXAgIAAg+IANAAIAAAFIAGgFQADgCAEAAQAGAAAEAEQAFADACAEQADAGABAIQgBAHgDAFQgCAFgFADQgEADgGAAIgHgCIgGgFIAAAXgAgGgTIgEADIAAAQIAEAEIAGABQAFAAADgDQADgDAAgGQAAgGgDgEQgDgEgFAAIgGACg");
	this.shape_128.setTransform(225.4,83.1);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AASAgIgEgLIgbAAIgEALIgPAAIAYg/IAQAAIAZA/gAAKAJIgKgaIgJAaIATAAg");
	this.shape_129.setTransform(219.175,81.4);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_130.setTransform(210.425,81.425);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQAAgGAEgFQADgGAFgDQAGgDAGAAQAHAAAEADQAGADACAGQADAGABAGIAAADIghAAQAAAEADADQADADAFAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgDAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_131.setTransform(269.05,72.675);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AAAAhQgHAAgEgCQgFgBgFgEIAGgJQADADAEACQADABAFAAIAEgBQADgBADgDQABgCABgFIAAgEIgHAFIgHACQgGAAgFgDQgEgCgDgGQgDgEAAgIQAAgHADgFQADgGAEgCQAFgDAGAAQADAAAEACQAEABADAEIAAgGIALAAIAAAqQAAAHgCAEQgCAEgEADQgEACgEABIgGABIgBAAgAgGgSQgEADAAAGQAAAGAEADQADADAEAAIAGgBIAFgDIAAgPIgFgEIgGgBQgEAAgDADg");
	this.shape_132.setTransform(263.45,73.5583);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEgBgFQABgFACgEQADgCADgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAFgCAEAAQAGAAAEACQAFABADAEQACAEAAAGIAAAdIgLAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgDACg");
	this.shape_133.setTransform(258.05,72.675);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIALAAIAAAGQACgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_134.setTransform(254.15,72.625);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFgBgHQABgGADgFQADgFAFgEQAGgDAGAAQAIAAAFADQAGAEADAFQADAFAAAGQAAAHgDAFQgDAGgGADQgFADgIAAQgGAAgGgDgAgGgKQgCABgCADQgBADAAADQAAAEABADIAEAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_135.setTransform(249.45,72.675);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgGIAAgXIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_136.setTransform(245.125,72.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAABQABAAAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_137.setTransform(240.575,71.825);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgCACIAAAeg");
	this.shape_138.setTransform(233.75,72.625);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgEgFAAgHQAAgGAEgFQADgFAFgEQAGgDAGAAQAIAAAFADQAFAEADAFQAEAFAAAGQAAAHgEAFQgDAGgFADQgFADgIAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_139.setTransform(229.1,72.675);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgEgFAAgHQAAgGAEgFQADgFAFgEQAFgDAHAAQAHAAAGADQAFAEADAFQAEAFAAAGQAAAHgEAFQgDAGgFADQgGADgHAAQgHAAgFgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_140.setTransform(223.6,72.675);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgNAeQgEgDgDgGQgCgFAAgHQAAgIACgFQADgFAEgDQAFgDAGAAQADAAAEACQAEACADADIAAgYIALAAIAAA/IgLAAIAAgFIgHAFQgEABgDAAQgGAAgFgCgAgGAAQgEACAAAHQAAAFAEAEQADAEAEAAIAGgCIAFgDIAAgRIgFgDIgGgBQgEAAgDAEg");
	this.shape_141.setTransform(217.9,71.85);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgGIAAgXIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_142.setTransform(213.675,72.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgRATQgEgDAAgHIAAggIAMAAIAAAbQAAAFADACQACACAEAAIAFgCIAEgDIAAgfIANAAIAAAtIgNAAIAAgFQgCADgEABQgDACgGAAQgHAAgEgEg");
	this.shape_143.setTransform(209.275,72.75);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgQAdQgIgEgEgIQgEgHAAgKQAAgJAEgHQAEgIAIgEQAHgDAJgBQAKABAHADQAIAEAEAIQAEAHAAAJQAAAKgEAHQgEAIgIAEQgHAEgKAAQgJAAgHgEgAgJgRQgFADgCAEQgCAFgBAFQABAGACAFQACAEAFADQAEADAFAAQAGAAAEgDQAEgDADgEQACgFAAgGQAAgFgCgFQgDgEgEgDQgEgDgGAAQgFAAgEADg");
	this.shape_144.setTransform(202.875,71.8);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_145.setTransform(74.375,82.225);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgEgFAAgHQAAgGAEgFQADgFAFgEQAGgDAGAAQAIAAAFADQAFAEADAFQAEAFAAAGQAAAHgEAFQgDAGgFADQgFADgIAAQgGAAgGgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_146.setTransform(68.9,82.275);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_147.setTransform(64.925,81.325);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_148.setTransform(62.125,81.7);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAIgCQAEAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAGAAAEACQAFABACAEQADAEABAGIAAAdIgNAAIAAgFQgCADgEACQgDABgEAAIgIgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_149.setTransform(57.75,82.275);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgSAXIAAgJIAUgZIgUAAIAAgLIAkAAIAAAIIgUAaIAVAAIAAALg");
	this.shape_150.setTransform(53.05,82.3);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_151.setTransform(49.525,81.325);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_152.setTransform(45.575,82.225);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_153.setTransform(40.05,82.275);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgBAhQgFAAgFgCQgFgBgFgEIAGgJQADADADACQAEABAEAAIAFgBQADgBADgDQABgCABgFIAAgEIgHAFIgHACQgGAAgFgDQgEgCgDgGQgCgEAAgIQAAgHACgFQADgGAEgCQAFgDAGAAQADAAAEACQAEABADAEIAAgGIALAAIAAAqQABAHgDAEQgCAEgEADQgEACgEABIgGABIgCAAgAgGgSQgEADAAAGQAAAGAEADQADADAEAAIAGgBIAFgDIAAgPIgFgEIgGgBQgEAAgDADg");
	this.shape_154.setTransform(34.65,83.1583);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIALAAIAAAGQACgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_155.setTransform(30.5,82.225);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgQAdQgIgFgEgHQgEgHAAgKQAAgIAEgIQAEgIAIgDQAHgFAJAAQAKAAAHAFQAIADAEAIQAEAIAAAIQAAAKgEAHQgEAHgIAFQgHAEgKAAQgJAAgHgEgAgJgRQgFADgCAFQgCAEgBAFQABAGACAFQACAFAFACQAEADAFAAQAGAAAEgDQAEgCADgFQACgFAAgGQAAgFgCgEQgDgFgEgDQgEgDgGAAQgFAAgEADg");
	this.shape_156.setTransform(24.925,81.4);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_157.setTransform(15.775,81.425);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AgKAWQgGgBgDgEIAFgJIAEAEIAGACIAFABQAEAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDACgEQADgDAEgCQAEgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgEgBgEAAIgEABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABIAFABIAIADQAFABACACQADADAAAGQAAAEgCADQgDAEgEABQgFACgGAAQgFAAgFgCg");
	this.shape_158.setTransform(78.8,72.675);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgGIAAgXIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_159.setTransform(74.925,72.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFAAgIQAAgGACgFQADgGAGgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgBABIgFAEIgBAFIAWAAIAAAAg");
	this.shape_160.setTransform(70.65,72.675);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_161.setTransform(65.275,72.625);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_162.setTransform(61.275,71.725);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AgEAfIgGgFIAAAFIgMAAIAAg/IAMAAIAAAYQACgDAEgCQAEgCADAAQAGAAAFADQAEADADAFQADAFAAAIQAAAHgDAFQgDAGgEADQgFACgGAAQgEAAgDgBgAgGgDIgEAEIAAAQIAEADIAGACQAEAAADgEQAEgEAAgFQAAgHgEgCQgDgEgEAAIgGABg");
	this.shape_163.setTransform(57.4,71.85);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAFgBQAEgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_164.setTransform(51.7,72.675);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgIQgEgHAAgKQAAgJAEgHQAFgIAHgEQAIgEAJAAQAHAAAFADQAFACADADIAGAIIgMAGQgCgEgEgDQgDgDgFAAQgFAAgFADQgEADgDAEQgCAFgBAFQABAGACAFQADAEAEADQAFADAFAAQAFAAADgDQAEgCACgEIAMAFIgGAIQgDAEgFACQgFACgHAAQgJAAgIgEg");
	this.shape_165.setTransform(46.075,71.8);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQADgGAGgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgFACQgFABgGAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgCgCgCgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_166.setTransform(37.55,72.675);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AgBAhQgFAAgFgCQgFgBgFgEIAGgJQADADADACQAEABAEAAIAFgBQADgBADgDQABgCABgFIAAgEIgHAFIgHACQgGAAgEgDQgFgCgDgGQgCgEAAgIQAAgHACgFQADgGAFgCQAEgDAGAAQADAAAEACQAEABADAEIAAgGIALAAIAAAqQABAHgDAEQgCAEgEADQgEACgEABIgGABIgCAAgAgGgSQgEADAAAGQAAAGAEADQADADAEAAIAGgBIAFgDIAAgPIgFgEIgGgBQgEAAgDADg");
	this.shape_167.setTransform(31.95,73.5583);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAEgBQAFgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_168.setTransform(26.6,72.675);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgMAYIAAgtIAMAAIAAAGQABgDAEgCQAEgCAFgBIAAAMIgCAAIgCAAIgEABIgFACIgBACIAAAeg");
	this.shape_169.setTransform(22.65,72.625);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AgMAXQgDgCgDgDQgCgEAAgFQAAgFACgEQADgCADgBIAHgCQAFAAADACQAEABACACIAAgFQAAgEgCgCQgDgCgEAAIgHACIgGAEIgFgJQAFgEAFgBQAEgCAFAAQAFAAAFACQAFABACAEQADAEAAAGIAAAdIgMAAIAAgFQgCADgEACQgDABgFAAIgHgBgAgGAEQgCACAAADQAAAEACABQADACADAAIAFgBIAEgDIAAgGIgEgDIgFgBQgDAAgDACg");
	this.shape_170.setTransform(17.95,72.675);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AgNAdQgIgEgEgIQgEgHgBgKQABgJAEgIQAEgHAIgEQAIgEAJAAQAGAAAFACQAFACADADIAHAHIgMAHQgCgEgEgDQgEgCgEAAQgGAAgEADQgEADgDAEQgDAFAAAFQAAAGADAFQADAEAEADQAEADAGAAQAEAAADgCIAGgDIAAgIIgRAAIAAgKIAfAAIAAAXQgGAGgHADQgGADgIAAQgJAAgIgEg");
	this.shape_171.setTransform(12.05,71.8);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AAAAhQgGAAgFgCQgFgBgEgEIAFgJQADADADACQAEABAFAAIAFgBQADgBABgDQACgCAAgFIAAgEIgGAFIgHACQgGAAgEgDQgFgCgCgGQgDgEgBgIQABgHADgFQACgGAFgCQAEgDAGAAQADAAAEACQADABADAEIAAgGIANAAIAAAqQAAAHgDAEQgCAEgEADQgDACgFABIgGABIgBAAgAgHgSQgDADAAAGQAAAGADADQADADAFAAIAGgBIAEgDIAAgPIgEgEIgGgBQgFAAgDADg");
	this.shape_172.setTransform(344.75,83.9083);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_173.setTransform(339.325,82.975);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_174.setTransform(335.325,82.075);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIAMAAIAAAGQACgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgDACIAAAeg");
	this.shape_175.setTransform(332.65,82.975);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAFgDAHAAQAHAAAGADQAGAEADAFQACAFAAAGQAAAHgCAFQgDAGgGADQgGADgHAAQgHAAgFgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_176.setTransform(327.95,83.025);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgDgFAAgHQAAgGADgFQADgFAGgEQAFgDAHAAQAHAAAGADQAFAEADAFQADAFABAGQgBAHgDAFQgDAGgFADQgGADgHAAQgHAAgFgDgAgGgKQgCABgBADQgCADAAADQAAAEACADIADAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_177.setTransform(322.5,83.025);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_178.setTransform(318.5,82.15);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AgVAgIAAg/IAsAAIAAAMIgfAAIAAAOIAeAAIAAALIgeAAIAAAag");
	this.shape_179.setTransform(314.7,82.15);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_180.setTransform(352.65,73.475);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_181.setTransform(348.75,72.6);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_182.setTransform(346.375,72.525);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AgGAgIAAgzIgTAAIAAgMIAzAAIAAAMIgTAAIAAAzg");
	this.shape_183.setTransform(342.4,72.6);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABg");
	this.shape_184.setTransform(334.125,72.625);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AAIAgIgMgSIgFAGIAAAMIgNAAIAAg/IANAAIAAAmIAQgUIAPAAIgSAUIASAZg");
	this.shape_185.setTransform(326.2,72.6);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_186.setTransform(320.575,73.425);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAHgCQAFAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAGgBQAFgCAEAAQAGAAAEACQAFABADAEQACAEAAAGIAAAdIgLAAIAAgFQgDADgEACQgDABgFAAIgHgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_187.setTransform(315.1,73.475);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FFFFFF").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_188.setTransform(311.4,72.6);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFFFFF").s().p("AgYAgIAAg/IAcAAQAHAAAFADQAEADADAFQACAEAAAGQAAAFgCAFQgDAEgEADQgFACgHAAIgPAAIAAAXgAgLgBIANAAQAFgBACgCQACgCABgEQgBgFgCgCQgCgCgFAAIgNAAg");
	this.shape_189.setTransform(307.45,72.6);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_190.setTransform(364.35,63.875);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABABIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_191.setTransform(360.125,63.3);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_192.setTransform(357.275,62.925);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFFFFF").s().p("AgKAWQgGgBgDgEIAFgJIAEAEIAGACIAFABQAEAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgGgCIgIgCQgFgBgCgCQgDgDAAgGQAAgDACgEQADgDAEgCQAEgCAFAAQAGAAAEACQAFABADADIgEAJIgGgEQgEgBgEAAIgEABQAAAAgBAAQAAABAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABABAAIAFABIAIADQAFABADACQACADAAAGQAAAEgCADQgDAEgEABQgFACgGAAQgFAAgFgCg");
	this.shape_193.setTransform(353.75,63.875);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAFgDAHAAQAIAAAFADQAGAEADAFQACAFAAAGQAAAHgCAFQgDAGgGADQgFADgIAAQgHAAgFgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_194.setTransform(348.75,63.875);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFFFFF").s().p("AgXAgIAAg+IANAAIAAAGIAGgGQAEgBADAAQAGAAAFACQAEAEACAEQAEAGAAAIQAAAHgEAFQgCAGgEACQgFADgGAAIgHgBIgGgGIAAAXgAgGgTIgEAEIAAAPIAEAEIAGABQAFAAADgDQADgDAAgGQAAgGgDgEQgDgDgFgBIgGACg");
	this.shape_195.setTransform(343.4,64.7);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_196.setTransform(336.375,63.825);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFgBgHQABgGADgFQADgFAFgEQAGgDAGAAQAHAAAGADQAGAEADAFQADAFAAAGQAAAHgDAFQgDAGgGADQgGADgHAAQgGAAgGgDgAgGgKQgCABgCADQgBADAAADQAAAEABADIAEAFQADACADAAQAEAAADgCIADgFQACgDAAgEQAAgDgCgDQgBgDgCgBQgDgCgEAAQgDAAgDACg");
	this.shape_197.setTransform(329.55,63.875);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgIQgEgHAAgKQAAgJAEgHQAFgHAHgFQAIgEAJAAQAHAAAFACQAFACADAEIAGAIIgMAFQgCgEgEgCQgDgCgFgBQgFABgFACQgEACgDAFQgCAFgBAFQABAGACAFQADAFAEADQAFACAFAAQAFAAADgCQAEgDACgEIAMAFIgGAIQgDADgFADQgFACgHAAQgJAAgIgEg");
	this.shape_198.setTransform(323.625,63);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFFFFF").s().p("AgLAVQgFgDgDgFQgDgFgBgIQAAgGADgFQAEgGAFgDQAFgDAHAAQAHAAAFADQAFADADAGQACAGAAAGIAAADIghAAQABAEAEADQACADAGAAIAEAAIAEgCIAEgCIAGAIQgEADgFACQgGABgFAAQgGAAgGgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBgCgDgCQgCgBgEAAQgEAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_199.setTransform(315.1,63.875);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_200.setTransform(309.725,63.825);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFFFFF").s().p("AgMAVQgGgDgDgGQgCgFAAgHQAAgGACgFQADgFAGgEQAFgDAHAAQAIAAAFADQAGAEADAFQACAFAAAGQAAAHgCAFQgDAGgGADQgFADgIAAQgHAAgFgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAFgFQABgDAAgEQAAgDgBgDQgCgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_201.setTransform(304.2,63.875);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFFFFF").s().p("AgDAbQgEgEAAgFIAAgYIgHAAIAAgKIAHAAIAAgNIALAAIAAANIAKAAIAAAKIgKAAIAAAUIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABABIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_202.setTransform(299.875,63.3);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFFFFF").s().p("AgOAeQgHgDgEgEIAHgLQAEAEAFACQAFADAFAAQAGAAADgCQACgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgHgDIgIgCIgJgDQgEgCgDgDQgCgEAAgGQAAgFADgEQADgFAFgCQAFgDAHAAQAIAAAGACQAGADAFAEIgIAKQgEgEgEgBIgJgCQgFAAgCACQgCABAAADQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAHADIAIACQAFABAEACQAEACADADQACAEAAAFQAAAGgCAFQgDAEgGADQgGADgIAAQgIAAgHgDg");
	this.shape_203.setTransform(295.325,63.025);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFFFFF").s().p("AgQAgIgDAAIACgLIACABIABAAIAEgBIADgDIACgEIgTgtIANAAIALAfIAMgfIANAAIgWA0QgCAFgBACIgFADIgIABIgDAAg");
	this.shape_204.setTransform(159.85,83.225);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFFFFF").s().p("AgNAYIAAgtIANAAIAAAGQABgDAEgCQAEgCAEgBIAAAMIgBAAIgCAAIgEABIgEACIgCACIAAAeg");
	this.shape_205.setTransform(155.9,82.225);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgHIAAgWIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIACAAIACgBIACAJQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_206.setTransform(152.375,81.7);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQABgGADgFQADgGAFgDQAGgDAFAAQAIAAAEADQAGADACAGQAEAGAAAGIAAADIghAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgFABgFAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQAAgCgDgCQgDgBgEAAQgCAAgDABIgEAEIgBAFIAWAAIAAAAg");
	this.shape_207.setTransform(148.1,82.275);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_208.setTransform(142.675,82.225);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_209.setTransform(138.725,81.325);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FFFFFF").s().p("AgEAfIgHgGIAAAGIgLAAIAAg+IALAAIAAAXQADgDAEgCQAEgCADAAQAGAAAFADQAEADADAFQADAFAAAHQAAAIgDAGQgDAFgEADQgFADgGgBQgEABgDgCgAgGgDIgFAEIAAAPIAFAFIAGABQAEgBADgDQAEgDAAgHQAAgFgEgEQgDgDgEAAIgGABg");
	this.shape_210.setTransform(134.8,81.45);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FFFFFF").s().p("AgMAXQgEgCgCgDQgCgEgBgFQABgFACgEQACgCAEgBIAIgCQAEAAADACQAEABADACIAAgFQgBgEgDgCQgCgCgEAAIgHACIgGAEIgFgJQAEgEAFgBQAGgCAEAAQAGAAAEACQAFABADAEQADAEAAAGIAAAdIgMAAIAAgFQgDADgEACQgDABgEAAIgIgBgAgFAEQgDACAAADQAAAEADABQACACADAAIAFgBIAFgDIAAgGIgFgDIgFgBQgDAAgCACg");
	this.shape_211.setTransform(129.15,82.275);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#FFFFFF").s().p("AgNAdQgHgEgFgHQgEgIAAgKQAAgJAEgHQAFgIAHgDQAIgFAJAAQAHAAAFADQAFABADAEIAGAIIgMAGQgCgEgEgDQgDgDgFAAQgFAAgFADQgEADgDAFQgCAEgBAFQABAGACAFQADAFAEACQAFADAFAAQAFAAADgDQAEgCACgEIAMAGIgGAHQgDADgFADQgFACgHAAQgJAAgIgEg");
	this.shape_212.setTransform(123.525,81.4);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgDgFgBgIQAAgGAEgFQADgGAFgDQAFgDAHAAQAGAAAFADQAGADACAGQADAGAAAGIAAADIggAAQAAAEADADQAEADAEAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgDAAQgDAAgDABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_213.setTransform(173.55,72.675);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#FFFFFF").s().p("AAXAYIAAgcQAAgEgCgCQgCgCgDAAQgEAAgCACIgEAEIAAAeIgLAAIAAgcQAAgEgCgCQgBgCgEAAQgDAAgDACIgEAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAFAAACADQADACABAEIAEgEQACgCAEgBQADgCADAAQAHAAADAEQAEADAAAHIAAAhg");
	this.shape_214.setTransform(166.775,72.625);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgGQgDgFAAgHQAAgGADgFQADgFAFgEQAGgDAGAAQAHAAAGADQAFAEAEAFQACAFAAAGQAAAHgCAFQgEAGgFADQgGADgHAAQgGAAgGgDgAgFgKQgDABgCADQgBADAAADQAAAEABADIAFAFQACACADAAQAEAAACgCIAEgFQACgDAAgEQAAgDgCgDQgBgDgDgBQgCgCgEAAQgDAAgCACg");
	this.shape_215.setTransform(160,72.675);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#FFFFFF").s().p("AAPAgIAAgbIgdAAIAAAbIgNAAIAAg/IANAAIAAAaIAdAAIAAgaIANAAIAAA/g");
	this.shape_216.setTransform(153.75,71.8);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FFFFFF").s().p("AgSAfQgFgCgDgEQgCgEAAgHQAAgEABgEIAFgGIAHgDIgDgHIgBgHQAAgEACgDQADgEAEgCQAEgCAFAAQAEAAAEACQADABADADQACADAAAEQAAAFgCAEIgGAFIgHAEIACADIADADIAFAGIAEgGIACgFIAKAEIgEAHIgFAIIAGAGIAGAHIgPAAIgCgCIgDgDQgEADgEABQgDACgFAAQgGAAgFgCgAgOAIQgCACAAADQAAADACADIADADIAFABIAFgBIADgCIgDgEIgDgEIgDgEIgDgFIgEAFgAgFgVQgCACAAADIABAEIACAEQAEgCACgCQACgCABgEIgCgEQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABg");
	this.shape_217.setTransform(144.725,71.825);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#FFFFFF").s().p("AAJAYIAAgbQAAgFgCgCQgCgCgEAAQgDAAgCACIgFAEIAAAeIgMAAIAAgtIAMAAIAAAFIAEgDIAFgCQADgCAEAAQAHABAEADQAEAEAAAHIAAAgg");
	this.shape_218.setTransform(136.325,72.625);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFFFFF").s().p("AgKAVQgGgDgDgFQgEgFAAgIQAAgGAEgFQADgGAFgDQAGgDAFAAQAIAAAEADQAGADACAGQADAGABAGIAAADIghAAQAAAEADADQADADAFAAIAFAAIAEgCIAEgCIAFAIQgDADgGACQgEABgGAAQgGAAgFgDgAAMgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgBgCgCgCQgDgBgEAAQgDAAgCABIgDAEIgCAFIAWAAIAAAAg");
	this.shape_219.setTransform(130.9,72.675);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#FFFFFF").s().p("AAKAgIAAgcQAAgEgDgCQgCgBgEAAQgDgBgCACIgEADIAAAfIgNAAIAAg/IANAAIAAAXIADgCIAFgDQADgBAEAAQAHAAAEAEQAEADAAAHIAAAgg");
	this.shape_220.setTransform(125.525,71.8);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AgJAVQgFgDgDgFQgDgGAAgHQAAgGADgFQADgGAFgDQAGgDAGAAQAFAAAEABIAFADIAFAEIgIAIIgFgEIgFgBQgFAAgDADQgEAEAAAFQAAAGAEAEQADADAFABQADAAACgCIAFgDIAIAHIgFAEIgFADIgJABQgGAAgGgDg");
	this.shape_221.setTransform(120.4,72.675);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FFFFFF").s().p("AgDAbQgEgDAAgGIAAgXIgHAAIAAgLIAHAAIAAgNIALAAIAAANIAKAAIAAALIgKAAIAAATIABAEQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAIACgBIACgBIACAJQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAIgHABQgFAAgDgDg");
	this.shape_222.setTransform(116.375,72.1);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FFFFFF").s().p("AgFAhIAAgtIALAAIAAAtgAgEgUQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_223.setTransform(113.525,71.725);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FFFFFF").s().p("AAKAgIgSgaIgFAHIAAATIgNAAIAAg/IANAAIAAAdIAWgdIAQAAIgZAeIAbAhg");
	this.shape_224.setTransform(109.575,71.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120}]},368).to({state:[]},142).to({state:[{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120}]},368).to({state:[]},142).wait(84));

	// Слой_9
	this.instance_5 = new lib.PC33();
	this.instance_5.parent = this;
	this.instance_5.setTransform(190,63,1,1,0,0,0,190,63);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(368).to({_off:false},0).to({y:31},141).to({_off:true},1).wait(368).to({_off:false,y:63},0).to({y:31},141).to({_off:true},1).wait(84));

	// Слой_21
	this.instance_6 = new lib.pc3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(249.4,101.15,0.73,0.73,0,0,0,342.7,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(220).to({_off:false},0).to({y:-8.05},147).to({_off:true},1).wait(362).to({_off:false,y:101.15},0).to({y:-8.05},147).to({_off:true},1).wait(226));

	// pc11
	this.instance_7 = new lib.pc11();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-5.45,-7.05,0.8893,0.8893);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(105).to({_off:false},0).to({y:-77.05},115).to({_off:true},1).wait(394).to({_off:false,y:-7.05},0).to({y:-77.05},115).to({_off:true},1).wait(373));

	// Слой_3
	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_225.setTransform(364,45);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("rgba(255,255,255,0.898)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_226.setTransform(364,45);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("rgba(255,255,255,0.8)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_227.setTransform(364,45);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("rgba(255,255,255,0.698)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_228.setTransform(364,45);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_229.setTransform(364,45);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("rgba(255,255,255,0.502)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_230.setTransform(364,45);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("rgba(255,255,255,0.4)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_231.setTransform(364,45);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("rgba(255,255,255,0.302)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_232.setTransform(364,45);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_233.setTransform(364,45);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_234.setTransform(364,45);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_235.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_225}]}).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[]},1).to({state:[{t:this.shape_225}]},499).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[]},1).to({state:[]},499).wait(84));

	// Слой_6
	this.instance_8 = new lib.icons();
	this.instance_8.parent = this;
	this.instance_8.setTransform(150.75,152.2,1,1,0,0,0,136.4,18.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(4).to({_off:false},0).to({alpha:1},6).to({_off:true},95).wait(409).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},95).wait(489));

	// screen21.jpg - копия
	this.instance_9 = new lib.pc21("synched",39);
	this.instance_9.parent = this;
	this.instance_9.setTransform(302,72.05,0.5818,0.5818,0,0,0,296.1,139.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({y:81.05},105).to({_off:true},1).wait(404).to({_off:false,y:72.05},0).to({y:81.05},105).to({_off:true},1).wait(488));

	// Слой_1
	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_236.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_236).wait(510).to({_off:true},510).wait(84));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-65.2,728.5,284);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_Omnichannel Retailers_atlas_P_.png", id:"728x90_Omnichannel Retailers_atlas_P_"},
		{src:"images/728x90_Omnichannel Retailers_atlas_NP_.jpg", id:"728x90_Omnichannel Retailers_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;