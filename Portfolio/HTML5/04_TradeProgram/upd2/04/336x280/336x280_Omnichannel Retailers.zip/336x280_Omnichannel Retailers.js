(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"336x280_Omnichannel Retailers_atlas_P_", frames: [[0,0,98,28]]},
		{name:"336x280_Omnichannel Retailers_atlas_NP_", frames: [[112,298,54,44],[0,298,52,49],[54,343,45,40],[338,271,336,192],[338,0,336,269],[54,298,56,43],[0,0,336,296],[676,0,336,192],[676,194,336,192]]}
];


// symbols:



(lib.Растровоеизображение11 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение12 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение13 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение15111 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение1511 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen11 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.screen211 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.screen21 = function() {
	this.initialize(ss["336x280_Omnichannel Retailers_atlas_NP_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape.setTransform(214.1,71.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_1.setTransform(206,71.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_2.setTransform(200.375,69.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_3.setTransform(194.725,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgFAjIgdhFIAMAAIAWA5IAXg5IAMAAIgdBFg");
	this.shape_4.setTransform(187.55,71.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_5.setTransform(178.25,71.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAGAAQAJAAAGADQAGADAEAFQAFAFABAHQADAHAAAHIAAADIg4AAQABAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgIgZQgFACgDAEQgDADgBAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgFAAgDACg");
	this.shape_6.setTransform(171.4,71.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_7.setTransform(163.75,71.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_8.setTransform(158.575,70.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_9.setTransform(155.325,69.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgCADgCAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgEAAgFACg");
	this.shape_10.setTransform(149.65,71.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_11.setTransform(141.175,70.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgDgIAAgHQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgDAEgBAEQgBAFAAAFQAAAFABAFQABAFADAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_12.setTransform(129.3,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_13.setTransform(123.05,70.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_14.setTransform(112.775,70.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAFADQAHADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape_15.setTransform(104.75,71.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_16.setTransform(96.65,71.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_17.setTransform(88.275,72.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_18.setTransform(82.675,70.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_19.setTransform(77.575,71.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgCgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_20.setTransform(70.25,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_21.setTransform(61.775,70.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_22.setTransform(50.575,71.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgCgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_23.setTransform(43.25,71.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_24.setTransform(35.675,71.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_25.setTransform(30.325,70.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_26.setTransform(25.15,71.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_27.setTransform(19.6,71.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(12.75,71.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_29.setTransform(5.175,71.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgXAwQgFgCgEgDQgEgDgDgFQgCgGAAgGQAAgGACgFQACgDADgEIAHgFIAIgFIgGgLQgCgFAAgFQAAgGACgDQACgFADgDQAEgDAEgCQAEgBAFAAIAIABIAHAEQADACACAEQACADAAAFQgBAFgCAEQgCAFgEACIgHAGIgJAFIAGAGIAFAHIAFAHIAHAGIAGgMIAEgKIAJAEIgGAMQgDAHgEAGIAJAIIAKAKIgPAAIgFgEIgGgGQgFAFgHAEQgGADgIAAQgHAAgGgCgAgZAKQgEAFAAAHQAAAEACAEQABAEADACQADACADABQAEACAEAAQAGAAAEgDQAFgDAEgEIgIgIIgFgGIgGgHIgGgJQgGAEgEAFgAgHgoIgFAEQgCABgBADIgBAGIACAIIAFAIIAGgEIAFgEIAFgGQABgCABgEQgBgFgDgDQgDgCgEgBIgFABg");
	this.shape_30.setTransform(-6.45,69.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_31.setTransform(-18.375,71.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAKAAIAAATIANAAIAAAJIgNAAIAAArQgBAEACACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_32.setTransform(-23.75,70.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_33.setTransform(-29.375,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_34.setTransform(-37.1,71.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_35.setTransform(-45.475,70.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFAAAFQAAAFACAFQACAFACAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_36.setTransform(-53.6,71.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgFAAIgFABIgFACIgEAEIgDAEIAAAxg");
	this.shape_37.setTransform(-59.75,71.175);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgiAwIAAhfIAmAAQAIAAAFACQAGACADAEQAEAEADAFQABAGAAAGQAAAGgBAFQgDAFgEADQgDAEgGACQgFADgIAAIgZAAIAAAmgAgVAAIAYAAQAJAAAEgFQAGgFAAgIQAAgJgGgFQgEgFgJAAIgYAAg");
	this.shape_38.setTransform(-66.45,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t122, new cjs.Rectangle(-73.1,61.3,293.4,18.5), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgEAFQgDgBAAgEQAAgDADgCQACgCACAAQADAAADACQACACAAADQAAAEgCABQgDADgDAAQgCAAgCgDg");
	this.shape.setTransform(171.7,74.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_1.setTransform(166.575,71.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAGgDQAFgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_2.setTransform(159.3,71.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_3.setTransform(151.825,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFAAAFQAAAFACAFQACAFACAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_4.setTransform(143.95,71.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgLAxIAAg8IgLAAIAAgJIALAAIAAgFQAAgMAGgFQAFgGAIAAIAIABQAEABADADIgEAIIgEgEIgFAAQgFAAgDAEQgCADAAAHIAAAFIANAAIAAAJIgNAAIAAA8g");
	this.shape_5.setTransform(138.275,69.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_6.setTransform(129.95,71.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAHABQAFAAAGgDQAFgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgGAEQgHADgHAAQgLAAgGgFg");
	this.shape_7.setTransform(123.15,71.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgCgIgBgHQABgHACgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQADAGgBAHQABAHgDAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgEACgEAEQgDAEgBAEQgBAFAAAFQAAAFABAFQABAFADAEQAEADAEADQAEACAFAAQAGAAAEgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgEgCgGAAQgFAAgEACg");
	this.shape_8.setTransform(115,71.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgYAxIgDgBIABgKIADABIADAAQAEAAACgBQADgCACgEIAEgLIgdhFIALAAIAXA4IAXg4IAMAAIgjBTQgCAIgGADQgFADgGAAIgFAAg");
	this.shape_9.setTransform(103.55,72.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_10.setTransform(95.625,72.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAHAAAGADQAHADAEAFQAEAFACAHQADAHAAAHIAAADIg4AAQAAAFADAEQACAEACADQAEAEAEACQAFACAEAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgIAAQgIAAgGgDgAgIgZQgFACgDAEQgCADgCAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgEgCQgFgCgGAAQgEAAgEACg");
	this.shape_11.setTransform(87.6,71.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgEApQgEgFAAgHIAAgtIgLAAIAAgJIALAAIAAgTIAKAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_12.setTransform(81.4,70.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_13.setTransform(75.225,71.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_14.setTransform(69.6,71.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgDApQgEgFgBgHIAAgtIgLAAIAAgJIALAAIAAgTIALAAIAAATIANAAIAAAJIgNAAIAAArQAAAEABACQACADADAAIAFgBIADgDIADAJIgFADQgDABgFABQgHgBgDgEg");
	this.shape_15.setTransform(64.7,70.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_16.setTransform(59.075,71.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgFAAIgFABIgFACIgEAEIgDAEIAAAxg");
	this.shape_17.setTransform(50.05,71.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgXAfQgFgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAHABQAFAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgGAEQgHADgHAAQgLAAgGgFg");
	this.shape_18.setTransform(43.25,71.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgNAiQgHgDgEgFQgFgFgCgGQgCgIAAgHQAAgHACgGQACgHAFgFQAEgFAHgDQAGgDAHAAQAIAAAGADQAHADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgHADQgGADgIAAQgHAAgGgDgAgJgYQgEACgDAEQgEAEgBAEQgCAFABAFQgBAFACAFQABAFAEAEQADADAEADQAFACAEAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_19.setTransform(35.1,71.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgYAxIgDgBIABgKIADABIADAAQAEAAACgBQADgCACgEIAEgLIgdhFIALAAIAXA4IAXg4IAMAAIgjBTQgCAIgGADQgEADgHAAIgFAAg");
	this.shape_20.setTransform(27.4,72.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_21.setTransform(15.725,72.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgFACIgGAEIgDAEIAAAyIgLAAIAAhFIALAAIAAAKIAEgEIAGgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_22.setTransform(7.75,71.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_23.setTransform(2.125,70.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AARAwIgYgfIgMALIAAAUIgLAAIAAhfIALAAIAAA+IAkgkIAOAAIgfAfIAfAmg");
	this.shape_24.setTransform(-2.775,69.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_25.setTransform(-10.975,71.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AAjAwIAAhOIghBOIgEAAIgghOIAABOIgMAAIAAhfIARAAIAdBHIAehHIARAAIAABfg");
	this.shape_26.setTransform(-20.475,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-28.4,61.3,203.9,18.5), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgTApQgKgEgGgGIALgOQAEAEAHAEQAHADAIAAQAIAAADgDQAEgCAAgEQAAgEgEgCIgJgDIgLgDQgGgCgGgDQgFgCgEgEQgEgFAAgIQAAgIAEgGQAEgGAIgDQAHgEAJAAQAKAAAJADQAIADAHAGIgKAOQgGgFgGgCQgHgCgGAAQgFAAgEACQgDACAAAEQAAAEAEABIAJAEIALADIAMAEQAGADADAEQAEAFAAAIQAAAIgEAGQgEAGgHAEQgIAEgMAAQgLAAgJgEg");
	this.shape.setTransform(258.975,129.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_1.setTransform(251.175,129.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_2.setTransform(243.125,129.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgbArIAAhVIATAAIAABFIAjAAIAAAQg");
	this.shape_3.setTransform(236.05,129.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_4.setTransform(230.725,129.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAYArIgGgOIgjAAIgGAOIgVAAIAihVIAVAAIAiBVgAANAMIgNgkIgNAkIAaAAg");
	this.shape_5.setTransform(224.5,129.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgIArIAAhFIgaAAIAAgQIBFAAIAAAQIgaAAIAABFg");
	this.shape_6.setTransform(216.275,129.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_7.setTransform(208.825,129.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_8.setTransform(200.925,129.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgbArIAAhVIATAAIAABFIAjAAIAAAQg");
	this.shape_9.setTransform(190.05,129.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_10.setTransform(182.825,129.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAVArIgog3IAAA3IgTAAIAAhVIATAAIAnA1IAAg1IATAAIAABVg");
	this.shape_11.setTransform(174.125,129.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAVArIgog3IAAA3IgTAAIAAhVIATAAIAnA1IAAg1IATAAIAABVg");
	this.shape_12.setTransform(164.625,129.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAYArIgFgOIgkAAIgGAOIgVAAIAhhVIAWAAIAiBVgAANAMIgNgkIgNAkIAaAAg");
	this.shape_13.setTransform(155.45,129.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAVArIAAgkIgpAAIAAAkIgSAAIAAhVIASAAIAAAiIApAAIAAgiIASAAIAABVg");
	this.shape_14.setTransform(146.25,129.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgSAnQgKgGgGgKQgGgKAAgNQAAgMAGgLQAGgKAKgFQALgGAMAAQAJAAAHADQAHADAFAFQAFAFADAFIgQAIQgDgFgFgEQgFgDgHAAQgHAAgGADQgGAEgEAGQgDAHAAAHQAAAIADAHQAEAGAGAEQAGADAHAAQAHAAAFgDQAFgEADgFIAQAHQgDAGgFAFQgFAFgHADQgHADgJAAQgMAAgLgGg");
	this.shape_15.setTransform(137.125,129.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_16.setTransform(130.775,129.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAVArIgog3IAAA3IgTAAIAAhVIATAAIAnA1IAAg1IATAAIAABVg");
	this.shape_17.setTransform(124.225,129.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAdArIAAg9IgZA9IgHAAIgZg9IAAA9IgSAAIAAhVIAaAAIAUA1IAVg1IAaAAIAABVg");
	this.shape_18.setTransform(113.95,129.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgWAnQgLgGgFgKQgGgKAAgNQAAgMAGgKQAFgKALgGQAKgGAMAAQANAAAKAGQALAGAFAKQAGAKAAAMQAAANgGAKQgFAKgLAGQgKAGgNAAQgMAAgKgGgAgNgYQgGAEgDAGQgDAHAAAHQAAAIADAGQADAHAGAEQAGADAHAAQAIAAAGgDQAGgEADgHQADgGAAgIQAAgHgDgHQgDgGgGgEQgGgDgIAAQgHAAgGADg");
	this.shape_19.setTransform(103.425,129.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAVArIAAgkIgpAAIAAAkIgSAAIAAhVIASAAIAAAiIApAAIAAgiIASAAIAABVg");
	this.shape_20.setTransform(90.35,129.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgIArIAAhFIgaAAIAAgQIBFAAIAAAQIgaAAIAABFg");
	this.shape_21.setTransform(81.825,129.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_22.setTransform(76.275,129.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAPArIgPg6IgOA6IgTAAIgahVIAVAAIAQA9IAQg9IANAAIARA9IAPg9IAUAAIgYBVg");
	this.shape_23.setTransform(68.5,129.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgTApQgKgEgGgGIALgOQAEAEAHAEQAHADAIAAQAIAAADgDQAEgCAAgEQAAgEgEgCIgJgDIgLgDQgGgCgGgDQgFgCgEgEQgEgFAAgIQAAgIAEgGQAEgGAIgDQAHgEAJAAQAKAAAJADQAIADAHAGIgKAOQgGgFgGgCQgHgCgGAAQgFAAgEACQgDACAAAEQAAAEAEABIAJAEIALADIAMAEQAGADADAEQAEAFAAAIQAAAIgEAGQgEAGgHAEQgIAEgMAAQgLAAgJgEg");
	this.shape_24.setTransform(55.225,129.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAOArIgZgjIgHAJIAAAaIgSAAIAAhVIASAAIAAAmIAegmIAXAAIgjAoIAlAtg");
	this.shape_25.setTransform(47.725,129.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_26.setTransform(39.175,129.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgWAnQgLgGgFgKQgGgKAAgNQAAgMAGgKQAFgKALgGQAKgGAMAAQANAAAKAGQALAGAFAKQAGAKAAAMQAAANgGAKQgFAKgLAGQgKAGgNAAQgMAAgKgGgAgNgYQgGAEgDAGQgDAHAAAHQAAAIADAGQADAHAGAEQAGADAHAAQAIAAAGgDQAGgEADgHQADgGAAgIQAAgHgDgHQgDgGgGgEQgGgDgIAAQgHAAgGADg");
	this.shape_27.setTransform(29.825,129.675);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAQArIgQg6IgOA6IgUAAIgZhVIAWAAIAOA9IARg9IAOAAIAQA9IAPg9IAVAAIgZBVg");
	this.shape_28.setTransform(18.85,129.675);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgNAYQgGgEgEgGQgDgGgBgIQABgGADgHQAEgGAGgDQAGgFAHAAQAIAAAGAFQAHADADAGQADAHAAAGQAAAIgDAGQgDAGgHAEQgGAEgIgBQgHABgGgEgAgLgTQgFADgDAFQgDAGgBAFQABAHADAFQADAFAFADQAGAEAFAAQAGAAAGgEQAFgDADgFQAEgFAAgHQAAgFgEgGQgDgFgFgDQgGgDgGAAQgFAAgGADgAAIAQIgIgMIgFAAIAAAMIgEAAIAAgfIALAAQAFAAACADQADADABAEIgCAFIgDACIgDACIAIAMgAgFAAIAHAAIAFgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAAAIgFgCIgHAAg");
	this.shape_29.setTransform(6.35,127.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_30.setTransform(-0.525,129.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgSAnQgKgFgGgKQgHgKABgOQgBgNAHgKQAGgKAKgFQALgGAMAAQAIAAAIADQAHADAFAEIAIAKIgQAIQgDgFgFgDQgGgDgGAAQgHAAgHADQgFAEgEAGQgEAHABAHQgBAIAEAHQAEAGAFAEQAHADAHAAQAGAAAEgCQAFgCADgCIAAgLIgXAAIAAgPIAqAAIAAAhQgHAHgKAEQgJAFgLAAQgMAAgLgGg");
	this.shape_31.setTransform(-9.2,129.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAYArIgFgOIgkAAIgGAOIgVAAIAhhVIAWAAIAiBVgAANAMIgNgkIgNAkIAaAAg");
	this.shape_32.setTransform(-18.25,129.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAPArIgPg6IgOA6IgTAAIgahVIAVAAIAPA9IARg9IANAAIARA9IAPg9IAUAAIgYBVg");
	this.shape_33.setTransform(-28.7,129.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_34.setTransform(-38.325,129.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AAVArIgog3IAAA3IgTAAIAAhVIATAAIAnA1IAAg1IATAAIAABVg");
	this.shape_35.setTransform(-47.025,129.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(-53.8,121.8,318.90000000000003,17.000000000000014), null);


(lib.pc31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение1511();
	this.instance.parent = this;
	this.instance.setTransform(-5,-4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc31, new cjs.Rectangle(-5,-4,336,269), null);


(lib.pc21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],14.7,-19,14.7,27).s().p("A7vEsIAApXMA3fAAAIAAJXg");
	this.shape.setTransform(166,162.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_1
	this.instance = new lib.screen21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc21, new cjs.Rectangle(-11.6,0,355.3,192), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.screen11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,296), null);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib._8AssortmentSelection = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение13();
	this.instance.parent = this;
	this.instance.setTransform(-23,-20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._8AssortmentSelection, new cjs.Rectangle(-23,-20,45,40), null);


(lib._7CustomPrograms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение12();
	this.instance.parent = this;
	this.instance.setTransform(-26,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._7CustomPrograms, new cjs.Rectangle(-26,-23,52,49), null);


(lib._5Multiple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение11();
	this.instance.parent = this;
	this.instance.setTransform(-28,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._5Multiple, new cjs.Rectangle(-28,-23,54,44), null);


(lib._1flexibleShipping = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;
	this.instance.setTransform(-28,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1flexibleShipping, new cjs.Rectangle(-28,-21,56,43), null);


(lib.pc31_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},13).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},19).to({state:[]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},22).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},28).to({state:[]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},32).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},38).to({state:[]},1).wait(113));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},42).to({state:[]},1).wait(113));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},48).to({state:[]},1).wait(113));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},52).to({state:[]},1).wait(113));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},58).to({state:[]},1).wait(113));

	// Слой_1
	this.instance_1 = new lib.Растровоеизображение15111();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(66).to({_off:true},1).wait(113));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_1.setTransform(369.675,49.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_2.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},44).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_11}]},7).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2 - копия
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_12.setTransform(369.675,146.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_13.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_13}]},39).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},13).to({state:[]},1).wait(119));

	// Слой_3 - копия: 2
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_22.setTransform(286.05,49.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_23.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22}]}).to({state:[{t:this.shape_23}]},35).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},16).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2
	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_33.setTransform(286.05,146.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_34.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33}]}).to({state:[{t:this.shape_34}]},30).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},22).to({state:[]},1).wait(119));

	// Слой_3 - копия: 2
	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43}]}).to({state:[{t:this.shape_43}]},25).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_52}]},26).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2
	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_53.setTransform(204.875,48.325);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_54.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53}]}).to({state:[{t:this.shape_54}]},20).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_62}]},32).to({state:[]},1).wait(119));

	// Слой_3 - копия
	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_63.setTransform(122.675,49.275);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_64.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_63}]}).to({state:[{t:this.shape_64}]},15).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_73}]},36).to({state:[]},1).wait(119));

	// Слой_2 - копия
	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_74.setTransform(122.675,146.25);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_75.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_74}]}).to({state:[{t:this.shape_75}]},10).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},42).to({state:[]},1).wait(119));

	// Слой_10
	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_84.setTransform(41.5,145.75);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_85.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_84}]}).to({state:[{t:this.shape_85}]},5).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_94}]},46).to({state:[]},1).wait(119));

	// Слой_11
	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_103.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_95}]}).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_103}]},52).to({state:[]},1).wait(119));

	// Слой_1
	this.instance_1 = new lib.screen211();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60).to({_off:true},1).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgHAWQgFgBgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAEAAAFIAAACIgkAAIACAFIADAGIAFADQADACADAAQAEgBADgCQAEgBADgCIADAEQgDADgFACQgEACgGAAQgEAAgEgCgAgFgPQgDAAgCADIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDAAQgDgCgEAAQgCAAgDACg");
	this.shape.setTransform(276.125,27.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgDAgIAAg/IAGAAIAAA/g");
	this.shape_1.setTransform(272.35,27.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgHAeQgEgCgCgEIAAAHIgHAAIAAg+IAHAAIAAAYQACgEAEgCQAFgCADAAIAIACIAHAFQADADABAEQABAEAAAFQAAAGgBAEIgEAIQgDADgEACIgIABQgDAAgFgCgAgIgGQgDACgCADIAAAUQACADADACQAEACAEAAQADAAADgBIAEgEQACgCACgEIABgHIgBgHQgCgCgCgCIgEgEIgGgBQgEAAgEACg");
	this.shape_2.setTransform(268.7,27.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgIAXQgDAAgCgCIgEgGQgBgDAAgDQAAgEABgCIAEgFIAFgCIAGgBQAEAAADABQAEACADACIAAgHQAAgFgDgCQgDgDgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEAAACACIAEAGQABACAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQADADAFAAQADAAAEgCIAFgDIAAgJIgFgEQgEgBgDAAQgFAAgDACg");
	this.shape_3.setTransform(263.225,27.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_4.setTransform(259.75,27.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_5.setTransform(257.625,27.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgIAXQgDAAgCgCIgEgGQgBgDAAgDQAAgEABgCIAEgFIAFgCIAGgBQAEAAADABQAEACADACIAAgHQAAgFgDgCQgDgDgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEAAACACIAEAGQABACAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQADADAFAAQADAAAEgCIAFgDIAAgJIgFgEQgEgBgDAAQgFAAgDACg");
	this.shape_6.setTransform(253.925,27.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgDAXIgTgtIAIAAIAOAkIAPgkIAIAAIgTAtg");
	this.shape_7.setTransform(249.225,27.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgIAXQgDAAgCgCIgEgGQgBgDAAgDQAAgEABgCIAEgFIAFgCIAGgBQAEAAADABQAEACADACIAAgHQAAgFgDgCQgDgDgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEAAACACIAEAGQABACAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQADADAFAAQADAAAEgCIAFgDIAAgJIgFgEQgEgBgDAAQgFAAgDACg");
	this.shape_8.setTransform(244.275,27.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgJAWQgFgCgDgDIAEgFQABADAFABQADACAFABQAFAAADgDQADgCAAgDQAAgBgBgBQAAgBAAAAQAAgBgBAAQAAAAgBgBIgFgCIgGgCIgHgCIgFgDQgCgDAAgEIABgFQABgCACgCIAGgDIAGgBQAGAAAEACQAFACACADIgEAEQgCgCgDgBQgEgCgEAAQgEAAgCACQgDACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAIAFACIAGABIAHADIAFADQADADAAAFIgCAEQgBADgDACQgCACgDABIgIABQgFAAgEgCg");
	this.shape_9.setTransform(237.25,27.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AAMAYIAAgeQAAgFgCgDQgDgCgFAAIgDAAIgEACIgDACIgCADIAAAhIgIAAIAAguIAIAAIAAAHIACgCIAEgDIAEgCIAEgBQAPAAAAAPIAAAgg");
	this.shape_10.setTransform(232.5,27.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgJAWQgEgCgDgDQgDgDgBgEQgCgFAAgFQAAgEACgFQABgEADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAHQACAFAAAEQAAAFgCAFIgEAHQgDADgFACQgEACgFAAQgEAAgFgCgAgGgPIgEADIgDAHIgBAFIABAHIADAGIAEADQADACADAAQAEAAACgCIAFgDIADgGIABgHIgBgFIgDgHIgFgDQgCgBgEAAQgDAAgDABg");
	this.shape_11.setTransform(227.175,27.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_12.setTransform(223.375,27.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_13.setTransform(220.925,27.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgVAgIAAg+IAIAAIAAAHQACgEAFgCQADgCAFAAQAEAAAEABQAEACACADQADADABAFQABAEABAGQgBAFgBAEQgBAEgDADQgCAEgEABQgEACgEAAQgFAAgDgCQgEgCgDgEIAAAYgAgHgXQgEACgCADIAAAUQACADAEACQADADAEAAQADAAACgCIAGgEIACgEIABgHIgBgHIgCgGIgGgEIgFgBQgEAAgDACg");
	this.shape_14.setTransform(216.9,28.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgJAWQgEgCgDgDQgDgDgBgEQgCgFAAgFQAAgEACgFQABgEADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAHQACAFAAAEQAAAFgCAFIgEAHQgDADgFACQgEACgFAAQgEAAgFgCgAgGgPIgEADIgDAHIgBAFIABAHIADAGIAEADQADACADAAQAEAAACgCIAFgDIADgGIABgHIgBgFIgDgHIgFgDQgCgBgEAAQgDAAgDABg");
	this.shape_15.setTransform(211.325,27.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_16.setTransform(204.825,27.325);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AAMAYIAAgeQAAgFgCgDQgEgCgEAAIgDAAIgEACIgDACIgDADIAAAhIgHAAIAAguIAHAAIAAAHIADgCIAEgDIAEgCIAEgBQAPAAAAAPIAAAgg");
	this.shape_17.setTransform(200.8,27.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgHAWQgFgBgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAEAAAFIAAACIgkAAIACAFIADAGIAFADQADACADAAQAEgBADgCQAEgBADgCIADAEQgDADgFACQgEACgGAAQgEAAgEgCgAgFgPQgDAAgCADIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDAAQgDgCgEAAQgCAAgDACg");
	this.shape_18.setTransform(195.525,27.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AAYAYIAAgfQAAgEgCgDQgCgCgEAAQgEAAgDACQgEACgBADIAAAhIgHAAIAAgfQAAgEgBgDQgCgCgFAAQgDAAgEACQgDACgCADIAAAhIgHAAIAAguIAHAAIAAAHIACgCIAEgDIAEgCIAFgBQAFAAADADQACADABADIADgDIADgDIAFgCIAFgBQAGAAADAEQADADAAAIIAAAgg");
	this.shape_19.setTransform(188.975,27.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgPAgIgDAAIABgHIACABIACAAIAEgBIADgEIADgHIgTgtIAIAAIAOAkIAPgkIAIAAIgXA2QgBAFgDACQgEACgEAAIgDAAg");
	this.shape_20.setTransform(182.825,28.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgIAXQgDAAgCgCIgEgGQgBgDAAgDQAAgEABgCIAEgFIAFgCIAGgBQAEAAADABQAEACADACIAAgHQAAgFgDgCQgDgDgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEAAACACIAEAGQABACAAAFIAAAeIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDACAAAFQAAAEADADQADADAFAAQADAAAEgCIAFgDIAAgJIgFgEQgEgBgDAAQgFAAgDACg");
	this.shape_21.setTransform(177.875,27.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgVAgIAAg+IAIAAIAAAHQACgEAFgCQADgCAFAAQAEAAAEABQAEACACADQADADABAFQABAEABAGQgBAFgBAEQgBAEgDADQgCAEgEABQgEACgEAAQgFAAgDgCQgFgCgCgEIAAAYgAgHgXQgFACgBADIAAAUQABADAFACQADADAEAAQADAAACgCIAGgEIACgEIABgHIgBgHIgCgGIgGgEIgFgBQgEAAgDACg");
	this.shape_22.setTransform(172.9,28.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgHAWQgFgBgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAEAAAFIAAACIgkAAIACAFIADAGIAFADQADACADAAQAEgBADgCQAEgBADgCIADAEQgDADgFACQgEACgGAAQgEAAgEgCgAgFgPQgDAAgCADIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDAAQgDgCgEAAQgCAAgDACg");
	this.shape_23.setTransform(164.975,27.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_24.setTransform(161.2,27.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgUAgIAAg+IAHAAIAAAHQACgEAEgCQAFgCADAAQAFAAADABQAEACADADQADADABAFQABAEAAAGQAAAFgBAEQgBAEgDADQgDAEgEABQgDACgFAAQgDAAgFgCQgEgCgCgEIAAAYgAgIgXQgDACgCADIAAAUQACADADACQAEADAEAAQADAAADgCIAEgEIADgEIABgHIgBgHIgDgGIgEgEIgGgBQgEAAgEACg");
	this.shape_25.setTransform(157.55,28.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_26.setTransform(153.625,27.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_27.setTransform(151.175,27.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgCAgIAAg/IAGAAIAAA/g");
	this.shape_28.setTransform(148.65,27.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAUQgEgDAAgIIAAggIAHAAIAAAeIABAFIACADIADACIAEAAQAEAAADgCIAGgFIAAghIAHAAIAAAuIgHAAIAAgHQgDADgEACQgEADgEAAQgHAAgEgEg");
	this.shape_29.setTransform(145,27.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AAXAgIAAgzIgWAzIgBAAIgWgzIAAAzIgIAAIAAg/IALAAIATAvIATgvIAMAAIAAA/g");
	this.shape_30.setTransform(138.55,27.025);

	this.instance = new lib._5Multiple();
	this.instance.parent = this;
	this.instance.setTransform(121.95,29.05,0.367,0.367,0,0,0,0.6,0.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AAMAXIAAgcQAAgGgCgDQgDgCgFAAIgDABIgEABIgDACIgDADIAAAgIgHAAIAAgtIAHAAIAAAIIADgEIAEgCIAEgCIAEAAQAPgBAAAQIAAAeg");
	this.shape_31.setTransform(220.7,12.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgJAXQgEgDgDgDQgDgDgBgFQgCgEAAgFQAAgEACgEQABgFADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAIQACAEAAAEQAAAFgCAEIgEAIQgDADgFADQgEABgFAAQgEAAgFgBgAgGgPIgEAEIgDAFIgBAGIABAHIADAFIAEAFQADABADAAQAEAAACgBIAFgFIADgFIABgHIgBgGIgDgFIgFgEQgCgBgEgBQgDABgDABg");
	this.shape_32.setTransform(215.375,12.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_33.setTransform(211.575,11.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_34.setTransform(209.125,11.625);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgFAXQgEgDgDgDQgDgDgCgFQgCgEAAgFQAAgEACgEQACgFADgDQADgEAEgBQAEgCAEAAQAGAAAEACQAEADADADIgFAFQgCgEgDgBQgDgBgEgBIgFABIgFAFQgCACgBADIgBAGIABAHQABAEACABIAFAFQACABADAAQAIAAAEgGIAFAEQgDAEgEACQgEACgGAAQgEAAgEgBg");
	this.shape_35.setTransform(205.425,12.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgHAXQgFgDgDgDQgDgCgCgFQgBgFAAgFQAAgEABgEQACgFADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAADIAAACIgkAAIACAHIADAFIAFADQADACADgBQAEAAADgBQAEgCADgDIADAFQgDADgFADQgEABgGAAQgEAAgEgBgAgFgQIgFAEIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDgBQgDgBgEAAQgCAAgDABg");
	this.shape_36.setTransform(200.325,12.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_37.setTransform(196.55,11.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgHAXQgFgDgDgDQgDgCgCgFQgBgFAAgFQAAgEABgEQACgFADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAADIAAACIgkAAIACAHIADAFIAFADQADACADgBQAEAAADgBQAEgCADgDIADAFQgDADgFADQgEABgGAAQgEAAgEgBgAgFgQQgDABgCADIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDgBQgDgBgEAAQgCAAgDABg");
	this.shape_38.setTransform(192.825,12.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgNAeQgGgDgEgEIAFgGIADADIAFADIAGACIAEABIAIgBIAFgDIACgDIABgEQgBgDgBgCIgEgDIgGgDIgGgCIgHgCIgGgCIgEgFQgCgDAAgEQAAgEACgDIAEgGQADgCAEgBQAEgCAEAAQAHAAAGADQAGACAEAEIgGAGQgDgEgFgCQgFgCgEAAQgFAAgEADQgEADABAFQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABIAEADIAGACIAGACIAHACIAGADIAEAFQACADAAAEIgBAHQgCADgDADIgHAEQgEACgHAAQgHAAgGgDg");
	this.shape_39.setTransform(187.35,11.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_40.setTransform(180.825,11.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AAMAXIAAgcQAAgGgDgDQgCgCgFAAIgDABIgEABIgDACIgCADIAAAgIgIAAIAAgtIAIAAIAAAIIACgEIAEgCIAEgCIAEAAQAPgBAAAQIAAAeg");
	this.shape_41.setTransform(176.8,12.15);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgHAXQgFgDgDgDQgDgCgCgFQgBgFAAgFQAAgEABgEQACgFADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAADIAAACIgkAAIACAHIADAFIAFADQADACADgBQAEAAADgBQAEgCADgDIADAFQgDADgFADQgEABgGAAQgEAAgEgBgAgFgQIgFAEIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgDgDgBQgDgBgEAAQgCAAgDABg");
	this.shape_42.setTransform(171.525,12.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AAYAXIAAgdQAAgFgCgCQgCgDgEAAQgEAAgDACQgEACgBADIAAAgIgHAAIAAgdQAAgFgBgCQgCgDgFAAQgDAAgEACQgDACgCADIAAAgIgHAAIAAgtIAHAAIAAAIIACgDIAEgDIAEgCIAFAAQAFgBADADQACADABADIADgDIADgDIAFgCIAFAAQAGAAADADQADAEAAAGIAAAgg");
	this.shape_43.setTransform(164.975,12.15);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_44.setTransform(159.775,11.625);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgKAXIAAgtIAHAAIAAAIIAGgGQAEgDAEABIAAAHIgDAAIgDABIgEABIgCACIgCADIAAAfg");
	this.shape_45.setTransform(157.025,12.15);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AgJAXQgEgDgDgDQgDgDgBgFQgCgEAAgFQAAgEACgEQABgFADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAIQACAEAAAEQAAAFgCAEIgEAIQgDADgFADQgEABgFAAQgEAAgFgBgAgGgPIgEAEIgDAFIgBAGIABAHIADAFIAEAFQADABADAAQAEAAACgBIAFgFIADgFIABgHIgBgGIgDgFIgFgEQgCgBgEgBQgDABgDABg");
	this.shape_46.setTransform(152.475,12.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AgJAXQgFgDgEgDIAFgFQABADAEACQAFABADAAQAGABACgDQAEgCAAgEQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAgBAAIgFgDIgGgCIgHgCIgFgDQgCgCAAgFIABgFQABgDACgBIAGgDIAGgBQAGAAAEACQAEACADACIgDAGQgCgDgEgCQgDgBgFAAQgEAAgCACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAIAFACIAGACIAHACIAFADQACADAAAEIgBAGQgBADgCABQgCACgEABIgIABQgFAAgEgBg");
	this.shape_47.setTransform(147.5,12.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("AgJAXQgFgDgEgDIAFgFQABADAFACQADABAFAAQAFABACgDQAEgCAAgEQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAgBAAIgFgDIgGgCIgHgCIgFgDQgCgCAAgFIABgFQABgDACgBIAGgDIAGgBQAGAAAEACQAEACADACIgEAGQgCgDgDgCQgEgBgEAAQgEAAgCACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQAAABABAAIAFACIAGACIAHACIAFADQADADAAAEIgCAGQgBADgDABQgCACgDABIgIABQgEAAgFgBg");
	this.shape_48.setTransform(143.1,12.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#333333").s().p("AAVAgIgFgOIgfAAIgFAOIgJAAIAZg/IAJAAIAZA/gAgMALIAZAAIgNghg");
	this.shape_49.setTransform(137.825,11.325);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#333333").s().p("AgJAXQgFgCgEgEIAFgFQACACADACQAFACADAAQAGAAACgCQADgCAAgDQAAgBAAgBQAAgBAAAAQAAgBgBAAQAAAAgBgBIgFgCIgGgCIgHgCIgFgDQgCgDAAgEIABgFQABgCADgCIAEgDIAHgBQAGAAAEACIAHAEIgDAFQgCgCgEgBQgEgCgEAAQgEAAgDACQgCACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAIAFACIAGABIAHADIAFADQADADgBAFIgBAEQgBADgCACQgCACgEABIgIABQgFAAgEgBg");
	this.shape_50.setTransform(94.2,27.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AAYAXIAAgeQAAgEgCgDQgCgCgEAAQgEAAgDACQgEACgBADIAAAgIgHAAIAAgeQAAgEgBgDQgCgCgFAAQgDAAgEACQgDACgCADIAAAgIgHAAIAAgtIAHAAIAAAHIACgCIAEgDIAEgCIAFgBQAFABADACQACACABAEIADgDIADgDIAFgCIAFgBQAGABADADQADADAAAIIAAAfg");
	this.shape_51.setTransform(88.175,27.75);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#333333").s().p("AgIAXQgDgBgCgBIgEgGQgBgDAAgDQAAgEABgCIAEgFIAFgCIAGgBQAEAAADACQAEABADACIAAgHQAAgFgDgCQgDgDgGAAQgHAAgGAGIgDgEQAHgIAKAAIAHABQAEAAACACIAEAGQABACAAAEIAAAfIgHAAIAAgFQgGAGgIAAIgGgBgAgIACQgDADAAAEQAAAEADADQADADAFAAQADAAAEgCIAFgDIAAgJIgFgFQgEAAgDAAQgFAAgDACg");
	this.shape_52.setTransform(81.725,27.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#333333").s().p("AgKAXIAAgtIAHAAIAAAIIAGgGQAEgCAEgBIAAAIIgDAAIgDAAIgEACIgCADIgCACIAAAfg");
	this.shape_53.setTransform(78.025,27.75);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("AgKAfQgEgBgEgEIAEgFQADADADACIAIABIAFgBIAFgCIADgEQACgDgBgEIAAgGQgCADgEACQgEADgEAAQgEAAgFgCQgDgBgDgEIgEgHQgBgDgBgGQABgFABgFQACgEACgDIAGgFQAFgCAEAAQADAAAEACQAFACACAEIAAgHIAIAAIAAAsQAAAGgCADQgCAEgEADIgHADIgHABQgFAAgFgCgAgEgYIgFADIgDAGIgBAHIABAHIADAFIAFADQACACADAAIAEgBIADgCIAEgCIACgDIAAgTIgCgDIgEgCIgDgCIgEAAIgFABg");
	this.shape_54.setTransform(73.35,28.675);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("AgJAXQgEgCgDgEQgDgDgBgFQgCgEAAgFQAAgEACgFQABgEADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAHQACAFAAAEQAAAFgCAEIgEAIQgDAEgFACQgEABgFAAQgEAAgFgBgAgGgPIgEADIgDAHIgBAFIABAHIADAGIAEADQADACADAAQAEAAACgCIAFgDIADgGIABgHIgBgFIgDgHIgFgDQgCgCgEAAQgDAAgDACg");
	this.shape_55.setTransform(68.025,27.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#333333").s().p("AgKAXIAAgtIAHAAIAAAIIAGgGQAEgCAEgBIAAAIIgDAAIgDAAIgEACIgCADIgCACIAAAfg");
	this.shape_56.setTransform(63.975,27.75);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#333333").s().p("AgVAgIAAg/IAYAAQAEAAAEACQAEABACADIAFAGIABAHIgBAIIgFAFQgCADgEABQgDACgFAAIgQAAIAAAZgAgNAAIAPAAQAFAAAEgDQADgDABgGQgBgFgDgDQgEgEgFAAIgPAAg");
	this.shape_57.setTransform(59.55,26.925);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#333333").s().p("AAYAXIAAgeQAAgEgCgDQgCgCgEAAQgEAAgDACQgEACgBADIAAAgIgHAAIAAgeQAAgEgBgDQgCgCgFAAQgDAAgEACQgDACgCADIAAAgIgHAAIAAgtIAHAAIAAAHIACgCIAEgDIAEgCIAFgBQAFABADACQACACABAEIADgDIADgDIAFgCIAFgBQAGABADADQADADAAAIIAAAfg");
	this.shape_58.setTransform(50.275,27.75);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#333333").s().p("AgJAXQgEgCgDgEQgDgDgBgFQgCgEAAgFQAAgEACgFQABgEADgDIAHgFQAFgCAEAAQAFAAAEACQAFACADADIAEAHQACAFAAAEQAAAFgCAEIgEAIQgDAEgFACQgEABgFAAQgEAAgFgBgAgGgPIgEADIgDAHIgBAFIABAHIADAGIAEADQADACADAAQAEAAACgCIAFgDIADgGIABgHIgBgFIgDgHIgFgDQgCgCgEAAQgDAAgDACg");
	this.shape_59.setTransform(43.725,27.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#333333").s().p("AgCAbQgDgDAAgFIAAgdIgHAAIAAgGIAHAAIAAgNIAGAAIAAANIAKAAIAAAGIgKAAIAAAcQAAAAAAABQAAAAABABQAAABAAAAQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIADgBIACgBIACAFIgDACIgGABQgEAAgCgDg");
	this.shape_60.setTransform(39.625,27.225);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#333333").s().p("AgJAXQgFgCgDgEIADgFQACACAEACQAFACADAAQAGAAADgCQACgCAAgDQAAgBAAgBQAAgBAAAAQAAgBgBAAQAAAAgBgBIgFgCIgGgCIgHgCIgFgDQgCgDAAgEIABgFQABgCADgCIAEgDIAHgBQAGAAAEACIAHAEIgEAFQgBgCgEgBQgDgCgFAAQgEAAgDACQgCACAAADQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAFACIAGABIAHADIAFADQACADAAAFIgBAEQgBADgDACQgBACgEABIgIABQgEAAgFgBg");
	this.shape_61.setTransform(35.95,27.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#333333").s().p("AgOAUQgEgEAAgHIAAggIAIAAIAAAeIAAAFIACADIAEACIADABQAEgBAEgCIAFgFIAAghIAHAAIAAAtIgHAAIAAgGQgCADgFACQgEACgEABQgHAAgEgEg");
	this.shape_62.setTransform(31.2,27.85);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#333333").s().p("AgIAfQgGgDgEgEQgEgEgDgHQgCgGAAgHQAAgGACgGQADgGAEgFQAEgEAGgCQAGgDAGAAIAIABIAHADIAFAEIAEAFIgGAEQgDgEgFgDQgEgDgGAAQgEAAgFACQgEACgDAEQgEADgBAFQgCAEAAAFQAAAGACAEQABAFAEAEQADADAEACQAFACAEAAQAGAAAEgDQAFgCADgEIAGADQgEAGgFADQgGAEgJAAQgGAAgGgCg");
	this.shape_63.setTransform(25.525,26.925);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#333333").s().p("AgJAWQgFgBgEgEIAFgFQABADAFACQADABAFAAQAFAAACgCQAEgCAAgEQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAgBAAIgFgDIgGgCIgHgCIgFgDQgCgCAAgFIABgFQABgDACgBIAGgDIAGgBQAGAAAEACQAEACADADIgEAFQgCgDgDgCQgEgBgEAAQgEAAgCACQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQAAABABAAIAFACIAGACIAHACIAFADQADADAAAEIgCAGQgBADgDABQgCACgDABIgIABQgEAAgFgCg");
	this.shape_64.setTransform(92.25,12.55);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#333333").s().p("AgHAWQgFgCgDgCQgDgDgCgFQgBgFAAgFQAAgEABgEQACgFADgDIAHgFQAEgCAEAAQAGAAAEACIAHAFIAEAIQABAFAAADIAAACIgkAAIACAHIADAEIAFAEQADABADAAQAEAAADgBQAEgCADgDIADAFQgDAEgFABQgEACgGAAQgEAAgEgCgAgFgQIgFAEIgDAFIgBAFIAdAAIgBgFQAAgDgCgCQgCgCgDgCQgDgBgEAAQgCAAgDABg");
	this.shape_65.setTransform(87.425,12.55);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#333333").s().p("AAYAXIAAgdQAAgFgCgCQgCgDgEAAQgEAAgDACQgEACgBADIAAAgIgHAAIAAgdQAAgFgBgCQgCgDgFAAQgDAAgEACQgDACgCADIAAAgIgHAAIAAgsIAHAAIAAAHIACgDIAEgDIAEgBIAFgBQAFgBADADQACADABADIADgDIADgDIAFgCIAFAAQAGgBADAEQADAEAAAGIAAAgg");
	this.shape_66.setTransform(80.875,12.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_67.setTransform(75.975,11.75);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#333333").s().p("AgDAgIAAg4IgUAAIAAgHIAvAAIAAAHIgUAAIAAA4g");
	this.shape_68.setTransform(72.2,11.675);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#333333").s().p("AgUAgIAAg+IAHAAIAAAHQACgEAEgCQAFgCADAAQAFAAADABQAFACACADQADADABAFQACAEAAAGQAAAFgCAEQgBAEgDADQgCAEgFABQgDACgFAAQgDAAgFgCQgEgCgCgEIAAAYgAgIgXQgEACgBADIAAAUQABADAEACQAEADAEAAQADAAADgCIAEgEIADgEIABgHIgBgHIgDgGIgEgEIgGgBQgEAAgEACg");
	this.shape_69.setTransform(64.5,13.375);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_70.setTransform(60.575,11.75);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#333333").s().p("AAMAgIAAgeIgBgFIgCgDQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAIgEgBIgDABIgEABIgDACIgDADIAAAhIgHAAIAAg/IAHAAIAAAZIADgDIAEgDIAEgCIAEAAQAIAAADADQAEAEAAAHIAAAgg");
	this.shape_71.setTransform(56.925,11.675);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#333333").s().p("AgNAeQgGgDgEgEIAFgGIAEADIAEADIAFACIAGABIAHgBIAEgDIADgDIAAgEQAAgDgBgCIgEgDIgGgDIgGgCIgHgCIgGgCIgFgFQgBgDAAgEQAAgEACgDIAFgGQACgCAEgBQAEgCAEAAQAHAAAGADQAFACAEAEIgEAGQgEgEgEgCQgGgCgEAAQgGAAgDADQgDADgBAFQAAAAABABQAAABAAAAQAAAAAAABQABAAAAABIAEADIAGACIAGACIAHACIAGADIAEAFQACADAAAEIgCAHQgBADgCADIgIAEQgEACgGAAQgIAAgGgDg");
	this.shape_72.setTransform(51.5,11.675);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#333333").s().p("AALAgIgPgVIgIAIIAAANIgHAAIAAg/IAHAAIAAApIAXgXIAJAAIgUAUIAUAZg");
	this.shape_73.setTransform(44.225,11.675);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#333333").s().p("AgFAWQgEgBgDgEQgDgDgCgFQgCgEAAgFQAAgEACgEQACgFADgDQADgEAEgBQAEgCAEAAQAGAAAEACQAEACADAEIgFAFQgCgEgDgBQgDgBgEAAIgFAAIgFAFQgCABgBAEIgBAGIABAHQABADACACIAFAFQACABADAAQAIAAAEgGIAFAEQgDADgEADQgEACgGAAQgEAAgEgCg");
	this.shape_74.setTransform(39.225,12.55);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#333333").s().p("AgDAfIAAgtIAHAAIAAAtgAgCgWQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_75.setTransform(35.725,11.75);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#333333").s().p("AgOAUQgEgDAAgIIAAgfIAHAAIAAAdIABAFIACADIAEACIADAAQAEAAADgCIAGgEIAAghIAHAAIAAAsIgHAAIAAgGQgDADgEADQgEABgEAAQgHAAgEgDg");
	this.shape_76.setTransform(32.05,12.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#333333").s().p("AARAbIgIAEIgJABQgGAAgGgDQgGgCgEgEQgEgFgCgGQgCgGAAgGQAAgHACgGQACgGAEgEQAEgFAGgCQAGgDAGAAQAHAAAGADQAGACAEAFQAEAEACAGQACAGAAAHQAAAGgCAGQgCAGgEAEIAGAHIgGAFgAgJgYQgEACgDAEQgDADgCAFQgBAFAAAFQAAAFABAEQACAFADADQADAEAEACQAFACAEAAQAHAAAFgDIgJgKIAGgFIAJAKIAEgIQABgFAAgEQAAgFgBgFIgFgIQgDgEgEgCQgFgCgFAAQgEAAgFACg");
	this.shape_77.setTransform(25.825,11.775);

	this.instance_1 = new lib._8AssortmentSelection();
	this.instance_1.parent = this;
	this.instance_1.setTransform(122.3,11.35,0.367,0.367,0,0,0,0.6,0);

	this.instance_2 = new lib._7CustomPrograms();
	this.instance_2.parent = this;
	this.instance_2.setTransform(6.5,27.85,0.367,0.367,0,0,0,0.4,-0.3);

	this.instance_3 = new lib._1flexibleShipping();
	this.instance_3.parent = this;
	this.instance_3.setTransform(7.05,11.9,0.367,0.367,0,0,0,0.1,0.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#575757").ss(1,1,1).p("A2YAAMAsxAAA");
	this.shape_78.setTransform(136.175,38.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_78},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.instance},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-8.1,4,289.1,35.3), null);


// stage content:
(lib._336x280_OmnichannelRetailers = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_770 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(770).call(this.frame_770).wait(131));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape.setTransform(167.9993,139.9994,1.12,1.12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_1.setTransform(168,140);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_2.setTransform(168,140);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_3.setTransform(168,140);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_4.setTransform(168,140);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_5.setTransform(168,140);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_6.setTransform(168,140);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A6rW1MAAAgtpMA1XAAAMAAAAtpg");
	this.shape_7.setTransform(168,140);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_8.setTransform(167.9993,139.9994,1.12,1.12);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(59).to({_off:false},0).wait(1).to({_off:true},1).wait(65).to({_off:false},0).wait(1).to({_off:true},1).wait(121).to({_off:false},0).wait(1).to({_off:true},1).wait(84).to({_off:false},0).wait(1).to({_off:true},1).wait(85).to({_off:false},0).wait(1).to({_off:true},1).wait(59).to({_off:false},0).wait(1).to({_off:true},1).wait(65).to({_off:false},0).to({_off:true},1).wait(53));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(119).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(82).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(83).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(54));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(117).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(80).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(81).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(55));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(115).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(78).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(79).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(56));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(113).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(76).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(77).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(57));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(111).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(74).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(58));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(109).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(72).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(73).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(59));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(107).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(70).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(71).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(60));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(43).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(105).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(68).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(69).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(43).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(61));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(167.95,17.9,0.7999,0.7999);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(720).to({_off:true},128).wait(53));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-137.8,-29.5,-71.9,8.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_9.setTransform(167.825,250.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-129.1,-26.5,-63.3,11.5).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_10.setTransform(167.825,250.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-120.5,-23.4,-54.6,14.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_11.setTransform(167.825,250.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-111.8,-20.4,-46,17.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_12.setTransform(167.825,250.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-103.2,-17.4,-37.3,20.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_13.setTransform(167.825,250.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-94.5,-14.4,-28.7,23.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_14.setTransform(167.825,250.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-85.8,-11.4,-20,26.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_15.setTransform(167.825,250.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-77.2,-8.4,-11.3,29.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_16.setTransform(167.825,250.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.5,-5.4,-2.7,32.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_17.setTransform(167.825,250.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-59.9,-2.4,6,35.6).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_18.setTransform(167.825,250.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-51.2,0.7,14.6,38.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_19.setTransform(167.825,250.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-42.6,3.7,23.3,41.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_20.setTransform(167.825,250.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-33.9,6.7,31.9,44.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_21.setTransform(167.825,250.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-25.3,9.7,40.5,47.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_22.setTransform(167.825,250.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-16.7,12.7,49.2,50.7).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_23.setTransform(167.825,250.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-8,15.8,57.8,53.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_24.setTransform(167.825,250.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,18.8,66.5,56.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_25.setTransform(167.825,250.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],9.3,21.8,75.1,59.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_26.setTransform(167.825,250.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],18,24.8,83.8,62.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_27.setTransform(167.825,250.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],26.6,27.8,92.5,65.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_28.setTransform(167.825,250.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],35.3,30.8,101.1,68.8).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_29.setTransform(167.825,250.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],43.9,33.9,109.8,71.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_30.setTransform(167.825,250.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],52.6,36.9,118.4,74.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_31.setTransform(167.825,250.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],61.2,39.9,127.1,77.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_32.setTransform(167.825,250.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],69.9,42.9,135.7,80.9).s().p("ApmCRQgkAAAAgkIAAjYQAAglAkAAITNAAQAkAAAAAlIAADYQAAAkgkAAg");
	this.shape_33.setTransform(167.825,250.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},37).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},399).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[]},362).wait(53));

	// Слой_8
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_34.setTransform(301.525,175.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgUApQgJgEgIgFIAKgRQADAEAFACIALAEQAGACAEAAQAHAAAEgDQADgCAAgEQAAgEgFgCIgMgDIgPgEQgHgDgFgEQgFgFgBgKQABgHAEgGQAEgGAHgDQAIgEAKgBQALAAAJAEQAJADAFAFIgJAQQgDgEgHgDQgGgDgJAAQgEAAgEADQgEACAAADQAAAEAFACIAMACIAPAFQAHACAGAFQAEAGAAAJQAAAIgDAHQgFAFgIAEQgJAEgMgBQgJABgLgEg");
	this.shape_35.setTransform(295,172.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgKQgGgLAAgNQAAgLAGgKQAFgKAKgHQAKgFAMgBQANABAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAGgKACQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_36.setTransform(286.025,172.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgKA7IAAh1IAVAAIAAB1g");
	this.shape_37.setTransform(278.975,171.075);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgXApQgGgCgFgHQgEgGAAgKQAAgKAEgGQAFgEAGgEQAHgCAHAAQAJAAAGACQAHAEAEAEIAAgLQAAgGgFgDQgFgEgIAAQgHAAgGACQgGADgFAFIgJgQQAIgHAJgDQAKgDAJgBQAKABAIADQAJACAFAIQAFAGAAAMIAAA2IgWAAIAAgJQgFAGgHACQgGADgIAAQgHAAgHgDgAgLAHQgFADAAAHQAAAGAFADQAEAEAHAAQAEAAAFgDQAFgBADgEIAAgKQgDgEgFgCQgFgCgEAAQgHAAgEADg");
	this.shape_38.setTransform(271.675,172.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgTApQgLgEgGgFIAKgRQACAEAGACIAKAEQAFACAFAAQAHAAADgDQAEgCAAgEQAAgEgFgCIgLgDIgQgEQgHgDgFgEQgFgFgBgKQAAgHAFgGQAEgGAHgDQAIgEAKgBQALAAAJAEQAIADAHAFIgJAQQgEgEgHgDQgGgDgJAAQgEAAgEADQgEACAAADQABAEAEACIAMACIAPAFQAHACAGAFQAEAGAAAJQAAAIgDAHQgFAFgJAEQgHAEgNgBQgJABgKgEg");
	this.shape_39.setTransform(262.85,172.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgKQgGgLAAgNQAAgLAGgKQAFgKAKgHQAKgFAMgBQANABAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAGgKACQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_40.setTransform(249.375,172.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgLAqIgihTIAYAAIAVA5IAWg5IAYAAIgiBTg");
	this.shape_41.setTransform(240.075,172.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgKA8IAAhUIAVAAIAABUgAgIglQgEgDAAgGQAAgGAEgEQADgDAFAAQAGAAADADQAEAEAAAGQAAAGgEADQgDAEgGAAQgFAAgDgEg");
	this.shape_42.setTransform(233.325,170.925);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_43.setTransform(228.375,172.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgYA3QgIgGgFgKQgFgKAAgOQAAgOAFgJQAFgJAIgGQAJgGALAAQAGABAHADQAHADAFAHIAAgsIAWAAIAAB0IgWAAIAAgKQgFAGgHADQgHAEgGgBQgLAAgJgEgAgNgCQgGAGAAALQAAALAGAHQAGAGAJAAQAFABAGgDQAFgDADgEIAAgeQgDgDgFgDQgGgCgFAAQgJgBgGAHg");
	this.shape_44.setTransform(219.375,171.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_45.setTransform(206.975,171.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgXApQgGgCgFgHQgEgGAAgKQAAgKAEgGQAFgEAGgEQAHgCAHAAQAJAAAGACQAHAEAEAEIAAgLQAAgGgFgDQgFgEgIAAQgHAAgGACQgGADgFAFIgJgQQAIgHAJgDQAKgDAJgBQAKABAIADQAJACAFAIQAFAGAAAMIAAA2IgWAAIAAgJQgFAGgHACQgGADgIAAQgHAAgHgDgAgLAHQgFADAAAHQAAAGAFADQAEAEAHAAQAEAAAFgDQAFgBADgEIAAgKQgDgEgFgCQgFgCgEAAQgHAAgEADg");
	this.shape_46.setTransform(198.975,172.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AARA7IAAg0QAAgIgDgDQgFgEgHABQgFAAgGADQgEADgEACIAAA6IgWAAIAAh1IAWAAIAAAsIAHgGIAKgFQAFgCAIAAQANAAAHAHQAHAHAAAMIAAA8g");
	this.shape_47.setTransform(189.35,171.075);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_48.setTransform(181.275,171.65);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgUApQgJgEgIgFIAKgRQADAEAFACIALAEQAGACAEAAQAHAAAEgDQADgCAAgEQAAgEgFgCIgMgDIgPgEQgHgDgFgEQgFgFgBgKQABgHAEgGQAEgGAHgDQAIgEAKgBQALAAAJAEQAJADAFAFIgJAQQgDgEgHgDQgGgDgJAAQgEAAgEADQgEACAAADQAAAEAFACIAMACIAPAFQAIACAFAFQAEAGAAAJQAAAIgDAHQgFAFgIAEQgJAEgMgBQgJABgLgEg");
	this.shape_49.setTransform(169.45,172.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAqArIAAg0QAAgGgDgEQgEgEgGABQgHAAgEADQgEACgDAEIAAA4IgWAAIAAg0QAAgGgCgEQgDgEgHABQgGAAgEADQgFACgCAEIAAA4IgXAAIAAhTIAXAAIAAALIAFgGQAFgDAFgCQAFgDAHAAQAJABAGAEQAFADACAIQADgEAEgEQAFgDAFgCQAHgDAGAAQAMAAAHAHQAGAGAAANIAAA8g");
	this.shape_50.setTransform(157.85,172.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgXApQgGgCgFgHQgEgGAAgKQAAgKAEgGQAFgEAGgEQAHgCAHAAQAJAAAGACQAHAEAEAEIAAgLQAAgGgFgDQgFgEgIAAQgHAAgGACQgGADgFAFIgJgQQAIgHAJgDQAKgDAJgBQAKABAIADQAJACAFAIQAFAGAAAMIAAA2IgWAAIAAgJQgFAGgHACQgGADgIAAQgHAAgHgDgAgLAHQgFADAAAHQAAAGAFADQAEAEAHAAQAEAAAFgDQAFgBADgEIAAgKQgDgEgFgCQgFgCgEAAQgHAAgEADg");
	this.shape_51.setTransform(145.325,172.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_52.setTransform(138.025,172.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgVA6QgJgDgIgHIAKgQQAFAFAHADQAGACAIAAQAFAAAFgBQAFgCAEgFQAEgFAAgIIAAgJQgFAHgHADQgHAEgHAAQgKAAgJgFQgIgFgFgKQgFgIAAgPQAAgNAFgKQAFgKAIgFQAJgFAKAAQAHAAAHADQAHAEAFAGIAAgLIAWAAIAABPQAAAMgEAHQgEAIgHAFQgHAEgIACQgIACgHAAQgLAAgIgDgAgNgiQgGAGAAALQAAAMAGAFQAGAGAJAAQAFAAAFgDQAGgDADgDIAAgbQgDgFgGgCQgFgDgFAAQgJAAgGAGg");
	this.shape_53.setTransform(129.025,174.325);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgFgKQgFgKgBgMQABgMAFgJQAFgKAKgHQAKgFANgBQAOABAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgEADgDAFQgDAGABAGQgBAGADAHQADAFAEAEQAFACAGAAQAHAAAFgCQAEgEADgFQADgHAAgGQAAgGgDgGQgDgFgEgDQgFgEgHABQgGgBgFAEg");
	this.shape_54.setTransform(119.05,172.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_55.setTransform(111.275,172.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgqA8IAAh1IAWAAIAAALQAFgGAHgDQAHgEAHAAQALAAAIAGQAIAFAGAKQAEAKAAAOQAAAOgEAJQgGAKgIAFQgIAFgLAAQgHAAgHgDQgHgDgFgHIAAAsgAgLgkQgFACgEAFIAAAdQAEAEAFADQAFACAFAAQAKAAAFgGQAGgGAAgLQAAgLgGgHQgFgHgKAAQgFAAgFADg");
	this.shape_56.setTransform(102.85,174.225);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgKQgGgLAAgNQAAgLAGgKQAFgKAKgHQAKgFAMgBQANABAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAGgKACQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_57.setTransform(88.025,172.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgDQAIgEAIgBIAAAXIgDgBIgDAAIgIABIgIADQgDACgBAEIAAA2g");
	this.shape_58.setTransform(80.425,172.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgFgKAAgMQAAgMAFgJQAGgKAKgHQAKgFANgBQAOABAKAFQAKAHAFAKQAGAJAAAMQAAAMgGAKQgFAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgEADgDAFQgDAGAAAGQAAAGADAHQADAFAEAEQAFACAGAAQAHAAAFgCQAFgEADgFQACgHAAgGQAAgGgCgGQgDgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_59.setTransform(71.75,172.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgHAxQgGgGAAgMIAAgrIgOAAIAAgTIAOAAIAAgXIAVAAIAAAXIARAAIAAATIgRAAIAAAmQAAAEACACQACADAEAAIAFAAIADgDIAEARQgCADgFACQgEABgHAAQgLAAgGgGg");
	this.shape_60.setTransform(63.725,171.65);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgUApQgJgEgHgFIAKgRQACAEAGACIAKAEQAGACAEAAQAHAAADgDQAEgCAAgEQAAgEgFgCIgLgDIgPgEQgIgDgFgEQgFgFAAgKQAAgHADgGQAFgGAIgDQAHgEALgBQAKAAAJAEQAIADAHAFIgJAQQgEgEgHgDQgHgDgHAAQgGAAgDADQgEACAAADQABAEAFACIALACIAPAFQAIACAEAFQAGAGAAAJQAAAIgFAHQgEAFgJAEQgIAEgLgBQgLABgKgEg");
	this.shape_61.setTransform(56.45,172.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgUAJIAAgSIApAAIAAASg");
	this.shape_62.setTransform(49.725,172.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AARArIAAgyQAAgJgEgDQgEgEgHABQgGAAgFADIgIAGIAAA4IgWAAIAAhTIAWAAIAAALIAIgHIAJgEQAFgCAHgBQAPAAAGAIQAHAHAAAMIAAA7g");
	this.shape_63.setTransform(42,172.6);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgMA7IAAh1IAYAAIAAB1g");
	this.shape_64.setTransform(34.5,171.075);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AARArIAAgyQAAgJgEgDQgEgEgHABQgGAAgFACIgIAHIAAA4IgWAAIAAhTIAWAAIAAAKIAHgGIAKgEQAFgCAHAAQAPgBAGAIQAHAHAAANIAAA6g");
	this.shape_65.setTransform(233.7,173.15);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgEQAIgDAIAAIAAAVIgDAAIgDAAIgIABIgIADQgDADgBACIAAA3g");
	this.shape_66.setTransform(221.425,173.15);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgLQgGgKAAgNQAAgLAGgLQAFgJAKgHQAKgFAMAAQANAAAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgCIAGgFIAKAPQgGAFgKADQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_67.setTransform(212.975,173.25);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgRA7IAAhAIgPAAIAAgTIAPAAIAAgEQAAgPAHgHQAIgJAMAAQAHAAAFACQAHADADAEIgIANIgEgDIgGAAQgEAAgDADQgDADAAAGIAAAEIARAAIAAATIgRAAIAABAg");
	this.shape_68.setTransform(205.75,171.55);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgRA7IAAhAIgPAAIAAgTIAPAAIAAgEQAAgPAIgHQAHgJAMAAQAHAAAFACQAHADADAEIgIANIgEgDIgGAAQgFAAgCADQgDADAAAGIAAAEIARAAIAAATIgRAAIAABAg");
	this.shape_69.setTransform(200,171.55);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgfA1QgNgIgIgOQgIgNAAgSQAAgRAIgOQAIgNANgIQAOgHARgBQASABAOAHQANAIAIANQAIAOAAARQAAASgIANQgIAOgNAIQgOAHgSAAQgRAAgOgHgAgSggQgIAEgEAJQgEAJgBAKQABALAEAJQAEAJAIAEQAIAGAKAAQALAAAIgGQAIgEAEgJQAFgJAAgLQAAgKgFgJQgEgJgIgEQgIgFgLgBQgKABgIAFg");
	this.shape_70.setTransform(189.825,171.65);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgQAnQgKgGgGgKQgGgKAAgNQAAgMAGgKQAGgKAKgGQAKgFAMAAQAJAAAGACQAHACAEADQAFAEACAEIgOAOQgDgFgFgDQgEgBgGAAQgJAAgHAGQgGAHAAAKQAAALAGAHQAHAGAJAAQAGABAEgDQAFgCADgFIAOAOQgCAEgFAEQgEADgHACQgGACgJAAQgMABgKgGg");
	this.shape_71.setTransform(168.325,173.25);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AggAlQgHgIAAgMIAAg7IAXAAIAAAyQAAAJAEAEQAEADAHgBQAGAAAFgCQAFgDADgEIAAg4IAWAAIAABTIgWAAIAAgKQgFAFgHAEQgHADgKAAQgOAAgHgGg");
	this.shape_72.setTransform(158.725,173.35);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgYA3QgIgGgFgKQgFgKAAgOQAAgOAFgJQAFgJAIgGQAJgGALABQAGAAAHADQAHADAFAGIAAgrIAWAAIAAB0IgWAAIAAgLQgFAHgHADQgHADgGAAQgLAAgJgEgAgNgCQgGAGAAALQAAALAGAHQAGAGAJAAQAFABAGgDQAFgDADgEIAAgeQgDgDgFgDQgGgDgFABQgJAAgGAGg");
	this.shape_73.setTransform(148.225,171.75);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgEgKgBgMQABgMAEgJQAGgKAKgHQAKgFANAAQAOAAAKAFQAKAHAFAKQAGAJAAAMQAAAMgGAKQgFAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgCAHgBAFQABAGACAHQACAFAFAEQAFACAGAAQAHAAAFgCQAFgEADgFQACgHAAgGQAAgFgCgHQgDgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_74.setTransform(138.25,173.25);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgEQAIgDAIAAIAAAVIgDAAIgDAAIgIABIgIADQgDADgBACIAAA3g");
	this.shape_75.setTransform(130.475,173.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AguA7IAAh1IA2AAQAMABAJAFQAJAFAFAIQAEAJAAAKQAAALgEAIQgFAIgJAFQgJAFgMAAIgdAAIAAAqgAgVgEIAZAAQAIAAAFgEQAEgEABgIQgBgHgEgEQgFgEgIgBIgZAAg");
	this.shape_76.setTransform(121.775,171.625);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgKA7IAAh1IAVAAIAAB1g");
	this.shape_77.setTransform(104.775,171.625);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AggAlQgHgIAAgMIAAg7IAXAAIAAAyQAAAJAEAEQAEADAHgBQAGAAAFgCQAFgDADgEIAAg4IAWAAIAABTIgWAAIAAgKQgFAFgHAEQgHADgKAAQgOAAgHgGg");
	this.shape_78.setTransform(97.425,173.35);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgpA7IAAh1IBSAAIAAAWIg5AAIAAAZIA4AAIAAAVIg4AAIAAAxg");
	this.shape_79.setTransform(87.6,171.625);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgYArIAAhTIAXAAIAAALQADgGAHgEQAIgDAIAAIAAAVIgDAAIgDAAIgIABIgIADQgDADgBACIAAA3g");
	this.shape_80.setTransform(259.175,155.6);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AggAlQgHgIAAgMIAAg7IAXAAIAAAyQAAAJAEAEQAEADAHgBQAGAAAFgCQAFgDADgEIAAg4IAWAAIAABTIgWAAIAAgKQgFAFgHADQgHAEgKAAQgOAAgHgGg");
	this.shape_81.setTransform(250.475,155.8);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgEgKgBgMQABgMAEgJQAGgKAKgHQAKgFANAAQAOAAAKAFQAKAHAGAKQAFAJAAAMQAAAMgFAKQgGAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgFADgCAFQgCAHgBAFQABAGACAHQACAFAFAEQAFACAGAAQAHAAAFgCQAEgEAEgFQACgHAAgGQAAgFgCgHQgEgFgEgDQgFgEgHABQgGgBgFAEg");
	this.shape_82.setTransform(240.3,155.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgXAnQgKgHgGgKQgFgKAAgMQAAgMAFgJQAGgKAKgHQAKgFANAAQAOAAAKAFQAKAHAFAKQAGAJAAAMQAAAMgGAKQgFAKgKAHQgKAFgOAAQgNAAgKgFgAgLgUQgEADgDAFQgDAHAAAFQAAAGADAHQADAFAEAEQAFACAGAAQAHAAAFgCQAFgEADgFQACgHAAgGQAAgFgCgHQgDgFgFgDQgFgEgHABQgGgBgFAEg");
	this.shape_83.setTransform(225.65,155.7);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgTApQgKgEgHgGIAJgQQAEADAEADIALAEQAFACAFAAQAHAAAEgDQADgCAAgEQAAgEgFgCIgMgDIgPgEQgHgDgFgEQgFgFgBgKQAAgHAFgGQAEgGAHgEQAIgDAKAAQALAAAJADQAJADAFAFIgJAQQgDgEgHgDQgGgDgJAAQgEAAgEADQgEACAAADQAAAEAFABIAMADIAPAFQAHACAGAFQAEAGAAAJQAAAJgDAFQgFAGgJAEQgHADgNAAQgKAAgJgDg");
	this.shape_84.setTransform(205.8,155.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgTApQgLgEgGgGIAKgQQACADAGADIAKAEQAGACAEAAQAHAAADgDQAEgCAAgEQAAgEgFgCIgLgDIgQgEQgHgDgFgEQgFgFgBgKQAAgHAEgGQAFgGAIgEQAHgDALAAQAKAAAJADQAIADAHAFIgJAQQgEgEgHgDQgHgDgHAAQgFAAgEADQgEACAAADQABAEAEABIAMADIAPAFQAHACAFAFQAGAGgBAJQAAAJgDAFQgFAGgJAEQgHADgMAAQgLAAgJgDg");
	this.shape_85.setTransform(197.4,155.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgLQgGgKAAgNQAAgLAGgLQAFgJAKgHQAKgFAMAAQANAAAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgDIAGgEIAKAPQgGAFgKADQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_86.setTransform(188.425,155.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgQAnQgKgGgGgKQgGgKAAgNQAAgMAGgKQAGgKAKgGQAKgFAMAAQAJAAAGACQAHACAEADQAFAEACAEIgOAOQgDgFgFgDQgEgBgGAAQgJAAgHAGQgGAHAAAKQAAALAGAHQAHAGAJAAQAGABAEgDQAFgCADgFIAOAOQgCAEgFAEQgEADgHACQgGACgJAAQgMABgKgGg");
	this.shape_87.setTransform(179.225,155.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgQAnQgKgGgGgKQgGgKAAgNQAAgMAGgKQAGgKAKgGQAKgFAMAAQAJAAAGACQAHACAEADQAFAEACAEIgOAOQgDgFgFgDQgEgBgGAAQgJAAgHAGQgGAHAAAKQAAALAGAHQAHAGAJAAQAGABAEgDQAFgCADgFIAOAOQgCAEgFAEQgEADgHACQgGACgJAAQgMABgKgGg");
	this.shape_88.setTransform(170.475,155.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AAgA7IgHgUIgxAAIgIAUIgcAAIAth1IAfAAIAtB1gAASARIgSgyIgRAyIAjAAg");
	this.shape_89.setTransform(159.975,154.075);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgYA3QgIgGgFgKQgFgKAAgOQAAgOAFgJQAFgJAIgGQAJgGALABQAGAAAHADQAHADAFAHIAAgsIAWAAIAAB0IgWAAIAAgLQgFAHgHADQgHADgGAAQgLAAgJgEgAgNgCQgGAGAAALQAAALAGAHQAGAGAJAAQAFABAGgDQAFgDADgEIAAgeQgDgDgFgDQgGgDgFABQgJAAgGAGg");
	this.shape_90.setTransform(143.975,154.2);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgLQgGgKAAgNQAAgLAGgLQAFgJAKgHQAKgFAMAAQANAAAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgDIAGgEIAKAPQgGAFgKADQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_91.setTransform(134.225,155.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgYA3QgIgGgFgKQgFgKAAgOQAAgOAFgJQAFgJAIgGQAJgGALABQAGAAAHADQAHADAFAHIAAgsIAWAAIAAB0IgWAAIAAgLQgFAHgHADQgHADgGAAQgLAAgJgEgAgNgCQgGAGAAALQAAALAGAHQAGAGAJAAQAFABAGgDQAFgDADgEIAAgeQgDgDgFgDQgGgDgFABQgJAAgGAGg");
	this.shape_92.setTransform(123.925,154.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AASArIAAgyQAAgJgFgDQgEgEgHABQgGAAgFACIgHAHIAAA4IgXAAIAAhTIAXAAIAAALIAGgHIAKgEQAFgCAHAAQAPgBAGAIQAHAHAAANIAAA6g");
	this.shape_93.setTransform(113.95,155.6);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgLQgGgKAAgNQAAgLAGgLQAFgJAKgHQAKgFAMAAQANAAAJAFQAKAHAFAKQAFAKAAANIAAAFIg+AAQABAIAHAGQAGAFAKAAIAIgBIAIgDIAGgEIAKAPQgGAFgKADQgJADgKAAQgMABgKgGgAAWgHQAAgEgDgEQgCgFgEgCQgFgDgHAAQgGAAgFADQgEACgCAFQgCAEgBAEIApAAIAAAAg");
	this.shape_94.setTransform(103.975,155.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AATAqIgTgcIgSAcIgZAAIAegqIgcgpIAYAAIARAaIARgaIAZAAIgcApIAeAqg");
	this.shape_95.setTransform(88.775,155.7);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgpA7IAAh1IBSAAIAAAWIg4AAIAAAZIA3AAIAAAVIg3AAIAAAbIA4AAIAAAWg");
	this.shape_96.setTransform(79.4,154.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60,p:{x:63.725,y:171.65}},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53,p:{x:129.025,y:174.325}},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48,p:{x:181.275,y:171.65}},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45,p:{x:206.975,y:171.65}},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:233.325,y:170.925}},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:278.975,y:171.075}},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34,p:{x:301.525,y:175.725}}]},123).to({state:[{t:this.shape_96},{t:this.shape_95},{t:this.shape_60,p:{x:96.175,y:154.65}},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_48,p:{x:217.625,y:154.65}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_37,p:{x:109.175,y:171.625}},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_45,p:{x:175.625,y:172.2}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_42,p:{x:226.375,y:171.475}},{t:this.shape_65},{t:this.shape_53,p:{x:243.675,y:174.875}},{t:this.shape_34,p:{x:251.325,y:176.275}}]},86).to({state:[]},87).to({state:[{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60,p:{x:63.725,y:171.65}},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53,p:{x:129.025,y:174.325}},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48,p:{x:181.275,y:171.65}},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45,p:{x:206.975,y:171.65}},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42,p:{x:233.325,y:170.925}},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:278.975,y:171.075}},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34,p:{x:301.525,y:175.725}}]},251).to({state:[{t:this.shape_96},{t:this.shape_95},{t:this.shape_60,p:{x:96.175,y:154.65}},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_48,p:{x:217.625,y:154.65}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_37,p:{x:109.175,y:171.625}},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_45,p:{x:175.625,y:172.2}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_42,p:{x:226.375,y:171.475}},{t:this.shape_65},{t:this.shape_53,p:{x:243.675,y:174.875}},{t:this.shape_34,p:{x:251.325,y:176.275}}]},86).to({state:[]},87).to({state:[]},128).wait(53));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.instance_2 = new lib.t122();
	this.instance_2.parent = this;
	this.instance_2.setTransform(168.05,168.95,1,1,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},296).to({state:[{t:this.instance_1}]},128).to({state:[{t:this.instance_2}]},296).to({state:[]},128).wait(53));

	// t11
	this.instance_3 = new lib.t11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(168,117.25,1,1,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(424).to({_off:true},424).wait(53));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(168,213.4,1,1,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(123).to({y:215.6},0).wait(301).to({y:213.4},0).wait(123).to({y:215.6},0).to({_off:true},301).wait(53));

	// Слой_5
	this.instance_5 = new lib.icons();
	this.instance_5.parent = this;
	this.instance_5.setTransform(168.8,170.55,1.12,1.12,0,0,0,136.4,18.6);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({alpha:1},6).to({_off:true},117).wait(301).to({_off:false,alpha:0},0).to({alpha:1},6).to({_off:true},117).wait(354));

	// Слой_14
	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("A6PJ+IAAz8MA0fAAAIAAT8g");
	this.shape_97.setTransform(168,216.35);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("A6PJ/IAAz8MA0fAAAIAAT8g");
	this.shape_98.setTransform(168,252.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_97}]}).to({state:[{t:this.shape_98}]},123).to({state:[{t:this.shape_97}]},301).to({state:[{t:this.shape_98}]},123).to({state:[]},301).wait(53));

	// Слой_3
	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgEIAHgNIAHAFIAIACIAHACQAGAAACgCQADgCAAgDQAAgDgEgCIgJgCIgLgDQgGgCgDgDQgEgEgBgIQAAgGAEgEQACgFAHgDQAFgDAIAAQAJABAGACQAGADAFADIgGANQgEgDgEgCQgGgCgGgBIgGACQgDACAAACQAAAEAEABIAJACIALADQAGACAEADQAEAFAAAHQAAAGgEAGQgDAEgGADQgHACgJABQgHgBgIgCg");
	this.shape_99.setTransform(291.05,175.9);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgFgHQgFgJAAgKQAAgIAFgJQAEgHAIgEQAHgGAJAAQAKABAIAEQAHAEAEAJQAFAIAAAJIAAAFIgxAAQACAGAEAEQAFAFAIgBIAFgBIAHgBIAFgEIAHAMQgEAEgIADQgHACgIAAQgIAAgJgFgAARgGIgCgFQgCgEgEgCQgDgCgGAAQgEAAgEACQgDACgBADQgCADgBADIAgAAIAAAAg");
	this.shape_100.setTransform(284.1,175.9);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgNAeQgHgFgFgHQgEgIAAgKQAAgJAEgIQAFgIAHgEQAIgEAKgBQAGAAAFACQAFACADADIAHAFIgMALQgDgDgDgDQgDgBgFAAQgHAAgFAFQgEAFgBAIQABAJAEAFQAFAFAHAAQAFAAADgBQADgCADgEIAMAKIgHAGIgIAFQgFABgGABQgKgBgIgEg");
	this.shape_101.setTransform(277,175.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_102.setTransform(269.55,175.825);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgDgFAAgHQAAgIADgFQAEgDAEgDQAGgCAFABQAHgBAFACQAFADADADIAAgIQAAgFgEgDQgDgCgHAAQgFAAgFABQgEACgEAEIgHgMQAGgGAIgCQAHgCAGgBQAIABAHACQAGACAEAFQAFAGAAAKIAAApIgSAAIAAgHQgDAEgGADQgEACgHAAQgFgBgGgCgAgJAGQgDADAAAEQAAAFADACQAEADAFAAQADAAAEgCQAEgBACgDIAAgIQgCgDgEgCQgEgBgDAAQgFAAgEADg");
	this.shape_103.setTransform(261.7,175.9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_104.setTransform(256.475,174.525);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_105.setTransform(253.025,174.65);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AghAuIAAhaIASAAIAAAJQADgFAGgDQAFgCAFAAQAJAAAGAEQAHAEADAIQAFAHAAALQAAALgFAHQgDAIgHAEQgGAEgJAAQgEAAgGgDQgFgCgEgFIAAAhgAgJgcQgDACgDAEIAAAWQACADAEACQAEACAFAAQAGAAAFgFQAEgEABgJQgBgIgEgFQgFgGgGAAQgFAAgEACg");
	this.shape_106.setTransform(247.55,177.075);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AggAuIAAhaIARAAIAAAJQAEgFAFgDQAFgCAFAAQAIAAAIAEQAGAEAEAIQADAHAAALQAAALgDAHQgEAIgGAEQgIAEgIAAQgFAAgFgDQgFgCgEgFIAAAhgAgIgcQgEACgDAEIAAAWQACADAFACQAEACAEAAQAHAAAEgFQAFgEgBgJQABgIgFgFQgEgGgHAAQgEAAgEACg");
	this.shape_107.setTransform(239.6,177.075);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AAZAtIgGgPIgmAAIgFAPIgWAAIAjhaIAXAAIAjBagAAOANIgOgmIgNAmIAbAAg");
	this.shape_108.setTransform(230.725,174.65);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgGQgEgFAAgJQAAgHADgFQACgFAFgEIAKgFIgFgKIgBgJQAAgGADgFQADgFAGgDQAGgDAIAAQAFAAAFACQAGACADAFQADAFAAAFQAAAHgDAFQgDAEgFADIgKAHIADADIAEAFIAIAKIAFgJIADgIIAOAGIgGALIgHAKIAJAJIAJAJIgWAAIgEgCIgDgFQgFAEgHADQgFACgHAAQgIAAgHgDgAgUALQgDADAAAFQAAAEACAEQACADADACQAEACADAAIAHgCIAGgDIgFgGIgFgGIgEgGIgFgGQgDADgCADgAgHgeQgDACAAAEIABAHIADAGQAGgDACgDQAEgEAAgFQAAgDgCgDQgCgCgDAAQgEABgCADg");
	this.shape_109.setTransform(218.275,174.65);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgFgHAAgLQAAgIAFgJQAEgHAIgEQAHgFAJgBQAKAAAIAFQAHAFAEAIQAFAIAAAJIAAAFIgxAAQACAGAEAEQAFAFAIAAIAFgCIAHgCIAFgDIAHALQgEAFgIADQgHABgIAAQgIAAgJgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgEACQgDACgBADQgCAEgBADIAgAAIAAAAg");
	this.shape_110.setTransform(302.1,162.25);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_111.setTransform(294.075,163.5063);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgRAgQgGgCgDgFQgEgFAAgHQAAgIAEgFQADgDAGgCQAFgDAGAAQAGAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgFAAgGACQgEACgEAEIgHgMQAGgGAHgCQAIgDAHAAQAHAAAHADQAGACAFAGQADAFAAAJIAAAqIgRAAIAAgHQgEAEgFADQgEABgGAAQgGABgFgDgAgIAGQgEADAAAEQAAAFAEADQADACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgDADg");
	this.shape_112.setTransform(286.4,162.25);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_113.setTransform(280.725,162.175);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgFAKgBQALABAIAFQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_114.setTransform(274.075,162.25);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQgBADACACQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIACgCIAEAOIgFADIgJABQgJAAgEgFg");
	this.shape_115.setTransform(267.8,161.425);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgVArQgJgEgHgGIALgQQAFAGAHADQAIAEAIAAQAIAAAEgDQAEgDAAgEQAAgEgEgCQgEgCgGgBIgLgEIgNgEQgGgDgEgEQgDgGgBgIQABgHAEgHQAEgHAIgDQAHgDAKgBQALAAAJAEQAJADAGAGIgKAOQgGgFgHgCQgHgCgGgBQgGABgDACQgEACAAAEQABAEADACQAEACAGABIALADQAHACAGADQAGADAEAFQADAEABAJQAAAJgEAGQgEAGgJAEQgIAEgMAAQgMAAgKgEg");
	this.shape_116.setTransform(261.325,161);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_117.setTransform(251.675,162.175);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgFAKgBQALABAIAFQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_118.setTransform(244.975,162.25);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgIAAgJQAAgJAEgHQAEgIAIgEQAIgFAKgBQALABAIAFQAHAEAFAIQAEAHAAAJQAAAJgEAIQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_119.setTransform(237.125,162.25);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgSAqQgHgEgDgIQgFgHAAgLQAAgLAFgHQADgHAHgFQAGgEAIAAQAFAAAGADQAFACAEAFIAAghIASAAIAABaIgSAAIAAgJQgEAFgFADQgFACgGAAQgIAAgGgEgAgKgBQgEAEgBAJQABAIAEAGQAFAFAGAAQAFAAADgCQAEgCADgEIAAgXQgDgCgEgCQgDgCgFAAQgGAAgFAFg");
	this.shape_120.setTransform(229,161.075);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQgBADACACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgFADIgKABQgIAAgEgFg");
	this.shape_121.setTransform(222.9,161.425);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgYAcQgGgFAAgKIAAguIARAAIAAAnQAAAHAEADQADADAGgBQADAAAFgCIAFgFIAAgsIASAAIAABBIgSAAIAAgIQgDAEgGADQgFADgHAAQgMAAgEgGg");
	this.shape_122.setTransform(216.65,162.325);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgYApQgKgGgGgLQgGgKAAgOQAAgNAGgKQAGgLAKgGQALgGANAAQAOAAALAGQALAGAGALQAFAKAAANQAAAOgFAKQgGALgLAGQgLAGgOAAQgNAAgLgGgAgOgZQgGAEgDAHQgDAHgBAHQABAJADAGQADAHAGAEQAGAEAIAAQAJAAAGgEQAGgEAEgHQADgGAAgJQAAgHgDgHQgEgHgGgEQgGgDgJgBQgIABgGADg");
	this.shape_123.setTransform(207.5,161);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AAOAiIAAgnQgBgHgDgDQgDgCgGAAQgDAAgFACQgEACgBADIAAAsIgSAAIAAhBIASAAIAAAIIAFgEIAHgEQAEgCAFAAQAMAAAEAGQAGAGAAAJIAAAug");
	this.shape_124.setTransform(127.6,176.925);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgJAEgHQAEgIAIgEQAIgFAKgBQALABAIAFQAHAEAFAIQAEAHAAAJQAAAKgEAHQgFAIgHAFQgIAEgLAAQgKAAgIgEgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAEQACAFAEACQAEADAEAAQAFAAAEgDQAEgCACgFQACgEAAgFQAAgEgCgFQgCgEgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_125.setTransform(119.725,177);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_126.setTransform(114.075,175.625);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQAAADACACQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgCIADAOIgFADIgJABQgJAAgEgFg");
	this.shape_127.setTransform(110,176.175);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgRAgQgFgCgEgFQgEgFAAgHQAAgIAEgFQAEgDAFgDQAFgCAFAAQAHAAAEACQAGADADADIAAgIQAAgFgEgDQgEgCgFAAQgGgBgEACQgFACgEAEIgHgMQAGgFAHgDQAIgDAGAAQAJAAAGADQAGACAFAFQADAGAAAJIAAAqIgRAAIAAgHQgDAEgGADQgEABgHAAQgFAAgFgCgAgIAGQgEADAAAEQAAAFAEACQADADAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_128.setTransform(103.8,177);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgaAhIAAgNIAdglIgdAAIAAgPIA1AAIAAANIgeAlIAeAAIAAAPg");
	this.shape_129.setTransform(97.05,177);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_130.setTransform(92.075,175.625);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AANAiIAAgnQAAgHgDgDQgDgCgFAAQgFAAgDACQgFACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAFAGQAGAGAAAJIAAAug");
	this.shape_131.setTransform(86.4,176.925);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgDgFAAgHQAAgIADgFQAEgDAEgDQAGgCAFAAQAHAAAFACQAFADADADIAAgIQAAgFgEgDQgDgCgHAAQgFgBgEACQgFACgEAEIgHgMQAGgFAIgDQAHgDAGAAQAIAAAHADQAGACAEAFQAFAGAAAJIAAAqIgSAAIAAgHQgDAEgGADQgEABgHAAQgFAAgGgCgAgJAGQgDADAAAEQAAAFADACQAEADAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgEADg");
	this.shape_132.setTransform(78.55,177);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_133.setTransform(70.825,178.2563);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_134.setTransform(64.875,176.925);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgXApQgLgGgGgLQgGgKgBgOQABgNAGgKQAGgLALgGQALgGANAAQANAAAKAGQAMAGAFALQAHAKgBANQABAOgHAKQgFALgMAGQgKAGgNAAQgNAAgLgGgAgOgZQgFAEgEAHQgEAHABAHQgBAIAEAIQAEAGAFAEQAHAEAIAAQAHAAAHgEQAGgEADgGQAEgIAAgIQAAgHgEgHQgDgHgGgEQgHgDgHAAQgIAAgHADg");
	this.shape_135.setTransform(56.9,175.75);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgGQgEgFAAgJQAAgHADgFQACgFAFgEIAKgEIgFgKIgBgKQAAgGADgFQADgFAGgDQAGgCAIgBQAFAAAFACQAGACADAFQADAFAAAFQAAAIgDAEQgDAEgFADIgKAGIADAFIAEAEIAIAJIAFgJIADgHIAOAGIgGAKIgHALIAJAJIAJAJIgWAAIgEgCIgDgEQgFAEgHACQgFACgHAAQgIAAgHgDgAgUALQgDAEAAAEQAAAFACADQACADADACQAEABADAAIAHgBIAGgDIgFgGIgFgGIgEgFIgFgHQgDADgCADgAgHgeQgDACAAAFIABAFIADAHQAGgDACgEQAEgCAAgGQAAgDgCgCQgCgCgDgBQgEABgCADg");
	this.shape_136.setTransform(43.925,175.75);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIAEIAIABQAGAAACgCQADgCAAgDQAAgDgEgBIgJgDIgLgDQgGgCgDgDQgFgEAAgIQAAgFAEgFQACgFAHgDQAFgCAIAAQAIAAAHACQAHADAEAEIgHAMQgCgDgGgDQgFgBgGgBIgHACQgCACAAADQAAACAEABIAJADIALADQAGACAEAEQAEAEAAAHQAAAGgEAFQgCAFgHADQgGACgKAAQgHAAgIgCg");
	this.shape_137.setTransform(133.8,163.35);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQgBADACACQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAIAEAAIACgCIAEAOIgFADIgJABQgJAAgEgFg");
	this.shape_138.setTransform(128.3,162.525);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgQAfQgIgFgEgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAHgEAKAAQAKgBAHAFQAHAEAEAJQAEAIABAKIAAADIgxAAQACAHAEAEQAFAEAHABIAHgBIAGgDIAFgDIAHALQgEAFgHACQgHACgIAAQgJAAgJgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_139.setTransform(122.25,163.35);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AANAiIAAgnQABgHgEgDQgDgCgFAAQgEAAgEACQgEACgDADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQALAAAFAGQAFAGAAAJIAAAug");
	this.shape_140.setTransform(114.5,163.275);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_141.setTransform(108.825,161.975);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgGAsQgFgDgEgFIAAAJIgRAAIAAhaIARAAIAAAhQAEgFAFgCQAFgDAFAAQAJAAAGAEQAHAFAEAHQAEAHAAALQAAALgEAHQgFAIgGAEQgHAEgIAAQgFAAgFgCgAgJgEQgEACgCACIAAAYQACADAEACQAFACAEAAQAGAAAFgFQAEgGAAgIQAAgJgEgEQgFgFgGAAQgEAAgFACg");
	this.shape_142.setTransform(103.3,162.175);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgDgFAAgHQAAgIADgEQAEgFAEgBQAGgCAFAAQAHAAAFACQAFABADAEIAAgIQAAgFgEgCQgDgEgHAAQgFAAgFADQgEABgEAEIgHgMQAGgFAIgDQAHgCAGAAQAIAAAHACQAGACAEAGQAFAFAAAJIAAAqIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAFQgDADAAAFQAAAFADADQAEACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgEACg");
	this.shape_143.setTransform(95.2,163.35);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgSApQgLgGgHgLQgGgKAAgOQAAgNAGgKQAHgLALgGQALgGAMAAQAKAAAIAEQAHACAFAGQAFAEADAHIgQAIQgDgGgGgEQgFgEgIAAQgHAAgGAEQgHAEgDAHQgEAGAAAIQAAAJAEAGQADAHAHAEQAGAEAHAAQAIAAAFgEQAGgDADgHIAQAIQgDAGgFAGQgFAFgHADQgIADgKAAQgMAAgLgGg");
	this.shape_144.setTransform(87.125,162.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgHQgEgIgBgLQABgJAEgHQAEgIAIgFQAHgEAKAAQAKgBAHAFQAHAEAEAJQAFAIAAAKIAAADIgxAAQABAHAFAEQAFAEAHABIAGgBIAHgDIAFgDIAHALQgFAFgGACQgIACgIAAQgJAAgIgDgAARgFIgCgHQgCgDgEgCQgDgCgFgBQgFABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_145.setTransform(75.1,163.35);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgBAvQgIAAgHgCQgHgDgGgFIAHgMQAEAEAFACQAGACAGAAQADAAAEgCQAEgBADgEQADgDAAgHIAAgGQgEAEgFADQgFADgFAAQgJAAgGgEQgHgEgDgHQgEgHAAgLQAAgKAEgIQADgHAHgEQAGgEAJAAQAFAAAFACQAFADAEAFIAAgJIARAAIAAA9QAAAJgDAGQgDAGgFAEQgFADgHACIgJABIgCAAgAgKgaQgEAFgBAIQABAJAEAEQAFAEAGAAQAFAAAEgCQAEgCACgCIAAgVQgCgEgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_146.setTransform(67.075,164.6063);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgSAgQgFgCgDgFQgDgFgBgHQABgIADgEQADgFAFgBQAGgCAGAAQAGAAAEACQAGABADAEIAAgIQAAgFgEgCQgDgEgHAAQgEAAgGADQgEABgEAEIgHgMQAGgFAHgDQAIgCAHAAQAHAAAHACQAGACAEAGQAFAFAAAJIAAAqIgSAAIAAgHQgDAEgGACQgEACgGAAQgGAAgGgCgAgJAFQgDADAAAFQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgEACg");
	this.shape_147.setTransform(59.4,163.35);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgSAiIAAhBIARAAIAAAJQADgFAFgDQAGgDAGAAIAAARIgCAAIgDAAIgGABIgGACIgDAEIAAArg");
	this.shape_148.setTransform(53.725,163.275);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgDgFAAgHQAAgIADgEQAEgFAEgBQAGgCAFAAQAHAAAFACQAFABADAEIAAgIQAAgFgEgCQgDgEgHAAQgFAAgFADQgEABgEAEIgHgMQAGgFAIgDQAHgCAGAAQAIAAAHACQAGACAEAGQAFAFAAAJIAAAqIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAFQgDADAAAFQAAAFADADQAEACAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgEACg");
	this.shape_149.setTransform(47.05,163.35);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgTApQgKgGgHgKQgGgLgBgOQABgOAGgKQAHgKAKgGQALgGANAAQAJAAAHADQAIACAFAGQAFAEADAGIgQAIQgDgFgFgDQgGgEgHAAQgHAAgHAEQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAHAGAEQAHAEAHAAQAGAAAFgCIAIgFIAAgLIgYAAIAAgQIAsAAIAAAiQgHAIgKAEQgKAFgMAAQgNAAgLgGg");
	this.shape_150.setTransform(38.575,162.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AANAiIAAgnQABgHgEgDQgDgCgFAAQgFAAgDACQgEACgDADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAGAGQAFAGAAAJIAAAug");
	this.shape_151.setTransform(286.85,175.825);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgJAAgJQAAgIAEgIQAEgIAIgEQAIgGAKAAQALAAAIAGQAHAEAFAIQAEAIAAAIQAAAJgEAJQgFAHgHAFQgIAEgLABQgKgBgIgEgAgIgQQgEADgCAFQgCAEAAAEQAAAFACAEQACAFAEADQAEACAEAAQAFAAAEgCQAEgDACgFQACgEAAgFQAAgEgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_152.setTransform(270.575,175.9);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgHQgEgJAAgJQAAgIAEgIQAEgIAIgEQAIgGAKAAQALAAAIAGQAHAEAFAIQAEAIAAAIQAAAJgEAJQgFAHgHAFQgIAEgLABQgKgBgIgEgAgIgQQgEADgCAFQgCAEAAAEQAAAFACAEQACAFAEADQAEACAEAAQAFAAAEgCQAEgDACgFQACgEAAgFQAAgEgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_153.setTransform(262.775,175.9);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgfAtIAAhaIA/AAIAAASIgsAAIAAASIArAAIAAARIgrAAIAAAlg");
	this.shape_154.setTransform(251.725,174.65);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgPAeQgJgEgEgHQgFgJABgKQgBgIAFgJQAEgHAIgEQAIgGAJAAQAJABAIAEQAHAEAFAJQADAIAAAJIAAAFIgvAAQABAGAEAEQAFAFAIgBIAGgBIAFgBIAGgEIAIAMQgGAEgHADQgHACgHAAQgKAAgHgFgAARgGIgCgFQgCgEgDgCQgEgCgFAAQgFAAgDACQgEACgCADQgBADAAADIAfAAIAAAAg");
	this.shape_155.setTransform(240.3,175.9);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_156.setTransform(234.775,174.65);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgJAtIAAhIIgaAAIAAgSIBHAAIAAASIgaAAIAABIg");
	this.shape_157.setTransform(225.625,174.65);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AALAtIgRgZIgIAJIAAAQIgRAAIAAhaIARAAIAAA2IAYgdIAVAAIgaAdIAbAkg");
	this.shape_158.setTransform(323.075,161);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AAOAiIAAgnQAAgHgEgDQgDgCgGAAQgEAAgEACQgDACgCADIAAAsIgSAAIAAhBIASAAIAAAIIAFgEIAHgEQAEgCAFAAQAMAAAFAGQAFAGAAAJIAAAug");
	this.shape_159.setTransform(315.05,162.175);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AgRAgQgFgCgEgFQgEgFAAgHQAAgIAEgFQAEgDAFgCQAFgDAFAAQAHAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgGAAgEACQgFACgEAEIgHgMQAGgGAHgCQAIgDAHAAQAIAAAGADQAGACAFAGQADAFAAAJIAAAqIgRAAIAAgHQgDAEgGADQgEABgHAAQgFABgFgDgAgIAGQgEADAAAEQAAAFAEADQADACAFAAQAEAAADgBQAEgCACgDIAAgIQgCgDgEgBQgDgCgEAAQgFAAgDADg");
	this.shape_160.setTransform(307.2,162.25);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgIAtIAAhaIARAAIAABag");
	this.shape_161.setTransform(301.975,161);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgkAtIAAhaIAqAAQAKAAAHAFQAHAEADAGQAEAHgBAIQABAIgEAGQgEAGgGAEQgHAEgKAAIgWAAIAAAggAgQgDIAUAAQAFAAAEgDQADgDABgGQgBgGgDgDQgEgDgFgBIgUAAg");
	this.shape_162.setTransform(296.25,161);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgFgHAAgLQAAgIAFgJQAEgHAIgEQAHgFAJgBQALAAAHAFQAHAFAEAIQAFAIAAAJIAAAFIgxAAQABAGAFAEQAFAFAHAAIAGgCIAHgCIAFgDIAHALQgFAFgGADQgIABgIAAQgJAAgIgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgEACQgDACgBADQgDAEAAADIAgAAIAAAAg");
	this.shape_163.setTransform(284.45,162.25);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIAQAAIAAASIAOAAIAAAQIgOAAIAAAcQABADABACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgJABQgIAAgEgFg");
	this.shape_164.setTransform(278.35,161.425);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AgPAgQgIgDgFgFIAIgMIAFAEIAIADIAIACQAGAAACgCQADgCAAgDQAAgDgEgCIgIgCIgMgDQgGgCgDgDQgFgEAAgHQAAgHAEgEQACgEAHgDQAFgDAIgBQAIAAAHADQAHACAEAEIgHANQgCgEgGgCQgFgCgGAAIgHACQgCACAAADQAAACAEABIAJADIALADQAGACAEADQAEAFAAAIQAAAGgEAEQgCAFgHADQgGADgKgBQgHABgIgDg");
	this.shape_165.setTransform(269.25,162.25);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AggAuIAAhaIARAAIAAAJQAEgFAFgDQAFgCAFAAQAIAAAIAEQAGAEADAIQAEAHAAALQAAALgEAHQgDAIgGAEQgIAEgIAAQgFAAgFgDQgFgCgEgFIAAAhgAgIgcQgEACgDAEIAAAWQACADAFACQAEACAEAAQAHAAAEgFQAFgEgBgJQABgIgFgFQgEgGgHAAQgEAAgEACg");
	this.shape_166.setTransform(254.45,163.425);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AAhAiIAAgpQAAgFgDgCQgCgDgFAAQgFAAgEACQgDACgCADIAAAsIgRAAIAAgpQABgFgDgCQgCgDgFAAQgFAAgEACQgDACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAEgEQADgCAFgCQAFgCAFAAQAGAAAEADQAFAEACAFIAFgGIAIgEQAEgCAFAAQAKAAAEAFQAFAFABAKIAAAvg");
	this.shape_167.setTransform(244.4,162.175);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgSApQgLgGgHgLQgGgKAAgOQAAgNAGgKQAHgLALgGQALgGAMAAQAKAAAIAEQAHADAFAEQAFAFADAHIgQAIQgDgGgGgEQgFgDgIgBQgHABgGADQgHAEgDAHQgEAGAAAIQAAAJAEAGQADAHAHAEQAGAEAHAAQAIAAAFgEQAGgDADgHIAQAIQgDAHgFAEQgFAGgHADQgIADgKAAQgMAAgLgGg");
	this.shape_168.setTransform(226.175,161);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgQAfQgHgFgFgIQgEgHgBgLQABgIAEgJQAEgHAIgEQAHgFAJgBQALAAAHAFQAHAFAEAIQAFAIAAAJIAAAFIgxAAQABAGAFAEQAFAFAHAAIAGgCIAHgCIAFgDIAHALQgFAFgGADQgHABgJAAQgJAAgIgDgAARgFIgCgGQgCgEgEgCQgDgCgGgBQgEABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_169.setTransform(214.15,162.25);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AANAiIAAgnQABgHgEgDQgDgCgFAAQgEAAgFACQgEACgCADIAAAsIgRAAIAAhBIARAAIAAAIIAGgEIAHgEQAEgCAGAAQAKAAAGAGQAFAGAAAJIAAAug");
	this.shape_170.setTransform(206.4,162.175);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AgFAmQgFgEAAgJIAAghIgLAAIAAgQIALAAIAAgSIARAAIAAASIANAAIAAAQIgNAAIAAAcQgBADACACQAAABABAAQAAABABAAQAAAAABAAQABAAABAAIADAAIACgCIAEAOIgGADIgIABQgJAAgEgFg");
	this.shape_171.setTransform(192.3,161.425);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AgXAuIgFgBIADgPIADABIACAAIAGgBIADgEIADgFIgbhCIATAAIAQAtIARgtIATAAIgfBMQgDAGgDADQgDAEgFABQgFABgFAAIgEAAg");
	this.shape_172.setTransform(112.05,178.325);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgQAfQgIgFgEgIQgEgIgBgKQABgIAEgJQAEgHAIgEQAHgFAKgBQAKAAAHAFQAHAFAEAIQAEAIABAJIAAAFIgxAAQACAGAEAEQAFAFAHgBIAHgBIAGgCIAFgDIAHAMQgEAEgHADQgHABgIAAQgJABgJgEgAARgGIgCgFQgCgEgDgCQgEgCgFAAQgFAAgDACQgEACgCADQgCADAAADIAgAAIAAAAg");
	this.shape_173.setTransform(95.25,177);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AgSAgQgEgCgEgFQgDgFAAgHQAAgIADgFQAEgDAEgDQAGgCAFAAQAHAAAFACQAFADADADIAAgIQAAgFgEgDQgDgCgHAAQgFgBgFACQgEACgEAEIgHgMQAGgFAIgDQAHgDAGAAQAIAAAHADQAGACAEAFQAFAGAAAJIAAAqIgSAAIAAgHQgDAEgGADQgEABgHAAQgFAAgGgCgAgJAGQgDADAAAEQAAAFADACQAEADAFAAQADAAAEgBQAEgCACgDIAAgIQgCgDgEgBQgEgCgDAAQgFAAgEADg");
	this.shape_174.setTransform(68.2,177);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AgSApQgLgGgHgLQgGgKAAgOQAAgNAGgKQAHgLALgGQALgGAMAAQAKAAAIADQAHAEAFAEQAFAGADAGIgQAHQgDgFgGgEQgFgDgIAAQgHAAgGADQgHAEgDAHQgEAGAAAIQAAAIAEAIQADAGAHAEQAGAEAHAAQAIAAAFgEQAGgEADgGIAQAIQgDAGgFAFQgFAFgHAEQgIADgKAAQgMAAgLgGg");
	this.shape_175.setTransform(60.125,175.75);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIAAgLQAAgJAEgHQAEgIAIgFQAIgEAJAAQAKgBAHAFQAHAEAFAJQADAIAAAKIAAADIgvAAQABAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgFAFgHACQgIACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgCAEABADIAfAAIAAAAg");
	this.shape_176.setTransform(131.6,163.35);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AAgAiIAAgpQABgFgDgCQgCgDgGAAQgEAAgEACQgEACgBADIAAAsIgQAAIAAgpQAAgFgDgCQgCgDgGAAQgEAAgDACQgEACgCADIAAAsIgSAAIAAhBIASAAIAAAIIAEgEQADgCAFgCQAEgCAFAAQAHAAAFADQAEAEABAFIAGgGIAIgEQAFgCAFAAQAJAAAEAFQAGAFAAAKIAAAvg");
	this.shape_177.setTransform(121.95,163.275);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("AgSAeQgIgFgEgIQgEgHAAgKQAAgIAEgIQAEgIAIgFQAIgEAKAAQALAAAIAEQAHAFAFAIQAEAIAAAIQAAAKgEAHQgFAIgHAFQgIAFgLgBQgKABgIgFgAgIgPQgEACgCAEQgCAFAAAEQAAAFACAFQACAEAEACQAEADAEAAQAFAAAEgDQAEgCACgEQACgFAAgFQAAgEgCgFQgCgEgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_178.setTransform(112.225,163.35);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AAWAuIAAgnIgqAAIAAAnIgUAAIAAhaIAUAAIAAAkIAqAAIAAgkIATAAIAABag");
	this.shape_179.setTransform(103.3,162.1);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AgaAsQgHgDgEgFQgEgHAAgIQAAgHADgFQACgFAFgDIAKgFIgFgKIgBgKQAAgGADgFQADgFAGgDQAGgCAIgBQAFAAAFADQAGACADAEQADAEAAAHQAAAGgDAFQgDAEgFAEIgKAFIADAFIAEAEIAIAJIAFgJIADgHIAOAFIgGALIgHALIAJAJIAJAKIgWAAIgEgEIgDgDQgFADgHADQgFACgHAAQgIAAgHgDgAgUALQgDAEAAAEQAAAFACADQACADADABQAEACADAAIAHgBIAGgDIgFgHIgFgEIgEgGIgFgHQgDADgCADgAgHgfQgDADAAAFIABAGIADAFQAGgCACgDQAEgEAAgEQAAgFgCgCQgCgBgDAAQgEAAgCACg");
	this.shape_180.setTransform(90.525,162.1);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AgPAfQgJgFgEgHQgEgIAAgLQAAgJAEgHQAEgIAIgFQAIgEAJAAQAKgBAHAFQAHAEAEAJQAEAIAAAKIAAADIgwAAQACAHAEAEQAFAEAHABIAHgBIAFgDIAGgDIAIALQgFAFgHACQgIACgHAAQgKAAgHgDgAARgFIgCgHQgCgDgDgCQgEgCgFgBQgFABgDACQgEACgCADQgCAEAAADIAgAAIAAAAg");
	this.shape_181.setTransform(70.85,163.35);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFFFFF").s().p("AANAuIAAgpQAAgFgCgDQgEgDgFABQgFgBgDADQgFACgCACIAAAtIgRAAIAAhaIARAAIAAAhIAGgEIAHgFQAEgBAGAAQAKAAAGAGQAFAFAAAKIAAAug");
	this.shape_182.setTransform(63.1,162.1);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AgNAeQgIgEgEgIQgFgIABgKQgBgJAFgIQAEgIAIgEQAIgFAKABQAGAAAFACQAFABAEACIAFAGIgLALQgDgEgDgBQgEgCgEAAQgHAAgFAFQgFAFAAAIQAAAJAFAFQAFAFAHAAQAEAAAEgCQADgBADgEIALAKIgFAHIgJAEQgFABgGAAQgKABgIgFg");
	this.shape_183.setTransform(55.85,163.35);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFFFFF").s().p("AgIAvIAAhBIARAAIAABBgAgGgcQgDgDAAgFQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgDADQgDADgEAAQgDAAgDgDg");
	this.shape_184.setTransform(45.975,161.975);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AAPAuIgbglIgHAJIAAAcIgTAAIAAhaIATAAIAAAoIAggoIAXAAIgkAqIAnAwg");
	this.shape_185.setTransform(40.4,162.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142,p:{x:103.3,y:162.175}},{t:this.shape_141,p:{x:108.825,y:161.975}},{t:this.shape_140,p:{x:114.5,y:163.275}},{t:this.shape_139},{t:this.shape_138,p:{x:128.3}},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130,p:{x:92.075,y:175.625}},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126,p:{x:114.075,y:175.625}},{t:this.shape_125},{t:this.shape_124,p:{x:127.6,y:176.925}},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119,p:{x:237.125}},{t:this.shape_118,p:{x:244.975}},{t:this.shape_117,p:{x:251.675,y:162.175}},{t:this.shape_116,p:{x:261.325}},{t:this.shape_115,p:{x:267.8,y:161.425}},{t:this.shape_114,p:{x:274.075}},{t:this.shape_113,p:{x:280.725,y:162.175}},{t:this.shape_112},{t:this.shape_111,p:{x:294.075,y:163.5063}},{t:this.shape_110},{t:this.shape_109,p:{x:218.275}},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105,p:{x:253.025}},{t:this.shape_104,p:{x:256.475}},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99}]},296).to({state:[{t:this.shape_185},{t:this.shape_184},{t:this.shape_138,p:{x:50}},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_124,p:{x:78.55,y:163.275}},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_142,p:{x:76.3,y:175.825}},{t:this.shape_141,p:{x:81.825,y:175.625}},{t:this.shape_140,p:{x:87.5,y:176.925}},{t:this.shape_173},{t:this.shape_115,p:{x:101.3,y:176.175}},{t:this.shape_117,p:{x:106.425,y:176.925}},{t:this.shape_172},{t:this.shape_116,p:{x:185.825}},{t:this.shape_171},{t:this.shape_119,p:{x:198.575}},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_118,p:{x:234.675}},{t:this.shape_167},{t:this.shape_166},{t:this.shape_114,p:{x:262.125}},{t:this.shape_165},{t:this.shape_130,p:{x:274.275,y:160.875}},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_109,p:{x:213.875}},{t:this.shape_157},{t:this.shape_126,p:{x:231.325,y:174.525}},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_105,p:{x:257.075}},{t:this.shape_153},{t:this.shape_152},{t:this.shape_113,p:{x:277.275,y:175.825}},{t:this.shape_104,p:{x:281.175}},{t:this.shape_151},{t:this.shape_111,p:{x:294.575,y:177.1563}}]},61).to({state:[]},67).to({state:[{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142,p:{x:103.3,y:162.175}},{t:this.shape_141,p:{x:108.825,y:161.975}},{t:this.shape_140,p:{x:114.5,y:163.275}},{t:this.shape_139},{t:this.shape_138,p:{x:128.3}},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130,p:{x:92.075,y:175.625}},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126,p:{x:114.075,y:175.625}},{t:this.shape_125},{t:this.shape_124,p:{x:127.6,y:176.925}},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119,p:{x:237.125}},{t:this.shape_118,p:{x:244.975}},{t:this.shape_117,p:{x:251.675,y:162.175}},{t:this.shape_116,p:{x:261.325}},{t:this.shape_115,p:{x:267.8,y:161.425}},{t:this.shape_114,p:{x:274.075}},{t:this.shape_113,p:{x:280.725,y:162.175}},{t:this.shape_112},{t:this.shape_111,p:{x:294.075,y:163.5063}},{t:this.shape_110},{t:this.shape_109,p:{x:218.275}},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105,p:{x:253.025}},{t:this.shape_104,p:{x:256.475}},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99}]},296).to({state:[{t:this.shape_185},{t:this.shape_184},{t:this.shape_138,p:{x:50}},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_124,p:{x:78.55,y:163.275}},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_142,p:{x:76.3,y:175.825}},{t:this.shape_141,p:{x:81.825,y:175.625}},{t:this.shape_140,p:{x:87.5,y:176.925}},{t:this.shape_173},{t:this.shape_115,p:{x:101.3,y:176.175}},{t:this.shape_117,p:{x:106.425,y:176.925}},{t:this.shape_172},{t:this.shape_116,p:{x:185.825}},{t:this.shape_171},{t:this.shape_119,p:{x:198.575}},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_118,p:{x:234.675}},{t:this.shape_167},{t:this.shape_166},{t:this.shape_114,p:{x:262.125}},{t:this.shape_165},{t:this.shape_130,p:{x:274.275,y:160.875}},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_109,p:{x:213.875}},{t:this.shape_157},{t:this.shape_126,p:{x:231.325,y:174.525}},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_105,p:{x:257.075}},{t:this.shape_153},{t:this.shape_152},{t:this.shape_113,p:{x:277.275,y:175.825}},{t:this.shape_104,p:{x:281.175}},{t:this.shape_151},{t:this.shape_111,p:{x:294.575,y:177.1563}}]},61).to({state:[]},67).wait(53));

	// Слой_12
	this.instance_6 = new lib.pc31_1("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(233.6,140,1,1,0,0,0,233.6,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(357).to({_off:false},0).to({_off:true},67).wait(357).to({_off:false},0).to({_off:true},67).wait(53));

	// Слой_4
	this.instance_7 = new lib.pc21_1("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(233.75,140.85,1.0033,1.0033,0,0,0,233.4,140.3);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(296).to({_off:false},0).to({_off:true},61).wait(363).to({_off:false},0).to({_off:true},61).wait(120));

	// Слой_2
	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,1],14,-21.3,14,30.2).s().p("A6dFQIAAqfMA07AAAIAAKfg");
	this.shape_186.setTransform(169.35,163.725);
	this.shape_186._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_186).wait(209).to({_off:false},0).wait(86).to({_off:true},1).wait(337).to({_off:false},0).wait(86).to({_off:true},1).wait(181));

	// Слой_9
	this.instance_8 = new lib.pc31();
	this.instance_8.parent = this;
	this.instance_8.setTransform(239.8,145.45,1.0097,1.0097,0,0,0,233.7,140.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(209).to({_off:false},0).to({y:63.55},86).to({_off:true},1).wait(337).to({_off:false,y:145.45},0).to({y:63.55},86).to({_off:true},1).wait(181));

	// Слой_7
	this.instance_9 = new lib.pc21();
	this.instance_9.parent = this;
	this.instance_9.setTransform(252.05,151.35,1.0803,1.0803,0,0,0,233.3,140.1);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(123).to({_off:false},0).to({x:225.1},86).to({_off:true},1).wait(337).to({_off:false,x:252.05},0).to({x:225.1},86).to({_off:true},1).wait(267));

	// pc11
	this.instance_10 = new lib.pc11();
	this.instance_10.parent = this;
	this.instance_10.setTransform(168.05,139.05,1,1,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1).to({regY:148,y:147},0).wait(1).to({y:146.95},0).wait(1).to({y:146.9},0).wait(1).to({y:146.85},0).wait(1).to({y:146.8},0).wait(1).to({y:146.7},0).wait(1).to({y:146.65},0).wait(1).to({y:146.6},0).wait(1).to({y:146.5},0).wait(1).to({y:146.45},0).wait(1).to({y:146.4},0).wait(1).to({y:146.35},0).wait(1).to({y:146.25},0).wait(1).to({y:146.2},0).wait(1).to({y:146.15},0).wait(1).to({y:146.05},0).wait(1).to({y:146},0).wait(1).to({y:145.9},0).wait(1).to({y:145.85},0).wait(1).to({y:145.8},0).wait(1).to({y:145.7},0).wait(1).to({y:145.65},0).wait(1).to({y:145.55},0).wait(1).to({y:145.5},0).wait(1).to({y:145.4},0).wait(1).to({y:145.35},0).wait(1).to({y:145.3},0).wait(1).to({y:145.2},0).wait(1).to({y:145.1},0).wait(1).to({y:145.05},0).wait(1).to({y:144.95},0).wait(1).to({y:144.9},0).wait(1).to({y:144.8},0).wait(1).to({y:144.75},0).wait(1).to({y:144.65},0).wait(1).to({y:144.6},0).wait(1).to({y:144.5},0).wait(1).to({y:144.4},0).wait(1).to({y:144.35},0).wait(1).to({y:144.25},0).wait(1).to({y:144.15},0).wait(1).to({y:144.1},0).wait(1).to({y:144},0).wait(1).to({y:143.9},0).wait(1).to({y:143.85},0).wait(1).to({y:143.75},0).wait(1).to({y:143.65},0).wait(1).to({y:143.55},0).wait(1).to({y:143.5},0).wait(1).to({y:143.4},0).wait(1).to({y:143.3},0).wait(1).to({y:143.2},0).wait(1).to({y:143.1},0).wait(1).to({y:143.05},0).wait(1).to({y:142.95},0).wait(1).to({y:142.85},0).wait(1).to({y:142.75},0).wait(1).to({y:142.65},0).wait(1).to({y:142.55},0).wait(1).to({y:142.5},0).wait(1).to({y:142.4},0).wait(1).to({y:142.3},0).wait(1).to({y:142.2},0).wait(1).to({y:142.1},0).wait(1).to({y:142},0).wait(1).to({y:141.9},0).wait(1).to({y:141.8},0).wait(1).to({y:141.7},0).wait(1).to({y:141.6},0).wait(1).to({y:141.5},0).wait(1).to({y:141.4},0).wait(1).to({y:141.3},0).wait(1).to({y:141.2},0).wait(1).to({y:141.1},0).wait(1).to({y:141},0).wait(1).to({y:140.9},0).wait(1).to({y:140.75},0).wait(1).to({y:140.65},0).wait(1).to({y:140.55},0).wait(1).to({y:140.45},0).wait(1).to({y:140.35},0).wait(1).to({y:140.25},0).wait(1).to({y:140.15},0).wait(1).to({y:140},0).wait(1).to({y:139.9},0).wait(1).to({y:139.8},0).wait(1).to({y:139.7},0).wait(1).to({y:139.6},0).wait(1).to({y:139.45},0).wait(1).to({y:139.35},0).wait(1).to({y:139.25},0).wait(1).to({y:139.15},0).wait(1).to({y:139},0).wait(1).to({y:138.9},0).wait(1).to({y:138.8},0).wait(1).to({y:138.65},0).wait(1).to({y:138.55},0).wait(1).to({y:138.45},0).wait(1).to({y:138.3},0).wait(1).to({y:138.2},0).wait(1).to({y:138.05},0).wait(1).to({y:137.95},0).wait(1).to({y:137.85},0).wait(1).to({y:137.7},0).wait(1).to({y:137.6},0).wait(1).to({y:137.45},0).wait(1).to({y:137.35},0).wait(1).to({y:137.2},0).wait(1).to({y:137.1},0).wait(1).to({y:136.95},0).wait(1).to({y:136.85},0).wait(1).to({y:136.7},0).wait(1).to({y:136.6},0).wait(1).to({y:136.45},0).wait(1).to({y:136.35},0).wait(1).to({y:136.2},0).wait(1).to({y:136.1},0).wait(1).to({y:135.95},0).wait(1).to({y:135.8},0).wait(1).to({y:135.7},0).wait(1).to({y:135.55},0).wait(1).to({regY:139.9,y:127.35},0).to({_off:true},1).wait(301).to({_off:false,regY:140,y:139.05},0).wait(1).to({regY:148,y:147},0).wait(1).to({y:146.95},0).wait(1).to({y:146.9},0).wait(1).to({y:146.85},0).wait(1).to({y:146.8},0).wait(1).to({y:146.7},0).wait(1).to({y:146.65},0).wait(1).to({y:146.6},0).wait(1).to({y:146.5},0).wait(1).to({y:146.45},0).wait(1).to({y:146.4},0).wait(1).to({y:146.35},0).wait(1).to({y:146.25},0).wait(1).to({y:146.2},0).wait(1).to({y:146.15},0).wait(1).to({y:146.05},0).wait(1).to({y:146},0).wait(1).to({y:145.9},0).wait(1).to({y:145.85},0).wait(1).to({y:145.8},0).wait(1).to({y:145.7},0).wait(1).to({y:145.65},0).wait(1).to({y:145.55},0).wait(1).to({y:145.5},0).wait(1).to({y:145.4},0).wait(1).to({y:145.35},0).wait(1).to({y:145.3},0).wait(1).to({y:145.2},0).wait(1).to({y:145.1},0).wait(1).to({y:145.05},0).wait(1).to({y:144.95},0).wait(1).to({y:144.9},0).wait(1).to({y:144.8},0).wait(1).to({y:144.75},0).wait(1).to({y:144.65},0).wait(1).to({y:144.6},0).wait(1).to({y:144.5},0).wait(1).to({y:144.4},0).wait(1).to({y:144.35},0).wait(1).to({y:144.25},0).wait(1).to({y:144.15},0).wait(1).to({y:144.1},0).wait(1).to({y:144},0).wait(1).to({y:143.9},0).wait(1).to({y:143.85},0).wait(1).to({y:143.75},0).wait(1).to({y:143.65},0).wait(1).to({y:143.55},0).wait(1).to({y:143.5},0).wait(1).to({y:143.4},0).wait(1).to({y:143.3},0).wait(1).to({y:143.2},0).wait(1).to({y:143.1},0).wait(1).to({y:143.05},0).wait(1).to({y:142.95},0).wait(1).to({y:142.85},0).wait(1).to({y:142.75},0).wait(1).to({y:142.65},0).wait(1).to({y:142.55},0).wait(1).to({y:142.5},0).wait(1).to({y:142.4},0).wait(1).to({y:142.3},0).wait(1).to({y:142.2},0).wait(1).to({y:142.1},0).wait(1).to({y:142},0).wait(1).to({y:141.9},0).wait(1).to({y:141.8},0).wait(1).to({y:141.7},0).wait(1).to({y:141.6},0).wait(1).to({y:141.5},0).wait(1).to({y:141.4},0).wait(1).to({y:141.3},0).wait(1).to({y:141.2},0).wait(1).to({y:141.1},0).wait(1).to({y:141},0).wait(1).to({y:140.9},0).wait(1).to({y:140.75},0).wait(1).to({y:140.65},0).wait(1).to({y:140.55},0).wait(1).to({y:140.45},0).wait(1).to({y:140.35},0).wait(1).to({y:140.25},0).wait(1).to({y:140.15},0).wait(1).to({y:140},0).wait(1).to({y:139.9},0).wait(1).to({y:139.8},0).wait(1).to({y:139.7},0).wait(1).to({y:139.6},0).wait(1).to({y:139.45},0).wait(1).to({y:139.35},0).wait(1).to({y:139.25},0).wait(1).to({y:139.15},0).wait(1).to({y:139},0).wait(1).to({y:138.9},0).wait(1).to({y:138.8},0).wait(1).to({y:138.65},0).wait(1).to({y:138.55},0).wait(1).to({y:138.45},0).wait(1).to({y:138.3},0).wait(1).to({y:138.2},0).wait(1).to({y:138.05},0).wait(1).to({y:137.95},0).wait(1).to({y:137.85},0).wait(1).to({y:137.7},0).wait(1).to({y:137.6},0).wait(1).to({y:137.45},0).wait(1).to({y:137.35},0).wait(1).to({y:137.2},0).wait(1).to({y:137.1},0).wait(1).to({y:136.95},0).wait(1).to({y:136.85},0).wait(1).to({y:136.7},0).wait(1).to({y:136.6},0).wait(1).to({y:136.45},0).wait(1).to({y:136.35},0).wait(1).to({y:136.2},0).wait(1).to({y:136.1},0).wait(1).to({y:135.95},0).wait(1).to({y:135.8},0).wait(1).to({y:135.7},0).wait(1).to({y:135.55},0).wait(1).to({regY:139.9,y:127.35},0).to({_off:true},1).wait(354));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,412.3,316.1);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/336x280_Omnichannel Retailers_atlas_P_.png", id:"336x280_Omnichannel Retailers_atlas_P_"},
		{src:"images/336x280_Omnichannel Retailers_atlas_NP_.jpg", id:"336x280_Omnichannel Retailers_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;