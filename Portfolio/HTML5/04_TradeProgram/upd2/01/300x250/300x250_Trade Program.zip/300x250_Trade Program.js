(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_Trade Program_atlas_P_", frames: [[0,0,98,28]]},
		{name:"300x250_Trade Program_atlas_NP_", frames: [[338,0,336,192],[676,0,336,192],[0,0,336,540],[338,194,336,192]]}
];


// symbols:



(lib.Растровоеизображение14 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение151 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение18 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.NewAgelogo = function() {
	this.initialize(ss["300x250_Trade Program_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.screen211 = function() {
	this.initialize(ss["300x250_Trade Program_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape.setTransform(214.1,71.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_1.setTransform(206,71.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_2.setTransform(200.375,69.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgNAjQgEgBgDgDQgEgDgCgEQgCgFAAgFQAAgHACgDQACgEAEgDQADgDAEgBIAJgCQAGABAGACQAGACAEAEIAAgLQAAgIgFgDQgFgFgHAAQgMAAgJAKIgFgHQALgMAQAAQAGAAAFABQAFACADADQAEADACAEQACAEAAAHIAAAvIgLAAIAAgIQgIAKgOAAIgJgCgAgMACQgFAFAAAHQAAAHAFAEQAEAEAIAAQAFAAAFgDQAFgCADgEIAAgNQgDgFgFgCQgFgBgFAAQgIABgEACg");
	this.shape_3.setTransform(194.725,71.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgFAjIgdhFIAMAAIAWA5IAXg5IAMAAIgdBFg");
	this.shape_4.setTransform(187.55,71.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgQAkIAAhFIAKAAIAAALQAFgGAFgDQAGgEAHAAIAAALIgFAAIgEABIgGACIgEAEIgEAEIAAAxg");
	this.shape_5.setTransform(178.25,71.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgDgHQgCgHAAgIQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAGAAQAJAAAGADQAGADAEAFQAFAFABAHQADAHAAAHIAAADIg4AAQABAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgIgZQgFACgDAEQgDADgBAFIgCAIIAtAAIgBgIQgBgFgDgDQgDgEgFgCQgEgCgGAAQgFAAgDACg");
	this.shape_6.setTransform(171.4,71.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_7.setTransform(163.75,71.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_8.setTransform(158.575,70.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgEAwIAAhfIAJAAIAABfg");
	this.shape_9.setTransform(155.325,69.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgMAiQgHgDgEgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAEACQAFACAFAAQAGAAAFgDQAGgCAEgEIAGAHQgGAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgCADgCAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgEAAgFACg");
	this.shape_10.setTransform(149.65,71.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_11.setTransform(141.175,70.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgNAiQgHgDgFgFQgEgFgCgGQgDgIAAgHQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAHAAQAIAAAHADQAGADAEAFQAFAFACAHQACAGAAAHQAAAHgCAIQgCAGgFAFQgEAFgGADQgHADgIAAQgHAAgGgDgAgJgYQgFACgDAEQgDAEgBAEQgBAFAAAFQAAAFABAFQABAFADAEQADADAFADQAEACAFAAQAFAAAFgCIAHgGQADgEACgFQABgFAAgFQAAgFgBgFQgCgEgDgEIgHgGQgFgCgFAAQgFAAgEACg");
	this.shape_12.setTransform(129.3,71.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAJAAIAAATIAPAAIAAAJIgPAAIAAArQABAEABACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_13.setTransform(123.05,70.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_14.setTransform(112.775,70.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAFgFQAEgFAHgDQAGgDAGAAQAJAAAFADQAHADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFABAEQACAEAEADQADAEAFACQAEACAFAAQAFAAAGgDQAGgCAEgEIAGAHQgGAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgEACgCAEQgEADgBAFIgBAIIAsAAIgBgIQgBgFgEgDQgCgEgEgCQgFgCgGAAQgFAAgEACg");
	this.shape_15.setTransform(104.75,71.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AASAkIAAgtQAAgJgEgDQgFgEgGAAIgGABIgGACIgEAEIgEAEIAAAyIgLAAIAAhFIALAAIAAAKIAFgEIAFgEIAHgDIAGgBQAXAAAAAXIAAAwg");
	this.shape_16.setTransform(96.65,71.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgPAwQgHgCgGgGIAFgIQAFAFAFACQAGACAHAAIAIgBIAHgEQADgCACgEQACgEAAgGIAAgKQgEAGgGADQgGAEgHAAQgHAAgFgDQgGgCgEgFQgEgFgDgGQgCgGAAgJQAAgIACgHQADgHAEgEQAEgFAGgCQAFgDAHAAQAGAAAGADQAHADAEAGIAAgKIALAAIAABDQAAAIgDAGQgDAGgFAEQgEADgGACQgGABgGAAQgJAAgGgCgAgIglQgEACgDADQgDAEgBAFQgCAFAAAFQAAAGACAFQABAEADADQADAEAEACQAFACAEAAIAGgBIAGgCIAFgEIAEgEIAAgeIgEgEIgFgEIgGgCIgGgBQgEAAgFACg");
	this.shape_17.setTransform(88.275,72.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_18.setTransform(82.675,70.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_19.setTransform(77.575,71.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgCgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_20.setTransform(70.25,71.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_21.setTransform(61.775,70.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_22.setTransform(50.575,71.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAJAAAGADQAGADAEAFQAEAFADAHQACAHAAAHIAAADIg3AAQAAAFACAEQACAEACADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgCgDQgDgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_23.setTransform(43.25,71.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_24.setTransform(35.675,71.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgEAvIAAhFIAKAAIAABFgAgEgiQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_25.setTransform(30.325,70.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgFAjIgdhFIALAAIAXA5IAXg5IAMAAIgdBFg");
	this.shape_26.setTransform(25.15,71.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgEAAIgGABIgFACIgEAEIgDAEIAAAxg");
	this.shape_27.setTransform(19.6,71.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgMAiQgGgDgFgFQgFgEgCgHQgDgHAAgIQAAgHADgGQACgHAEgFQAFgFAHgDQAGgDAGAAQAIAAAHADQAGADAEAFQAFAFACAHQACAHAAAHIAAADIg3AAQAAAFACAEQABAEADADQAEAEAEACQAFACAEAAQAHAAAFgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgGAAgHgDgAgJgZQgEACgDAEQgDADgBAFIgBAIIAsAAIgBgIQgCgFgDgDQgCgEgFgCQgEgCgGAAQgFAAgEACg");
	this.shape_28.setTransform(12.75,71.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_29.setTransform(5.175,71.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgXAwQgFgCgEgDQgEgDgDgFQgCgGAAgGQAAgGACgFQACgDADgEIAHgFIAIgFIgGgLQgCgFAAgFQAAgGACgDQACgFADgDQAEgDAEgCQAEgBAFAAIAIABIAHAEQADACACAEQACADAAAFQgBAFgCAEQgCAFgEACIgHAGIgJAFIAGAGIAFAHIAFAHIAHAGIAGgMIAEgKIAJAEIgGAMQgDAHgEAGIAJAIIAKAKIgPAAIgFgEIgGgGQgFAFgHAEQgGADgIAAQgHAAgGgCgAgZAKQgEAFAAAHQAAAEACAEQABAEADACQADACADABQAEACAEAAQAGAAAEgDQAFgDAEgEIgIgIIgFgGIgGgHIgGgJQgGAEgEAFgAgHgoIgFAEQgCABgBADIgBAGIACAIIAFAIIAGgEIAFgEIAFgGQABgCABgEQgBgFgDgDQgDgCgEgBIgFABg");
	this.shape_30.setTransform(-6.45,69.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgOAiQgIgDgFgGIAGgHQADAEAGADQAHADAGAAQAIAAAEgDQAEgEAAgFQAAgFgDgCIgIgDIgJgDQgGgBgFgCQgFgBgDgFQgDgDAAgHQAAgDACgFQABgDAEgDIAIgEQAFgCAFAAQAJAAAGADQAHADAEAEIgFAIQgDgEgGgDQgFgCgHAAQgGAAgEADQgEADAAAFQAAAEADACIAIADIAJADQAGABAFACQAFACADAEQADADAAAIQAAAEgCAEQgCAEgDADQgEACgFACQgFACgHAAQgHAAgHgDg");
	this.shape_31.setTransform(-18.375,71.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgEApQgDgFAAgHIAAgtIgMAAIAAgJIAMAAIAAgTIAKAAIAAATIANAAIAAAJIgNAAIAAArQgBAEACACQACADAEAAIAEgBIADgDIADAJIgFADQgDABgFABQgHgBgEgEg");
	this.shape_32.setTransform(-23.75,70.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AgJAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgIAEgEQAFgFAGgDQAHgDAHAAQAJAAAGADQAGAEAEAFIgHAHQgEgFgEgCQgEgCgGAAQgFAAgEACQgEACgEADQgDAEgBAFQgCAFAAAFQAAAGACAEQABAGADADQAEAEAEACQAEACAFAAQALAAAHgJIAHAHQgEAFgGAEQgGADgJAAQgHAAgHgDg");
	this.shape_33.setTransform(-29.375,71.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgWAfQgGgGAAgLIAAgxIALAAIAAAtIABAIQABADACACIAFACIAGABQAGAAAFgDQAGgEADgDIAAgzIALAAIAABFIgLAAIAAgKQgEAFgHAEQgGADgHAAQgLAAgFgFg");
	this.shape_34.setTransform(-37.1,71.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgNAuQgGgCgEgFQgEgEgDgHQgCgHAAgJQAAgIACgGQADgHAEgFQAEgEAGgDQAFgDAHAAQAGAAAHAEQAGADAEAGIAAglIALAAIAABfIgLAAIAAgKQgEAFgGAEQgGADgHAAQgHAAgFgDgAgIgMQgEACgDAEQgDADgBAFQgCAEAAAGQAAAGACAFQABAFADAEQADADAEACQAFACAEAAQAGAAAGgDQAGgDADgFIAAgfQgDgEgGgEQgGgDgGAAQgEAAgFACg");
	this.shape_35.setTransform(-45.475,70.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgOAiQgGgDgFgFQgEgFgDgGQgCgIAAgHQAAgHACgGQADgHAEgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAGADAFAFQAEAFACAHQACAGABAHQgBAHgCAIQgCAGgEAFQgFAFgGADQgHADgIAAQgHAAgHgDgAgJgYQgFACgDAEQgCAEgCAEQgCAFAAAFQAAAFACAFQACAFACAEQADADAFADQAFACAEAAQAFAAAFgCIAHgGQADgEABgFQACgFAAgFQAAgFgCgFQgBgEgDgEIgHgGQgFgCgFAAQgEAAgFACg");
	this.shape_36.setTransform(-53.6,71.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgQAkIAAhFIALAAIAAALQAEgGAFgDQAGgEAHAAIAAALIgFAAIgFABIgFACIgEAEIgDAEIAAAxg");
	this.shape_37.setTransform(-59.75,71.175);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgiAwIAAhfIAmAAQAIAAAFACQAGACADAEQAEAEADAFQABAGAAAGQAAAGgBAFQgDAFgEADQgDAEgGACQgFADgIAAIgZAAIAAAmgAgVAAIAYAAQAJAAAEgFQAGgFAAgIQAAgJgGgFQgEgFgJAAIgYAAg");
	this.shape_38.setTransform(-66.45,69.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t122, new cjs.Rectangle(-73.1,61.3,293.4,18.5), null);


(lib.t12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape.setTransform(231.475,70.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgIAgQgGgDgEgEQgFgFgCgGQgCgHAAgHQAAgGACgGQACgHAFgEQAEgFAGgCQAGgDAGAAQAJAAAGADQAFADAEAFIgHAGQgDgEgEgCQgEgCgFAAQgFAAgEACQgEACgDADQgDADgBAFQgCAFAAAEQAAAGACAEQABAFADADQADAEAEABQAEACAFAAQAKAAAGgIIAHAGQgEAFgFADQgGADgJAAQgGAAgGgCg");
	this.shape_1.setTransform(224.425,70.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AARAiIAAgqQAAgJgEgDQgEgDgHgBIgEABIgGADIgFADIgDAEIAAAvIgKAAIAAhBIAKAAIAAAJIAEgDIAGgEIAGgDIAGgBQAVABAAAVIAAAtg");
	this.shape_2.setTransform(217.225,70.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_3.setTransform(209.725,70.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgEAsIAAhAIAJAAIAABAgAgEgfQAAgBgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgDACgCQABgBAAAAQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACACAAADQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAABQgCACgDAAQAAAAAAgBQgBAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_4.setTransform(204.375,69.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAEgDQAGgDAHAAIAAAKIgEAAIgFABIgFACIgDADIgEAEIAAAtg");
	this.shape_5.setTransform(201,70.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_6.setTransform(194.625,70.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgeAuIAAhZIALAAIAAAKQADgFAGgEQAGgDAGAAQAGAAAFADQAGACAEAFQADAEACAGQADAHAAAIQAAAIgDAEQgCAHgDAEQgEAFgGACQgFACgGAAQgGAAgGgDQgGgCgDgGIAAAjgAgLghQgGAEgCAEIAAAcQACAFAGADQAFACAGAAQAEAAAEgCQAEgBACgDQADgEACgDIABgKIgBgLQgCgEgDgDQgCgEgEgCQgEgCgEAAQgGAAgFADg");
	this.shape_7.setTransform(187.175,71.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("AAUAhIgUgbIgTAbIgLAAIAZghIgYggIAMAAIARAZIASgZIAMAAIgYAgIAZAhg");
	this.shape_8.setTransform(179.825,70.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_9.setTransform(172.775,70.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AgEAtIAAhZIAJAAIAABZg");
	this.shape_10.setTransform(163.9,69.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AgEAtIAAhZIAJAAIAABZg");
	this.shape_11.setTransform(160.85,69.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AgMAhQgEgBgDgDQgDgDgCgEQgCgEAAgFQAAgGACgEQACgDADgCQADgDAEgBQAEgCAFAAQAFAAAGACQAFADAEADIAAgLQAAgGgFgEQgEgDgHAAQgLAAgIAJIgFgHQAKgLAPAAQAFAAAFABQAEABAEADQADADACAEQACAEAAAGIAAAsIgKAAIAAgIQgIAJgMAAIgJgBgAgLADQgFAEAAAGQAAAGAFAEQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgMQgDgEgFgCQgEgBgFAAQgHAAgEADg");
	this.shape_12.setTransform(155.575,70.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAEgDQAGgDAHAAIAAAKIgEAAIgFABIgFACIgDADIgEAEIAAAtg");
	this.shape_13.setTransform(150.35,70.625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_14.setTransform(143.975,70.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AgFAhIgbhBIAMAAIAUA1IAVg1IAMAAIgbBBg");
	this.shape_15.setTransform(136.85,70.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("AgNAgQgGgDgEgFQgEgEgCgHQgCgGAAgHQAAgGACgGQACgHAEgEQAEgFAGgCQAGgDAHAAQAHAAAGADQAGACAEAFQAFAEACAHQACAGAAAGQAAAHgCAGQgCAHgFAEQgEAFgGADQgGACgHAAQgHAAgGgCgAgIgWQgFACgCAEQgDADgBAFQgCAEAAAEQAAAFACAFQABAEADAEQACADAFACQAEACAEAAQAFAAAEgCQAEgCADgDQADgEABgEIABgKIgBgIQgBgFgDgDQgDgEgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_16.setTransform(129.725,70.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAFgDQAFgDAHAAIAAAKIgEAAIgFABIgFACIgEADIgDAEIAAAtg");
	this.shape_17.setTransform(120.5,70.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_18.setTransform(114.125,70.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AgEAmQgDgEAAgHIAAgqIgLAAIAAgIIALAAIAAgSIAJAAIAAASIANAAIAAAIIgNAAIAAAoQAAAEACACQABACAEAAIAEAAIADgCIADAHIgFADIgIABQgGAAgEgEg");
	this.shape_19.setTransform(108.375,69.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgEAmQgDgEAAgHIAAgqIgLAAIAAgIIALAAIAAgSIAJAAIAAASIANAAIAAAIIgNAAIAAAoQAAAEACACQABACAEAAIAEAAIADgCIADAHIgFADIgIABQgGAAgEgEg");
	this.shape_20.setTransform(104.425,69.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_21.setTransform(98.625,70.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AgKArQgGgDgDgFIAAAJIgLAAIAAhZIALAAIAAAjQADgGAGgDQAGgDAGAAQAGAAAFADQAGACADAFQAEAEACAHQADAFAAAIQAAAIgDAGQgCAGgEAFQgDAEgGADQgFACgGAAQgGAAgGgDgAgLgJQgGADgCAEIAAAdQACAEAGADQAFADAGAAQAEAAAEgCQAEgCACgDQADgEACgEQABgFAAgFQAAgGgBgEQgCgEgDgDQgCgEgEgCQgEgCgEAAQgGAAgFAEg");
	this.shape_22.setTransform(91.125,69.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgMAhQgEgBgDgDQgDgDgCgEQgCgEAAgFQAAgGACgEQACgDADgCQADgDAEgBQAEgCAFAAQAFAAAGACQAFADAEADIAAgLQAAgGgFgEQgEgDgHAAQgLAAgIAJIgFgHQAKgLAPAAQAFAAAFABQAEABAEADQADADACAEQACAEAAAGIAAAsIgKAAIAAgIQgIAJgMAAIgJgBgAgLADQgFAEAAAGQAAAGAFAEQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgMQgDgEgFgCQgEgBgFAAQgHAAgEADg");
	this.shape_23.setTransform(79.775,70.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAEgDQAGgDAHAAIAAAKIgEAAIgFABIgFACIgDADIgEAEIAAAtg");
	this.shape_24.setTransform(71.05,70.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AgNAgQgGgDgEgFQgEgEgCgHQgCgGAAgHQAAgGACgGQACgHAEgEQAEgFAGgCQAGgDAHAAQAHAAAGADQAGACAEAFQAFAEACAHQACAGAAAGQAAAHgCAGQgCAHgFAEQgEAFgGADQgGACgHAAQgHAAgGgCgAgIgWQgFACgCAEQgDADgBAFQgCAEAAAEQAAAFACAFQABAEADAEQACADAFACQAEACAEAAQAFAAAEgCQAEgCADgDQADgEABgEIABgKIgBgIQgBgFgDgDQgDgEgEgCQgEgCgFAAQgEAAgEACg");
	this.shape_25.setTransform(64.625,70.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgKAuIAAg4IgLAAIAAgIIALAAIAAgFQAAgLAFgFQAFgGAIAAIAHABQAEABADADIgEAHIgEgCIgEgBQgFAAgDADQgCADAAAHIAAAFIANAAIAAAIIgNAAIAAA4g");
	this.shape_26.setTransform(59.275,69.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgeAuIAAhZIALAAIAAAKQADgFAGgEQAGgDAGAAQAGAAAFADQAGACAEAFQADAEACAGQADAHAAAIQAAAIgDAEQgCAHgDAEQgEAFgGACQgFACgGAAQgGAAgGgDQgGgCgDgGIAAAjgAgLghQgGAEgCAEIAAAcQACAFAGADQAFACAGAAQAEAAAEgCQAEgBACgDQADgEACgDIABgKIgBgLQgCgEgDgDQgCgEgEgCQgEgCgEAAQgGAAgFADg");
	this.shape_27.setTransform(49.775,71.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgEAsIAAhAIAJAAIAABAgAgEgfQAAgBgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgDACgCQABgBAAAAQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACACAAADQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAABQgCACgDAAQAAAAAAgBQgBAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_28.setTransform(44.175,69.55);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AARAtIAAgrQAAgDgBgDQgBgDgCgCQgCgCgDAAIgGgBIgEABIgGACIgEADIgEAFIAAAuIgKAAIAAhZIAKAAIAAAiIAEgDIAGgFIAGgCIAGgBQALAAAFAFQAFAFAAALIAAAtg");
	this.shape_29.setTransform(38.925,69.45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgNAgQgHgDgFgFIAFgHQADAEAGACQAGADAGAAQAHAAAEgDQAEgDAAgFQAAgEgDgCIgIgEIgIgCIgKgDQgFgBgDgEQgCgDAAgGQAAgEABgEIAFgGQADgCAEgCQAFgBAFAAQAJAAAFADQAGACAEAEIgEAHQgEgDgEgCQgGgDgGAAQgFAAgFADQgDADAAAEQAAAEACACIAIADIAJACIAJAEQAFABADAEQADADAAAHQAAAEgCADQgBAEgDADIgIAEQgGABgFAAQgIAAgGgCg");
	this.shape_30.setTransform(31.95,70.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAEgDQAGgDAHAAIAAAKIgEAAIgFABIgFACIgDADIgEAEIAAAtg");
	this.shape_31.setTransform(27.05,70.625);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_32.setTransform(20.675,70.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("AARAiIAAgqQAAgJgEgDQgEgDgHgBIgEABIgGADIgFADIgDAEIAAAvIgKAAIAAhBIAKAAIAAAJIAEgDIAGgEIAGgDIAGgBQAVABAAAVIAAAtg");
	this.shape_33.setTransform(13.125,70.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AgEAmQgDgEAAgHIAAgqIgLAAIAAgIIALAAIAAgSIAJAAIAAASIANAAIAAAIIgNAAIAAAoQAAAEACACQABACAEAAIAEAAIADgCIADAHIgFADIgIABQgGAAgEgEg");
	this.shape_34.setTransform(7.475,69.875);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAFgDQAFgDAHAAIAAAKIgEAAIgFABIgFACIgEADIgDAEIAAAtg");
	this.shape_35.setTransform(3.6,70.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AgMAhQgEgBgDgDQgDgDgCgEQgCgEAAgFQAAgGACgEQACgDADgCQADgDAEgBQAEgCAFAAQAFAAAGACQAFADAEADIAAgLQAAgGgFgEQgEgDgHAAQgLAAgIAJIgFgHQAKgLAPAAQAFAAAFABQAEABAEADQADADACAEQACAEAAAGIAAAsIgKAAIAAgIQgIAJgMAAIgJgBgAgLADQgFAEAAAGQAAAGAFAEQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgMQgDgEgFgCQgEgBgFAAQgHAAgEADg");
	this.shape_36.setTransform(-2.775,70.675);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AgeAuIAAhZIALAAIAAAKQADgFAGgEQAGgDAGAAQAGAAAFADQAGACAEAFQADAEACAGQADAHAAAIQAAAIgDAEQgCAHgDAEQgEAFgGACQgFACgGAAQgGAAgGgDQgGgCgDgGIAAAjgAgLghQgGAEgCAEIAAAcQACAFAGADQAFACAGAAQAEAAAEgCQAEgBACgDQADgEACgDIABgKIgBgLQgCgEgDgDQgCgEgEgCQgEgCgEAAQgGAAgFADg");
	this.shape_37.setTransform(-9.775,71.85);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AgNAsQgEgDgFgEQgDgFgCgGQgDgGAAgIQAAgIADgFQACgHADgEQAEgFAFgCQAGgDAHAAQAFAAAGADQAFADAEAGIAAgjIAKAAIAABZIgKAAIAAgJQgDAFgGADQgGADgFAAQgHAAgGgCgAgHgLQgEACgDAEQgCADgBAEQgCAEAAAGQAAAFACAFQABAEACAEQADADAEACQAEACAEAAQAGAAAFgDQAGgDACgEIAAgdQgCgEgGgDQgFgEgGAAQgEAAgEACg");
	this.shape_38.setTransform(-21.4,69.525);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_39.setTransform(-28.875,70.675);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AARAiIAAgqQAAgJgEgDQgEgDgHgBIgEABIgGADIgFADIgDAEIAAAvIgKAAIAAhBIAKAAIAAAJIAEgDIAGgEIAGgDIAGgBQAVABAAAVIAAAtg");
	this.shape_40.setTransform(-36.425,70.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AgEAsIAAhAIAJAAIAABAgAgEgfQAAgBgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgDACgCQABgBAAAAQABAAAAAAQABgBABAAQAAAAAAAAQADAAACACQACACAAADQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAABQgCACgDAAQAAAAAAgBQgBAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_41.setTransform(-41.675,69.55);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AgEAtIAAhZIAJAAIAABZg");
	this.shape_42.setTransform(-44.75,69.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AAjAiIAAgsQAAgGgDgDQgEgFgFAAQgGAAgFAEQgFADgCADIAAAwIgJAAIAAgsQAAgGgDgDQgDgFgGAAQgFABgFADQgFADgDAEIAAAvIgKAAIAAhBIAKAAIAAAJIAEgDIAEgDIAHgDQADgBAEgBQAIABAEADQADADACAGIADgFIAFgDIAGgEIAHgBQAJAAAFAGQAEAFAAAJIAAAvg");
	this.shape_43.setTransform(-51.7,70.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgMAhQgEgBgDgDQgDgDgCgEQgCgEAAgFQAAgGACgEQACgDADgCQADgDAEgBQAEgCAFAAQAFAAAGACQAFADAEADIAAgLQAAgGgFgEQgEgDgHAAQgLAAgIAJIgFgHQAKgLAPAAQAFAAAFABQAEABAEADQADADACAEQACAEAAAGIAAAsIgKAAIAAgIQgIAJgMAAIgJgBgAgLADQgFAEAAAGQAAAGAFAEQAEAEAHAAQAFAAAEgCQAFgCADgEIAAgMQgDgEgFgCQgEgBgFAAQgHAAgEADg");
	this.shape_44.setTransform(-60.925,70.675);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("AgLAgQgGgDgFgEQgEgFgCgGQgDgGAAgIQAAgGADgGQACgHAEgEQAEgFAGgCQAGgDAGAAQAIAAAFADQAGACAEAFQAEAFACAGQADAHAAAGIAAACIg0AAIACAJIAFAHIAHAFQAEACAEAAQAGAAAFgCQAFgCAEgEIAFAGQgFAFgGADQgHACgIAAQgGAAgGgCgAgIgXQgEACgDADIgEAHIgBAIIAqAAQAAgEgCgDIgEgHQgCgEgEgCQgEgCgGAAQgEAAgEACg");
	this.shape_45.setTransform(-68.075,70.675);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AgPAhIAAhAIAKAAIAAALQAEgGAEgDQAGgDAHAAIAAAKIgEAAIgFABIgFACIgDADIgEAEIAAAtg");
	this.shape_46.setTransform(-73.75,70.625);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AgEAmQgDgEAAgHIAAgqIgLAAIAAgIIALAAIAAgSIAJAAIAAASIANAAIAAAIIgNAAIAAAoQAAAEACACQABACAEAAIAEAAIADgCIADAHIgFADIgIABQgGAAgEgEg");
	this.shape_47.setTransform(-78.275,69.875);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("AgSArQgJgEgGgGIAHgJIAFAEIAGAFIAIACIAIABQAGABAEgCQAFgCACgBIADgGIABgFQAAgEgCgDIgGgFIgJgDIgJgDIgJgDQgFAAgEgDQgDgEgCgDQgDgEAAgGQAAgGADgEQACgFAEgDQAEgEAFgCQAHgCAFAAQALABAHADQAIADAGAGIgHAIQgFgFgHgDQgGgCgHgBQgIAAgFAFQgGAEABAGQAAADACADQACADAEACIAJACIAJADIAJAEIAJADQADADACAEQADAFAAAGQAAAFgCAFQgBAEgEAEQgFAEgGACQgGACgJAAQgLAAgIgDg");
	this.shape_48.setTransform(-84.3,69.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t12, new cjs.Rectangle(-90.2,61.3,327.6,17.5), null);


(lib.t11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAdArIAAg9IgZA9IgHAAIgYg9IAAA9IgTAAIAAhVIAaAAIAUA1IAVg1IAaAAIAABVg");
	this.shape.setTransform(186.95,129.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAYArIgFgOIgkAAIgGAOIgVAAIAhhVIAXAAIAhBVgAANAMIgNgkIgNAkIAaAAg");
	this.shape_1.setTransform(176.95,129.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_2.setTransform(168.525,129.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRAnQgLgFgGgKQgGgKgBgOQABgNAGgKQAGgKALgFQAKgGALAAQAJAAAIADQAGADAFAEIAIAKIgPAIQgDgFgFgDQgFgDgIAAQgGAAgGADQgHAEgDAGQgDAHgBAHQABAIADAHQADAGAHAEQAGADAGAAQAHAAAEgCQAFgCADgCIAAgLIgXAAIAAgPIApAAIAAAhQgGAHgKAEQgIAFgNAAQgLAAgKgGg");
	this.shape_3.setTransform(159.4,129.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgWAnQgLgGgFgKQgGgKAAgNQAAgMAGgKQAFgKALgGQAKgGAMAAQANAAAKAGQALAGAFAKQAGAKAAAMQAAANgGAKQgFAKgLAGQgKAGgNAAQgMAAgKgGgAgNgYQgGAEgDAGQgDAHAAAHQAAAIADAGQADAHAGAEQAGADAHAAQAIAAAGgDQAGgEADgHQADgGAAgIQAAgHgDgHQgDgGgGgEQgGgDgIAAQgHAAgGADg");
	this.shape_4.setTransform(149.825,129.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_5.setTransform(140.875,129.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgiArIAAhVIAnAAQAKAAAHADQAGAEADAHQAEAGAAAIQAAAHgEAGQgDAGgGADQgHAEgKAAIgUAAIAAAfgAgPgDIASAAQAGAAADgDQAEgDAAgFQAAgGgEgDQgDgDgGAAIgSAAg");
	this.shape_6.setTransform(132.75,129.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_7.setTransform(121.375,129.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgnArIAAhVIAiAAQANAAAKAFQAKAFAGAKQAGAKAAAMQAAANgGAKQgGAJgKAGQgKAFgNAAgAgVAbIAQAAQAIAAAGgEQAGgDADgHQADgGAAgHQAAgHgDgGQgDgGgGgEQgGgDgIAAIgQAAg");
	this.shape_8.setTransform(112.975,129.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAYArIgGgOIgkAAIgFAOIgVAAIAihVIAVAAIAiBVgAAOAMIgOgkIgMAkIAaAAg");
	this.shape_9.setTransform(103.65,129.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAOArIgQgfIgOAAIAAAfIgSAAIAAhVIAnAAQAJAAAHADQAHAEADAGQAEAGAAAIQAAAIgDAFQgDAFgEADQgFADgEABIATAhgAgQgDIATAAQAFAAAEgDQAEgDAAgGQAAgFgEgDQgEgDgFAAIgTAAg");
	this.shape_10.setTransform(95.225,129.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgIArIAAhFIgaAAIAAgQIBFAAIAAAQIgaAAIAABFg");
	this.shape_11.setTransform(87.075,129.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgNAYQgGgEgDgGQgFgGAAgIQAAgGAFgHQADgGAGgDQAHgFAGAAQAIAAAGAFQAHADADAGQAEAHgBAGQABAIgEAGQgDAGgHAEQgGAEgIgBQgGABgHgEgAgLgTQgFADgDAFQgDAGAAAFQAAAHADAFQADAFAFADQAFAEAGAAQAGAAAGgEQAFgDAEgFQADgFAAgHQAAgFgDgGQgEgFgFgDQgGgDgGAAQgGAAgFADgAAHAQIgHgMIgFAAIAAAMIgFAAIAAgfIANAAQAEAAACADQAEADAAAEIgCAFIgEACIgCACIAIAMgAgFAAIAIAAIAEgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAAAAAIgEgCIgIAAg");
	this.shape_12.setTransform(76.75,127.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_13.setTransform(69.875,129.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgSAnQgKgFgGgKQgGgKAAgOQAAgNAGgKQAGgKAKgFQALgGALAAQAKAAAHADQAGADAFAEIAJAKIgQAIQgDgFgFgDQgGgDgHAAQgHAAgGADQgGAEgDAGQgDAHAAAHQAAAIADAHQADAGAGAEQAGADAHAAQAGAAAFgCQAFgCADgCIAAgLIgXAAIAAgPIApAAIAAAhQgGAHgKAEQgIAFgNAAQgLAAgLgGg");
	this.shape_14.setTransform(61.2,129.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAYArIgFgOIgkAAIgGAOIgVAAIAihVIAVAAIAiBVgAANAMIgNgkIgNAkIAaAAg");
	this.shape_15.setTransform(52.15,129.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAQArIgQg6IgOA6IgUAAIgZhVIAWAAIAOA9IARg9IAOAAIAQA9IAPg9IAUAAIgYBVg");
	this.shape_16.setTransform(41.7,129.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgeArIAAhVIA9AAIAAAQIgqAAIAAASIApAAIAAAPIgpAAIAAAUIAqAAIAAAQg");
	this.shape_17.setTransform(32.075,129.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAVArIgog3IAAA3IgTAAIAAhVIATAAIAnA1IAAg1IATAAIAABVg");
	this.shape_18.setTransform(23.375,129.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t11, new cjs.Rectangle(16.6,121.8,178,17.000000000000014), null);


(lib.pc11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmAuIAAhbIAwAAQAJgBAGAEQAGAEADAEQADAGAAAGQAAAGgCAFQgCAEgEADIgIAEQAFAAAEACQAEAEACAEQADAFAAAGQAAAIgDAFQgDAGgGADQgGADgJAAgAgSAdIAZAAQAFAAAEgCQADgEAAgEQAAgFgDgDQgDgDgGAAIgZAAgAgSgIIAYAAQAFgBADgCQADgCAAgFQAAgEgDgDQgDgDgFAAIgYAAg");
	this.shape.setTransform(184.075,524.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AghAvIAAgPIAYgSIAOgOQAFgEADgEQACgEAAgFQAAgEgCgCQgCgDgDgCIgIgBQgHAAgGADQgGADgFAFIgLgNQAFgFAFgDQAGgEAGgCIANgBQAKAAAIAEQAIADAEAHQAFAGAAAJQAAAIgEAIQgEAHgJAHQgIAIgLAJIAlAAIAAARg");
	this.shape_1.setTransform(175,524.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgmAuIAAhbIAwAAQAJgBAGAEQAGAEADAEQADAGAAAGQAAAGgCAFQgCAEgEADIgIAEQAFAAAEACQAEAEACAEQADAFAAAGQAAAIgDAFQgDAGgGADQgGADgJAAgAgSAdIAZAAQAFAAAEgCQADgEAAgEQAAgFgDgDQgDgDgGAAIgZAAgAgSgIIAYAAQAFgBADgCQADgCAAgFQAAgEgDgDQgDgDgFAAIgYAAg");
	this.shape_2.setTransform(166.525,524.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgQAhQgHgDgFgFIAHgNIAGAFIAIADIAIABQAGAAADgCQADgBAAgEQgBgDgEgBIgJgDIgLgDQgGgCgEgDQgEgEAAgIQAAgGADgEQADgFAHgDQAGgDAHAAQAJAAAHACQAGADAFAEIgHANQgDgEgFgCQgFgCgHAAQgDAAgEACQgCACAAACQAAADAEACIAJACQAGABAGACQAFACAFAEQADAEAAAIQAAAGgDAFQgDAFgHADQgGACgKAAQgHAAgJgCg");
	this.shape_3.setTransform(286.8,393.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTAjIAAhDIASAAIAAAJQADgEAFgDQAGgDAGgBIAAASIgCgBIgCAAIgHABIgGADIgDAEIAAAsg");
	this.shape_4.setTransform(281.4,393.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSAeQgIgEgEgIQgEgIgBgKQABgJAEgHQAEgIAIgFQAIgFAKAAQALAAAIAFQAIAFAFAIQAEAHAAAJQAAAKgEAIQgFAIgIAEQgIAFgLAAQgKAAgIgFgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAFQACAEAEADQADADAFAAQAGAAADgDQAEgDACgEQACgFAAgFQAAgEgCgFQgCgEgEgDQgDgCgGAAQgFAAgDACg");
	this.shape_5.setTransform(274.55,393.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFAnQgFgEAAgKIAAgiIgMAAIAAgPIAMAAIAAgSIAQAAIAAASIAOAAIAAAPIgOAAIAAAeQABADABACQAAAAABABQAAAAABAAQAAABABAAQABAAABAAIADAAIADgCIADANIgFADIgJABQgJABgEgFg");
	this.shape_6.setTransform(268.2,392.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgNAfQgIgFgEgIQgFgHAAgLQAAgJAFgIQAEgIAIgFQAIgEAJAAQAIAAAEACQAGABADADQAEADACADIgLALQgDgEgEgCQgDgBgFAAQgGAAgFAFQgGAFAAAIQAAAJAGAFQAFAGAGAAQAFAAADgCQAEgCADgEIALALIgGAGIgJAFQgEABgIAAQgJAAgIgEg");
	this.shape_7.setTransform(262.45,393.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSAhQgFgDgDgEQgEgFAAgIQAAgIAEgFQADgDAFgCQAGgDAFAAQAHAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgGAAgFACQgFACgEAEIgHgNQAHgFAHgDQAIgCAHAAQAIAAAGACQAHADAEAFQAEAGAAAJIAAArIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAGQgDADAAAEQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgCIAAgJQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_8.setTransform(254.925,393.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgTAjIAAhDIASAAIAAAJQADgEAFgDQAGgDAHgBIAAASIgDgBIgDAAIgGABIgGADIgDAEIAAAsg");
	this.shape_9.setTransform(249.2,393.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAnQgFgEAAgKIAAgiIgMAAIAAgPIAMAAIAAgSIAQAAIAAASIAOAAIAAAPIgOAAIAAAeQAAADACACQAAAAABABQAAAAABAAQAAABABAAQABAAABAAIADAAIADgCIADANIgFADIgJABQgJABgEgFg");
	this.shape_10.setTransform(244,392.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAOAjIAAgoQgBgHgDgDQgDgDgGABQgEgBgEADQgEACgCADIAAAtIgRAAIAAhDIARAAIAAAJIAFgFIAIgEQAEgBAFgBQAMABAFAGQAGAFAAAKIAAAvg");
	this.shape_11.setTransform(237.65,393.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgSAeQgIgEgEgIQgFgIABgKQgBgJAFgHQAEgIAIgFQAIgFAKAAQALAAAIAFQAIAFAEAIQAEAHABAJQgBAKgEAIQgEAIgIAEQgIAFgLAAQgKAAgIgFgAgIgQQgEADgCAEQgCAFAAAEQAAAFACAFQACAEAEADQAEADAEAAQAGAAAEgDQADgDACgEQACgFAAgFQAAgEgCgFQgCgEgDgDQgEgCgGAAQgEAAgEACg");
	this.shape_12.setTransform(229.6,393.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgTAqQgLgGgHgLQgGgLAAgOQAAgOAGgKQAHgLALgGQALgGANAAQALAAAHAEQAHADAFAFQAGAFADAGIgRAIQgDgFgGgEQgFgEgIgBQgIABgGAEQgHADgDAIQgEAGAAAIQAAAJAEAHQADAGAHAFQAGAEAIgBQAIABAFgEQAGgEADgGIARAIIgJAMQgFAFgHADQgHADgLAAQgNAAgLgGg");
	this.shape_13.setTransform(220.95,392.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgGAnQgEgEAAgKIAAgiIgMAAIAAgPIAMAAIAAgSIAQAAIAAASIAOAAIAAAPIgOAAIAAAeQAAADACACQAAAAABABQAAAAABAAQAAABABAAQABAAAAAAIAFAAIACgCIADANIgFADIgJABQgJABgFgFg");
	this.shape_14.setTransform(122.15,392.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAOAjIAAgoQAAgHgEgDQgDgDgGABQgEgBgEADQgEACgCADIAAAtIgRAAIAAhDIARAAIAAAJIAFgFIAIgEQAEgBAFgBQALABAGAGQAGAFAAAKIAAAvg");
	this.shape_15.setTransform(115.8,393.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_16.setTransform(107.925,393.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAgAjIAAgqQAAgFgBgDQgDgCgGAAQgEgBgEADIgGAFIAAAtIgQAAIAAgqQAAgFgDgDQgCgCgFAAQgFgBgEADIgFAFIAAAtIgRAAIAAhDIARAAIAAAJIAEgEIAIgFQAFgCAFAAQAHABAEADQAEADACAGQACgEAEgCQAEgDAEgCQAFgCAFAAQAJAAAFAGQAFAEAAALIAAAwg");
	this.shape_17.setTransform(98.1,393.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AANAjIAAgoQAAgHgDgDQgDgDgGABQgEgBgEADQgEACgCADIAAAtIgSAAIAAhDIASAAIAAAJIAFgFIAIgEQAEgBAFgBQAMABAFAGQAGAFgBAKIAAAvg");
	this.shape_18.setTransform(88.15,393.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSAjIAAhDIARAAIAAAJQADgEAGgDQAFgDAGgBIAAASIgCgBIgCAAIgHABIgGADIgDAEIAAAsg");
	this.shape_19.setTransform(81.95,393.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_20.setTransform(75.275,393.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJAiIgbhDIATAAIARAuIASguIASAAIgaBDg");
	this.shape_21.setTransform(67.85,393.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgSAeQgIgEgEgIQgFgIABgKQgBgJAFgHQAEgIAIgFQAIgFAKAAQALAAAIAFQAIAFAFAIQADAHAAAJQAAAKgDAIQgFAIgIAEQgIAFgLAAQgKAAgIgFgAgJgQQgDADgCAEQgCAFAAAEQAAAFACAFQACAEADADQAFADAEAAQAFAAAFgDQADgDACgEQACgFAAgFQAAgEgCgFQgCgEgDgDQgFgCgFAAQgEAAgFACg");
	this.shape_22.setTransform(60.3,393.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgTAqQgLgGgHgLQgGgKAAgPQAAgNAGgLQAHgLALgGQALgGANAAQAKAAAHADQAHADAGAEIAIALIgQAJQgDgFgGgDQgGgEgHgBQgIABgGAEQgHADgDAIQgEAGAAAIQAAAJAEAHQADAGAHAFQAGAEAIgBQAGAAAFgBIAJgGIAAgKIgZAAIAAgRIAsAAIAAAiQgHAJgKAEQgJAFgNAAQgNAAgLgGg");
	this.shape_23.setTransform(51.225,392.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgQAhQgHgDgGgFIAIgNIAHAFIAHADIAIABQAGAAADgCQADgBAAgEQAAgDgFgBIgJgDIgLgDQgGgCgEgDQgEgEAAgIQAAgGADgEQADgFAHgDQAGgDAHAAQAJAAAGACQAHADAFAEIgGANQgEgEgFgCQgFgCgHAAQgDAAgEACQgCACAAACQAAADAEACIAJACQAGABAFACQAGACAEAEQAEAEABAIQgBAGgDAFQgDAFgHADQgGACgKAAQgHAAgJgCg");
	this.shape_24.setTransform(275.65,259.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgTAjIAAhDIASAAIAAAJQADgEAFgDQAGgDAGgBIAAASIgCAAIgCAAIgHABIgGACIgDAEIAAAsg");
	this.shape_25.setTransform(270.25,259.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_26.setTransform(263.575,259.575);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgTArQgGgEgEgIQgEgIAAgLQAAgLAEgHQADgIAHgEQAHgEAIAAQAFAAAGACQAFADAEAFIAAgiIASAAIAABcIgSAAIAAgJQgEAFgFADQgFACgGAAQgIAAgHgEgAgKgBQgFAEAAAJQAAAJAFAFQAEAGAHAAQAFAAAEgCIAGgGIAAgYQgCgCgEgCQgEgCgFAAQgHAAgEAFg");
	this.shape_27.setTransform(255.375,258.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_28.setTransform(249.775,258.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgIAwIAAhCIARAAIAABCgAgHgdQgCgDAAgEQAAgFACgDQADgDAEAAQAFAAADADQACADAAAFQAAAEgCADQgDADgFAAQgEAAgDgDg");
	this.shape_29.setTransform(246.2,258.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgaAdQgEgGAAgKIAAguIARAAIAAAnQAAAHADADQAEADAGAAQADAAAEgDQAFgCACgDIAAgsIASAAIAABCIgSAAIAAgJQgEAEgGADQgFADgIAAQgLAAgGgFg");
	this.shape_30.setTransform(240.45,259.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgmAvIAAhdIAwAAQAJAAAGAEQAGADADAGQADAFAAAGQAAAGgCAEQgCAFgEADIgIADQAFABAEADQAEADACAFQADAEAAAHQAAAGgDAGQgDAGgGADQgGAEgJAAgAgSAdIAZAAQAFAAAEgDQADgDAAgEQAAgFgDgDQgDgDgGAAIgZAAgAgSgJIAYAAQAFAAADgCQADgDAAgEQAAgEgDgDQgDgDgFAAIgYAAg");
	this.shape_31.setTransform(231.975,258.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgPAhQgIgDgFgFIAHgNIAGAFIAIADIAJABQAFAAADgCQADgBgBgEQAAgDgDgBIgJgDIgMgDQgGgCgEgDQgEgEAAgIQAAgGADgEQADgFAGgDQAHgDAIAAQAIAAAHACQAHADAFAEIgIANQgDgEgFgCQgGgCgFAAQgEAAgEACQgCACAAACQAAADAEACIAJACQAGABAGACQAFACAFAEQADAEAAAIQAAAGgCAFQgEAFgGADQgHACgJAAQgIAAgIgCg");
	this.shape_32.setTransform(132.15,259.575);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgSAjIAAhDIARAAIAAAJQACgEAHgDQAFgDAGgBIAAASIgCAAIgDAAIgFABIgHACIgDAEIAAAsg");
	this.shape_33.setTransform(126.75,259.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_34.setTransform(120.075,259.575);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_35.setTransform(114.475,258.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgHAwIAAhCIAQAAIAABCgAgGgdQgDgDAAgEQAAgFADgDQADgDADAAQAFAAADADQADADAAAFQAAAEgDADQgDADgFAAQgDAAgDgDg");
	this.shape_36.setTransform(110.9,258.175);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgSAhQgFgDgDgEQgEgFAAgIQAAgIAEgFQADgDAFgCQAGgDAFAAQAHAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgGAAgFACQgFACgEAEIgHgNQAHgFAHgDQAIgCAHAAQAIAAAGACQAHADAEAFQAEAGAAAJIAAArIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAGQgDADAAAEQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgCIAAgJQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_37.setTransform(105.175,259.575);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgFAnQgFgFAAgJIAAgiIgLAAIAAgPIALAAIAAgSIARAAIAAASIANAAIAAAPIgNAAIAAAeQAAADABACQAAABABAAQAAAAABAAQAAABABAAQABAAABAAIADAAIADgCIAEAOIgGACIgJABQgJABgEgFg");
	this.shape_38.setTransform(99.25,258.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_39.setTransform(93.075,259.575);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAPAvIgRgiIgPAAIAAAiIgUAAIAAhdIArAAQAKAAAHAFQAHAEADAGQAEAHAAAJQAAAHgDAGQgDAFgEADQgFAEgFABIAVAkgAgRgDIAUAAQAGAAAEgDQAEgEAAgFQAAgHgEgCQgEgEgGAAIgUAAg");
	this.shape_40.setTransform(84.925,258.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_41.setTransform(72.875,259.575);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AANAjIAAgoQAAgHgCgDQgEgDgFABQgFgBgEADQgEACgCADIAAAtIgSAAIAAhDIASAAIAAAJIAGgFIAHgEQAEgBAGgBQALABAFAGQAGAFgBAKIAAAvg");
	this.shape_42.setTransform(65,259.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgHAwIAAhCIAQAAIAABCgAgGgdQgDgDAAgEQAAgFADgDQADgDADAAQAFAAADADQADADAAAFQAAAEgDADQgDADgFAAQgDAAgDgDg");
	this.shape_43.setTransform(59.15,258.175);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_44.setTransform(55.675,258.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AANAjIAAgoQAAgHgDgDQgDgDgGABQgEgBgEADQgEACgCADIAAAtIgSAAIAAhDIASAAIAAAJIAFgFIAIgEQAEgBAFgBQAMABAFAGQAGAFgBAKIAAAvg");
	this.shape_45.setTransform(49.9,259.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgYAqQgLgGgGgLQgGgLAAgOQAAgNAGgKQAGgMALgFQALgHANAAQAOAAALAHQALAFAGAMQAGAKAAANQAAAOgGALQgGALgLAGQgLAGgOAAQgNAAgLgGgAgOgZQgGADgEAIQgDAGAAAIQAAAJADAGQAEAIAGADQAGAFAIAAQAJAAAGgFQAGgDAEgIQADgGAAgJQAAgIgDgGQgEgIgGgDQgGgEgJgBQgIABgGAEg");
	this.shape_46.setTransform(40.525,258.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgPAhQgIgDgGgFIAIgNIAGAFIAJADIAIABQAFAAADgCQADgBgBgEQAAgDgDgBIgJgDIgMgDQgGgCgEgDQgEgEAAgIQAAgGADgEQADgFAGgDQAHgDAIAAQAIAAAGACQAHADAGAEIgHANQgEgEgFgCQgGgCgFAAQgFAAgCACQgDACAAACQAAADAEACIAJACQAGABAFACQAGACAFAEQADAEAAAIQAAAGgCAFQgEAFgGADQgHACgJAAQgJAAgHgCg");
	this.shape_47.setTransform(281.45,123.875);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgTAjIAAhDIASAAIAAAJQADgEAGgDQAFgDAGgBIAAASIgCgBIgCAAIgHABIgGAEIgDADIAAAsg");
	this.shape_48.setTransform(276,123.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_49.setTransform(269.375,123.875);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAOAjIAAgoQgBgHgDgDQgDgCgGgBQgEABgEACQgEACgCADIAAAtIgRAAIAAhDIARAAIAAAJIAFgFIAIgEQAEgBAFgBQAMABAFAGQAGAFAAAKIAAAvg");
	this.shape_50.setTransform(261.5,123.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgBAwQgIAAgIgCQgHgDgGgFIAIgNQAEAFAFACQAGACAGAAIAIgCQAEgBADgEQACgEAAgHIAAgGQgDAFgGACQgFADgFAAQgJAAgHgEQgGgDgEgIQgEgHAAgLQAAgLAEgIQAEgHAGgEQAHgEAJAAQAEAAAGACQAGADADAFIAAgIIASAAIAAA9QAAAKgDAGQgDAGgGAEQgFADgHACIgJABIgCAAgAgKgaQgFAEAAAJQAAAJAFAEQAFAFAGAAQAFAAAEgDQAEgCACgCIAAgWQgCgDgEgCQgEgCgFAAQgGAAgFAFg");
	this.shape_51.setTransform(253.15,125.1563);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgHAwIAAhCIAQAAIAABCgAgGgdQgDgDgBgEQABgFADgDQADgDADAAQAEAAADADQAEADAAAFQAAAEgEADQgDADgEAAQgDAAgDgDg");
	this.shape_52.setTransform(247.5,122.475);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgQAhQgHgDgGgFIAIgNIAHAFIAHADIAIABQAGAAADgCQADgBAAgEQAAgDgFgBIgJgDIgLgDQgGgCgEgDQgEgEAAgIQAAgGADgEQADgFAHgDQAGgDAHAAQAJAAAGACQAIADAEAEIgGANQgEgEgFgCQgFgCgHAAQgDAAgEACQgCACAAACQAAADAEACIAJACQAGABAFACQAGACAEAEQAEAEABAIQgBAGgDAFQgDAFgHADQgGACgKAAQgHAAgJgCg");
	this.shape_53.setTransform(242.35,123.875);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_54.setTransform(235.275,123.875);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgqAvIAAhcIAlAAQAOAAAKAFQAMAGAFALQAHAKAAANQAAAOgHAKQgFALgMAFQgKAHgOAAgAgWAdIARAAQAIAAAGgEQAHgEADgHQAEgGAAgIQAAgHgEgHQgDgGgGgEQgHgEgIAAIgRAAg");
	this.shape_55.setTransform(226.6,122.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgPAhQgIgDgGgFIAIgNIAHAFIAIADIAIABQAFAAADgCQACgBABgEQAAgDgFgBIgJgDIgLgDQgGgCgEgDQgEgEAAgIQAAgGADgEQADgFAHgDQAFgDAJAAQAIAAAGACQAIADAFAEIgHANQgEgEgFgCQgFgCgGAAQgFAAgCACQgDACAAACQAAADAEACIAJACQAGABAFACQAHACADAEQAFAEAAAIQAAAGgEAFQgDAFgHADQgGACgJAAQgJAAgHgCg");
	this.shape_56.setTransform(153.45,123.875);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgTAjIAAhDIASAAIAAAJQADgEAFgDQAGgDAHgBIAAASIgDgBIgDAAIgGABIgGAEIgDADIAAAsg");
	this.shape_57.setTransform(148.05,123.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_58.setTransform(141.375,123.875);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_59.setTransform(135.725,122.6);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgIAwIAAhCIARAAIAABCgAgGgdQgDgDgBgEQABgFADgDQADgDADAAQAEAAADADQADADABAFQgBAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_60.setTransform(132.2,122.475);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgSAhQgFgDgDgEQgEgFAAgIQAAgIAEgFQADgDAFgCQAGgDAFAAQAHAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgGAAgFACQgFACgEAEIgHgNQAHgFAHgDQAIgCAHAAQAIAAAGACQAHADAEAFQAEAGAAAJIAAArIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAGQgDADAAAEQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgCIAAgJQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_61.setTransform(126.425,123.875);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgFAnQgFgFAAgJIAAgiIgLAAIAAgPIALAAIAAgSIAQAAIAAASIAOAAIAAAPIgOAAIAAAdQABADABADQAAAAABABQAAAAABAAQAAABABAAQABAAABAAIADAAIADgCIAEANIgGADIgJACQgJAAgEgFg");
	this.shape_62.setTransform(120.5,123.05);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_63.setTransform(114.325,123.875);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAPAvIgRgiIgPAAIAAAiIgUAAIAAhcIArAAQAKAAAHADQAHAEADAHQAEAHAAAJQAAAHgDAGQgDAFgEADQgFAEgFABIAVAkgAgRgDIAUAAQAGAAAEgDQAEgEAAgFQAAgHgEgCQgEgEgGAAIgUAAg");
	this.shape_64.setTransform(106.175,122.6);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_65.setTransform(96.175,122.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgQAfQgIgEgFgIQgEgIAAgLQAAgJAEgIQAFgIAHgEQAIgFAJAAQALAAAHAFQAIAEAEAJQAEAIAAAKIAAAEIgxAAQABAGAFAEQAFAFAIAAIAGgBIAGgCIAFgEIAIAMQgFAFgHACQgHACgIAAQgKAAgIgEgAARgFIgCgHQgCgDgDgCQgEgDgGAAQgEAAgEADIgFAFQgCADAAAEIAgAAIAAAAg");
	this.shape_66.setTransform(90.575,123.875);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AANAjIAAgoQAAgHgDgDQgDgCgGgBQgEABgEACQgEACgCADIAAAtIgSAAIAAhDIASAAIAAAJIAGgFIAHgEQAEgBAFgBQAMABAFAGQAGAFgBAKIAAAvg");
	this.shape_67.setTransform(82.75,123.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AANAjIAAgoQAAgHgCgDQgEgCgFgBQgFABgEACQgEACgCADIAAAtIgSAAIAAhDIASAAIAAAJIAGgFIAHgEQAEgBAGgBQAKABAGAGQAFAFAAAKIAAAvg");
	this.shape_68.setTransform(74.7,123.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgSAhQgFgDgDgEQgEgFAAgIQAAgIAEgFQADgDAFgCQAGgDAFAAQAHAAAEADQAGACADADIAAgIQAAgFgEgDQgEgDgFAAQgGAAgFACQgFACgEAEIgHgNQAHgFAHgDQAIgCAHAAQAIAAAGACQAHADAEAFQAEAGAAAJIAAArIgSAAIAAgHQgDAEgGACQgEACgHAAQgFAAgGgCgAgJAGQgDADAAAEQAAAFADADQAEACAFAAQAEAAADgBQAEgCACgCIAAgJQgCgDgEgBQgDgCgEAAQgFAAgEADg");
	this.shape_69.setTransform(66.625,123.875);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAOAvIAAgqQgBgFgDgDQgDgDgGAAQgEABgEACIgGAEIAAAuIgRAAIAAhcIARAAIAAAiIAFgFIAIgEQAEgBAFgBQAMAAAFAHQAGAFAAAKIAAAvg");
	this.shape_70.setTransform(59,122.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgNAfQgIgFgFgIQgEgHAAgLQAAgJAEgIQAFgIAIgFQAIgEAKAAQAGAAAFACQAGABADADQAEADACADIgMALQgCgEgDgCQgEgBgEAAQgIAAgFAFQgFAFAAAIQAAAJAFAFQAFAGAIAAQAEAAAEgCQADgCACgEIAMALIgGAGIgJAFQgFABgGAAQgKAAgIgEg");
	this.shape_71.setTransform(51.55,123.875);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgIAwIAAhCIARAAIAABCgAgGgdQgDgDgBgEQABgFADgDQADgDADAAQAEAAADADQADADABAFQgBAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_72.setTransform(46.25,122.475);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AANAjIAAgoQAAgHgCgDQgEgCgFgBQgFABgEACQgEACgCADIAAAtIgSAAIAAhDIASAAIAAAJIAGgFIAHgEQAEgBAGgBQAKABAGAGQAFAFAAAKIAAAvg");
	this.shape_73.setTransform(40.5,123.8);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AAhAjIAAgqQAAgEgCgEQgDgDgFAAQgFABgEACIgGAFIAAAtIgQAAIAAgqQAAgEgDgEQgCgDgFAAQgFABgEACIgFAFIAAAtIgRAAIAAhDIARAAIAAAJIAEgEIAIgFQAEgCAGAAQAIABADADQAEADACAGQACgDAEgDQAEgDAEgCQAFgCAFAAQAJAAAFAGQAFAEAAALIAAAwg");
	this.shape_74.setTransform(30.5,123.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgYAqQgLgGgGgLQgGgLAAgOQAAgNAGgKQAGgLALgHQALgFANgBQAOABALAFQALAHAGALQAGAKAAANQAAAOgGALQgGALgLAGQgLAGgOAAQgNAAgLgGgAgOgZQgGADgEAHQgDAIAAAHQAAAJADAGQAEAHAGAFQAGADAIAAQAJAAAGgDQAGgFAEgHQADgGAAgJQAAgHgDgIQgEgHgGgDQgGgEgJgBQgIABgGAEg");
	this.shape_75.setTransform(19.225,122.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_2
	this.instance = new lib.Растровоеизображение18();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pc11, new cjs.Rectangle(0,0,336,540), null);


(lib.pc4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},15).to({state:[]},1).wait(111));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},21).to({state:[]},1).wait(111));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},24).to({state:[]},1).wait(111));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},30).to({state:[]},1).wait(111));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},34).to({state:[]},1).wait(111));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},40).to({state:[]},1).wait(111));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},44).to({state:[]},1).wait(111));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},50).to({state:[]},1).wait(111));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},54).to({state:[]},1).wait(111));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},60).to({state:[]},1).wait(111));

	// Слой_2
	this.instance = new lib.Растровоеизображение14();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(68).to({_off:true},1).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.logowhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.NewAgelogo();
	this.instance.parent = this;
	this.instance.setTransform(-49,-13);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.949)").s().p("AoUGaQh4AAAAh4IAApDQAAh4B4AAIQpAAQB4AAAAB4IAAJDQAAB4h4AAg");
	this.shape.setTransform(0.325,-14.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logowhite, new cjs.Rectangle(-64.9,-55.9,130.5,82.1), null);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAjQgIgCgFgGIAGgIQADAEAHADQAGADAGAAQAJAAAFgEQAEgDAAgGQAAgEgDgCQgEgDgFgBIgJgDIgMgDQgFgCgDgEQgDgDAAgHIABgIQACgEAEgDQAEgDAFgBQAEgCAGAAQAJAAAHADQAGADAFAEIgFAIQgEgEgFgCQgGgDgHAAQgGAAgFADQgEAEAAAFQAAADADADIAJADIAKADIAKADQAFACAEAEQADAEAAAHQAAAFgCAEQgCAEgDADQgEADgFABQgGACgHAAQgIAAgHgDg");
	this.shape.setTransform(104.1,53.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAfQgFgFAAgMIAAgyIALAAIAAAvIABAHIADAGQADACADAAIAGABQAGAAAGgDQAFgEAEgEIAAg0IALAAIAABHIgLAAIAAgKQgEAFgHADQgHAEgHAAQgLAAgHgGg");
	this.shape_1.setTransform(96.6,54.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAyIAAgwQAAgDgCgDQgBgEgBgCQgDgCgDAAIgGgBIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhjIALAAIAAAmIAFgEIAGgFIAHgCIAHgBQALAAAGAFQAGAGAAAMIAAAyg");
	this.shape_2.setTransform(84.4,52.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_3.setTransform(78.075,53.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAxIAAhHIAJAAIAABHgAgEgjQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQADACgBAEQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_4.setTransform(74.15,52.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATAkIgTg5IgSA5IgLAAIgXhHIALAAIASA5IATg5IAJAAIATA5IARg5IAMAAIgXBHg");
	this.shape_5.setTransform(66.975,53.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEArQgEgFAAgIIAAgvIgMAAIAAgJIAMAAIAAgUIALAAIAAAUIAOAAIAAAJIgOAAIAAAsQAAAEABADQACADAEAAIAEgBIAEgCIADAIQgCACgEABQgDACgFAAQgHAAgEgEg");
	this.shape_6.setTransform(55.375,53.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgFgFgDgHQgCgHAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAKAAAGAEQAGADAEAGIgHAGQgEgFgEgCQgFgCgFAAQgGAAgEACQgEACgEAEQgDAEgCAFQgBAFAAAFQAAAGABAFQACAFADAEQAEAEAEACQAEACAGAAQALAAAHgJIAHAGQgEAGgGADQgGAEgKAAQgHAAgHgDg");
	this.shape_7.setTransform(49.525,53.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAjQgHgCgFgFQgFgGgCgGQgDgIAAgIQAAgHACgHQADgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAGADQAHADAEAFQAFAGACAHQACAHAAAHIAAADIg5AAQAAAFACAEQACAFADADQAEAEAEACQAFACAFAAQAGAAAGgDQAGgCAEgEIAFAHQgFAFgHADQgHADgJAAQgHAAgHgDgAgJgZQgEACgDADQgDAEgCAEIgBAIIAuAAIgBgIQgCgEgDgEQgDgDgEgCQgFgDgGAAQgEAAgFADg");
	this.shape_8.setTransform(41.475,53.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAlIAAguQABgKgFgDQgEgEgHAAIgGABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAFgEIAGgEIAHgDQACgBAFAAQAXAAAAAXIAAAyg");
	this.shape_9.setTransform(33.1,53.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASAlIAAguQAAgKgEgDQgEgEgIAAIgFABIgGACIgFAEIgEAEIAAA0IgLAAIAAhHIALAAIAAAKIAEgEIAHgEIAHgDQADgBAEAAQAXAAAAAXIAAAyg");
	this.shape_10.setTransform(24.8,53.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgFgFgCgHQgDgHAAgIQAAgHADgHQACgHAFgFQAFgFAGgDQAHgDAHAAQAIAAAHADQAHADAEAFQAFAFACAHQADAHAAAHQAAAIgDAHQgCAHgFAFQgEAFgHADQgHADgIAAQgHAAgHgDgAgJgZQgFADgDAEQgDADgBAFQgCAFAAAFIACALQABAFADAEQADADAFADQAEACAFAAQAGAAAEgCQAFgDADgDIAFgJIABgLQAAgFgBgFQgCgFgDgDQgDgEgFgDQgEgCgGAAQgFAAgEACg");
	this.shape_11.setTransform(16.325,53.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwQgJgEgHgHQgHgHgEgJQgEgKAAgLQAAgLAEgJQAEgKAHgHQAHgHAJgDQAKgEAKAAQAGAAAGACIAKAEQAFACADAEIAIAIIgLAGQgEgHgIgEQgHgEgIAAQgHAAgIADQgGADgGAGQgFAFgDAHQgDAIAAAIQAAAJADAHQADAIAFAFQAGAFAGADQAIADAHAAQAIAAAHgEQAIgEAEgGIALAGQgHAIgJAGQgJAGgNAAQgKAAgKgEg");
	this.shape_12.setTransform(7.15,52.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0072BC").s().p("ApcDDQgyAAAAgyIAAkhQAAgyAyAAIS5AAQAyAAAAAyIAAEhQAAAygyAAg");
	this.shape_13.setTransform(54.8391,53.2109,1.0218,0.8366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-12.1,36.9,133.9,32.699999999999996), null);


(lib.pc31копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},13).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},19).to({state:[]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},22).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},28).to({state:[]},1).wait(113));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},32).to({state:[]},1).wait(113));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},38).to({state:[]},1).wait(113));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},42).to({state:[]},1).wait(113));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},48).to({state:[]},1).wait(113));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},52).to({state:[]},1).wait(113));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},58).to({state:[]},1).wait(113));

	// Слой_1
	this.instance = new lib.Растровоеизображение151();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(66).to({_off:true},1).wait(113));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


(lib.pc21копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 - копия: 2 - копия
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape.setTransform(369.675,49.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApYK+IAA16ISxAAIAAV6g");
	this.shape_1.setTransform(369.6845,49.281,0.6926,0.6926);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_2.setTransform(369.675,49.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_3.setTransform(369.675,49.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_4.setTransform(369.675,49.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_5.setTransform(369.675,49.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_6.setTransform(369.675,49.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_7.setTransform(369.675,49.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_8.setTransform(369.675,49.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_9.setTransform(369.675,49.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_10.setTransform(369.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},44).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},7).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2 - копия
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_11.setTransform(369.675,146.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApYK9IAA16ISxAAIAAV6g");
	this.shape_12.setTransform(369.6845,146.2424,0.6926,0.6926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_13.setTransform(369.675,146.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_14.setTransform(369.675,146.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_15.setTransform(369.675,146.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_16.setTransform(369.675,146.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_17.setTransform(369.675,146.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_18.setTransform(369.675,146.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_19.setTransform(369.675,146.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_20.setTransform(369.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11}]}).to({state:[{t:this.shape_12}]},39).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},13).to({state:[]},1).wait(119));

	// Слой_3 - копия: 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_21.setTransform(286.05,49.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_22.setTransform(286.0553,49.281,0.6926,0.6926);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_23.setTransform(286.05,49.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_24.setTransform(286.05,49.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_25.setTransform(286.05,49.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_26.setTransform(286.05,49.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_27.setTransform(286.05,49.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_28.setTransform(286.05,49.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_29.setTransform(286.05,49.275);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_30.setTransform(286.05,49.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_31.setTransform(286.05,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_22}]},35).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},16).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_32.setTransform(286.05,146.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_33.setTransform(286.0553,146.2424,0.6926,0.6926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_34.setTransform(286.05,146.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_35.setTransform(286.05,146.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_36.setTransform(286.05,146.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_37.setTransform(286.05,146.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_38.setTransform(286.05,146.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_39.setTransform(286.05,146.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_40.setTransform(286.05,146.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_41.setTransform(286.05,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32}]}).to({state:[{t:this.shape_33}]},30).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},22).to({state:[]},1).wait(119));

	// Слой_3 - копия: 2
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_42.setTransform(204.875,144.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_43.setTransform(204.875,144.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_44.setTransform(204.875,144.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_45.setTransform(204.875,144.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_46.setTransform(204.875,144.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_47.setTransform(204.875,144.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_48.setTransform(204.875,144.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_49.setTransform(204.875,144.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_50.setTransform(204.875,144.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_51.setTransform(204.875,144.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},25).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},26).to({state:[]},1).wait(119));

	// Слой_2 - копия: 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_52.setTransform(204.875,48.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_53.setTransform(204.8848,48.3114,0.6926,0.6926);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_54.setTransform(204.875,48.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_55.setTransform(204.875,48.325);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_56.setTransform(204.875,48.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_57.setTransform(204.875,48.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_58.setTransform(204.875,48.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_59.setTransform(204.875,48.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_60.setTransform(204.875,48.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_61.setTransform(204.875,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52}]}).to({state:[{t:this.shape_53}]},20).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},32).to({state:[]},1).wait(119));

	// Слой_3 - копия
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_62.setTransform(122.675,49.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("ApXK+IAA16ISvAAIAAV6g");
	this.shape_63.setTransform(122.6754,49.281,0.6926,0.6926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_64.setTransform(122.675,49.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_65.setTransform(122.675,49.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_66.setTransform(122.675,49.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_67.setTransform(122.675,49.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_68.setTransform(122.675,49.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_69.setTransform(122.675,49.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_70.setTransform(122.675,49.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_71.setTransform(122.675,49.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_72.setTransform(122.675,49.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62}]}).to({state:[{t:this.shape_63}]},15).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},36).to({state:[]},1).wait(119));

	// Слой_2 - копия
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_73.setTransform(122.675,146.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("ApXK9IAA16ISvAAIAAV6g");
	this.shape_74.setTransform(122.6754,146.2424,0.6926,0.6926);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_75.setTransform(122.675,146.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_76.setTransform(122.675,146.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_77.setTransform(122.675,146.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_78.setTransform(122.675,146.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_79.setTransform(122.675,146.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_80.setTransform(122.675,146.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_81.setTransform(122.675,146.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_82.setTransform(122.675,146.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73}]}).to({state:[{t:this.shape_74}]},10).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},42).to({state:[]},1).wait(119));

	// Слой_10
	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_83.setTransform(41.5,145.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ApYK9IAA15ISxAAIAAV5g");
	this.shape_84.setTransform(41.5049,145.7576,0.6926,0.6926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.89)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_85.setTransform(41.5,145.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.776)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_86.setTransform(41.5,145.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.667)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_87.setTransform(41.5,145.75);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.557)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_88.setTransform(41.5,145.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.443)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_89.setTransform(41.5,145.75);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.333)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_90.setTransform(41.5,145.75);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.224)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_91.setTransform(41.5,145.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.11)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_92.setTransform(41.5,145.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_93.setTransform(41.5,145.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83}]}).to({state:[{t:this.shape_84}]},5).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},46).to({state:[]},1).wait(119));

	// Слой_11
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_94.setTransform(41.5,48.325);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.875)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_95.setTransform(41.5,48.325);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(255,255,255,0.749)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_96.setTransform(41.5,48.325);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.624)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_97.setTransform(41.5,48.325);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(255,255,255,0.502)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_98.setTransform(41.5,48.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(255,255,255,0.376)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_99.setTransform(41.5,48.325);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(255,255,255,0.251)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_100.setTransform(41.5,48.325);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(255,255,255,0.125)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_101.setTransform(41.5,48.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(255,255,255,0)").s().p("AmfHmIAAvLIM/AAIAAPLg");
	this.shape_102.setTransform(41.5,48.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94}]}).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_102}]},52).to({state:[]},1).wait(119));

	// Слой_1
	this.instance = new lib.screen211();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:true},1).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.2,411.40000000000003,195.1);


// stage content:
(lib._300x250_TradeProgram = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_704 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(704).call(this.frame_704).wait(98));

	// Слой_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.875)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_1.setTransform(150,125);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.749)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_2.setTransform(150,125);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.624)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_3.setTransform(150,125);
	this.shape_3._off = true;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.502)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_4.setTransform(150,125);
	this.shape_4._off = true;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_5.setTransform(150,125);
	this.shape_5._off = true;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_6.setTransform(150,125);
	this.shape_6._off = true;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.125)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_7.setTransform(150,125);
	this.shape_7._off = true;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0)").s().p("A30UZMAAAgoxMAvpAAAMAAAAoxg");
	this.shape_8.setTransform(150,125);
	this.shape_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(193).to({_off:false},0).wait(1).to({_off:true},1).wait(59).to({_off:false},0).wait(1).to({_off:true},1).wait(65).to({_off:false},0).wait(1).to({_off:true},1).wait(67).to({_off:false},0).wait(1).to({_off:true},1).wait(193).to({_off:false},0).wait(1).to({_off:true},1).wait(59).to({_off:false},0).wait(1).to({_off:true},1).wait(65).to({_off:false},0).wait(1).to({_off:true},1).wait(67).to({_off:false},0).to({_off:true},1).wait(18));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(191).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(65).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(191).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(65).to({_off:false},0).to({_off:true},1).wait(19));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(189).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(189).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},1).wait(63).to({_off:false},0).to({_off:true},1).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(187).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(187).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(6).to({_off:false},0).to({_off:true},1).wait(61).to({_off:false},0).to({_off:true},1).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).to({_off:true},1).wait(185).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(185).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(8).to({_off:false},0).to({_off:true},1).wait(59).to({_off:false},0).to({_off:true},1).wait(22));
	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(5).to({_off:false},0).to({_off:true},1).wait(183).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(183).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(10).to({_off:false},0).to({_off:true},1).wait(57).to({_off:false},0).to({_off:true},1).wait(23));
	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(6).to({_off:false},0).to({_off:true},1).wait(181).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(181).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(47).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(12).to({_off:false},0).to({_off:true},1).wait(55).to({_off:false},0).to({_off:true},1).wait(24));
	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(7).to({_off:false},0).to({_off:true},1).wait(179).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(179).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(45).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(14).to({_off:false},0).to({_off:true},1).wait(53).to({_off:false},0).to({_off:true},1).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(8).to({_off:false},0).to({_off:true},1).wait(177).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(43).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(177).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(43).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).to({_off:true},1).wait(16).to({_off:false},0).to({_off:true},1).wait(51).to({_off:false},0).to({_off:true},1).wait(26));

	// Слой_23
	this.instance = new lib.logowhite();
	this.instance.parent = this;
	this.instance.setTransform(150,16,0.7142,0.7142);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(392).to({_off:true},392).wait(18));

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-123,-26.3,-64.2,7.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_9.setTransform(149.85,223.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-115.3,-23.6,-56.5,10.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_10.setTransform(149.85,223.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-107.6,-20.9,-48.8,13.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_11.setTransform(149.85,223.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-99.8,-18.2,-41,15.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_12.setTransform(149.85,223.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-92.1,-15.5,-33.3,18.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_13.setTransform(149.85,223.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-84.4,-12.8,-25.6,21.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_14.setTransform(149.85,223.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-76.7,-10.1,-17.9,23.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_15.setTransform(149.85,223.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-68.9,-7.5,-10.1,26.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_16.setTransform(149.85,223.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-61.2,-4.8,-2.4,29.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_17.setTransform(149.85,223.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-53.5,-2.1,5.3,31.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_18.setTransform(149.85,223.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-45.8,0.6,13,34.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_19.setTransform(149.85,223.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-38,3.3,20.8,37.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_20.setTransform(149.85,223.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-30.3,6,28.5,40).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_21.setTransform(149.85,223.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-22.6,8.7,36.2,42.7).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_22.setTransform(149.85,223.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-14.8,11.4,44,45.4).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_23.setTransform(149.85,223.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],-7.1,14.1,51.7,48.1).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_24.setTransform(149.85,223.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],0.6,16.8,59.4,50.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_25.setTransform(149.85,223.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],8.3,19.5,67.1,53.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_26.setTransform(149.85,223.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],16.1,22.2,74.9,56.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_27.setTransform(149.85,223.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],23.8,24.9,82.6,58.8).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_28.setTransform(149.85,223.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],31.5,27.6,90.3,61.5).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_29.setTransform(149.85,223.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],39.2,30.3,98,64.2).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_30.setTransform(149.85,223.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],47,33,105.8,66.9).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_31.setTransform(149.85,223.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],54.7,35.7,113.5,69.6).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_32.setTransform(149.85,223.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.247)","rgba(255,255,255,0)"],[0,0.435,1],62.4,38.4,121.2,72.3).s().p("AolCBQgfAAAAggIAAjBQAAggAfAAIRKAAQAgAAAAAgIAADBQAAAgggAAg");
	this.shape_33.setTransform(149.85,223.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},69).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[{t:this.shape_9}]},367).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[]},1).to({state:[]},298).wait(18));

	// t12
	this.instance_1 = new lib.t12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.instance_2 = new lib.t122();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.05,150.85,0.8928,0.8928,0,0,0,73.7,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},195).to({state:[{t:this.instance_1}]},197).to({state:[{t:this.instance_2}]},195).to({state:[]},197).wait(18));

	// t11
	this.instance_3 = new lib.t11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,104.7,0.8928,0.8928,0,0,0,105.7,41.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(392).to({_off:true},392).wait(18));

	// btn
	this.instance_4 = new lib.btn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,190.55,0.8928,0.8928,0,0,0,54.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(392).to({_off:true},392).wait(18));

	// Слой_14
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("A3bI6IAAxzMAu3AAAIAARzg");
	this.shape_34.setTransform(150,223.575);

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(392).to({_off:true},392).wait(18));

	// Слой_3
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_35.setTransform(252.475,154.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_36.setTransform(249.375,154.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_37.setTransform(244.375,155.9208);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAMAdIgMgmIgMAmIgQAAIgSg6IAQAAIALAnIANgnIANAAIAMAnIALgnIARAAIgSA6g");
	this.shape_38.setTransform(236.55,155.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_39.setTransform(229.775,155.175);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_40.setTransform(224.225,155.9208);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_41.setTransform(219.525,154.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgTAnQgIgEgFgGIAJgOQAEAFAHADQAHADAHAAQAHAAAEgCQADgDAAgEQgBgDgCgBIgKgEIgJgDIgMgDQgFgDgDgEQgEgEAAgIQAAgHAEgGQADgFAIgEQAGgDAJAAQAKAAAIADQAIADAFAFIgJAOQgFgFgGgCQgGgCgGAAQgFAAgDACQgDACAAADQAAAEAEABIAIADIAKADQAGABAFADQAFADAEAEQAEAEgBAIQABAHgEAGQgDAGgIAEQgHADgLAAQgLAAgJgDg");
	this.shape_42.setTransform(214.3,154.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgXAoQgGgEgEgFQgDgEAAgIQAAgHACgEQADgEADgDIAJgFIgEgJIgBgIQAAgGADgEQADgEAFgEQAFgCAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAHgDAEIgHAHIgJAEIADAEIADAEIAHAIIAFgIIADgGIAMAEIgFAKIgGAKIAHAIIAIAIIgTAAIgDgCIgDgEQgFAEgGACQgEACgHAAQgHAAgGgCgAgSAKQgCADAAAEQAAAEACADIAEAEQADABAEABIAGgBIAEgEIgEgFIgEgFIgEgFIgEgGIgFAGgAgGgcQgDADAAAEIABAFIADAGIAHgFQAEgEAAgEQAAgDgCgCQgCgBgCgBQgEAAgCACg");
	this.shape_43.setTransform(203.725,154.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAHADIAGABQAFAAACgBQADgCAAgDQAAgCgEgCIgIgCIgKgDQgEgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAHAAAHACQAFADAFADIgHALQgCgDgEgCQgGgCgFAAQgDAAgCACQgBAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgHAAgGgDg");
	this.shape_44.setTransform(264.95,143.725);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_45.setTransform(258.75,143.725);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgHAdIgYg5IARAAIAOAnIAPgnIARAAIgYA5g");
	this.shape_46.setTransform(252.225,143.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_47.setTransform(247.525,142.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_48.setTransform(242.65,143.725);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAMAoIAAgkQAAgEgDgCQgDgDgFAAQgDAAgEACQgDACgCACIAAAnIgQAAIAAhQIAQAAIAAAeIAFgEIAGgDIAJgBQAJgBAFAFQAFAFAAAJIAAAog");
	this.shape_49.setTransform(235.725,142.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgTAmQgIgDgFgGIAJgNQAEAEAHAEQAGADAIAAQAHgBAEgCQADgDAAgDQAAgEgDgCIgJgDIgKgCIgMgFQgFgCgEgEQgDgEAAgIQAAgHAEgFQADgGAIgDQAGgEAJAAQAKAAAHADQAIADAHAGIgKAMQgFgEgGgDQgGgBgGgBQgFABgDABQgDADAAAEQAAACADACIAJAEIAKACQAGABAGAEQAEACAEADQADAGAAAHQAAAHgDAGQgDAGgIADQgHAEgLAAQgKAAgKgEg");
	this.shape_50.setTransform(228.5,142.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgIAMQADgCADgDQACgDABgDIgBAAIgBAAQgDAAgDgBQgCgDAAgDQAAgFADgDQADgCADAAQAEAAADADQADADAAAGQAAAGgDAGQgDAFgFAFg");
	this.shape_51.setTransform(220.275,146.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgNAcQgHgCgFgEIAHgMIAGAEIAGADIAHABQAFAAACgBQADgCAAgDQAAgCgEgCIgHgCIgKgDQgFgBgEgDQgEgEAAgGQAAgFADgFQADgEAFgCQAGgDAGAAQAIAAAGACQAFADAFADIgHALQgCgDgFgCQgEgCgGAAQgDAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACAEACIAIACIAKACQAFACAEADQADAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgGAAgHgDg");
	this.shape_52.setTransform(215.7,143.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAKAoIgPgWIgHAIIAAAOIgQAAIAAhQIAQAAIAAAwIAVgZIATAAIgXAaIAYAfg");
	this.shape_53.setTransform(209.975,142.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_54.setTransform(203.375,143.725);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_55.setTransform(196.775,143.7208);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AANAoIgPgdIgMAAIAAAdIgSAAIAAhQIAlAAQAIABAHADQAGADADAGQADAGAAAHQABAHgDAGQgDADgEAEQgEADgFABIATAegAgOgCIARAAQAFgBADgDQADgCAAgGQAAgEgDgEQgDgDgFAAIgRAAg");
	this.shape_56.setTransform(189.9,142.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgVApIgDgBIACgNIACABIADAAIAFgBIADgEIACgFIgYg7IARAAIAOApIAPgpIARAAIgcBEQgCAFgCAEQgDADgFABQgEABgFAAIgEAAg");
	this.shape_57.setTransform(100.075,158.15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCgBIgCAAIgGABIgFADIgDADIAAAmg");
	this.shape_58.setTransform(95.025,156.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_59.setTransform(90.475,156.225);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_60.setTransform(85.05,156.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgCgFgBQgDAAgEACQgDADgCADIAAAmIgQAAIAAg6IAQAAIAAAHIAFgEIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_61.setTransform(78.175,156.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_62.setTransform(73.075,155.725);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgFAnQgFgCgEgFIAAAIIgPAAIAAhQIAPAAIAAAdQAEgEAFgCQAEgCAFAAQAHAAAGADQAGAEAEAHQADAGAAAJQAAAKgDAHQgEAHgGAEQgGADgHAAQgFAAgEgCgAgHgEIgHAEIAAAVIAHAFQADABAEAAQAGAAAEgEQAEgFAAgIQAAgHgEgEQgEgFgGAAQgEAAgDACg");
	this.shape_63.setTransform(68.15,155.925);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_64.setTransform(60.925,156.9708);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgKgBgMQABgLAFgKQAGgJAKgGQAJgFAMAAQAJAAAGADQAHADAEAEQAFAEADAGIgPAHQgDgFgFgDQgFgDgGgBQgHABgGADQgFADgDAGQgEAGAAAHQAAAHAEAHQADAFAFAEQAGADAHAAQAGAAAFgDQAFgDADgFIAPAHIgIAKQgEAEgHADQgGADgJAAQgMAAgJgGg");
	this.shape_65.setTransform(53.725,155.85);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_66.setTransform(115.125,143.725);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_67.setTransform(108.2,144.775);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgEgHQgEgHAAgIQAAgIAEgHQAEgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQAEgDABgEQACgEAAgEQAAgEgCgEQgBgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_68.setTransform(101.2,144.775);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAOAoIgOg2IgNA2IgSAAIgYhQIAUAAIAOA6IAPg6IANAAIAPA6IAPg6IATAAIgXBQg");
	this.shape_69.setTransform(92.125,143.65);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgFgCgCQgCgDgFAAQgEABgDACIgFAEIAAAnIgPAAIAAgkQAAgFgCgCQgCgDgEAAQgFABgDACIgFAEIAAAnIgPAAIAAg6IAPAAIAAAIIAEgEIAHgEQAEgBAFAAQAGAAADACQAEADACAFIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAEAAAKIAAApg");
	this.shape_70.setTransform(78.175,144.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_71.setTransform(69.475,144.825);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_72.setTransform(64.425,143.525);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgFgCgCQgCgDgFAAQgEABgDACIgFAEIAAAnIgPAAIAAgkQAAgFgCgCQgCgDgEAAQgFABgDACIgFAEIAAAnIgPAAIAAg6IAPAAIAAAIIAEgEIAHgEQAEgBAFAAQAGAAADACQAEADACAFIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAEAAAKIAAApg");
	this.shape_73.setTransform(57.675,144.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_74.setTransform(49.15,144.775);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_75.setTransform(43.825,144.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AggAoIAAhQIAlAAQAJABAGADQAGADADAHQAEAFAAAHQAAAIgEAFQgDAGgGADQgGADgJABIgTAAIAAAcgAgOgDIARAAQAFAAADgCQAEgEAAgFQAAgEgEgEQgDgCgFAAIgRAAg");
	this.shape_76.setTransform(37.825,143.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35}]},323).to({state:[]},69).to({state:[{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35}]},323).to({state:[]},69).wait(18));

	// Слой_12
	this.instance_5 = new lib.pc4("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(208.55,125,0.8929,0.8929,0,0,0,233.6,140);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(323).to({_off:false},0).to({_off:true},69).wait(323).to({_off:false},0).to({_off:true},69).wait(18));

	// Слой_4
	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFACQAFABAFAAIAHgBQADgCADgDQACgDAAgGIAAgGQgDAFgFACQgEACgFAAQgHAAgGgDQgGgDgDgHQgEgFAAgLQAAgJAEgHQADgHAGgDQAGgDAHAAQAEAAAFACQAFACADAFIAAgIIAQAAIAAA2QAAAIgDAGQgDAGgFADQgEADgGAAIgKACQgHAAgHgCgAgJgXQgEAEAAAHQAAAJAEADQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgBQgEgDgEAAQgGAAgEAFg");
	this.shape_77.setTransform(245.925,157.05);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AAMAeIAAgiQAAgHgDgCQgDgDgFAAQgDAAgEADQgDACgCACIAAAnIgQAAIAAg6IAQAAIAAAIIAFgFIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_78.setTransform(239.075,155.85);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_79.setTransform(233.975,154.675);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCgBIgCAAIgGACIgFACIgDADIAAAmg");
	this.shape_80.setTransform(230.525,155.85);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgPAaQgHgEgFgHQgDgHAAgIQAAgIADgHQAFgHAHgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_81.setTransform(224.55,155.925);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_82.setTransform(217.55,155.925);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_83.setTransform(212.475,154.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgcAoIAAhQIA5AAIAAAQIgnAAIAAARIAmAAIAAAOIgmAAIAAAhg");
	this.shape_84.setTransform(207.675,154.8);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgFACgIAAQgIAAgHgEgAAPgFIgCgGIgEgEQgDgCgFAAQgEAAgEACQgCABgCADIgCAGIAcAAIAAAAg");
	this.shape_85.setTransform(275.25,143.725);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_86.setTransform(268.075,142.675);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_87.setTransform(261.225,143.7208);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_88.setTransform(256.175,143.65);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgRAkQgJgEgGgKQgFgJgBgNQABgMAFgKQAGgIAJgGQAKgFAMAAQAIAAAHADQAFACAGAEQAEAEADAFIgOAIQgDgEgFgEQgFgDgGAAQgHABgGADQgGADgDAGQgDAGAAAHQAAAIADAFQADAHAGADQAGADAHABQAFAAAEgCQAFgCADgDIAAgKIgWAAIAAgOIAnAAIAAAfQgGAGgJAFQgIAEgLAAQgMAAgKgGg");
	this.shape_89.setTransform(249.2,142.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgOAHIAAgNIAdAAIAAANg");
	this.shape_90.setTransform(243.075,143.7);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_91.setTransform(239.725,142.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_92.setTransform(234.675,143.7208);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_93.setTransform(230.025,142.475);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_94.setTransform(225.525,143.725);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGAAIgFADIgDADIAAAmg");
	this.shape_95.setTransform(220.475,143.65);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAFgBIAGgCIAFgDIAGALQgEAEgHACQgFACgHAAQgIAAgIgEgAAPgFIgCgGIgFgEQgDgCgEAAQgFAAgCACQgEABgBADIgCAGIAcAAIAAAAg");
	this.shape_96.setTransform(214.65,143.725);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgEgCgDQgCgDgFABQgEAAgDABIgFAGIAAAmIgPAAIAAgkQAAgEgCgDQgCgDgEABQgFAAgDABIgFAGIAAAmIgPAAIAAg6IAPAAIAAAHIAEgDIAHgEQAEgBAFAAQAGAAADADQAEADACAEIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAFAAAIIAAAqg");
	this.shape_97.setTransform(206.025,143.65);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AAdAeIAAgkQAAgEgCgDQgCgDgFABQgEAAgDABIgFAGIAAAmIgPAAIAAgkQAAgEgCgDQgCgDgEABQgFAAgDABIgFAGIAAAmIgPAAIAAg6IAPAAIAAAHIAEgDIAHgEQAEgBAFAAQAGAAADADQAEADACAEIAFgEIAHgFQAEgBAEAAQAIAAAFAEQAEAFAAAIIAAAqg");
	this.shape_98.setTransform(195.625,143.65);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_99.setTransform(186.95,143.725);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgKgBgMQABgLAFgKQAGgKAKgEQAJgGAMAAQAJAAAGADQAHADAEAEQAFAFADAFIgPAHQgDgFgFgDQgFgDgGgBQgHABgGADQgFADgDAGQgEAGAAAHQAAAIAEAFQADAHAFADQAGADAHABQAGgBAFgDQAFgDADgFIAPAHIgIAJQgEAFgHADQgGADgJAAQgMAAgJgGg");
	this.shape_100.setTransform(179.375,142.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAGAEAEAHQAEAIAAAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_101.setTransform(100.1,156.975);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgPAoQgGgCgFgFIAHgLQADAEAFABQAFACAFAAIAHgBQADgBADgDQACgEAAgGIAAgGQgDAFgFACQgEADgFgBQgHAAgGgDQgGgDgDgHQgEgFAAgKQAAgKAEgHQADgHAGgCQAGgEAHAAQAEAAAFACQAFACADAEIAAgHIAQAAIAAA2QAAAIgDAGQgDAFgFADQgEADgGACIgKABQgHAAgHgCgAgJgXQgEAEAAAIQAAAHAEAEQAEAEAGAAQAEAAAEgCQADgCACgCIAAgTQgCgDgDgCQgEgCgEAAQgGABgEAEg");
	this.shape_102.setTransform(92.975,158.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_103.setTransform(86.125,156.9708);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCgBIgCAAIgGABIgFADIgDADIAAAmg");
	this.shape_104.setTransform(81.075,156.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgEgHQgEgHAAgIQAAgIAEgHQAEgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQAEgDABgEQACgEAAgEQAAgEgCgEQgBgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_105.setTransform(75.1,156.975);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_106.setTransform(69.525,156.225);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgSAmQgJgDgGgGIAKgNQAEAEAHAEQAGACAIAAQAHABADgDQAEgDAAgEQgBgDgDgBIgJgEIgKgCIgLgFQgFgCgDgEQgEgFAAgHQAAgHAEgFQAEgGAGgDQAIgEAIAAQAJAAAJADQAHADAGAGIgJAMQgFgEgGgDQgHgCgEAAQgGAAgDACQgDADAAADQAAAEAEACIAIADIAKACQAGACAFADQAFACAEAEQAEAFAAAHQAAAHgEAGQgEAGgHADQgHAEgLAAQgKAAgJgEg");
	this.shape_107.setTransform(63.75,155.85);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgXAoQgGgEgEgEQgDgGAAgIQAAgFACgFQADgFADgDIAJgEIgEgJIgBgIQAAgGADgEQADgFAFgCQAFgDAHAAQAFAAAFACQAEACADAEQADADAAAGQAAAGgDAFIgHAGIgJAGIADADIADAFIAHAIIAFgIIADgHIAMAFIgFAKIgGAJIAHAIIAIAJIgTAAIgDgDIgDgDQgFADgGACQgEACgHAAQgHAAgGgCgAgSAKQgCADAAAEQAAAEACADIAEAEQADABAEAAIAGgBIAEgDIgEgFIgEgEIgEgGIgEgFIgFAFgAgGgcQgDADAAAEIABAFIADAGIAHgGQAEgDAAgEQAAgDgCgCQgCgCgCABQgEAAgCABg");
	this.shape_108.setTransform(53.175,155.85);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_109.setTransform(122.95,144.775);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_110.setTransform(117.625,144.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_111.setTransform(111.625,144.825);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_112.setTransform(106.075,144.025);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_113.setTransform(102.425,143.525);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AAMAeIAAgiQAAgHgDgCQgDgDgFAAQgDABgEACQgDACgCACIAAAnIgQAAIAAg6IAQAAIAAAIIAFgFIAGgDIAJgBQAJAAAFAFQAFAFAAAJIAAAog");
	this.shape_114.setTransform(97.375,144.7);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_115.setTransform(91.925,144.7);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_116.setTransform(85.925,144.825);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgcAoIAAhQIA5AAIAAAQIgnAAIAAARIAmAAIAAAOIgmAAIAAAhg");
	this.shape_117.setTransform(79.125,143.65);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgDQAFgCAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_118.setTransform(70.425,144.7);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAGgEAJAAQAKAAAGAEQAHAEAFAHQADAHAAAIQAAAIgDAHQgFAHgHAEQgGAFgKAAQgJAAgGgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_119.setTransform(64.45,144.775);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgQAaQgHgEgDgHQgEgHAAgIQAAgIAEgHQADgHAHgEQAIgEAIAAQAJAAAIAEQAHAEAEAHQADAHAAAIQAAAIgDAHQgEAHgHAEQgIAFgJAAQgIAAgIgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_120.setTransform(57.45,144.775);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_121.setTransform(50.175,143.725);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_122.setTransform(44.725,144.025);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_123.setTransform(39.125,144.825);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgVAlQgJgGgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgFQAJgGAMAAQANAAAJAGQAKAFAFAJQAFAJAAAMQAAAMgFAKQgFAJgKAGQgJAFgNAAQgMAAgJgFgAgMgWQgGAEgDAFQgCAHAAAGQAAAIACAFQADAGAGAEQAFAEAHAAQAHAAAGgEQAGgEADgGQACgFAAgIQAAgGgCgHQgDgFgGgEQgGgEgHABQgHgBgFAEg");
	this.shape_124.setTransform(30.95,143.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77}]},256).to({state:[]},67).to({state:[{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77}]},325).to({state:[]},67).to({state:[]},69).wait(18));

	// Слой_13
	this.instance_6 = new lib.pc31копия("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(208.55,125,0.8929,0.8929,0,0,0,233.6,140);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(256).to({_off:false},0).to({_off:true},67).wait(325).to({_off:false},0).to({_off:true},67).wait(87));

	// Слой_15
	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgOAcQgGgCgFgEIAHgMIAFAEIAHADIAHABQAFAAADgBQACgCAAgDQAAgCgDgCIgIgCIgKgDQgGgBgDgDQgDgEgBgGQAAgFADgFQADgEAFgCQAFgDAHAAQAIAAAFACQAHADAEADIgGALQgDgDgFgCQgFgCgFAAQgDAAgDACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAACADACIAIACIAKACQAGACADADQAEAEAAAHQAAAFgDAFQgDAEgGACQgFADgJAAQgHAAgHgDg");
	this.shape_125.setTransform(278.95,156.325);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAHgEAIAAQAJAAAHAEQAHAEADAHQAEAIAAAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAEgDIAIALQgFAEgGACQgHACgHAAQgHAAgIgEgAAPgFIgCgGIgEgEQgEgCgFAAQgEAAgDACQgDABgBADIgCAGIAcAAIAAAAg");
	this.shape_126.setTransform(272.75,156.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgLAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAHgEQAHgEAIAAQAGAAAEACIAIADIAFAGIgKAJQgCgDgDgCQgDgBgEAAQgHAAgEAEQgEAFAAAHQAAAIAEAEQAEAFAHAAQAEAAADgCQADgBACgDIAKAJIgFAFIgIAEQgEACgGAAQgIAAgHgEg");
	this.shape_127.setTransform(266.425,156.325);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEACQgDABgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_128.setTransform(259.775,156.25);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_129.setTransform(252.725,156.3208);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_130.setTransform(248.075,155.075);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_131.setTransform(244.975,155.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgdApIAAhQIAQAAIAAAHQADgEAFgCQAFgCAEAAQAHAAAGADQAGAEADAHQADAGABAKQgBAKgDAGQgDAHgGADQgGAEgHAAQgFAAgEgCQgEgCgEgFIAAAegAgIgZQgDACgCADIAAAUQACADADABQAEACAEAAQAFAAAEgEQAFgEAAgIQAAgHgFgFQgEgFgFAAQgEAAgEACg");
	this.shape_132.setTransform(240.1,157.375);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgdApIAAhQIAQAAIAAAHQADgEAFgCQAFgCAEAAQAHAAAGADQAGAEADAHQAEAGAAAKQAAAKgEAGQgDAHgGADQgGAEgHAAQgEAAgFgCQgEgCgEgFIAAAegAgIgZQgDACgCADIAAAUQABADAEABQAEACAEAAQAFAAAEgEQAFgEAAgIQAAgHgFgFQgEgFgFAAQgEAAgEACg");
	this.shape_133.setTransform(233,157.375);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AAWAoIgFgNIghAAIgGANIgTAAIAfhQIAVAAIAfBQgAANALIgNgiIgMAiIAZAAg");
	this.shape_134.setTransform(225.075,155.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_135.setTransform(215.875,156.25);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgPAaQgIgEgDgHQgEgHAAgIQAAgIAEgHQADgHAIgEQAHgEAIAAQAJAAAIAEQAGAEAFAHQADAHAAAIQAAAIgDAHQgFAHgGAEQgIAFgJAAQgIAAgHgFgAgHgOQgEACgCAEQgBAEAAAEQAAAEABAEQACAEAEADQADACAEAAQAFAAADgCQADgDACgEQACgEAAgEQAAgEgCgEQgCgEgDgCQgDgCgFAAQgEAAgDACg");
	this.shape_136.setTransform(209.9,156.325);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgQAaQgGgEgEgHQgEgHAAgIQAAgIAEgHQAEgHAGgEQAIgEAIAAQAJAAAIAEQAGAEAEAHQAEAHAAAIQAAAIgEAHQgEAHgGAEQgIAFgJAAQgIAAgIgFgAgHgOQgDACgDAEQgBAEAAAEQAAAEABAEQADAEADADQADACAEAAQAFAAADgCQAEgDABgEQACgEAAgEQAAgEgCgEQgBgEgEgCQgDgCgFAAQgEAAgDACg");
	this.shape_137.setTransform(202.9,156.325);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgQAmQgGgEgDgHQgEgHAAgKQAAgJAEgGQADgHAGgEQAGgDAHAAQAEAAAFACQAFACADAEIAAgdIAQAAIAABQIgQAAIAAgIQgDAFgFACQgEACgFAAQgHAAgGgDgAgJgBQgEAEAAAHQAAAIAEAFQAEAEAGAAQAEAAAEgBQADgCACgDIAAgVQgCgCgDgCQgEgCgEAAQgGAAgEAFg");
	this.shape_138.setTransform(195.625,155.275);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_139.setTransform(190.175,155.575);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgWAZQgFgFAAgIIAAgpIAQAAIAAAjQAAAGADACQADADAFgBQADAAAEgCIAFgEIAAgnIAQAAIAAA6IgQAAIAAgIQgDAEgFACQgEADgIAAQgJAAgFgFg");
	this.shape_140.setTransform(184.625,156.375);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgVAkQgKgFgFgKQgFgIAAgNQAAgLAFgKQAFgJAKgFQAJgGAMAAQANAAAJAGQAKAFAFAJQAGAKgBALQABANgGAIQgFAKgKAFQgJAGgNAAQgMAAgJgGgAgMgWQgGADgDAGQgCAHAAAGQAAAIACAFQADAHAGADQAFADAHABQAIgBAFgDQAGgDADgHQACgFAAgIQAAgGgCgHQgDgGgGgDQgFgDgIAAQgHAAgFADg");
	this.shape_141.setTransform(176.4,155.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgVApIgDAAIACgPIACACIADAAIAFgCIADgDIACgFIgYg6IARAAIAOAoIAPgoIARAAIgcBDQgCAFgCADQgDAEgFABQgEACgFgBIgEAAg");
	this.shape_142.setTransform(115.625,157.5);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgQAeIAAg6IAPAAIAAAIQADgEAFgCQAFgDAFAAIAAAPIgCAAIgCAAIgGABIgFACIgDADIAAAmg");
	this.shape_143.setTransform(110.575,156.25);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_144.setTransform(106.075,155.575);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQAEgHAGgEQAIgEAIAAQAIAAAHAEQAHAEADAHQADAIABAIIAAAEIgrAAQABAFAEAEQAFAEAGAAIAGgBIAFgCIAFgDIAHALQgFAEgHACQgFACgIAAQgIAAgHgEgAAPgFIgCgGIgEgEQgDgCgFAAQgEAAgDACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_145.setTransform(100.65,156.325);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AAMAeIAAgjQAAgFgDgDQgDgDgFABQgDAAgEACQgDABgCAEIAAAmIgQAAIAAg6IAQAAIAAAHIAFgDIAGgEIAJgBQAJAAAFAFQAFAFAAAIIAAApg");
	this.shape_146.setTransform(93.725,156.25);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgHAqIAAg6IAPAAIAAA6gAgFgZQgDgDAAgEQAAgEADgCQACgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEABQgDgBgCgCg");
	this.shape_147.setTransform(88.625,155.075);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgFAnQgFgCgEgFIAAAIIgPAAIAAhQIAPAAIAAAdQAEgEAFgCQAFgCAEAAQAIAAAFADQAGAEAEAHQACAGABAJQgBAKgCAHQgEAHgGAEQgFADgIAAQgEAAgFgCgAgIgEIgGAEIAAAVIAGAFQAEABAEAAQAGAAAEgEQAEgFAAgIQAAgHgEgEQgEgFgGAAQgEAAgEACg");
	this.shape_148.setTransform(83.75,155.275);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgPAdQgFgDgDgEQgDgEAAgHQAAgHADgEQADgDAFgCQAEgCAFAAQAGAAAEACQAFACADADIAAgHQAAgFgEgCQgDgDgFAAIgJACIgIAFIgGgLQAFgFAHgCQAGgCAHAAQAGAAAGACQAGACAEAFQADAFAAAIIAAAlIgPAAIAAgGQgDAEgFACQgEACgGAAQgFAAgEgCgAgHAFQgEACAAAEQAAAFAEACQADACAEAAQADAAADgBQAEgBACgDIAAgHQgCgDgEgBIgGgBQgEAAgDACg");
	this.shape_149.setTransform(76.475,156.3208);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgQAkQgKgEgGgKQgFgKgBgMQABgLAFgKQAGgKAKgEQAJgGAMAAQAJAAAGADQAHADAEAEQAFAFADAFIgPAHQgDgFgFgDQgFgDgGAAQgHAAgGADQgFADgDAGQgEAGAAAHQAAAIAEAFQADAHAFADQAGADAHABQAGgBAFgDQAFgDADgFIAPAHIgIAJQgEAFgHADQgGADgJAAQgMAAgJgGg");
	this.shape_150.setTransform(69.275,155.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgHAoIAAhQIAPAAIAABQg");
	this.shape_151.setTransform(60.325,155.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_152.setTransform(55.45,156.325);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgOAbQgHgEgEgHQgEgHAAgJQAAgIAEgHQADgHAIgEQAGgEAJAAQAIAAAHAEQAGAEAEAHQADAIABAIIAAAEIgrAAQABAFAEAEQAEAEAHAAIAGgBIAFgCIAFgDIAGALQgEAEgHACQgGACgGAAQgJAAgHgEgAAPgFIgCgGIgEgEQgEgCgEAAQgFAAgCACQgDABgCADIgCAGIAcAAIAAAAg");
	this.shape_153.setTransform(48.7,156.325);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgFAiQgEgEAAgIIAAgeIgKAAIAAgNIAKAAIAAgQIAPAAIAAAQIALAAIAAANIgLAAIAAAaIABAFQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIADAAIACgBIAEALIgFADIgIABQgIAAgEgEg");
	this.shape_154.setTransform(43.275,155.575);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgTAmQgIgDgGgGIAKgNQAEAEAHAEQAHADAHAAQAHgBAEgCQADgDAAgDQgBgEgCgCIgJgDIgLgCIgLgFQgFgCgEgEQgDgEAAgIQAAgHAEgFQAEgGAGgDQAIgEAIAAQAKAAAHADQAIADAHAGIgKAMQgFgEgGgDQgHgCgFABQgFgBgDACQgDADAAAEQAAACADACIAJAEIAKACQAGABAGAEQAFACADADQADAGABAHQgBAHgDAGQgEAGgHADQgHAEgLAAQgKAAgKgEg");
	this.shape_155.setTransform(37.5,155.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125}]},195).to({state:[]},61).to({state:[{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125}]},331).to({state:[]},61).to({state:[]},136).wait(18));

	// Слой_16
	this.instance_7 = new lib.pc21копия("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(208.7,125.7,0.8958,0.8958,0,0,0,233.4,140.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(195).to({_off:false},0).to({_off:true},61).wait(331).to({_off:false},0).to({_off:true},61).wait(154));

	// pc11
	this.instance_8 = new lib.pc11();
	this.instance_8.parent = this;
	this.instance_8.setTransform(150,125,0.8928,0.8928,0,0,0,168,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({y:-189.75},178).to({_off:true},17).wait(197).to({_off:false,y:125},0).to({y:-189.75},178).to({_off:true},17).wait(215));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-189.7,368.1,671.9);
// library properties:
lib.properties = {
	id: '2D2EAD1C98E8D94DBC02B1E32F878629',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_Trade Program_atlas_P_.png", id:"300x250_Trade Program_atlas_P_"},
		{src:"images/300x250_Trade Program_atlas_NP_.jpg", id:"300x250_Trade Program_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2D2EAD1C98E8D94DBC02B1E32F878629'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;